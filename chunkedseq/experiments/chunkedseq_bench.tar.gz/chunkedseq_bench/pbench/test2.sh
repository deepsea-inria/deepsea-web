echo bla 2
echo exectime 20
