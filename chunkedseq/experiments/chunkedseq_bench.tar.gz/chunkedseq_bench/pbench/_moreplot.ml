

type graph_data = 
  | Scatter of scatter
  | BarPlot of barplot





(** * Table description *)

type cols = string list
type rows = cols list

type table = {
   (* table_tag : string;  *)
   table_title : string;
   table_data : rows;
   }

type chart = 
   | Chart_graph of graph
   | Chart_table of table


(***************************************************************)
(** * Graph selection *)

let select_graphs_by_tag graphs tags =
   let hash = Hashtbl.create 100 in
   list_foreach graphs (fun graph -> 
      let tag = graph.graph_tag in
      if Hashtbl.mem hash tag 
         then Pbench.warning (sprintf "duplicated tag: \n%s\n" tag);
      Hashtbl.add hash tag graph);
   build_list (fun add -> 
      list_foreach tags (fun tag ->
         try add (Hashtbl.find hash tag)
         with Not_found -> Pbench.warning (sprintf "cannot find graph for tag: \n%s\n" tag)))






let rscript_of_scatter_graph_enriched graphtitle scatter =
   let legends,batches = List.split scatter.scatter_curves in
   let (_curve_a,_curve_b,_curve_c,_curve_d) = 
     match batches with a::b::c::d::[] -> (a,b,c,d) | _ -> failwith "not right nb of curves for enriched" in
   let curves = 
      [ 
        sprintf "points(%s,col='red',pch=15,type='l')" (batchname 3);
        sprintf "points(%s,col='red',pch=15,type='l',lty=5)" (batchname 2);
        sprintf "points(%s,col='red',pch=4,type='p')" (batchname 2);
        sprintf "points(%s,col='blue',pch=15,type='l',lty=2)" (batchname 1);
        sprintf "points(%s,col='blue',pch=15,type='l')" (batchname 0);
        sprintf "points(%s,col='blue',pch=15,type='p')" (batchname 0) ]
      in
  let core = rscript_of_scatter_graph_all_but_curves batches graphtitle scatter in
  core @ curves






   
(** Construction of a latex table *)

let generate_table table =
   let rows = table.table_data in 
   if rows = [] then raise EmptyGraph;
   let output = ref [] in
   let put s = add_to_list_ref output s in
   put "\\begin{verbatim}";
   put table.table_title;
   put "\\end{verbatim}";
   let nbcols = List.fold_left (fun acc row -> max acc (List.length row)) 0 rows in
   let col_descr = list_init (nbcols) (fun i -> if i = 0 then "l|" else "c|") in
   put (sprintf "\\begin{tabular}{|%s}" (String.concat "" col_descr));
   list_iter rows (fun cols ->
      if cols = [] then put "\\hline" else begin
         list_foreachi cols (fun i item ->
            put item;
            if i < nbcols-1 then put "&";
         );
         put "\\\\";
      end
   );
   put "\\end{tabular}";
   String.concat "\n" (List.rev !output) 
   
let generate_table_into_file filename table =
   file_put_contents filename (generate_table table)


type mathcurve = 
   | Mathcurve_abline of float * float
   (* other forms:  e.g. ("x", "sin(x)") *)
type mathcurves = mathcurve list
   scatter_mathcurves : mathcurves;



   let draw_mathcurve m =
      match m with
      | Mathcurve_abline (intersect,slope) ->
         sprintf "abline(%f,%f,col='gray')" intersect slope 
      in 
   let mathcurves =      
      List.map draw_mathcurve scatter.scatter_mathcurves in 
   @ mathcurves


         | Chart_table table ->
            begin try    
               let filename = sprintf "generated/table-%d.tex" num_chart in
               generate_table_into_file filename table;
               add_include (sprintf "\\mytable{%s}\n" filename);
            with EmptyGraph -> 
              msg (sprintf "Warning: no data for table\n")
            end


let string_of_barplot_series ((label, heights) : barplot_series) =
  sprintf "\t series=%s\t%s" label (String.concat ", " (List.map string_of_float heights))

let string_of_barplot_data ((group_titles, seriess) : string list * barplot_series list) =
  sprintf "groups=%s\ndata=%s\n" 
    (String.concat "," group_titles) 
    (String.concat "\n" (List.map string_of_barplot_series seriess))

let string_of_barplot (b : barplot) =
  sprintf "label=%s\n%s\n%s\n" 
    (b.barplot_xaxis_label)
    (b.barplot_yaxis_label)
    (string_of_barplot_data b.barplot_data)


