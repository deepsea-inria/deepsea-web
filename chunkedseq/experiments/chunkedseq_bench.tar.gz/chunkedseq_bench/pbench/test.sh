echo bla 1
echo exectime 30
