let param_type f k v = param k (Pint v)
let params_type f k vs = params k (List.map (fun x -> Pint x) vs)
let param_eval_type f k mk = params_eval k (fun e -> Pint (mk e))

let param_int k v = param k (Pint v)
let params_int k vs = params k (List.map (fun x -> Pint x) vs)
let param_eval_int k mk = params_eval k (fun e -> Pint (mk e))




(** Parse options from command line *)

let benchopt_from_cmdline () =
   let opt = { 
      benchopt_silent = false;
      benchopt_verbose = false;
      benchopt_virtual = false;
      benchopt_dummy = false;
      benchopt_output = "results.txt"; 
      benchopt_append = false; } in
   if XCmd.mem_flag "silent" then opt.benchopt_silent <- true;
   if XCmd.mem_flag "verbose" then opt.benchopt_verbose <- true;
   if XCmd.mem_flag "virtual" then opt.benchopt_virtual <- true;
   if XCmd.mem_flag "dummy" then opt.benchopt_dummy <- true;
   if XCmd.mem_flag "append" then opt.benchopt_append <- true;
   opt.benchopt_output <- XCmd.parse_or_default_string "output" opt.benchopt_output;
   opt


   
(*
          XBase.message "start";
         Syntax.show_expr e;
     
      Syntax.show_expr e;
       Syntax.show_value vres;
       XBase.message "ok";
*)
   let kvs = 
      let var_or_interp e = 
         match e with | Evar s -> Vstring s | _ -> interp env e in
      ~~ List.map evs (fun (k,e) -> 
         if k = "prog" then 
         if interp env e
      in





(****************************************************)
(****************************************************)
(****************************************************)


exception Param_not_found of string

let find_param key params =
   try List.assoc key params
   with Not_found -> raise (Param_not_found key)

let find_param_int key params =
   Dyn.get_int (find_param key params)

let find_param_float key params =
   Dyn.get_float (find_param key params)

let find_param_string key params =
   Dyn.get_string (find_param key params)

let find_param_as_float key params =
   Dyn.get_as_float (find_param key params)

let find_param_as_int key params =
   Dyn.get_as_int (find_param key params)


*)


(** Conversion function to convert a well-named parameter into a one letter parameter *)

let arg_of_param (key, dyn) =
   let value = Dyn.string_of_dyn dyn in
   if key = "" then value else sprintf "-%s %s" key value 

let bench_command bench =
   let exec = bench.bench_prog in
   String.concat " " (exec :: List.map arg_of_param bench.bench_params)

let string_of_key key =
   if key = "" then "" else Str.string_after key 1

let string_of_param (key,dyn) =
   sprintf "%s=%s" (string_of_key key) (Dyn.string_of_dyn dyn) 

let string_of_params params =
   String.concat ", " (List.map string_of_param params)


(** Decoding as a key, from a string or a param *)

let dk_as_key v = (* todo: factorize this pattern *)
   match v with
   | Vstring x -> x
   | Vconstr("param", _) -> let (Param (k,_)) = dk_param v in k

(** Decoding as a list of keys *)

let dk_as_keys v = (* todo: factorize this pattern *)
   match dk_value_or_list v with
   | ValueOrList_list l -> List.map dk_as_key l
   | ValueOrList_value v -> 
      match v with
      | Vconstr("params", _) -> let (Params  dk_params
      | _ -> [ dk_as_key v ]






(** Smart constructor for axes -- TODO: check ones used *)


let axis ?(islog=false) ?(lower=None) ?(upper=None) ?(iszero=false) label =
 { axis_label = label;
   axis_islog = islog;
   axis_lower = if iszero then Some 0. else lower;
   axis_upper = upper; }

let axis_zero ?(islog=false) label =
   axis ~islog:islog ~lower:(Some 0.) label

let axis_zero ?(islog=false) ?(upper=None) label =
   axis ~islog:islog ~lower:(Some 0.) ~upper:upper label



(** Sorting functions *)

let cmp_values x y =
  if x < y then -1 else 1

let cmp_points_x (x1,_) (y1,_) =
   if x1 < y1 then -1 else 1

let sort_points_x points =
   List.sort cmp_points_x points





(** Generic text production helpers *)

let listify strs = 
   String.concat "," strs 


let liststringify strs = 
  listify (List.map stringify strs) 


(** *)

let to_string_keys ps =
   XList.to_string ", " (fun x -> x) (keys ps)





(** Implementation of scatter_runplot and bar_runplot *)

let common_runplot plot_fct_name fname env arg =
   let kes = get_named_args fname env arg in
   let get_opt k = 
      try let e = List.assoc k kes in Some e
      with Not_found -> None
      in
   let eargs = 
      match get_opt "x" with
      | None -> error "scatter_runplot requires parameter x"
      | Some eargs0 -> 
         let eargs1 = 
            match get_opt "other_args" with
            | None -> eargs0
            | Some e -> build_apply (Evar("&")) [ eargs0; e ]
            in
         let eargs2 = 
            match get_opt "series" with
            | None -> eargs1
            | Some e -> build_apply (Evar("&")) [ e; eargs1 ]
            in
         let eargs3 =
            match get_opt "charts" with
            | None -> eargs2
            | Some e -> build_apply (Evar("&")) [ e; eargs2 ]
            in
         eargs3
      in
   let kes_for_result_file = 
      match get_opt "results" with Some e -> ["output", e] | None -> [] in
   let run_keys = [ "virtual"; "timeout"; "dummy"; "runs"; "attempts"; "append" ] in
   let elim_keys = "result_file" :: run_keys in
   let kes_plot = List.filter (fun (k,e) -> not (List.mem k elim_keys)) kes in
   let kes_run = 
      kes_for_result_file @
      (List.filter (fun (k,e) -> List.mem k run_keys) kes) @
      [ "args", eargs ]
      in
   let is_virtual = 
      match get_opt "virtual" with | None -> false 
      | Some e -> dk_as_bool (interp env e)      
      in
   ignore (interp env (Eapply (Evar("run"), mk_named_args kes_run)));
   if not is_virtual 
      then ignore (interp env (Eapply (Evar(plot_fct_name), mk_named_args kes_plot)));
   mk_unit
 
let scatter_runplot = common_runplot "scatter_plot"
let bar_runplot = common_runplot "bar_plot"


(***************************************************************)
(** * Conversion *)

(** Conversion functions *)

exception Cast_error of string

let as_int s = 
   try int_of_string s
   with _ -> raise (Cast_error "int")

let as_float s =
   try float_of_string s
   with _ -> raise (Cast_error "float")

let as_string s = 
   s





(*

(*-------------------*)



let scatter_plot fname env arg =
   let kes = get_named_args fname env arg in
   let get ?(env=env) dk_value k def = 
      try let e = List.assoc k kes in
          dk_value (interp env e)     
      with Not_found -> def
      in
   let getmendatory ?(env=env) dk_value k =  (* todo factorize *)
      try let e = List.assoc k kes in
          dk_value (interp env e)     
      with Not_found -> error_expr ("missing mendatory argument: " ^ k) arg
      in 
   let bsilent = get dk_as_bool "silent" false in
   let bdrawlines = get dk_as_bool "drawlines" true in
   let bxylog = get dk_as_bool "xylog" false in
   let bxlog = get dk_as_bool "xlog" bxylog in
   let bylog = get dk_as_bool "ylog" bxylog in
   let bxyzero = get dk_as_bool "xyzero" false in
   let bxzero = get dk_as_bool "xzero" bxyzero in
   let byzero = get dk_as_bool "yzero" bxyzero in
   let _bappend = get dk_as_bool "append" false in 
   let slegend = get dk_string "legend" "topleft" in
   let fsize = get dk_as_float "size" 6. in
   let ofymax = get (fun v -> Some (dk_as_float v)) "ymax" None in
   let fwidth = get dk_as_float "width" fsize in
   let fheight = get dk_as_float "height" fsize in
   let dimensions = (fwidth, fheight) in
   let results_all = getmendatory Run_fcts.dk_as_results "results" in 
   let soutput = get dk_string "output" "plots.pdf" in
   let ls_allowed_diverse = get (dk_list_of dk_string) "allowed_diverse" [] in
   let lparams_charts = get dk_as_lparams "charts" lparams_unit in 
   let ey =   (* todo factorize *)
      try List.assoc "y" kes 
      with Not_found -> error_expr ("missing mendatory argument: " ^ "y") arg
      in
   let osylabel = get (fun v -> Some (dk_as_string v)) "ylabel" None in
   let sy = 
      match osylabel with 
      | Some s -> s
      | _ -> match ey with 
             | Evar s -> s 
             | _ -> "y-value"
      in
   let build_point env key_x results_series value_x =
      let params_x = Params [ Param (key_x, value_x) ] in
      let env = env_append_params env params_x in
      let results_points = results_filter_by_params params_x results_series in
      if results_points = [] then [] else begin
         let output_list_of_key_values = analyse_repeated_results ls_allowed_diverse results_points in
         let env_outputs = Env.from_assoc (~~ XList.concat_map output_list_of_key_values (fun (k,vs) ->
            try let xs = List.map dk_as_float_or_cast_error vs in
                [k, mk_float (XFloat.mean_of xs)]
            with Semantics.CastError -> [])) in
         let env_results = Env.from_assoc [
            "_results", mk_results results_points; 
            "_all_results", mk_results results_all; ] in
         let env = Env.concat [ env; env_outputs; env_results ] in
          (* Printf.printf "===>%s<===\n" (Env.to_string_keys env_outputs); *)
            let y_value = interp env ey in 
            [(dk_as_float value_x, dk_as_float y_value)]
      end
      in
   let build_series env key_x values_x results_charts params_series =
      let title_series = string_of_params params_series in
      let results_series = results_filter_by_params params_series results_charts in
      let env = env_append_params env params_series in
      let points = XList.concat_map (build_point env key_x results_series) values_x in
      { Scatter.serie_title = title_series; 
        Scatter.serie_points = points }
      in
   let build_scatter params_charts = 
      let title_chart = string_of_params params_charts in
      let results_charts = results_filter_by_params params_charts results_all in
(*Printf.printf "===>\n"; show_value (mk_results results_charts);*)
      let env = env_append_params env params_charts in
      let lparams_series = get ~env:env dk_as_lparams "series" lparams_unit in 
      let lparams_x = getmendatory ~env:env dk_as_lparams "x" in 
      let (key_x, values_x) =
        if lparams_x = [] then error ("empty params for field x, in plot");
        let (keys,values) = List.split (~~ List.map lparams_x (function
           | Params [Param(k,v)] -> (k, v)
           | _ -> error ("params with several keys for field x, in plot"))) in
        let key = List.hd keys in
        ~~ List.iter keys (fun k -> if k <> key then error ("inconsistent params for field x, in plot"));
        (key, values) 
        in
      let xaxis = { Axis.default with 
         Axis.get_label = key_x; 
         Axis.islog = bxlog;
         Axis.get_lower = if bxzero then Some 0. else None;
         } in
      let yaxis = { (* Axis.default with *)
         Axis.get_label = sy; 
         Axis.islog = bylog; 
         Axis.get_lower = if byzero then Some 0. else None;
         Axis.get_upper = ofymax } in
      let series = List.map (build_series env key_x values_x results_charts) lparams_series in
      {  Scatter.title = title_chart;
         Scatter.xaxis = xaxis;
         Scatter.yaxis = yaxis;
         Scatter.series = series;
         Scatter.drawline = bdrawlines;
         Scatter.legend_pos = slegend; } in
   let scatters = List.map build_scatter lparams_charts in


*)

(* TODO: add support for append on pdf
   gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile=out.pdf in1.pdf in2.pdf
   gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -dPDFSETTINGS=/prepress -sOutputFile=out.pdf in1.pdf in2.pdf
*)












open XBase
open Printf
open Sys_tools

let _ = 
   let _debug = XCmd.mem_flag "debug" in
   let files = XCmd.get_others() in
   if files = [] then failwith "expecting a list of files as argument";
   ~~ List.iter files (fun file -> 
      let base = Filename.chop_extension file in
      let flags = XCmd.string_of_flags (XCmd.get_flags()) in
      let args = XCmd.string_of_args (XCmd.get_args()) in
      let s = sprintf "make %s.byte && ./%s.byte %s %s" base base flags args in
      Printf.printf "Command: %s" s; print_newline();
      let r = XSys.command_as_bool s in
      if not r then failwith (sprintf "==> Failure on file %s" file)
      )

(*
   let pbench = XSys.absolute_path (Pbench.get_pbench_folder()) in
*)

(** Example usage:
    make pbench.byte && ./pbench.byte demo.ml -test graph

    --requires a Makefile that is able to produce demo.byte
*)