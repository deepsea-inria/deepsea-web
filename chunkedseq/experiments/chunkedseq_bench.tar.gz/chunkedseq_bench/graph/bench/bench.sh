make -C ~/pbench/trunk graph.byte && ~/pbench/trunk/graph.byte $*
