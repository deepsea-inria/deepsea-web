/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file control.cpp
 * \brief Control operators
 *
 */

#include "control.hpp"

namespace pasl {
namespace util {
namespace control {

/***********************************************************************/

void* _pasl_cxt_save(char* env) {
  assert(false);
}

void _pasl_cxt_restore(char* env, void* val) {
  assert(false);
}

/***********************************************************************/

} // end namespace
} // end namespace
} // end namespace
