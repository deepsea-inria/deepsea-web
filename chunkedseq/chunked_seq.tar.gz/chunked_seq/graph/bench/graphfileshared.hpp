/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file graphfileshared.hpp
 *
 */

#ifndef _PASL_GRAPHFILESHARED_H_
#define _PASL_GRAPHFILESHARED_H_

#include "graphgenerators.hpp"
#include "graphio.hpp"
#include "graphconversions.hpp"
#include "cmdline.hpp"

/***********************************************************************/

namespace pasl {
namespace graph {
  
using thunk_type = std::function<void ()>;

template <class Adjlist>
void print_adjlist_summary(const Adjlist& graph) {
  std::cout << "nb_vertices\t" << graph.get_nb_vertices() << std::endl;
  std::cout << "nb_edges\t" << graph.nb_edges << std::endl;
}
  
template <class Adjlist>
void generate_graph_by_nb_edges(Adjlist& graph) {
  using vtxid_type = typename Adjlist::vtxid_type;
  vtxid_type nb_edges_target = vtxid_type(util::cmdline::parse_or_default_uint64("nb_edges_target", 0));
  using vtxid_type = typename Adjlist::vtxid_type;
  using edge_type = edge<vtxid_type>;
  using edgelist_bag_type = data::array_seq<edge_type>;
  using edgelist_type = edgelist<edgelist_bag_type>;
  edgelist_type edges;
  util::cmdline::argmap<thunk_type> tmg;
  tmg.add("complete",       [&] { generate_complete_graph_by_nb_edges(nb_edges_target, edges); });
  tmg.add("phased",         [&] { generate_phased_by_nb_edges(nb_edges_target, edges); });
  tmg.add("parallel_paths", [&] { generate_parallel_paths_by_nb_edges(nb_edges_target, edges); });
  tmg.add("rmat",           [&] { generate_rmat_by_nb_edges(nb_edges_target, edges); });
  tmg.add("random",         [&] { generate_randlocal_by_nb_edges(nb_edges_target, edges); });
  tmg.add("square_grid",    [&] { generate_square_grid_by_nb_edges(nb_edges_target, edges); });
  tmg.add("cube_grid",      [&] { generate_cube_grid_by_nb_edges(nb_edges_target, edges); });
  tmg.add("chain",          [&] { generate_chain_by_nb_edges(nb_edges_target, edges); });
  tmg.add("star",           [&] { generate_star(nb_edges_target, edges); });
  tmg.add("tree",           [&] { generate_balanced_tree(nb_edges_target, edges); });
  tmg.find_by_arg("generator")();
  adjlist_from_edgelist(edges, graph);
}

void parse_fname(std::string fname, std::string& base, std::string& extension) {
  if (fname == "")
    util::atomic::die("bogus filename");
  std::stringstream ss(fname);
  std::getline(ss, base, '.');
  std::getline(ss, extension);
}

template <class Adjlist>
void load_graph_from_file(Adjlist& graph) {
  std::string infile = util::cmdline::parse_or_default_string("infile", "");
  std::string base;
  std::string extension;
  parse_fname(infile, base, extension);
  if (extension == "adj_bin")
    read_adjlist_from_file(infile, graph);
  else if (extension == "snap")
    read_snap_graph(infile, graph);
  else if (extension == "twitter")
    read_twitter_graph(infile, graph);
  else if (extension == "mmarket")
    read_matrix_market(infile, graph);
  else
    util::atomic::die("unknown file format %s", extension.c_str());
}

template <class Adjlist>
void write_graph_to_file(Adjlist& graph) {
  std::string outfile = util::cmdline::parse_or_default_string("outfile", "");
  std::stringstream ss(outfile);
  std::string base;
  std::string extension;
  parse_fname(outfile, base, extension);
  if (extension == "adj_bin") {
    std::cout << "Writing file " << outfile << std::endl;
    write_adjlist_to_file(outfile, graph);
  } else if (extension == "dot") {
    write_adjlist_to_dotfile(outfile, graph);
  } else {
    util::atomic::die("unknown extension for outfile %s", extension.c_str());
  }
}

} // end namespace
} // end namespace

/***********************************************************************/

#endif /*! _PASL_GRAPHFILESHARED_H_ */