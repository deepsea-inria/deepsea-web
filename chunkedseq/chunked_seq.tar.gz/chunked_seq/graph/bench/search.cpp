/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file search.cpp
 *
 */

#include "graphfileshared.hpp"
#include "bfs.hpp"
#include "dfs.hpp"
#include "benchmark.hpp"
#include "container.hpp"
#include "ls_bag.hpp"
#include "frontiersegment.hpp"

#ifdef USE_MALLOC_COUNT
#include "malloc_count.h"
#endif

/***********************************************************************/

namespace pasl {
namespace graph {
  
/*---------------------------------------------------------------------*/
  
template <class Adjlist>
using fftree_stack = data::pcontainer::stack<typename Adjlist::vtxid_type>;

template <class Adjlist>
using fftree_deque = data::pcontainer::deque<typename Adjlist::vtxid_type>;

template <class Adjlist>
using fftree_bag = data::pcontainer::bag<typename Adjlist::vtxid_type>;
  

template <class Adjlist>
using bootstrap_fftree_stack = data::pcontainer::bootstrap_stack<typename Adjlist::vtxid_type>;

template <class Adjlist>
using bootstrap_fftree_deque = data::pcontainer::bootstrap_deque<typename Adjlist::vtxid_type>;

template <class Adjlist>
using bootstrap_fftree_bag = data::pcontainer::bootstrap_bag<typename Adjlist::vtxid_type>;

  
template <class Adjlist>
using bootseq_stack = data::pcontainer::bootseq_stack<typename Adjlist::vtxid_type>;

template <class Adjlist>
using bootseq_deque = data::pcontainer::bootseq_deque<typename Adjlist::vtxid_type>;
  

template <class Adjlist>
using stl_deque = data::stl::deque_seq<typename Adjlist::vtxid_type>;

template <class Adjlist>
using stl_vector = data::stl::vector_seq<typename Adjlist::vtxid_type>;
  
#ifdef HAVE_ROPE
template <class Adjlist>
using stl_rope = data::stl::rope_seq<typename Adjlist::vtxid_type>;
#endif
  
#ifdef HAVE_CORD
template <class Adjlist>
using cord = data::stl::cord_seq<typename Adjlist::vtxid_type>;
#endif

template <class Adjlist>
using ls_bag = data::Bag<typename Adjlist::vtxid_type>;

template <class Adjlist>
using frontier_segment_type = data::frontier_segment<typename Adjlist::alias_type>;
  
/*---------------------------------------------------------------------*/
  
template <class Adjlist, class Search, class Report, class Destroy>
void search_benchmark_select_input_graph(const Search& search,
                                         const Report& report,
                                         const Destroy& destroy) {
  using vtxid_type = typename Adjlist::vtxid_type;
  Adjlist graph;
  vtxid_type source = vtxid_type(util::cmdline::parse_or_default_uint64("source", 0));
  auto init = [&] {
    util::cmdline::argmap<thunk_type> tmg;
    tmg.add("from_file",          [&] { load_graph_from_file(graph); });
    tmg.add("by_generator",       [&] { generate_graph_by_nb_edges(graph); });
    tmg.find_by_arg("load")();
  };
  auto run = [&] (bool sequential) {
    search(graph, source);
  };
  auto output = [&] {
    report(graph);
    print_adjlist_summary(graph);
    std::cout << "chunk_capacity\t" << data::pcontainer::chunk_capacity << std::endl;
  };
  sched::launch(init, run, output, destroy);
}
  
/*---------------------------------------------------------------------*/

template <class Adjlist, class Frontier>
void search_benchmark_for_sequential_select_algo() {
  using adjlist_type = Adjlist;
  using adjlist_seq_type = typename adjlist_type::adjlist_seq_type;
  using vtxid_type = typename Adjlist::vtxid_type;
  using search_type = std::function<void (const adjlist_type& graph, vtxid_type source)>;
  vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
  vtxid_type* dists = NULL;
  int* visited = NULL;
  util::cmdline::argmap<search_type> m;
  m.add("bfs_by_array", [&] (const adjlist_type& graph, vtxid_type source) {
    dists = bfs_by_array(graph, source); });
  m.add("bfs_by_dynamic_array", [&] (const adjlist_type& graph, vtxid_type source) {
    dists = bfs_by_dynamic_array<adjlist_seq_type, Frontier>(graph, source); });
  m.add("bfs_by_dual_frontiers_and_foreach", [&] (const adjlist_type& graph, vtxid_type source) {
    dists = bfs_by_dual_frontiers_and_foreach<adjlist_seq_type, Frontier>(graph, source); });
  m.add("bfs_by_dual_frontiers_and_pushpop", [&] (const adjlist_type& graph, vtxid_type source) {
    dists = bfs_by_dual_frontiers_and_pushpop<adjlist_seq_type, Frontier>(graph, source); });
  m.add("bfs_by_dual_arrays", [&] (const adjlist_type& graph, vtxid_type source) {
    dists = bfs_by_dual_arrays<adjlist_seq_type>(graph, source); });
  m.add("bfs_by_frontier_segment", [&] (const adjlist_type& graph, vtxid_type source) {
    dists = bfs_by_frontier_segment<adjlist_type, frontier_segment_type<adjlist_type>>(graph, source); });
  m.add("dfs_by_vertexid_array", [&] (const adjlist_type& graph, vtxid_type source) {
    visited = dfs_by_vertexid_array(graph, source); });
  m.add("dfs_by_vertexid_frontier", [&] (const adjlist_type& graph, vtxid_type source) {
    visited = dfs_by_vertexid_frontier<adjlist_seq_type, Frontier>(graph, source); });
  m.add("dfs_by_frontier_segment", [&] (const adjlist_type& graph, vtxid_type source) {
    visited = dfs_by_frontier_segment<adjlist_type, frontier_segment_type<adjlist_type>>(graph, source); });
  auto search = m.find_by_arg("algo");
  auto report = [&] (const adjlist_type& graph) {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (dists != NULL) {
      vtxid_type max_dist = pbbs::sequence::maxReduce(dists, nb_vertices);
      auto is_visited = [&] (vtxid_type i) { return (dists[i] == unknown) ? 0 : 1; };
      vtxid_type nb_visited = pbbs::sequence::plusReduce(dists, nb_vertices, is_visited);
      std::cout << "max_dist\t" << max_dist << std::endl;
      std::cout << "nb_visited\t" << nb_visited << std::endl;
    } else if (visited != NULL) {
      auto is_visited = [&] (vtxid_type i) { return vtxid_type(visited[i]); };
      vtxid_type nb_visited = pbbs::sequence::plusReduce((vtxid_type*)NULL, nb_vertices, is_visited);
      std::cout << "nb_visited\t" << nb_visited << std::endl;
    }
    std::cout << "chunk_capacity\t" << data::pcontainer::chunk_capacity << std::endl;
#ifdef GRAPH_SEARCH_STATS
    std::cout << "peak_frontier_size\t" << peak_frontier_size << std::endl;
#endif
  };
  auto destroy = [&] {
    if (dists != NULL)
      data::myfree(dists);
    else if (visited != NULL)
      data::myfree(visited);
  };
  search_benchmark_select_input_graph<Adjlist>(search, report, destroy);
}
  
template <class Adjlist>
void search_benchmark_for_sequential_select_frontier() {
  util::cmdline::argmap<thunk_type> tmg;
  tmg.add("fftree_stack",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, fftree_stack<Adjlist>>(); });
  tmg.add("fftree_deque",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, fftree_deque<Adjlist>>(); });
  tmg.add("fftree_bag",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, fftree_bag<Adjlist>>(); });
  tmg.add("bootstrap_fftree_stack",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, bootstrap_fftree_stack<Adjlist>>(); });
  tmg.add("bootstrap_fftree_deque",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, bootstrap_fftree_deque<Adjlist>>(); });
  tmg.add("bootseq_stack",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, bootseq_stack<Adjlist>>(); });
  tmg.add("bootseq_deque",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, bootseq_deque<Adjlist>>(); });
  tmg.add("stl_deque",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, stl_deque<Adjlist>>(); });
  tmg.add("stl_vector",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, stl_vector<Adjlist>>(); });
#ifdef HAVE_ROPE
  tmg.add("stl_rope",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, stl_rope<Adjlist>>(); });
#endif
#ifdef HAVE_CORD
  tmg.add("cord",       [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, cord<Adjlist>>(); });
#endif
  tmg.add("default", [&] {
    search_benchmark_for_sequential_select_algo<Adjlist, stl_vector<Adjlist>>(); });
  tmg.find_by_arg("frontier")();
}
  
/*---------------------------------------------------------------------*/
  
template <class Adjlist, class Frontier, bool idempotent>
void search_benchmark_for_parallel_select_algo() {
  using adjlist_type = Adjlist;
  using adjlist_seq_type = typename adjlist_type::adjlist_seq_type;
  using vtxid_type = typename Adjlist::vtxid_type;
  using search_type = std::function<void (const adjlist_type& graph, vtxid_type source)>;
  vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
  std::atomic<vtxid_type>* dists = NULL;
  std::atomic<int>* visited = NULL;
  util::cmdline::argmap<search_type> m;
  m.add("pbfs",   [&] (const adjlist_type& graph, vtxid_type source) {
    dists = pbfs<idempotent>::template main<adjlist_seq_type, Frontier>(graph, source); });
  m.add("fpbfs",   [&] (const adjlist_type& graph, vtxid_type source) {
    dists = fpbfs<idempotent>::template main<adjlist_type, frontier_segment_type<adjlist_type>>(graph, source); });
  m.add("pseudodfs",   [&] (const adjlist_type& graph, vtxid_type source) {
    visited = pseudodfs<adjlist_type, frontier_segment_type<adjlist_type>, idempotent>(graph, source); });
  m.add("cong_pseudodfs",   [&] (const adjlist_type& graph, vtxid_type source) {
    visited = cong_pseudodfs<adjlist_seq_type, Frontier, idempotent>(graph, source); });
  auto search = m.find_by_arg("algo");
  auto report = [&] (const adjlist_type& graph) {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (dists != NULL) {
      auto load_dist = [&] (vtxid_type i) { return dists[i].load(); };
      vtxid_type max_dist = pbbs::sequence::maxReduce((vtxid_type*)NULL, nb_vertices, load_dist);
      auto is_visited = [&] (vtxid_type i) { return load_dist(i) == unknown ? 0 : 1; };
      vtxid_type nb_visited = pbbs::sequence::plusReduce((vtxid_type*)NULL, nb_vertices, is_visited);
      std::cout << "max_dist\t" << max_dist << std::endl;
      std::cout << "nb_visited\t" << nb_visited << std::endl;
    } else if (visited != NULL) {
      auto load_visited = [&] (vtxid_type i) { return vtxid_type(visited[i].load()); };
      vtxid_type nb_visited = pbbs::sequence::plusReduce((vtxid_type*)NULL, nb_vertices, load_visited);
      std::cout << "nb_visited\t" << nb_visited << std::endl;
    }
    std::cout << "chunk_capacity\t" << data::pcontainer::chunk_capacity << std::endl;
#ifdef GRAPH_SEARCH_STATS
    std::cout << "peak_frontier_size\t" << peak_frontier_size << std::endl;
#endif
  };
  auto destroy = [&] {
    if (dists != NULL)
      data::myfree(dists);
    else if (visited != NULL)
      data::myfree(visited);
  };
  search_benchmark_select_input_graph<Adjlist>(search, report, destroy);
}
  
template <class Adjlist, class Frontier>
void search_benchmark_for_parallel_select_idempotent() {
  bool idempotent = util::cmdline::parse_or_default_bool("idempotent", false);
  if (idempotent)
    search_benchmark_for_parallel_select_algo<Adjlist, Frontier, true>();
  else
    search_benchmark_for_parallel_select_algo<Adjlist, Frontier, false>();
}

template <class Adjlist>
void search_benchmark_for_parallel_select_frontier() {
  std::string frontier = util::cmdline::parse_or_default_string("frontier", "deque");
  util::cmdline::argmap<thunk_type> tmg;
  tmg.add("fftree_stack",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, fftree_stack<Adjlist>>(); });
  tmg.add("fftree_deque",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, fftree_deque<Adjlist>>(); });
  tmg.add("fftree_bag",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, fftree_bag<Adjlist>>(); });
  tmg.add("bootstrap_fftree_stack",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, bootstrap_fftree_stack<Adjlist>>(); });
  tmg.add("bootstrap_fftree_deque",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, bootstrap_fftree_deque<Adjlist>>(); });
  tmg.add("bootstrap_fftree_bag",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, bootstrap_fftree_bag<Adjlist>>(); });
  tmg.add("bootseq_stack",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, bootseq_stack<Adjlist>>(); });
  tmg.add("bootseq_deque",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, bootseq_deque<Adjlist>>(); });
  tmg.add("stl_deque",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, stl_deque<Adjlist>>(); });
  tmg.add("stl_vector",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, stl_vector<Adjlist>>(); });
  tmg.add("ls_bag",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, ls_bag<Adjlist>>(); });
#ifdef HAVE_ROPE
  tmg.add("stl_rope",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, stl_rope<Adjlist>>(); });
#endif
#ifdef HAVE_CORD
  tmg.add("cord",       [&] {
    search_benchmark_for_parallel_select_idempotent<Adjlist, cord<Adjlist>>(); });
#endif
  tmg.find_by_arg("frontier")();
}
  
/*---------------------------------------------------------------------*/
  
bool is_parallel_algo() {
  std::string algo = util::cmdline::parse_or_default_string("algo", "");
  if (algo == "pbfs")               return true;
  if (algo == "fpbfs")              return true;
  if (algo == "pseudodfs")          return true;
  if (algo == "cong_pseudodfs")     return true;
  return false;
}
  
template <class Adjlist>
void search_benchmark_select_mode() {
  if (is_parallel_algo())
    search_benchmark_for_parallel_select_frontier<Adjlist>();
  else
    search_benchmark_for_sequential_select_frontier<Adjlist>();
}
  
int cong_pdfs_cutoff = 10000;
int pseudodfs_cutoff = 10000;
int pbfs_cutoff = 10000;
int fpbfs_cutoff = 10000;

} // end namespace
} // end namespace

/*---------------------------------------------------------------------*/

using namespace pasl;

int main(int argc, char ** argv) {
  util::cmdline::set(argc, argv);

  pasl::graph::pbfs_cutoff = pasl::util::cmdline::parse_or_default_int("pbfs_cutoff", 8192);
  pasl::graph::fpbfs_cutoff = pasl::util::cmdline::parse_or_default_int("fpbfs_cutoff", 8192);
  pasl::graph::cong_pdfs_cutoff = pasl::util::cmdline::parse_or_default_int("cong_pdfs_cutoff", 8192);
  pasl::graph::pseudodfs_cutoff = pasl::util::cmdline::parse_or_default_int("pseudodfs_cutoff", 8192);
  
  using vtxid_type32 = int;
  using adjlist_seq_type32 = graph::flat_adjlist_seq<vtxid_type32>;
  using adjlist_type32 = graph::adjlist<adjlist_seq_type32>;
  
  using vtxid_type64 = long;
  using adjlist_seq_type64 = graph::flat_adjlist_seq<vtxid_type64>;
  using adjlist_type64 = graph::adjlist<adjlist_seq_type64>;
  
  int nb_bits = util::cmdline::parse_or_default_int("bits", 32);
  
  if (nb_bits == 32 )
    graph::search_benchmark_select_mode<adjlist_type32>();
  else if (nb_bits == 64)
    graph::search_benchmark_select_mode<adjlist_type64>();
  else
    util::atomic::die("bits must be either 32 or 64");

#ifdef USE_MALLOC_COUNT
  malloc_pasl_report();
#endif
  
  return 0;
}

/***********************************************************************/
