/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file edgelist.hpp
 * \brief Edge-list graph format
 *
 */

#ifndef _PASL_GRAPH_EDGELIST_H_
#define _PASL_GRAPH_EDGELIST_H_

#include <vector>

#include "graph.hpp"

/***********************************************************************/

namespace pasl {
namespace graph {
  
template <class Vertex_id>
class edge {
public:
  
  typedef Vertex_id vtxid_type;
  
  vtxid_type src;
  vtxid_type dst;
  
  edge(vtxid_type src, vtxid_type dst)
  : src(src), dst(dst) { }
  
  edge()
  : src(vtxid_type(0)), dst(vtxid_type(0)) { }
  
  void check(vtxid_type nb_vertices) const {
#ifndef NDEBUG
    check_vertex(src, nb_vertices);
    check_vertex(dst, nb_vertices);
#endif
  }
  
};
  
/*---------------------------------------------------------------------*/

template <class Edge_bag>
class edgelist {
public:
  
  typedef Edge_bag edge_bag_type;
  typedef typename edge_bag_type::value_type edge_type;
  typedef typename edge_type::vtxid_type vtxid_type;
  typedef edgelist<Edge_bag> self_type;
  
  vtxid_type nb_vertices;
  edge_bag_type edges;
  
  edgelist()
  : nb_vertices(0) { }
  
  edgelist(vtxid_type nb_vertices, edge_bag_type& other)
  : nb_vertices(nb_vertices) {
    edges.swap(other);
  }
  
  void clear() {
    nb_vertices = 0;
    edges.clear();
  }
  
  edgeid_type get_nb_edges() const {
    return edgeid_type(edges.size());
  }
  
  void check() const {
#ifndef NDEBUG
    for (edgeid_type i = 0; i < get_nb_edges(); i++)
      edges[i].check(nb_vertices);
#endif
  }
  
  edge_type* data() const {
    return edges.data();
  }
  
  void swap(self_type& other) {
    std::swap(nb_vertices, other.nb_vertices);
    edges.swap(other.edges);
  }
  
};
  
/*---------------------------------------------------------------------*/

template <class Vertex_id>
bool operator==(const edge<Vertex_id>& e1,
                const edge<Vertex_id>& e2) {
  return e1.src == e2.src
  && e1.dst == e2.dst;
}

template <class Vertex_id>
bool operator!=(const edge<Vertex_id>& e1,
                const edge<Vertex_id>& e2) {
  return ! (e1 == e2);
}

template <class Edge_bag>
bool operator==(const edgelist<Edge_bag>& e1, const edgelist<Edge_bag>& e2) {
  using edge_type = typename Edge_bag::value_type;
  using vtxid_type = typename edgelist<Edge_bag>::vtxid_type;
  if (e1.nb_vertices != e2.nb_vertices)
    return false;
  if (e1.get_nb_edges() != e2.get_nb_edges())
    return false;
  std::vector<edge_type> edges1;
  std::vector<edge_type> edges2;
  for (edgeid_type i = 0; i < e1.get_nb_edges(); i++) {
    edges1.push_back(e1.edges[i]);
    edges2.push_back(e2.edges[i]);
  }
  auto comp = [] (edge_type e, edge_type f) {
    return e.src < f.src || ((e.src == f.src) && (e.dst < f.dst));
  };
  std::sort(edges1.begin(), edges1.end(), comp);
  std::sort(edges2.begin(), edges2.end(), comp);
  for (vtxid_type i = 0; i < edges1.size(); i++)
    if (edges1[i] != edges2[i])
      return false;
  return true;
}

template <class Edge_bag>
bool operator!=(const edgelist<Edge_bag>& e1, const edgelist<Edge_bag>& e2) {
  return ! (e1 == e2);
}

  
} // end namespace
} // end namespace

/***********************************************************************/

#endif /*! _PASL_GRAPH_EDGELIST_H_ */
