/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Frontier segment
 * \file frontiersegment.hpp
 *
 */

#ifndef _PASL_FRONTIERSEGMENT_H_
#define _PASL_FRONTIERSEGMENT_H_

#include "fftree.hpp"

namespace pasl {
namespace data {

/***********************************************************************/
  
template <class Graph>
class frontier_segment {
public:
  
  typedef frontier_segment self_type;
  typedef Graph graph_type;
  typedef typename graph_type::vtxid_type vtxid_type;
  typedef graph_type env_type;
  
  class edgelist_type {
  public:
    
    typedef edgelist_type self_type;
    typedef size_t size_type;
    
    vtxid_type* lo;
    vtxid_type* hi;
    
    edgelist_type()
    : lo(NULL), hi(NULL) { }
    
    edgelist_type(size_type nb, vtxid_type* edges)
    : lo(edges), hi(edges + nb) { }
    
    size_type size() const {
      return size_type(hi - lo);
    }
    
    // moves the nb edges at the back to dst and keeps the rest
    // precondition: size of dst equals zero
    // precondition: size greater than or equal to nb
    // postcondition: size decreased by nb and size of increased by nb
    void transfer_back(self_type& dst, size_type nb) {
      assert(dst.size() == 0);
      assert(size() >= nb);
      dst.hi = hi;
      hi -= nb;
      dst.lo = hi;
    }

    // moves the nb edges at the front to dst and keeps the rest
    // precondition: size of dst equals zero
    // precondition: size greater than or equal to nb
    // postcondition: size decreased by nb and size of increased by nb
    void transfer_front(self_type& dst, size_type nb) {
      assert(dst.size() == 0);
      assert(size() >= nb);
      dst.lo = lo;
      lo += nb;
      dst.hi = lo;
    }
    
    void swap(self_type& other) {
      std::swap(lo, other.lo);
      std::swap(hi, other.hi);
    }
    
  };
  
private:
  
  static constexpr int chunk_capacity = data::pcontainer::chunk_capacity;
  
  using chunk_allocator = fixedcapacity::heap_allocator<vtxid_type, chunk_capacity>;
  
  using vector_type = fixedcapacity::stack<chunk_allocator>;
  
  class cache_type {
  public:
    
    typedef size_t size_type;
    typedef algebra::sum_int<size_type> algebra_type;
    typedef size_type measured_type;
    typedef vtxid_type value_type;
    
    class measure_type {
    private:
      
      env_type graph;
      
      measured_type get_out_degree(vtxid_type v) const {
        return measured_type(graph.adjlists[v].get_out_degree());
      }
      
    public:
      
      measure_type(const env_type& graph) : graph(graph) { }
      
      void operator()(const value_type& v, measured_type& dst) const {
        dst = get_out_degree(v);
      }
      
      void operator()(const value_type* lo, const value_type* hi,
                      measured_type& dst) const {
        algebra_type::identity(&dst);
        for (; lo < hi; lo++) {
          measured_type m = get_out_degree(*lo);
          algebra_type::reduce(&dst, &m);
        }
      }
      
      env_type get_graph() const {
        return graph;
      }
      
    };
    
    static void swap(measured_type& m1, measured_type& m2) {
      std::swap(m1, m2);
    }
    
  };
  
  typedef fftree_base::deque_with_size_plus<cache_type, vector_type, -1> fftree_config_type;
  typedef fftree_base::fftree<fftree_config_type> fftree_type;
  
public:
  
  typedef typename fftree_type::size_type size_type;
  
private:
  
  edgelist_type fr;
  fftree_type mid;
  edgelist_type bk;
  
  size_type nb_outedges(const fftree_type& fft) const {
    typename fftree_type::size_type nb;
    fft.cget_cached(nb);
    return size_type(nb);
  }
  
  void check(const fftree_type& fft) const {
    // expensive but thorough consistency check
#if 0
    size_type nb_out1 = nb_outedges(fft);
    size_type nb_out2 = 0;
    for (auto lo = fft.begin(); lo != fft.end(); lo++)
      nb_out2 += get_graph().adjlists[*lo].get_out_degree();
    assert(nb_out1 == nb_out2);
#endif
  }
  
  edgelist_type create_edgelist(vtxid_type v) const {
    size_type degree = get_graph().adjlists[v].get_out_degree();
    vtxid_type* neighbors = get_graph().adjlists[v].get_out_neighbors();
    return edgelist_type(vtxid_type(degree), neighbors);
  }
  
  void transfer_back_of_mid(edgelist_type& dst_fr,
                            fftree_type& dst_mid,
                            size_type nb) {
    check(mid);
    check(dst_mid);
    size_type nb_to_keep = nb_outedges(mid) - nb;
    size_type nb_to_keep_orig = nb_to_keep;
    auto p = [nb_to_keep] (const size_type& i) {
      return i > nb_to_keep;
    };
    mid.transfer_from_back_to_front_by_client(dst_mid, p);
    nb_to_keep -= nb_outedges(mid);
    assert(bk.size() == 0);
    if (nb_to_keep > 0) {
      bk = create_edgelist(dst_mid.pop_front());
      bk.transfer_back(dst_fr, vtxid_type(bk.size() - nb_to_keep));
    }
    assert(bk.size() + nb_outedges(mid) == nb_to_keep_orig);
    assert(dst_fr.size() + nb_outedges(dst_mid) == nb);
    check(mid);
    check(dst_mid);
  }
  
public:
  
  frontier_segment(const env_type& graph)
  : mid(graph) { }
 
  bool sides_empty() const {
    return fr.size() == 0 && bk.size() == 0;
  }
 
  bool empty() const {
    return mid.empty() && sides_empty();
  }
 
  size_type nb_outedges() const {
    return fr.size()
         + nb_outedges(mid)
         + bk.size();
  }
  
  // currently not used
  size_type nb_vertices() const {
    int nb = 0;
    nb += (fr.size() > 0) ? 1 : 0;
    nb += mid.size();
    nb += (bk.size() > 0) ? 1 : 0;
    return nb;
  }
  
  void push_back_edgelist(const edgelist_type& r) {
    assert(bk.size() == 0);
    assert(r.size() > 0);
    bk = r;
  }
  
  edgelist_type pop_back_edgelist() {
    check(mid);
    edgelist_type r;
    assert(nb_vertices() > 0);
    //assert(nb_outedges() > 0);
    if (bk.size() > 0) {
      r.swap(bk);
    } else if (! mid.empty()) {
      r = create_edgelist(mid.pop_back());
    } else {
      assert(fr.size() > 0);
      r.swap(fr);
    }
    //assert(r.size() > 0);
    check(mid);
    return r;
  }
  
  edgelist_type pop_back_edgelist(size_type nb) {
    assert(nb_outedges() >= nb);
    edgelist_type edges = pop_back_edgelist();
    if (edges.size() <= nb)
      return edges;
    edgelist_type spill;
    edges.transfer_back(spill, vtxid_type(edges.size() - nb));
    push_back_edgelist(spill);
    assert(edges.size() <= nb);
    return edges;
  }
  
  void push_back_vertex(const vtxid_type& v) {
    check(mid);
    mid.push_back(v);
    check(mid);
  }

  // post condition:
  // moves the nb items at the back to dst
  // and keeps the rest
  void transfer_from_back(self_type& dst, size_type nb) {
    check(mid);
    check(dst.mid);
    assert(nb_outedges() >= nb);
    assert(dst.empty());
    size_type nb_outedges_orig = nb_outedges();
    size_type nb_to_transfer = nb;
    do {
      size_type m;
      m = std::min(size_type(bk.size()), nb_to_transfer);
      bk.transfer_back(dst.bk, vtxid_type(m));
      nb_to_transfer -= m;
      if (nb_to_transfer == 0)
        break;
      m = std::min(nb_outedges(mid), nb_to_transfer);
      transfer_back_of_mid(dst.fr, dst.mid, m);
      nb_to_transfer -= dst.fr.size() + dst.nb_outedges(dst.mid);
      if (nb_to_transfer == 0)
        break;
      m = std::min(size_type(fr.size()), nb_to_transfer);
      fr.transfer_front(dst.fr, vtxid_type(m));
    } while(false);
    assert(nb_to_transfer == 0);
    assert(nb_outedges() == nb_outedges_orig - nb);
    assert(dst.nb_outedges() == nb);
    check(mid);
    check(dst.mid);
  }
  
  void transfer_from_front(self_type& dst, size_type nb) {
    transfer_from_back(dst, nb_outedges() - nb);
    swap(dst);
  }
  
  // pre-condition (slightly stonger than required):
  //  fr and bk must be both empty;
  // post-condition: other is empty.
  void transfer_to_back(self_type& other) {
    check(mid);
    check(other.mid);
    assert(sides_empty());
    assert(other.sides_empty());
    mid.transfer_to_back(other.mid);
    check(mid);
    check(other.mid);
  }
  
  void swap(self_type& other) {
    fr.swap(other.fr);
    mid.swap(other.mid);
    bk.swap(other.bk);
  }
  
  void clear() {
    check(mid);
    fr = edgelist_type();
    mid.clear();
    bk = edgelist_type();
    check(mid);
  }
  
#ifdef USE_PREFETCHING
  
#define NB_EDGES_BEFORE_PREFETCH 4
  
  template <class Body>
  inline void for_each(const Body& body) {
    if (fr.size() > 0)
      body(fr);
    auto _body = [&body,this] (size_type, vtxid_type* lo, vtxid_type* hi) {
      for (auto p = lo; p < hi; p++) {
        edgelist_type edges_before_prefetch = create_edgelist(*p);
        edgelist_type edges_after_prefetch;
        size_type nb_edges = edges_before_prefetch.size();
        size_type nb = std::min(nb_edges, size_type(NB_EDGES_BEFORE_PREFETCH));
        edges_before_prefetch.transfer_back(edges_after_prefetch, nb);
        body(edges_before_prefetch);
        auto next = p + 1;
        if (next < hi) { // prefetch if possible
          edgelist_type next_edges = create_edgelist(*next);
          __builtin_prefetch(next_edges.lo);
        }
        body(edges_after_prefetch);
      }
    };
    mid.for_each_segment(_body);
    if (bk.size() > 0)
      body(bk);
  }
  
#else
  
  template <class Body>
  inline void for_each(const Body& body) {
    if (fr.size() > 0)
      body(fr);
    mid.for_each([&body,this] (size_type, vtxid_type& v) {
      body(create_edgelist(v));
    });
    if (bk.size() > 0)
      body(bk);
  }
  
#endif
  
  env_type get_graph() const {
    return mid.get_measure().get_graph();
  }
  
};
  
/***********************************************************************/

}
}

#endif /*! _PASL_FRONTIERSEGMENT_H_ */