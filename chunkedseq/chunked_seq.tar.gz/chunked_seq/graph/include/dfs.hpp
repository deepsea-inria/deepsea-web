/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file dfs.hpp
 *
 */

#ifndef _PASL_GRAPH_DFS_H_
#define _PASL_GRAPH_DFS_H_

#include "edgelist.hpp"
#include "adjlist.hpp"
#include "native.hpp"

/***********************************************************************/

namespace pasl {
namespace graph {

#ifdef GRAPH_SEARCH_STATS
size_t peak_frontier_size;
#endif

/*---------------------------------------------------------------------*/
/* Depth first search in a graph in adjacency-list format; serial */

// preallocated array of node ids
template <class Adjlist_seq>
int* dfs_by_vertexid_array(const adjlist<Adjlist_seq>& graph,
                           typename adjlist<Adjlist_seq>::vtxid_type source) {
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  int* visited = data::mynew_array<int>(nb_vertices);
  fill_array_seq(visited, nb_vertices, 0);
  vtxid_type* frontier = data::mynew_array<vtxid_type>(nb_vertices);
  vtxid_type frontier_size = 0;
  frontier[frontier_size++] = source;
  visited[source] = 1;
  while (frontier_size > 0) {
    vtxid_type vertex = frontier[--frontier_size];
    vtxid_type degree = graph.adjlists[vertex].get_out_degree();
    vtxid_type* neighbors = graph.adjlists[vertex].get_out_neighbors();
    for (vtxid_type edge = 0; edge < degree; edge++) {
      vtxid_type other = neighbors[edge];
      if (visited[other])
        continue;
      visited[other] = 1;
      frontier[frontier_size++] = other;
    }
  }
  data::myfree(frontier);
  return visited;
}

// dynamic array of node ids
template <class Adjlist_seq, class Frontier>
int* dfs_by_vertexid_frontier(const adjlist<Adjlist_seq>& graph,
                              typename adjlist<Adjlist_seq>::vtxid_type source) {
#ifdef GRAPH_SEARCH_STATS
  peak_frontier_size = 0l;
#endif
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  int* visited = data::mynew_array<int>(nb_vertices);
  fill_array_seq(visited, nb_vertices, 0);
  Frontier frontier;
  frontier.push_back(source);
  visited[source] = 1;
  while (! frontier.empty()) {
    vtxid_type vertex = frontier.pop_back();
    vtxid_type degree = graph.adjlists[vertex].get_out_degree();
    vtxid_type* neighbors = graph.adjlists[vertex].get_out_neighbors();
    for (vtxid_type edge = 0; edge < degree; edge++) {
      vtxid_type other = neighbors[edge];
      if (visited[other])
        continue;
      visited[other] = 1;
      frontier.push_back(other);
    }
#ifdef GRAPH_SEARCH_STATS
    peak_frontier_size = std::max((size_t)frontier.size(), peak_frontier_size);
#endif
  }
  return visited;
}

// custom frontier based on fast finger trees
template <class Adjlist, class Frontier>
int* dfs_by_frontier_segment(const Adjlist& graph,
                             typename Adjlist::vtxid_type source) {
  using vtxid_type = typename Adjlist::vtxid_type;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  int* visited = data::mynew_array<int>(nb_vertices);
  fill_array_seq(visited, nb_vertices, 0);
  Frontier frontier(get_alias_of_adjlist(graph));
  frontier.push_back_vertex(source);
  visited[source] = 1;
  while (! frontier.empty()) {
    auto neighbors = frontier.pop_back_edgelist();
    for (auto i = neighbors.lo; i < neighbors.hi; i++) {
      vtxid_type other = *i;
      if (visited[other])
        continue;
      visited[other] = 1;
      frontier.push_back_vertex(other);
    }
  }
  return visited;
}

/*---------------------------------------------------------------------*/
/* Parallel (pseudo) depth-first search of a graph in adacency-list format */

template <class Index, class Item, bool idempotent = false>
bool try_to_mark(std::atomic<Item>* bits, Index target) {
  if (bits[target].load(std::memory_order_relaxed))
    return false;
  if (! idempotent) {
    Item orig = 0;
    if (! bits[target].compare_exchange_strong(orig, 1))
      return false;
  } else {
    bits[target].store(1, std::memory_order_relaxed);
  }
  return true;
}

extern int pseudodfs_cutoff;

template <class Adjlist, class Frontier, bool idempotent = false>
std::atomic<int>* pseudodfs(const Adjlist& graph,
                            typename Adjlist::vtxid_type source) {
  using vtxid_type = typename Adjlist::vtxid_type;
  using edgelist_type = typename Frontier::edgelist_type;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  std::atomic<int>* visited = data::mynew_array<std::atomic<int>>(nb_vertices);
  fill_array_par(visited, nb_vertices, 0);
  auto graph_alias = get_alias_of_adjlist(graph);
  Frontier* frontier = new Frontier(graph_alias);
  frontier->push_back_vertex(source);
  visited[source].store(1);
  auto is_done = [] (Frontier& frontier) {
    return frontier.nb_outedges() == 0;      // later: frontier.empty() may be faster
  };
  auto fork = [] (Frontier& src, Frontier& dst) {
    vtxid_type m = vtxid_type(src.nb_outedges() / 2);
    src.transfer_from_front(dst, m);
  };
  sched::native::parallel_while(*frontier, graph_alias, is_done, fork, [&] (Frontier& frontier) {
    vtxid_type nb_outedges = vtxid_type(frontier.nb_outedges());
    vtxid_type nb_targeted = std::min(vtxid_type(pseudodfs_cutoff), nb_outedges);
    while (nb_targeted > 0) {
      edgelist_type neighbors = frontier.pop_back_edgelist(nb_targeted);
      for (auto i = neighbors.lo; i < neighbors.hi; i++) {
        vtxid_type other = *i;
        if (try_to_mark<vtxid_type, int, idempotent>(visited, other))
          frontier.push_back_vertex(other);
      }
      nb_targeted -= vtxid_type(neighbors.size());
    }
  });
  return visited;
}

/*---------------------------------------------------------------------*/
/* Bader & Cong's adaptive parallel pseudo DFS */

extern int cong_pdfs_cutoff;
static constexpr int max_deque_sz = 60;

template <class Adjlist_seq, class Frontier, bool idempotent = false>
void _cong_pseudodfs(Frontier& frontier,
                     const adjlist<Adjlist_seq>& graph,
                     std::atomic<int>* visited,
                     sched::native::multishot* join) {
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  while (! frontier.empty()) {
    vtxid_type v = frontier.pop_back();
    vtxid_type degree = graph.adjlists[v].get_out_degree();
    vtxid_type* neighbors = graph.adjlists[v].get_out_neighbors();
    for (vtxid_type edge = 0; edge < degree; edge++) {
      vtxid_type other = neighbors[edge];
      if (try_to_mark<vtxid_type, int, idempotent>(visited, other)) {
        int deque_sz = sched::native::my_deque_size();
        auto frontier_sz = frontier.size();
        bool should_spawn =
        (frontier_sz >= cong_pdfs_cutoff)
        ||  ( (deque_sz < max_deque_sz) && (frontier_sz >= (1<<deque_sz)));
        if (should_spawn) {
          Frontier* frontier2 = new Frontier();
          frontier.swap(*frontier2);
          sched::native::async([&] {
            _cong_pseudodfs(*frontier2, graph, visited, join);
          }, join);
        }
        frontier.push_back(other);
      }
    }
  }
  delete &frontier;
}

template <class Adjlist_seq, class Frontier, bool idempotent = false>
std::atomic<int>* cong_pseudodfs(const adjlist<Adjlist_seq>& graph,
                                 typename adjlist<Adjlist_seq>::vtxid_type source) {
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  std::atomic<int>* visited = data::mynew_array<std::atomic<int>>(nb_vertices);
  fill_array_par(visited, nb_vertices, 0);
  return visited; //todo fix this algorithm
  Frontier* frontier = new Frontier();
  frontier->push_back(source);
  visited[source].store(1);
  sched::native::finish([&] (sched::native::multishot* join) {
    _cong_pseudodfs<Adjlist_seq, Frontier, idempotent>(*frontier, graph, visited, join);
  });
  return visited;
}


} // end namespace
} // end namespace

/***********************************************************************/

#endif /*! _PASL_GRAPH_DFS_H_ */
