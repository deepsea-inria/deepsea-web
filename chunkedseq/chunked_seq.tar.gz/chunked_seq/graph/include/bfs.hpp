/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file bfs.hpp
 *
 */

#ifndef _PASL_GRAPH_BFS_H_
#define _PASL_GRAPH_BFS_H_

#include "edgelist.hpp"
#include "adjlist.hpp"
#include "pcontainer.hpp"

/***********************************************************************/

namespace pasl {
namespace graph {

/*---------------------------------------------------------------------*/
/* Breadth first search of a graph in adjacency-list format; serial */

// preallocated array with tokens
template <class Adjlist_seq>
typename adjlist<Adjlist_seq>::vtxid_type*
bfs_by_array(const adjlist<Adjlist_seq>& graph,
             typename adjlist<Adjlist_seq>::vtxid_type source) {
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  vtxid_type* dists = data::mynew_array<vtxid_type>(nb_vertices);
  fill_array_seq(dists, nb_vertices, unknown);
  vtxid_type* queue = data::mynew_array<vtxid_type>(2 * nb_vertices);
  const vtxid_type next_dist_token = vtxid_type(-2); // todo: change to maxint-1
  vtxid_type head = 0;
  vtxid_type tail = 0;
  vtxid_type dist = 0;
  dists[source] = 0;
  queue[tail++] = source;
  queue[tail++] = next_dist_token;
  while (tail - head > 1) {
    vtxid_type vertex = queue[head++];
    if (vertex == next_dist_token) {
      dist++;
      queue[tail++] = next_dist_token;
      continue;
    }
    vtxid_type degree = graph.adjlists[vertex].get_out_degree();
    vtxid_type* neighbors = graph.adjlists[vertex].get_out_neighbors();
    for (vtxid_type edge = 0; edge < degree; edge++) {
      vtxid_type other = neighbors[edge];
      if (dists[other] != unknown)
        continue;
      dists[other] = dist+1;
      queue[tail++] = other;
    }
  }
  free(queue);
  return dists;
}

// dynamic array with tokens
template <class Adjlist_seq, class Fifo>
typename adjlist<Adjlist_seq>::vtxid_type*
bfs_by_dynamic_array(const adjlist<Adjlist_seq>& graph,
                     typename adjlist<Adjlist_seq>::vtxid_type source) {
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  vtxid_type* dists = data::mynew_array<vtxid_type>(nb_vertices);
  fill_array_seq(dists, nb_vertices, unknown);
  Fifo queue;
  const vtxid_type next_dist_token = vtxid_type(-2); // todo: change to maxint-1
  vtxid_type dist = 0;
  dists[source] = 0;
  queue.push_back(source);
  queue.push_back(next_dist_token);
  while (queue.size() > 1) {
    vtxid_type vertex = queue.pop_front();
    if (vertex == next_dist_token) {
      dist++;
      queue.push_back(next_dist_token);
      continue;
    }
    vtxid_type degree = graph.adjlists[vertex].get_out_degree();
    vtxid_type* neighbors = graph.adjlists[vertex].get_out_neighbors();
    for (vtxid_type edge = 0; edge < degree; edge++) {
      vtxid_type other = neighbors[edge];
      if (dists[other] != unknown)
        continue;
      dists[other] = dist+1;
      queue.push_back(other);
    }
  }
  return dists;
}

// preallocated dual arrays
template <class Adjlist_seq>
typename adjlist<Adjlist_seq>::vtxid_type*
bfs_by_dual_arrays(const adjlist<Adjlist_seq>& graph,
                   typename adjlist<Adjlist_seq>::vtxid_type source) {
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  vtxid_type* dists = data::mynew_array<vtxid_type>(nb_vertices);
  fill_array_seq(dists, nb_vertices, unknown);
  vtxid_type* stacks[2];
  stacks[0] = data::mynew_array<vtxid_type>(graph.get_nb_vertices());
  stacks[1] = data::mynew_array<vtxid_type>(graph.get_nb_vertices());
  vtxid_type nbs[2]; // size of the stacks
  nbs[0] = 0;
  nbs[1] = 0;
  vtxid_type cur = 0; // either 0 or 1, depending on parity of dist
  vtxid_type nxt = 1; // either 1 or 0, depending on parity of dist
  vtxid_type dist = 0;
  dists[source] = 1;
  stacks[cur][nbs[cur]++] = source;
  while (nbs[cur] > 0) {
    vtxid_type nb = nbs[cur];
    for (vtxid_type ix = 0; ix < nb; ix++) {
      vtxid_type vertex = stacks[cur][ix];
      vtxid_type degree = graph.adjlists[vertex].get_out_degree();
      vtxid_type* neighbors = graph.adjlists[vertex].get_out_neighbors();
      for (vtxid_type edge = 0; edge < degree; edge++) {
        vtxid_type other = neighbors[edge];
        if (dists[other] != unknown)
          continue;
        dists[other] = dist+1;
        stacks[nxt][nbs[nxt]++] = other;
      }
    }
    nbs[cur] = 0;
    cur = 1 - cur;
    nxt = 1 - nxt;
    dist++;
  }
  free(stacks[0]);
  free(stacks[1]);
  return dists;
}

// dynamic array of vertex ids and foreach loop
template <class Adjlist_seq, class Frontier>
typename adjlist<Adjlist_seq>::vtxid_type*
bfs_by_dual_frontiers_and_foreach(const adjlist<Adjlist_seq>& graph,
                                  typename adjlist<Adjlist_seq>::vtxid_type source) {
#ifdef GRAPH_SEARCH_STATS
  peak_frontier_size = 0l;
#endif
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  vtxid_type* dists = data::mynew_array<vtxid_type>(nb_vertices);
  fill_array_seq(dists, nb_vertices, unknown);
  Frontier prev;
  Frontier next;
  prev.push_back(source);
  dists[source] = 0;
  vtxid_type dist = 0;
  while (! prev.empty()) {
    prev.for_each([&graph,dists,&prev,&next,dist,unknown] (vtxid_type _ix, vtxid_type vertex) {
      vtxid_type degree = graph.adjlists[vertex].get_out_degree();
      vtxid_type* neighbors = graph.adjlists[vertex].get_out_neighbors();
      for (vtxid_type edge = 0; edge < degree; edge++) {
        vtxid_type other = neighbors[edge];
        if (dists[other] != unknown)
          continue;
        dists[other] = dist+1;
        next.push_back(other);
      }
    } );
    prev.clear();
    next.swap(prev);
    dist++;
#ifdef GRAPH_SEARCH_STATS
    peak_frontier_size = std::max((size_t)frontier.size(), peak_frontier_size);
#endif
  }
  return dists;
}

// dynamic array of vertex ids and push/pop
template <class Adjlist_seq, class Frontier>
typename adjlist<Adjlist_seq>::vtxid_type*
bfs_by_dual_frontiers_and_pushpop(const adjlist<Adjlist_seq>& graph,
                                  typename adjlist<Adjlist_seq>::vtxid_type source) {
  using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
  vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  vtxid_type* dists = data::mynew_array<vtxid_type>(nb_vertices);
  fill_array_seq(dists, nb_vertices, unknown);
  Frontier prev;
  Frontier next;
  prev.push_back(source);
  dists[source] = 0;
  vtxid_type dist = 0;
  while (! prev.empty()) {
    while (! prev.empty()) {
      vtxid_type vertex = prev.pop_back(); // use pop_front for same order as bfs with deque
      vtxid_type degree = graph.adjlists[vertex].get_out_degree();
      vtxid_type* neighbors = graph.adjlists[vertex].get_out_neighbors();
      for (vtxid_type edge = 0; edge < degree; edge++) {
        vtxid_type other = neighbors[edge];
        if (dists[other] != unknown)
          continue;
        dists[other] = dist+1;
        next.push_back(other);
      }
    }
    next.swap(prev);
    dist++;
  }
  return dists;
}

// frontier_segment representation of the frontier
template <class Adjlist, class Frontier>
typename Adjlist::vtxid_type*
bfs_by_frontier_segment(const Adjlist& graph,
                        typename Adjlist::vtxid_type source) {
  using vtxid_type = typename Adjlist::vtxid_type;
  using edgelist_type = typename Frontier::edgelist_type;
  vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
  vtxid_type nb_vertices = graph.get_nb_vertices();
  vtxid_type* dists = data::mynew_array<vtxid_type>(nb_vertices);
  fill_array_seq(dists, nb_vertices, unknown);
  auto graph_alias = get_alias_of_adjlist(graph);
  Frontier prev(graph_alias);
  Frontier next(graph_alias);
  prev.push_back_vertex(source);
  dists[source] = 1;
  vtxid_type dist = 0;
  while (! prev.empty()) {
    prev.for_each([dist,dists,&prev,&next,unknown] (edgelist_type outs) {
      for (auto i = outs.lo; i < outs.hi; i++) {
        vtxid_type out = *i;
        if (dists[out] != unknown)
          continue;
        dists[out] = dist+1;
        next.push_back_vertex(out);
      }
    });
    prev.clear();
    next.swap(prev);
    dist++;
  }
  return dists;
}

/*---------------------------------------------------------------------*/
/* Breadth-first search of a graph in adjacency-list format; parallel */

extern int pbfs_cutoff;

// parallel BFS using Shardl and Leiserson's algorithm
template <bool idempotent = false>
class pbfs {
public:
  
  using idempotent_pbfs = pbfs<true>;
  
  template <class Index, class Item>
  static bool try_to_set_dist(Index target,
                              Item unknown, Item dist,
                              std::atomic<Item>* dists) {
    if (dists[target].load(std::memory_order_relaxed) != unknown)
      return false;
    if (idempotent)
      dists[target].store(dist, std::memory_order_relaxed);
    else if (! dists[target].compare_exchange_strong(unknown, dist))
      return false;
    return true;
  }
  
  template <class Adjlist_seq, class Frontier>
  static void process_layer(const adjlist<Adjlist_seq>& graph,
                            std::atomic<typename adjlist<Adjlist_seq>::vtxid_type>* dists,
                            typename adjlist<Adjlist_seq>::vtxid_type dist_of_next,
                            typename adjlist<Adjlist_seq>::vtxid_type source,
                            Frontier& prev,
                            Frontier& next) {
    using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
    using size_type = typename Frontier::size_type;
    vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
    auto cutoff = [] (Frontier& f) {
      return f.size() <= vtxid_type(pbfs_cutoff);
    };
    auto split = [] (Frontier& src, Frontier& dst) {
      src.split_approximate(dst);
    };
    auto append = [] (Frontier& src, Frontier& dst) {
      src.transfer_to_back(dst);
    };
    sched::native::reduce(prev, next, cutoff, split, append, [&] (Frontier& prev, Frontier& next) {
      prev.for_each([&] (size_type _i, vtxid_type vertex) {
        vtxid_type degree = graph.adjlists[vertex].get_out_degree();
        vtxid_type* neighbors = graph.adjlists[vertex].get_out_neighbors();
        data::pcontainer::tabulate(vtxid_type(0), degree, next, [&] (vtxid_type edge, Frontier& next) {
          vtxid_type other = neighbors[edge];
          if (try_to_set_dist(other, unknown, dist_of_next, dists))
            next.push_back(other);
        });
      });
      prev.clear();
    });
  }
  
  template <class Adjlist_seq, class Frontier>
  static std::atomic<typename adjlist<Adjlist_seq>::vtxid_type>*
  main(const adjlist<Adjlist_seq>& graph,
       typename adjlist<Adjlist_seq>::vtxid_type source) {
#ifdef GRAPH_SEARCH_STATS
  peak_frontier_size = 0l;
#endif
    using vtxid_type = typename adjlist<Adjlist_seq>::vtxid_type;
    using size_type = typename Frontier::size_type;
    vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
    vtxid_type nb_vertices = graph.get_nb_vertices();
    std::atomic<vtxid_type>* dists = data::mynew_array<std::atomic<vtxid_type>>(nb_vertices);
    fill_array_par(dists, nb_vertices, unknown);
    Frontier prev;
    Frontier next;
    vtxid_type dist = 0;
    prev.push_back(source);
    dists[source].store(dist);
    while (! prev.empty()) {
      dist++;
      if (prev.size() <= pbfs_cutoff)
        idempotent_pbfs::process_layer(graph, dists, dist, source, prev, next);
      else
        process_layer(graph, dists, dist, source, prev, next);
      prev.swap(next);
#ifdef GRAPH_SEARCH_STATS
    peak_frontier_size = std::max((size_t)prev.size(), peak_frontier_size);
#endif
    }
    return dists;
  }
  
};

extern int fpbfs_cutoff;

// parallel BFS using our frontier-segment-based algorithm
template <bool idempotent = false>
class fpbfs {
public:
  
  using idempotent_fpbfs = fpbfs<true>;
  
  template <class Adjlist, class Frontier>
  static void process_layer(const Adjlist& graph,
                            std::atomic<typename Adjlist::vtxid_type>* dists,
                            typename Adjlist::vtxid_type& dist_of_next,
                            typename Adjlist::vtxid_type source,
                            Frontier& prev,
                            Frontier& next) {
    using vtxid_type = typename Adjlist::vtxid_type;
    using size_type = typename Frontier::size_type;
    using edgelist_type = typename Frontier::edgelist_type;
    vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
    auto cutoff = [] (Frontier& f) {
      return f.nb_outedges() <= vtxid_type(fpbfs_cutoff);
    };
    auto split = [] (Frontier& src, Frontier& dst) {
      src.transfer_from_back(dst, src.nb_outedges() / 2);
    };
    auto append = [] (Frontier& src, Frontier& dst) {
      src.transfer_to_back(dst);
    };
    auto graph_alias = get_alias_of_adjlist(graph);
    sched::native::reduce(prev, next, graph_alias, graph_alias, cutoff, split, append,
                          [&] (Frontier& prev, Frontier& next) {
      prev.for_each([&] (edgelist_type outedges) {
        for (auto i = outedges.lo; i < outedges.hi; i++) {
          vtxid_type other = *i;
          if (pbfs<idempotent>::try_to_set_dist(other, unknown, dist_of_next, dists))
            next.push_back_vertex(other);
        }
      });
      prev.clear();
    });
  }
  
  template <class Adjlist, class Frontier>
  static std::atomic<typename Adjlist::vtxid_type>*
  main(const Adjlist& graph,
       typename Adjlist::vtxid_type source) {
    using vtxid_type = typename Adjlist::vtxid_type;
    using size_type = typename Frontier::size_type;
    vtxid_type unknown = graph_constants<vtxid_type>::unknown_vtxid;
    vtxid_type nb_vertices = graph.get_nb_vertices();
    std::atomic<vtxid_type>* dists = data::mynew_array<std::atomic<vtxid_type>>(nb_vertices);
    fill_array_par(dists, nb_vertices, unknown);
    auto graph_alias = get_alias_of_adjlist(graph);
    Frontier prev(graph_alias);
    Frontier next(graph_alias);
    prev.push_back_vertex(source);
    vtxid_type dist = 0;
    dists[source].store(dist);
    while (! prev.empty()) {
      dist++;
      if (prev.nb_outedges() <= pbfs_cutoff)
        idempotent_fpbfs::process_layer(graph, dists, dist, source, prev, next);
      else
        process_layer(graph, dists, dist, source, prev, next);
      prev.swap(next);
    }
    return dists;
  }
  
};

} // end namespace
} // end namespace

/***********************************************************************/

#endif /*! _PASL_GRAPH_BFS_H_ */
