/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file tests.cpp
 *
 */

#include "graphgenerators.hpp"
#include "quickcheck.hh"
#include "frontiersegment.hpp"
#include "graphconversions.hpp"
#include "bfs.hpp"
#include "dfs.hpp"
#include "benchmark.hpp"

namespace pasl {
namespace graph {
  
/***********************************************************************/
  
using namespace data;

template <class Item, class Size, class Op>
Item reduce_std_atomic(std::atomic<Item>* array, Size sz, const Op& op) {
  auto get_from_array = [&] (Size i) {
    return array[i].load();
  };
  return pbbs::sequence::reduce<int>(Size(0), sz, op, get_from_array);
}

  /*
auto add2_atomic = [] (const std::atomic<int>& a, const std::atomic<int>& b) {
  return a.load() + b.load();
};
   */

template <class Size, class Values_equal,
class Array1, class Array2,
class Get_value1, class Get_value2>
bool same_arrays(Size sz,
                 Array1 array1, Array2 array2,
                 const Get_value1& get_value1, const Get_value2& get_value2,
                 const Values_equal& equals) {
  for (Size i = 0; i < sz; i++)
    if (! equals(get_value1(array1, i), get_value2(array2, i)))
      return false;
  return true;
}
  
/*---------------------------------------------------------------------*/

template <class Container>
class prop_for_each_correct : public quickcheck::Property<Container> {
public:
  
  using container_type = Container;
  using value_type = typename container_type::value_type;
  using size_type = typename container_type::size_type;
  
  bool holdsFor(const container_type& _cont) {
    container_type cont(_cont);
    pcontainer::for_each(cont, [] (value_type& v) {
      v++;
    });
    for (size_type i = 0; i < cont.size(); i++)
      if (_cont[i] != cont[i] + 1)
        return false;
    return true;
  }
  
};
  
/*---------------------------------------------------------------------*/
/* Graph format conversion */

template <class Edgelist, class Adjlist>
class prop_graph_format_conversion_identity : public quickcheck::Property<Edgelist> {
public:
  
  using edgelist_type = Edgelist;
  using adjlist_type = Adjlist;
  
  bool holdsFor(const edgelist_type& graph) {
    adjlist_type adj;
    adjlist_from_edgelist(graph, adj);
    edgelist_type edg;
    edgelist_from_adjlist(adj, edg);
    return edg == graph;
  }
  
};

void check_conversion() {
  int nb = 1000;
  
  using vtxid_type = int;
  
  using edge_type = edge<vtxid_type>;
  using edgelist_bag_type = data::stl::vector_seq<edge_type>;
  using edgelist_type = edgelist<edgelist_bag_type>;
  
  using adjlist_seq_type = flat_adjlist_seq<vtxid_type>;
  using adjlist_type = adjlist<adjlist_seq_type>;
  
  std::cout << "conversion" << std::endl;
  prop_graph_format_conversion_identity<edgelist_type, adjlist_type> prop;
  prop.check(nb);
}
  
/*---------------------------------------------------------------------*/
/* Graph search */

template <class Adjlist, class Search_trusted, class Search_to_test,
class Get_value1, class Get_value2,
class Res>
class prop_search_same : public quickcheck::Property<Adjlist> {
public:
  
  using adjlist_type = Adjlist;
  using vtxid_type = typename adjlist_type::vtxid_type;
  
  Search_trusted search_trusted;
  Search_to_test search_to_test;
  Get_value1 get_value1;
  Get_value2 get_value2;
  
  prop_search_same(const Search_trusted& search_trusted,
                   const Search_to_test& search_to_test,
                   const Get_value1& get_value1,
                   const Get_value2& get_value2)
  : search_trusted(search_trusted), search_to_test(search_to_test),
  get_value1(get_value1), get_value2(get_value2) { }
  
  bool holdsFor(const adjlist_type& graph) {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    vtxid_type source;
    quickcheck::generate(std::max(vtxid_type(0), nb_vertices-1), source);
    source = std::abs(source);
    auto res_trusted = search_trusted(graph, source);
    auto res_to_test = search_to_test(graph, source);
    if (res_trusted == NULL || res_to_test == NULL)
      return true;
    bool success = same_arrays(nb_vertices, res_trusted, res_to_test,
                               get_value1, get_value2,
                               [] (Res x, Res y) {return x == y;});
    return success;
  }
  
};
  
/*---------------------------------------------------------------------*/
/* BFS */

template <class Adjlist_seq>
void check_bfs() {
  using adjlist_type = adjlist<Adjlist_seq>;
  using vtxid_type = typename adjlist_type::vtxid_type;
  using fftree_type = pcontainer::bag<vtxid_type>;
  using adjlist_alias_type = typename adjlist_type::alias_type;
  using frontier_segment_type = pasl::data::frontier_segment<adjlist_alias_type>;
  
  pbfs_cutoff = 16;
  
  int nb_check = 1000;
  
  auto trusted_bfs = [&] (const adjlist_type& graph, vtxid_type source) -> vtxid_type* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return NULL;
    return bfs_by_array(graph, source);
  };
  
  auto by_dynamic_array = [&] (const adjlist_type& graph, vtxid_type source) -> vtxid_type* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return NULL;
    return bfs_by_dynamic_array<Adjlist_seq, data::stl::deque_seq<vtxid_type>>(graph, source);
  };
  
  auto by_dual_arrays = [&] (const adjlist_type& graph, vtxid_type source) -> vtxid_type* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return NULL;
    return bfs_by_dual_arrays(graph, source);
  };
  
  auto by_dual_frontiers_and_pushpop = [&] (const adjlist_type& graph, vtxid_type source) -> vtxid_type* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return NULL;
    return bfs_by_dual_frontiers_and_pushpop<Adjlist_seq, data::stl::vector_seq<vtxid_type>>(graph, source);
  };
  
  auto by_dual_frontiers_and_foreach = [&] (const adjlist_type& graph, vtxid_type source) -> vtxid_type* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return NULL;
    return bfs_by_dual_frontiers_and_foreach<Adjlist_seq, data::stl::vector_seq<vtxid_type>>(graph, source);
  };
  
  auto by_frontier_segment = [&] (const adjlist_type& graph, vtxid_type source) -> vtxid_type* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return NULL;
    return bfs_by_frontier_segment<adjlist_type, frontier_segment_type>(graph, source);
  };
  
  auto by_pbfs = [&] (const adjlist_type& graph, vtxid_type source) -> std::atomic<vtxid_type>* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return NULL;
    return pbfs<false>::main<Adjlist_seq, fftree_type>(graph, source);
  };
  
  auto by_fpbfs = [&] (const adjlist_type& graph, vtxid_type source) -> std::atomic<vtxid_type>* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return NULL;
    return fpbfs<false>::main<adjlist_type, frontier_segment_type>(graph, source);
  };
  
  auto get_visited_seq = [] (vtxid_type* dists, vtxid_type i) {
    return (dists[i] != graph_constants<vtxid_type>::unknown_vtxid) ? 1 : 0;
  };
  
  auto get_visited_par = [] (std::atomic<vtxid_type>* dists, vtxid_type i) {
    vtxid_type dist = dists[i].load();
    return (dist != graph_constants<vtxid_type>::unknown_vtxid) ? 1 : 0;
  };
  
  std::cout << "prop_fpbfs" << std::endl;
  using prop_fpbfs =
  prop_search_same<adjlist_type, typeof(trusted_bfs), typeof(by_fpbfs),
  typeof(get_visited_seq), typeof(get_visited_par), vtxid_type>;
  prop_fpbfs (trusted_bfs, by_fpbfs, get_visited_seq, get_visited_par).check(nb_check);
  
  std::cout << "prop_by_dynamic_array" << std::endl;
  using prop_by_dynamic_array =
  prop_search_same<adjlist_type, typeof(trusted_bfs), typeof(by_dynamic_array),
  typeof(get_visited_seq), typeof(get_visited_seq), vtxid_type>;
  prop_by_dynamic_array (trusted_bfs, by_dynamic_array, get_visited_seq, get_visited_seq).check(nb_check);
  
  std::cout << "prop_by_dual_arrays" << std::endl;
  using prop_by_dual_arrays =
  prop_search_same<adjlist_type, typeof(trusted_bfs), typeof(by_dual_arrays),
  typeof(get_visited_seq), typeof(get_visited_seq), vtxid_type>;
  prop_by_dual_arrays (trusted_bfs, by_dual_arrays, get_visited_seq, get_visited_seq).check(nb_check);
  
  std::cout << "prop_by_dual_frontiers_and_foreach" << std::endl;
  using prop_by_dual_frontiers_and_foreach =
  prop_search_same<adjlist_type, typeof(trusted_bfs), typeof(by_dual_frontiers_and_foreach),
  typeof(get_visited_seq), typeof(get_visited_seq), vtxid_type>;
  prop_by_dual_frontiers_and_foreach (trusted_bfs, by_dual_frontiers_and_foreach,
                                      get_visited_seq, get_visited_seq).check(nb_check);
  
  std::cout << "prop_by_dual_frontiers_and_pushpop" << std::endl;
  using prop_by_dual_frontiers_and_pushpop =
  prop_search_same<adjlist_type, typeof(trusted_bfs), typeof(by_dual_frontiers_and_pushpop),
  typeof(get_visited_seq), typeof(get_visited_seq), vtxid_type>;
  prop_by_dual_frontiers_and_pushpop (trusted_bfs, by_dual_frontiers_and_pushpop,
                                      get_visited_seq, get_visited_seq).check(nb_check);
  
  std::cout << "prop_by_frontier_segment" << std::endl;
  using prop_by_frontier_segment =
  prop_search_same<adjlist_type, typeof(trusted_bfs), typeof(by_frontier_segment),
  typeof(get_visited_seq), typeof(get_visited_seq), vtxid_type>;
  prop_by_frontier_segment (trusted_bfs, by_frontier_segment,
                            get_visited_seq, get_visited_seq).check(nb_check);
  
  
  std::cout << "prop_pbfs" << std::endl;
  using prop_pbfs =
  prop_search_same<adjlist_type, typeof(trusted_bfs), typeof(by_pbfs),
  typeof(get_visited_seq), typeof(get_visited_par), vtxid_type>;
  prop_pbfs (trusted_bfs, by_pbfs, get_visited_seq, get_visited_par).check(nb_check);
  
}
  
/*---------------------------------------------------------------------*/
/* DFS */

template <class Adjlist_seq>
void check_dfs() {
  using adjlist_type = adjlist<Adjlist_seq>;
  using vtxid_type = typename adjlist_type::vtxid_type;
  using adjlist_alias_type = typename adjlist_type::alias_type;
  using frontier_segment_type = pasl::data::frontier_segment<adjlist_alias_type>;
  
  int nb_check = 1000;
  
  auto trusted_dfs = [&] (const adjlist_type& graph, vtxid_type source) -> int* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return 0;
    return dfs_by_vertexid_array(graph, source);
  };
  
  auto by_vertexid_frontier = [&] (const adjlist_type& graph, vtxid_type source) -> int* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return 0;
    return dfs_by_vertexid_frontier<Adjlist_seq, data::stl::vector_seq<vtxid_type>>(graph, source);
  };
  
  auto by_frontier_segment = [&] (const adjlist_type& graph, vtxid_type source) -> int* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return 0;
    return dfs_by_frontier_segment<adjlist_type, frontier_segment_type>(graph, source);
  };
  
  auto by_pseudodfs = [&] (const adjlist_type& graph, vtxid_type source) -> std::atomic<int>* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return 0;
    return pseudodfs<adjlist_type, frontier_segment_type>(graph, source);
  };
  
  auto by_cong_pseudodfs = [&] (const adjlist_type& graph, vtxid_type source) -> std::atomic<int>* {
    vtxid_type nb_vertices = graph.get_nb_vertices();
    if (nb_vertices == 0)
      return 0;
    return cong_pseudodfs<Adjlist_seq, data::stl::vector_seq<vtxid_type>>(graph, source);
  };
  
  auto get_visited_seq = [] (int* visited, vtxid_type i) {
    return visited[i];
  };
  
  auto get_visited_par = [] (std::atomic<int>* visited, vtxid_type i) {
    return visited[i].load();
  };
  
  std::cout << "prop_by_dynamic_array" << std::endl;
  using prop_by_vertexid_frontier =
  prop_search_same<adjlist_type, typeof(trusted_dfs), typeof(by_vertexid_frontier),
  typeof(get_visited_seq), typeof(get_visited_seq), int>;
  prop_by_vertexid_frontier (trusted_dfs, by_vertexid_frontier,
                             get_visited_seq, get_visited_seq).check(nb_check);
  
  std::cout << "prop_by_frontier_segment" << std::endl;
  using prop_by_frontier_segment =
  prop_search_same<adjlist_type, typeof(trusted_dfs), typeof(by_frontier_segment),
  typeof(get_visited_seq), typeof(get_visited_seq), int>;
  prop_by_frontier_segment (trusted_dfs, by_frontier_segment,
                            get_visited_seq, get_visited_seq).check(nb_check);
  
  std::cout << "prop_by_pseudodfs" << std::endl;
  using prop_by_pseudodfs =
  prop_search_same<adjlist_type, typeof(trusted_dfs), typeof(by_pseudodfs),
  typeof(get_visited_seq), typeof(get_visited_par), int>;
  prop_by_pseudodfs (trusted_dfs, by_pseudodfs,
                     get_visited_seq, get_visited_par).check(nb_check);
  
  std::cout << "prop_by_cong_pseudodfs" << std::endl;
  using prop_by_cong_pseudodfs =
  prop_search_same<adjlist_type, typeof(trusted_dfs), typeof(by_cong_pseudodfs),
  typeof(get_visited_seq), typeof(get_visited_par), int>;
  prop_by_cong_pseudodfs (trusted_dfs, by_cong_pseudodfs,
                          get_visited_seq, get_visited_par).check(nb_check);
}
  
/*---------------------------------------------------------------------*/
/* IO */

template <class Adjlist>
class prop_file_io_preserves_adjlist : public quickcheck::Property<Adjlist> {
public:
  
  using adjlist_type = Adjlist;
  using vtxid_type = typename adjlist_type::vtxid_type;
  
  bool holdsFor(const adjlist_type& graph) {
    std::string fname = "foobar.bin";
    write_adjlist_to_file(fname, graph);
    adjlist_type graph2;
    read_adjlist_from_file(fname, graph2);
    bool success = graph == graph2;
    graph.check();
    graph2.check();
    return success;
  }
  
};

template <class Vertex_id>
void check_io() {
  using vtxid_type = Vertex_id;
  using adjlist_seq_type = flat_adjlist_seq<vtxid_type>;
  using adjlist_type = adjlist<adjlist_seq_type>;
  
  int nb = 1000;
  
  std::cout << "file io" << std::endl;
  prop_file_io_preserves_adjlist<adjlist_type> prop;
  prop.check(nb);
}

int cong_pdfs_cutoff = 1000;
int pseudodfs_cutoff = 1000;
int pbfs_cutoff = 1000;
int fpbfs_cutoff = 1000;
  
} // end namespace
} // end namespace

/*---------------------------------------------------------------------*/

int main(int argc, char ** argv) {
  using vtxid_type = long;
  using adjlist_seq_type = pasl::graph::flat_adjlist_seq<vtxid_type>;
  
  auto init = [&] {
    
  };
  auto run = [&] (bool sequential) {
    pasl::graph::check_dfs<adjlist_seq_type>();
    pasl::graph::check_bfs<adjlist_seq_type>();
    pasl::graph::check_io<vtxid_type>();
    pasl::graph::check_conversion();
  };
  auto output = [&] {
    std::cout << "All tests complete" << std::endl;
  };
  auto destroy = [&] {
    ;
  };
  pasl::sched::launch(argc, argv, init, run, output, destroy);

  return 0;
}

/***********************************************************************/

