/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file cmdline.cpp
 * \brief Command-line parsing routines
 *
 */

#include <string.h>
#include <utility>
#include <stdio.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>
// NEW: remove useless includes

#include "cmdline.hpp"

namespace pasl {
namespace util {
namespace cmdline {

/***********************************************************************/
/* Command line arguments */

int global_argc = -1;
char** global_argv;

void set(int argc, char** argv)
{
  global_argc = argc;
  global_argv = argv;
}

std::string name_of_my_executable() {
  return std::string(global_argv[0]);
}

/*---------------------------------------------------------------------*/
/* Auxiliary failure functions */

static void failure()
{
   printf("sError illegal command line\n");
   exit(-1);
}

static void check_set() 
{
  if (global_argc == -1) {
    printf("you must call cmdline::set(argc,argv) in your main.");
    exit(-1);
  }
}

static void check (std::string name, bool result) 
{
  if (! result) {
     printf("missing command line argument %s\n", name.c_str());
     exit(-1);
  }
}

/*---------------------------------------------------------------------*/
/* Supported type of arguments */

typedef enum {
  INT,
  UINT64,
  FLOAT,
  DOUBLE,
  CHARS,
  STRING,
  BOOL,
  /* could add support for:
  INT32,
  INT64,
  UINT32,
  UINT64,
  */
} type_t;


/* Parsing of one value of a given type into a given address */

static void parse_value(type_t type, void* dest, char* arg_value)
{
  switch (type)
  {
    case INT: {
      int* vi = (int*) dest;
      *vi = atoi(arg_value);
      break; }
    case UINT64: {
      uint64_t* vi = (uint64_t*) dest;
      sscanf(arg_value, "%llu", vi);
      break; }
    case BOOL: {
      bool* vb = (bool*) dest;
      *vb = (atoi(arg_value) != 0);
      break; }
    case DOUBLE: {
      double* vf = (double*) dest;
      *vf = atof(arg_value);
      break; }
    case CHARS: {
      char* vs = (char*) dest;
      strcpy(vs, arg_value);
      break; }
    case STRING: {
      std::string* vs = (std::string*) dest;
      *vs = std::string(arg_value);
      break; }
    default: {
      printf("not yet supported");
      exit(-1); }
  }
}

static bool parse(type_t type, std::string name, void* dest) 
{ 
  check_set();  
  for (int a = 1; a < global_argc; a++)  
  {
    if (*(global_argv[a]) != '-') 
      failure();
    char* arg_name = global_argv[a] + 1;
    if (arg_name[0] == '-') {
      if (name.compare(arg_name+1) == 0) {
        *((bool*) dest) = 1;
        return true;
      }
    } else {
      a++;
      if (a >= global_argc) 
        failure();
      char* arg_value = global_argv[a];
      //printf("%s %s\n", arg_name, arg_value);
      if (name.compare(arg_name) == 0) {
        parse_value(type, dest, arg_value);
        return true;
      }
    }
  }
  return false;
}

/*---------------------------------------------------------------------*/
/* Specific parsing functions */

bool parse_bool(std::string name) {
  bool r;
  check (name, parse(BOOL, name, &r));
  return r;
}

int parse_int(std::string name) {
  int r;
  check (name, parse(INT, name, &r));
  return r;
}

int parse_uint64(std::string name) {
  int r;
  check (name, parse(UINT64, name, &r));
  return r;
}

double parse_double(std::string name) {
  double r;
  check (name, parse(DOUBLE, name, &r));
  return r;
}

std::string parse_string(std::string name) {
  std::string r;
  check (name, parse(STRING, name, &r));
  return r;
}

/*---------------------------------------------------------------------*/
/* Specific parsing functions with default values */

bool parse_or_default_bool(std::string name, bool d) {
  bool r;
  if (parse(BOOL, name, &r))
    return r; 
  else 
    return d;
}

int parse_or_default_int(std::string name, int d) {
  int r;
  if (parse(INT, name, &r))
    return r;
  else
    return d;
}

uint64_t parse_or_default_uint64(std::string name, uint64_t d) {
  uint64_t r;
  if (parse(UINT64, name, &r))
    return r;
  else
    return d;
}

double parse_or_default_double(std::string name, double d) {
  double r;
  if (parse(DOUBLE, name, &r))
    return r;
  else
    return d;
}

std::string parse_or_default_string(std::string name, std::string d) {
  std::string r;
  if (parse(STRING, name, &r))
    return r;
  else
    return d;
}

/*---------------------------------------------------------------------*/
/* Could add support for parsing several arguments 

class arg_t {
  string name;
  type_t type;
  void* dest;
  arg_t(string name, type_t type, void* dest) 
    : name(name), type(type), dest(dest) {}
};

void parse_several(vector<arg_t*> args) 
{
  for (vector<arg_t*>::iterator it = args.begin(); it != args.end(); it++) {
    arg_t* arg = *it;
    parse(arg->name, arg->type, arg->dest);
  }
}
*/

/***********************************************************************/

} // end namespace
} // end namespace
} // end namespace

