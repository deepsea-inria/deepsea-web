/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file control.hpp
 * \brief Control operators
 *
 */

#include <signal.h>
#include <cstdlib>
#include <assert.h>

namespace pasl {
namespace util {
namespace control {
  
/***********************************************************************/
  
#if defined(TARGET_MAC_OS) || defined(USE_UCONTEXT)
  
  // on MAC OS need to define _XOPEN_SOURCE to access setcontext
#include <ucontext.h>
  
  struct context_struct {
    ucontext_t cxt;
    void* val;
  };
  
  using context_type = struct context_struct;
  
  using context_pointer = context_type*;
  
  static inline context_pointer addr(context_type& r) {
    return &r;
  }
  
  template <class Value>
  Value capture(context_pointer cxt) {
    cxt->val = NULL;
    getcontext(&(cxt->cxt));
    return (Value)(cxt->val);
  }
  
  template <class Value>
  void throw_to(context_pointer cxt, Value val) {
    cxt->val = (Value)val;
    setcontext(&(cxt->cxt));
  }
  
  template <class Value>
  void swap(context_pointer cxt1,
            context_pointer cxt2,
            Value val2) {
    cxt2->val = val2;
    swapcontext(&(cxt1->cxt), &(cxt2->cxt));
  }
  
  template <class Value>
  char* spawn(context_pointer cxt, Value val) {
    char* stack = (char*)malloc(SIGSTKSZ);
    getcontext(&(cxt->cxt));
    cxt->cxt.uc_link = NULL;
    cxt->cxt.uc_stack.ss_sp = stack;
    cxt->cxt.uc_stack.ss_size = SIGSTKSZ;
    makecontext(&(cxt->cxt), (void (*)(void)) val->enter, 1, val);
    return stack;
  }
  
#else
  
  typedef char context_type[8*8];
  typedef char* context_pointer;
  
  extern "C" void* _pasl_cxt_save(context_pointer cxt);
  extern "C" void _pasl_cxt_restore(context_pointer cxt, void* t);
  
  template <class X>
  context_pointer addr(X r) {
    return r;
  }
  
  template <class Value>
  void throw_to(context_pointer cxt, Value val) {
    _pasl_cxt_restore(cxt, (void*)val);
  }
  
  template <class Value>
  void swap(context_pointer cxt1,
            context_pointer cxt2,
            Value val2) {
    if (_pasl_cxt_save(cxt1))
      return;
    _pasl_cxt_restore(cxt2, val2);
  }
  
// register number 6
#define _X86_64_SP_OFFSET   6
  
  template <class Value>
  Value capture(context_pointer cxt) {
    void* r = _pasl_cxt_save(cxt);
    return (Value)r;
  }
  
  template <class Value>
  char* spawn(context_pointer cxt, Value val) {
    Value target;
    if (target = (Value)_pasl_cxt_save(cxt)) {
      target->enter(target);
      assert(false);
    }
    char* stack = (char*)malloc(SIGSTKSZ);
    void** _cxt = (void**)cxt;
    _cxt[_X86_64_SP_OFFSET] = &stack[SIGSTKSZ];
    return stack;
  }
  
#endif
  
  context_pointer my_cxt();
  
/***********************************************************************/
  
} // end namespace
} // end namespace
} // end namespace
