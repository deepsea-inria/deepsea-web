open Shared
open Benchmark
open Printf
open Results
open Custom



(*********************************************************)

let latex_escape r =
   let r = Str.global_replace (Str.regexp "_") "-" r in
   let r = Str.global_replace (Str.regexp "%") "\\%" r in
   r

let latex_escapes rs = 
  List.map latex_escape rs

let remove_data_slash s =
   if string_starts_with "data/" s 
      then Str.string_after s 5 
      else s

let title_of_results_input_data_ignoring ignored results =
  let (data,inputs) = List.hd results in
  let inputs = list_substract inputs ignored in
  string_of_list "," (fun (k,v) -> if List.mem k inputs then sprintf "%s=%s" k v else "") data


let rec list_contain_before x1 x2 = function
  | [] -> 0
  | x::l -> if x = x1 then -1 else 
            if x = x2 then 1 else
            list_contain_before x1 x2 l



let mode_default add_chart results = 
  failwith "please specify a mode"


let mode_steal_cst_by xkey add_chart resultsA =
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true "steals/(proc-1)/fork_depth";
      scatter_xaxis = axis ~islog:true xkey;
      scatter_mathcurves = [Mathcurve_abline(2.68,0.)]; } 
      in
  if (not (list_for_all resultsA (fun r -> (get "fork_depth" r) > 0.)))
     then failwith "non positive fork_depth";
  (*msg (sprintf "nbA = %d\n" (List.length resultsA));*)
  let resultsF = list_filter resultsA (fun r -> (get "proc" r) > 1.) in
  graph_by [(*"proc"*)] add_chart scatter resultsF (fun resultsG add_curve ->
  (*msg (sprintf "nbG = %d\n" (List.length resultsG));*)
  curve_by_not [xkey] add_curve resultsG (fun resultsC add_point ->
  (*msg (sprintf "nbC = %d\n" (List.length resultsG));*)
  point_by xkey add_point resultsC (fun resultsP ->
  (* msg (sprintf "nbP = %d\n" (List.length resultsP)); *)
  average resultsP (fun r -> 
     (get "task_send" r) /. (get "proc" r -. 1.) /. (get "fork_depth" r)
  ))))


let mode_idle_per_steal add_chart resultsA =
   let scatter = { scatter_default with
      scatter_yaxis = axis ~islog:true ~iszero:true "total_idle_time/steals";
      scatter_xaxis = axis ~islog:true ~iszero:true "delta";
      scatter_mathcurves = [Mathcurve_abline(0.,1.)]; } 
      in
  let resultsF = list_filter resultsA (fun r -> (get "task_send" r) > 0.) in
  graph_by [(*"proc"*)] add_chart scatter resultsF (fun resultsG add_curve ->
  curve_by_not ["delta"] add_curve resultsG (fun resultsC add_point ->
  point_by "delta" add_point resultsC (fun resultsP ->
  average resultsP (fun r -> 
     1000000. *. (get "total_idle_time" r) /. (get "task_send" r) (* /. (get "delta" r)*)
  ))))


let not_cilk_result r =
   not (string_ends_with ".cilk" (get_string "prog" r))

let not_opt_result r =
   not (string_ends_with ".opt" (get_string "prog" r))

let basename_of_prog prog = 
   let progname_found = Str.string_match (Str.regexp "examples/\\(.*\\)\\.\\([^.]\\)") prog 0 in
   if not progname_found then failwith "program name needs to be of the form examples/foo.sta";
   let progname = Str.matched_group 1 prog in
   progname

let cilk_for_results results =
   let prog = get_string_of_set "prog" results in
   (*printf "%s\n" prog;*)
   let progname = basename_of_prog prog in
   let progcilk = sprintf "cilk/%s.cilk" progname in
   progcilk

let opt_for_results results =
   let prog = get_string_of_set "prog" results in
   (*printf "%s\n" prog;*)
   let progname = basename_of_prog prog in
   let progopt = sprintf "examples/%s.opt" progname in
   progopt


let mode_sched_vs_cilk_by xkey add_chart resultsA =
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true "exectime / cilk_exectime";
      scatter_xaxis = axis ~iszero:true xkey;
      scatter_mathcurves = [Mathcurve_abline(1.,0.)]; } 
      in
  graph_by [] add_chart scatter resultsA (fun resultsG add_curve ->
  let resultsB = list_filter resultsG (fun r -> not_cilk_result r) in
  curve_by_not [xkey] add_curve resultsB (fun resultsC add_point ->
  point_by xkey add_point resultsC (fun resultsP ->
  let progcilk = cilk_for_results resultsP in
  let resultsCilk = select_like_ignoring ["delta"; "deal_heuristic"; "taskset"] 
                                         resultsP [("prog", progcilk)] resultsG in
        average resultsP (fun r -> get "exectime" r)
     /. average resultsCilk (fun r -> get "exectime" r)
  )))

let mode_sched_vs_chase_by xkey add_chart resultsA =
   let scatter = { scatter_default with
      scatter_yaxis = axis "exectime / chase_exectime";
      scatter_xaxis = axis ~iszero:true xkey;
      scatter_mathcurves = [Mathcurve_abline(1.,0.)]; } 
      in
  graph_by [] add_chart scatter resultsA (fun resultsG add_curve ->
  let resultsB = list_filter resultsG (fun r -> (get_string "taskset" r) <> "shared_deques") in
  curve_by_not [xkey] add_curve resultsB (fun resultsC add_point ->
  point_by xkey add_point resultsC (fun resultsP ->
  let resultsChase = select_like resultsP [("taskset", "shared_deques")] resultsG in
        average resultsP (fun r -> get "exectime" r)
     /. average resultsChase (fun r -> get "exectime" r)
  )))


let mode_cost_of_interrupt add_chart resultsA =
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true "(exectime - exectime_no_interrupt) / exectime_no_interrupt"; (*nb_interrupts  ---(in microseconds)*)
      scatter_xaxis = axis ~iszero:true ~islog:true "ping";
      scatter_mathcurves = [Mathcurve_abline(1.,0.)]; 
      }
      in
  graph_by [] add_chart scatter resultsA (fun resultsG add_curve ->
  let resultsB = list_filter resultsG not_opt_result in
  curve_by_not ["ping"] add_curve resultsB (fun resultsC add_point ->
  point_by "ping" add_point resultsC (fun resultsP ->
  let progopt = opt_for_results resultsP in
  let resultsOpt = select_like_ignoring ["ping"; "delta"; "interrupts"] 
                                         resultsP [("prog", progopt);("taskset", "shared_deques")] resultsG in
  let exectime r = get "exectime" r in                                       
  let basetime = average resultsOpt exectime in
  average resultsP (fun r -> 
     exectime r /. basetime
      (*let nb = (get "interrupt" r) in
      if nb = 0. then failwith "no interrupts were received";
      let x = 1000000. *. ((get "exectime" r) -. basetime) /. nb in
      x
      *)
      )
  )))

let mode_cost_of_task xkey add_chart resultsA =
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true "(time_proc_1 - time_proc_0) / nb_tasks ---(in microseconds)";
      scatter_xaxis = axis ~iszero:true xkey; }
      in
  let resultsF = list_filter resultsA (fun r -> List.mem (get_int "proc" r) [0;1]) in
  graph_by [] add_chart scatter resultsF (fun resultsG add_curve ->
  let resultsB = list_filter resultsG (fun r -> get_int "proc" r <> 0) in
  curve_by_not [xkey] add_curve resultsB (fun resultsC add_point ->
  point_by xkey add_point resultsC (fun resultsP ->
  let resultsBase = select_like_ignoring ["delta"; "taskset"; "cutoff"] resultsP [("proc", "0")] resultsG in
  let basetime = average resultsBase (fun r -> get "exectime" r) in
  let exectime = average resultsP (fun r -> get "exectime" r) in
  let nbtasks = int_of_string (get_string_of_set "task_create" resultsP) in 
  1000000. *. (exectime -. basetime) /. (float_of_int nbtasks)
  )))


let mode_speedup graphkeys add_chart resultsA =
   let maxproc = List.fold_left max 0. (list_map resultsA (fun r -> get "proc" r)) in
   let baseproc = List.fold_left min 10000 (list_map resultsA (fun r -> get_int "proc" r)) in
   if baseproc > 1 then failwith "speedup needs data for proc=0 or proc=1";
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true ~upper:(Some maxproc) "speedup";
      scatter_xaxis = axis ~iszero:true ~upper:(Some maxproc) "proc";
      scatter_mathcurves = [Mathcurve_abline(0.,1.)]; } 
      in
  graph_by graphkeys add_chart scatter resultsA (fun resultsG add_curve ->
  let resultsB = list_filter resultsG (fun r -> (get_int "proc" r) <> baseproc) in
  curve_by_not ["proc"] add_curve resultsB (fun resultsC add_point ->
  point_by "proc" add_point resultsC (fun resultsP ->
  let results_proc0 = select_like resultsP [("proc", string_of_int baseproc)] resultsG in
  let baseline = average results_proc0 (fun r -> get "exectime" r) in
  average resultsP (fun r -> baseline /. get "exectime" r)
  )))



let mode_ppopp14_vary_input_size graphkeys add_chart resultsA =
  arg_legend_position := "bottomright";
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true "exectime";
      scatter_xaxis = axis  ~islog:true "size";
      scatter_mathcurves = []; } 
      in
  graph_by ("op"::"proc"::"computation"::"force_sequential_init_array"::graphkeys) add_chart scatter resultsA (fun resultsG add_curve ->
  curve_by ["gap"] add_curve resultsG (fun resultsC add_point ->
  point_by "size" add_point resultsC (fun resultsP ->
  average resultsP (fun r -> get "exectime" r)
  )))

let mode_ppopp14_vary_input_size_extra graphkeys add_chart resultsA =
  arg_legend_position := "bottomright";
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true ~islog:true "exectime";
      scatter_xaxis = axis  ~islog:true "size";
      scatter_mathcurves = []; } 
      in
  graph_by ("gap"::"computation"::graphkeys) add_chart scatter resultsA (fun resultsG add_curve ->
  curve_by ["proc"] add_curve resultsG (fun resultsC add_point ->
  point_by "size" add_point resultsC (fun resultsP ->
  average resultsP (fun r -> get "exectime" r)
  )))

let mode_ppopp14_vary_input_size_speedup graphkeys add_chart resultsA =
  arg_legend_position := "topright";
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true "speedup";
      scatter_xaxis = axis  ~islog:true "size";
      scatter_mathcurves = []; } 
      in
  graph_by ("op"::"gap"::"computation"::"force_sequential_init_array"::graphkeys) add_chart scatter resultsA (fun resultsG add_curve ->
  curve_by ["proc"] add_curve resultsG (fun resultsC add_point ->
  point_by "size" add_point resultsC (fun resultsP ->
  let results_proc0 = select_like resultsP [("proc", string_of_int 0)] resultsG in
  let baseline = average results_proc0 (fun r -> get "exectime" r) in
  average resultsP (fun r -> baseline /. get "exectime" r)
  )))

let mode_efficiency xkey xlog add_chart resultsA =
   let baseproc = List.fold_left min 10000 (list_map resultsA (fun r -> get_int "proc" r)) in
   if baseproc > 1 then failwith "efficiency needs data for proc=0 or proc=1";
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true ~upper:(Some 1.2) "efficiency";
      scatter_xaxis = axis ~iszero:true ~islog:xlog xkey;
      scatter_mathcurves = [Mathcurve_abline(1.,0.)]; } 
      in
  graph_by [] add_chart scatter resultsA (fun resultsG add_curve ->
  let resultsB = list_filter resultsG (fun r -> (get_int "proc" r) <> baseproc) in
  curve_by_not [xkey] add_curve resultsB (fun resultsC add_point ->
  point_by xkey add_point resultsC (fun resultsP ->
  let results_proc0 = select_like_ignoring ["machine"; "delta"; "taskset"; "cutoff"] resultsP [("proc", string_of_int baseproc)] resultsG in
  let proc = float_of_string (get_string_of_set "proc" resultsP) in
  let baseline = average results_proc0 (fun r -> get "exectime" r) in
  average resultsP (fun r -> baseline /. (proc *. get "exectime" r))
  )))


let mode_scatter_plot yaxis xaxis ylog xlog curve graphkeys add_chart resultsA =
  let orig_arg_legend_position = !arg_legend_position in
  arg_legend_position := "bottomright";
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true ~islog:ylog yaxis;
      scatter_xaxis = axis  ~islog:xlog xaxis;
      scatter_mathcurves = []; } 
      in
  graph_by graphkeys add_chart scatter resultsA (fun resultsG add_curve ->
  curve_by [curve] add_curve resultsG (fun resultsC add_point ->
  point_by xaxis add_point resultsC (fun resultsP ->
  average resultsP (fun r -> get yaxis r)
  )));
  arg_legend_position := orig_arg_legend_position

let mode_barplot ?series_beautifier:(sb=fun x -> x) ?group_beautifier:(gb=fun x -> x) 
		 reserved xaxis yaxis eval group_by series_by force add_graph results1 =
   let all_datas = List.map fst results1 in
   let results2 = results_filter force results1 in

   (* we ensure that heights are sorted by their series_by label *)

   let group_title group = String.concat "," (List.map snd group) in

   let create_group_titles inputs series_params series_datas =
     let by_group = make_buckets (indexer_for_data group_by) series_datas in
     let titles = build_list (fun add_title ->
       list_foreach by_group (fun (group,datas) ->
	 add_title (group_title group)))
     in
     List.sort String.compare titles
   in
   let create_series inputs series_params series_datas =
     let series_title = title_of_params series_params in
     let by_group = make_buckets (indexer_for_data group_by) series_datas in
     let heights = build_list (fun add_height ->
       list_foreach by_group (fun (group,datas) ->
	 let add h = add_height (group_title group, h) in
	 try eval inputs all_datas datas add
	 with Missing_data -> ()))
     in
     let heights' = list_ksort String.compare heights in
     let heights'' = List.map snd heights' in
     (series_title, heights'')
   in
   let create_group inputs group_params group_datas =
     let by_series = make_buckets (indexer_for_data series_by) group_datas in
     build_list (fun add_series ->
       list_foreach by_series (fun (series_params,series_datas) -> 
	 add_series (create_series inputs series_params series_datas)))
   in
   let create_graph graph_params data = 
      let graph_title = title_of_params graph_params in
      let barplot = {
	barplot_xaxis_label = String.concat " " xaxis;
	barplot_yaxis_label = String.concat " " yaxis;
	barplot_data = data;
	barplot_series_beautifier = sb;
	barplot_group_beautifier = gb;
      }
      in
      add_graph { 
         graph_tag = "";  
         graph_title = graph_title; 
         graph_data = BarPlot barplot; }
   in begin
      let by_kind = make_buckets (fun (_,inputs) -> inputs) results2 in
      list_foreach by_kind (fun (inputs,results3) ->  
         let datas1 = List.map fst results3 in
         let reserved_keys = reserved @ 
	                     group_by @ 
			     series_by in
         let not_reserved_keys = list_substract inputs reserved_keys in
         let by_graph = make_buckets (indexer_for_data not_reserved_keys) datas1 in
         list_foreach by_graph (fun (graph_params,datas2) ->
 	    let groups = create_group inputs graph_params datas2 in
	    let group_titles = create_group_titles inputs graph_params datas2 in
            create_graph graph_params (group_titles,groups))
      )
   end        

(*********************************************************)


(*********************************************************)

(* TODO : ARTHUR: merge back here old version *)
let mode_ppopp13_table add_chart resultsA = 
  assert false
  (*
   let rows = build_list (fun add_row ->
      let first_row = [""; "Shared deques (speedup)"; "Shared deques (time)"; "Recv.-init."; "Sender-init."; "Cilk Plus" ]
         @ (if extended then [ "proc 1 cilk"; "proc 1 shared"; "proc 1 recv"; "proc 1 send"] else []) in
      add_row first_row;
      let resultsM = list_filter resultsA not_cilk_result in
      let resultsM = list_filter resultsM (fun r -> get_int "proc" r = 30) in
      let params = ["graph"; "points"; "sequence"] in
      let resultsR_buckets = bucket (["prog"]@params) resultsM in
      let resultsR_buckets = list_ksort (fun p1 p2 ->
         let prog1 = basename_of_prog (data_string "prog" p1) in
         let prog2 = basename_of_prog (data_string "prog" p2) in
         let b= list_contain_before prog1 prog2 ordered_prog in
         b) resultsR_buckets in
      list_iter resultsR_buckets (fun (row_fixed,resultsR) ->
         let cols = build_list (fun add_col ->
            let prog = latex_escape (basename_of_prog (get_string_of_set "prog" resultsR)) in
            let label = List.fold_left (fun acc param ->
               try sprintf "%s(%s)" acc (
                  remove_data_slash (get_string_of_set param resultsR))
               with _ -> acc ) prog params
               in
            add_col (label);
            let progcilk = cilk_for_results resultsR in
            let ignorescilk = ["seed"; "delta"; "deal_heuristic"; "taskset";"machine"] in
            let resultsCilk = select_like_ignoring ignorescilk 
                                          resultsR [("prog", progcilk)] resultsA in
            let gettime r = get "exectime" r in
            let select_taskset taskset = list_filter resultsR (fun r -> get_string "taskset" r = taskset) in
            let show_float x = sprintf "%.2f" x in
            let _show_change_unsigned x = 
               sprintf "%.0f" x 
               in
            let show_change_base x = 
               if x >= 0.
                  then sprintf "+%.1f" x 
                  else sprintf "%.1f" x 
               in
            let show_change x = 
               show_change_base x
               in
            let averagetime results = average results gettime in
            let basetime = averagetime (select_taskset "shared_deques") in
               let oneignores = ["seed"; "delta"; "deal_heuristic"; "machine"] in
               let seqignores = oneignores @ ["taskset";"cutoff"] in
            let seqtime = 
               try 
                 averagetime (select_like_ignoring seqignores 
                              (select_taskset "shared_deques") [("proc", "0")] resultsA) 
               with Missing_data -> nan 
               in
            let speedup = seqtime /. basetime in
            add_col (sprintf "%.1f" speedup);
            add_col (show_float basetime ^ "");
            let add_col_for resultsP =
               let values = evaluate resultsP (fun r ->
                  100. *. (gettime r -. basetime) /. basetime) in
               let ratio = mean values in
               let (mi,ma) = range values in
               if show_ranges then begin
                  add_col (sprintf "%s [%s - %s]" (show_change ratio)  (show_change mi) (show_change ma)
                    );
               end else begin
                  add_col (show_change ratio);
               end
               in
            List.iter add_col_for [select_taskset "cas_ri"; select_taskset "cas_si_poisson"; resultsCilk];
            if extended then begin
               try
               let overhead results =
                  ((averagetime results -. seqtime) /. seqtime) in
               let onecilk = select_like_ignoring ignorescilk resultsR 
                    [("prog", progcilk);("proc", "1")] resultsA in
               let one taskset = select_like_ignoring oneignores 
                  (select_taskset taskset) [("proc", "1")] resultsA in
               List.iter (fun results -> add_col (show_change (overhead results)))
                   [onecilk; one "shared_deques"; one "cas_ri"; one "cas_si_poisson" ];
               with Missing_data -> ()
            end
            ) in
          add_row cols;
       );
     ) in
   add_chart (Chart_table { table_title = "vs_shared"; table_data = rows })
*)


(*********************************************************)

type col_type = AVGTIME | SPEEDUP | PCT_DIFF_AVGTIME | TOTAL_SEQUENTIAL | PCT_DIFF_TOTAL_SEQUENTIAL

let mode_spaa13_table_with_details show_seq  basesched first_row col_types col_descrs show_full add_chart resultsA =
   let extended = show_full in (* PARAM *)
   let show_ranges = extended in (* PARAM *)
   let ordered_prog = (* PARAM *)
      [ "matmul"; "cilksort"; "fib";
        "matching"; "MIS"; "hull"; "sort" ] in 
   let row1 = List.map (fun (a,b,c) -> a) first_row in
   let row2 = List.map (fun (a,b,c) -> b) first_row in
   let row3 = List.map (fun (a,b,c) -> c) first_row in
   let resultsB = list_filter resultsA (fun r -> not (not_opt_result r)) in (* only opt results *)
   let resultsP = list_filter resultsB not_cilk_result in
   let resultsP = list_filter resultsP (fun r -> get_int "proc" r > 1) in
   let resultsP_buckets = bucket (["proc"]) resultsP in
   list_iter resultsP_buckets (fun (proc_fixed,resultsM) ->
      let nbproc = data_int "proc" proc_fixed in
      let rows = build_list (fun add_row ->
         add_row [];
         add_row (latex_escapes row1);
         add_row (latex_escapes row2);
         add_row (latex_escapes row3);
         add_row [];
         let params = ["graph"; "points"; "sequence"] in
         let resultsR_buckets = bucket (["prog"]@params) resultsM in
         let resultsR_buckets = list_ksort (fun p1 p2 ->
            let prog1 = basename_of_prog (data_string "prog" p1) in
            let prog2 = basename_of_prog (data_string "prog" p2) in
            let b = list_contain_before prog1 prog2 ordered_prog in
            b) resultsR_buckets in
         list_iter resultsR_buckets (fun (row_fixed,resultsR) ->

            let cols = build_list (fun add_col ->
               (* todo: use row_fixed isntead of resultsR *)
               let prog = latex_escape (basename_of_prog (get_string_of_set "prog" resultsR)) in
               let label = List.fold_left (fun acc param ->
                  try sprintf "%s (%s)" acc (
                     remove_data_slash (get_string_of_set param resultsR))
                  with _ -> acc ) prog params
                  in
               add_col (label);
               
               let progcilk = cilk_for_results resultsR in
               let ignorescilk = ["seed"; "delta"; "deal_heuristic"; "taskset";"machine"] in
               let resultsCilk = select_like_ignoring ignorescilk 
                                             resultsR [("prog", progcilk)] resultsA in
               let gettime r = get "exectime" r in
	       let gettotalseq r = get "total_sequential" r in
               let show_float x = sprintf "%.2f" x in
               let _show_change_unsigned x = 
                  sprintf "%.0f" x 
                  in
               let show_change_base prec x = 
                    (if x >= 0. then "+" else "") 
                  ^ (if prec = 0 then sprintf "%.0f" x else sprintf "%.1f" x)
                  in
               let show_change x = 
                  show_change_base 1 x
               in
               let averagetime results = average results gettime in
	       let averagetotalseq results = average results gettotalseq in
               let select_sched sched = if sched = "cilk" then resultsCilk else list_filter resultsR (fun r -> get_string "taskset" r = sched) in
               let basetaskset = select_sched basesched in
               let basetime = averagetime basetaskset in
               let oneignores = ["seed"; "delta"; "deal_heuristic"; "machine"] in
               let seqignores = oneignores @ ["taskset";"cutoff";"controller"] in
               let seqtime = 
                  try 
                    let resultsseq = select_like_ignoring seqignores (select_sched "cas_ri") [("proc", "0")] resultsA in
                    averagetime resultsseq 
                  with Missing_data -> nan 
               in
	       let show_speedup x =
		 sprintf "%.1f" (seqtime /. x)
	       in
(*               let speedup = seqtime /. basetime in
               add_col (sprintf "%.1f" speedup); 
               add_col (show_float basetime ^ ""); 
*)
               let add_col_for col_type resultsP =
                  try
                     let values = evaluate resultsP (fun r ->
                        100. *. (gettime r -. basetime) /. basetime) in
                     let mean_values = mean (evaluate resultsP (fun r -> gettime r)) in
                     let ratio = mean values in
                     let (mi,ma) = range values in
		     match col_type with
		       | PCT_DIFF_AVGTIME ->
			 if show_ranges then begin
                           add_col (sprintf "%s [%s;%s] (%s)" (show_change ratio) (show_change_base 0 mi) (show_change_base 0 ma) (show_float mean_values)
                          (* (show_change_unsigned dev)
                             (string_of_list "," show_change_base values)*)
                           );
			 end else begin
                           add_col (show_change ratio);
			 end
		       | SPEEDUP ->
			   add_col (show_speedup (averagetime resultsP))
		       | AVGTIME ->
			   add_col (sprintf "%.1f" (averagetime resultsP))
		       | TOTAL_SEQUENTIAL ->
			   add_col (sprintf "%.1f" (averagetotalseq resultsP))
		       | PCT_DIFF_TOTAL_SEQUENTIAL ->
			   failwith ""
                     with Missing_data -> add_col "na"
                   in
               List.iter2 add_col_for col_types (List.map select_sched col_descrs);
               if show_seq then begin
                  (*add_col (show_float seqtime);*)
                  let overhead results =
                     ((averagetime results -. seqtime) /. seqtime) in
                  let onecilk = select_like_ignoring ignorescilk resultsR 
                       [("prog", progcilk);("proc", "1")] resultsA in
                  let one taskset = select_like_ignoring oneignores 
                     (select_sched taskset) [("proc", "1")] resultsA in
                  List.iter (fun results -> 
                      try add_col (show_change (overhead results)) with Missing_data -> add_col "na")
                      [one "cas_si"; one "fencefree_si"; one "shared_deques"; onecilk; ];
                     (* (printf "Warning: cannot find data for %s\n"
                     (title_of_results_input_data_ignoring seqignores resultsR)) *)
               end
               ) in
             add_row cols;
          );
         add_row [];
        ) in
      let title = sprintf "%s_for_proc_%d" (if extended then "details" else "summary") nbproc in
      add_chart (Chart_table { table_title = title; table_data = rows }))


let mode_spaa13_table add_chart resultsA =
  let extended = false in
   let show_seq = false in  (* TODO: in order to compare baselines *)
   let first_row = [("","",""); ("CAS-","based","(speedup)"); ("CAS-","based","(sec)");] @ (if extended then [("CAS-RI","","(%)")] else []) @ [ ("Our","algo.","(%)"); ] @ (if extended then [ ("Our SI","","(%)"); ("CAS-SI","","(%)"); ] else []) @ [ ("Conc.","deques", "(%)"); ("Cilk","Plus","(%)") ]
      @ (if show_seq then 
         List.map (fun k -> (k, "1 proc", "(%)")) [ "cassi"; "RMW-free"; "shared"; "cilk-p1" ] else []) in
   let col_descrs = (["cas_ri"] @ ["cas_ri"] @ (if extended then ["cas_ri"] else []) @ [ "fencefree_ri"; ] @ (if extended then [ "fencefree_si"; "cas_si"; ] else []) @ [ "shared_deques"; "cilk"]) in
   let col_types = ([SPEEDUP] @ [AVGTIME] @ (if extended then [PCT_DIFF_AVGTIME] else []) @ [ PCT_DIFF_AVGTIME; ] @ (if extended then [ PCT_DIFF_AVGTIME; PCT_DIFF_AVGTIME; ] else []) @ [ PCT_DIFF_AVGTIME; PCT_DIFF_AVGTIME]) in
   let base_sched = "cas_ri" in
   mode_spaa13_table_with_details show_seq base_sched first_row col_types col_descrs true add_chart resultsA;

   let first_row = [("","",""); ("Cilk","Plus","(speedup)"); ("Cilk","Plus","(sec)"); ("Our","algo.","(%)"); ("Chase-","Lev", "(%)"); ("Priv. deques","with CAS", "(%)");] in
   let col_descrs = (["cilk"; "cilk"; "fencefree_ri";"shared_deques"; "cas_ri";]) in
   let col_types = [SPEEDUP; AVGTIME; PCT_DIFF_AVGTIME; PCT_DIFF_AVGTIME; PCT_DIFF_AVGTIME]  in
   let base_sched = "cilk" in
   mode_spaa13_table_with_details show_seq base_sched first_row col_types col_descrs false add_chart resultsA;

   let first_row = [("","",""); ("Priv. deques","with CAS", "(speedup)"); ("Our","algo.","(speedup)"); ("Relative", "difference", "(%)")] in
   let col_descrs = (["cas_ri"; "fencefree_ri"; "fencefree_ri";]) in
   let col_types = [SPEEDUP; SPEEDUP; PCT_DIFF_AVGTIME]  in
   let base_sched = "cas_ri" in
   mode_spaa13_table_with_details show_seq base_sched first_row col_types col_descrs false add_chart resultsA;

(*   mode_spaa13_table_with_details show_seq  first_row col_descrs true add_chart resultsA *)
   ()


(* for debugging:
list_map resultsR (fun (d,_) -> msg_newline (string_of_list "," (fun (a,b) -> sprintf "(%s,%s)" a b) d));
msg_newline (string_of_int (List.length resultsCilk));
*)

(*********************************************************)
(*
      let barplot = {
	barplot_axis_label = d.barplot_descr_axis_label;
	barplot_data = data;
      }
*)

let mode_ppopp13_barplot add_chart resultsA =
   let ordered_prog = (* PARAM *)
      [ "matmul"; "cilksort"; "fib";
        "matching"; "MIS"; "hull"; "sort" ] in 
   let first_row = ["Shared deques"; "Recv.-init."; "Sender-init."; "Cilk Plus" ] in
   let rows = build_list (fun add_row ->
      let resultsM = list_filter resultsA not_cilk_result in
      let resultsM = list_filter resultsM (fun r -> get_int "proc" r = 30) in
      let params = ["graph"; "points"; "sequence"] in
      let resultsR_buckets = bucket (["prog"]@params) resultsM in
      let resultsR_buckets = list_ksort (fun p1 p2 ->
         let prog1 = basename_of_prog (data_string "prog" p1) in
         let prog2 = basename_of_prog (data_string "prog" p2) in
         let b= list_contain_before prog1 prog2 ordered_prog in
         b) resultsR_buckets in
      list_iter resultsR_buckets (fun (row_fixed,resultsR) ->
         let last_label = ref "?" in
         let cols = build_list (fun add_col ->
            let prog = latex_escape (basename_of_prog (get_string_of_set "prog" resultsR)) in
            let label = List.fold_left (fun acc param ->
               try sprintf "%s(%s)" acc (
                  remove_data_slash (get_string_of_set param resultsR))
               with _ -> acc ) prog params
               in
            last_label := label;
            let progcilk = cilk_for_results resultsR in
            let ignorescilk = ["seed"; "delta"; "deal_heuristic"; "taskset";"machine"] in
            let resultsCilk = select_like_ignoring ignorescilk 
                                          resultsR [("prog", progcilk)] resultsA in
            let gettime r = get "exectime" r in
            let select_taskset taskset = list_filter resultsR (fun r -> get_string "taskset" r = taskset) in
            let averagetime results = average results gettime in
            let basetime = averagetime (select_taskset "shared_deques") in
            let add_col_for resultsP =
               let values = evaluate resultsP (fun r ->
                  gettime r /. basetime) in
               let ratio = mean values in
               (*let (mi,ma) = range values in*)
               add_col ratio;
               in
            add_col 1.0;
            List.iter add_col_for [select_taskset "cas_ri"; select_taskset "cas_si_poisson"; resultsCilk];
            ) in
          if not (string_starts_with "sort" !last_label)  && not (string_starts_with "cilksort(almost" !last_label)
             then add_row (!last_label, cols);
       );
     ) in
   let cols = first_row in
   let series = rows in
   (* 
   let series = [("a", [3.; 1.]); ("b", [4.; 2.]);  ("c", [4.; 3.])] in
   let cols = ["u"; "v"]
   *)
   let data = (cols,series) in
   let barplot = {
      barplot_xaxis_label = "";
      barplot_yaxis_label = "normalized execution time";
      barplot_data = data;
      barplot_series_beautifier = (fun x -> x);
      barplot_group_beautifier = (fun x -> x);
   } 
      in
   add_chart (Chart_graph { 
      graph_tag = "";  
      graph_title = ""; 
      graph_data = BarPlot barplot; })


(*********************************************************)

let modes_builders bykey = 
  let graphkeys = Cmdline.parse_or_default_list_string "graph" [] in
  let xlog = Cmdline.mem_flag "xlog" in
   [("default", mode_default);
    ("efficiency", mode_efficiency bykey xlog); 
    ("steal_cst", mode_steal_cst_by bykey); 
    ("idle_per_steal", mode_idle_per_steal); 
    ("sched_vs_cilk", mode_sched_vs_cilk_by bykey); 
    ("sched_vs_chase", mode_sched_vs_chase_by bykey); 
    ("cost_of_interrupt", mode_cost_of_interrupt);
    ("cost_of_task", mode_cost_of_task bykey);
    ("speedup", mode_speedup graphkeys);
    ("ppopp13_barplot", mode_ppopp13_barplot);
    ("ppopp13_table", mode_ppopp13_table);
    ("spaa", (mode_spaa13_table)); 
    ]

let create_charts mode results bykey =
   if results = [] 
      then failwith "no results in input file";
   let builder = 
      try List.assoc mode (modes_builders bykey)
      with Not_found -> failwith "unknown mode"
      in 
   build_list (fun add_chart ->  
      builder add_chart results) 
