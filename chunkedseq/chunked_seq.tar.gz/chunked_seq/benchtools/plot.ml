open Shared
open Benchmark
open Printf
open Results



(*********************************************************)

type args = {
   mutable mode : string;
   mutable xkey : string option;
   mutable ykey : string option;
   mutable custom : string option;
   mutable xlog : bool;
   mutable ylog : bool;
   mutable xzero : bool;
   mutable yzero : bool;
   mutable reserved_keys : string list;
   mutable curve_fields : (string list) option;
   mutable graph_fields : (string list) option
   (*
   mutable curve_fields : string list;
   mutable graph_fields : string list;
   *)
   }

(*********************************************************)
(* Bar plot *)

type barplot_descr = {
  barplot_descr_xaxis_label : strings;
  barplot_descr_yaxis_label : strings;
  barplot_descr_graph : strings;
  barplot_descr_reserved : strings;
  barplot_descr_group_by : strings;
  barplot_descr_series_by : strings;
  barplot_descr_force : (stringp -> bool) list; 
  barplot_descr_eval : (strings -> datas -> datas -> (float->unit) -> unit);
  }

let default_barplot_descr = {
  barplot_descr_xaxis_label = [];
  barplot_descr_yaxis_label = [];
  barplot_descr_graph = [];
  barplot_descr_reserved = [];
  barplot_descr_group_by = [];
  barplot_descr_series_by  = [];
  barplot_descr_force = [];
  barplot_descr_eval = 
     (fun inputs all_datas datas add -> assert false);
  }

(*********************************************************)

type scatter_descr = {
   scatter_descr_extra : string;
   scatter_descr_force : (stringp -> bool) list; 
   scatter_descr_reserved : strings;
   scatter_descr_graph : strings;
   scatter_descr_curve : strings;
   scatter_descr_xaxis : axis;
   scatter_descr_yaxis : axis;
   scatter_descr_line : bool;
   scatter_descr_mathcurves : mathcurves;
   scatter_descr_eval : (strings -> datas -> datas -> (float->unit) -> unit);
   }

let default_scatter_descr = {
   scatter_descr_extra = "";
   scatter_descr_force = [];
   scatter_descr_reserved = [];
   scatter_descr_graph = [];
   scatter_descr_curve = [];
   scatter_descr_xaxis = axis "x";
   scatter_descr_yaxis = axis "y";
   scatter_descr_line = true;
   scatter_descr_mathcurves = [];
   scatter_descr_eval = 
      (fun inputs all_datas datas add -> assert false);
   }


let old_scatter_build add_graph results1 d =
   let all_datas = List.map fst results1 in
   let reserved_keys = d.scatter_descr_reserved @ d.scatter_descr_curve in
   let results2 = results_filter d.scatter_descr_force results1 in
   let by_kind = make_buckets (fun (_,inputs) -> inputs) results2 in
   list_foreach by_kind (fun (inputs,results3) ->
   let datas1 : ((string*string) list) list = List.map fst results3 in
   let not_reserved_keys = list_substract inputs reserved_keys in
   let by_graph = make_buckets (indexer_for_data not_reserved_keys) datas1 in
   list_foreach by_graph (fun (graph_params,datas2) ->
      let graph_title = title_of_params graph_params ^ " " ^ d.scatter_descr_extra in
      let by_curve = make_buckets (indexer_for_data d.scatter_descr_curve) datas2 in
      let curves = list_map by_curve (fun (curve_params,datas3) ->
         let curve_title = title_of_params curve_params in
         let xkey = d.scatter_descr_xaxis.axis_label in
         let by_xval = make_buckets (data_float xkey) datas3 in
         let points = build_list (fun add_point ->
            list_foreach by_xval (fun (xval,datas4) ->
               let add yval =
                  add_point (xval,yval) in
               try d.scatter_descr_eval inputs all_datas datas4 add
               with Missing_data -> ())) 
            in
         (curve_title, points))
         in
      let curves = list_ksort cmp_curve_title curves in 
      let scatter = { 
         scatter_xaxis = d.scatter_descr_xaxis;
         scatter_yaxis = d.scatter_descr_yaxis;
         scatter_curves = curves;
         scatter_drawline = d.scatter_descr_line;
         scatter_mathcurves = d.scatter_descr_mathcurves;
         scatter_enriched = false; } 
         in
      add_graph { 
         graph_tag = "";  
         graph_title = graph_title; 
         graph_data = Scatter scatter; }))

(* new version, generalized with graph_fields *)

let remove_common_params_in params_datas = 
   if (params_datas = [] 
     || fst (List.hd params_datas) = [])
     then failwith "remove_common_params_in: empty data";
   let params0 = fst (List.hd params_datas) in
   let params_cst = list_filter params0 (fun param ->
      list_for_all params_datas (fun (params,datas) ->
         list_mem params param))
      in
   let keys_to_hide = List.map fst params_cst in
   list_map params_datas (fun (params,datas) ->
      let params' = list_filter params (fun (k,v) -> not (list_mem keys_to_hide k)) in
      (params', datas))

let barplot_build add_graph results1 d =
   let all_datas = List.map fst results1 in
   let results2 = results_filter d.barplot_descr_force results1 in

   (* we ensure that heights are sorted by their series_by label *)

   let group_title group = String.concat "," (List.map snd group) in

   let create_group_titles inputs series_params series_datas =
     let by_group = make_buckets (indexer_for_data d.barplot_descr_group_by) series_datas in
     let titles = build_list (fun add_title ->
       list_foreach by_group (fun (group,datas) ->
	 add_title (group_title group)))
     in
     List.sort String.compare titles
   in
   let create_series inputs series_params series_datas =
     let series_title = title_of_params series_params in
     let by_group = make_buckets (indexer_for_data d.barplot_descr_group_by) series_datas in
     let heights = build_list (fun add_height ->
       list_foreach by_group (fun (group,datas) ->
	 let add h = add_height (group_title group, h) in
	 try d.barplot_descr_eval inputs all_datas datas add
	 with Missing_data -> ()))
     in
     let heights' = list_ksort String.compare heights in
     let heights'' = List.map snd heights' in
     (series_title, heights'')
   in
   let create_group inputs group_params group_datas =
     let by_series = make_buckets (indexer_for_data d.barplot_descr_series_by) group_datas in
     build_list (fun add_series ->
       list_foreach by_series (fun (series_params,series_datas) -> 
	 add_series (create_series inputs series_params series_datas)))
   in
   let create_graph graph_params data = 
      let graph_title = title_of_params graph_params in
      let barplot = {
        barplot_xaxis_label = String.concat " " d.barplot_descr_xaxis_label;
        barplot_yaxis_label = String.concat " " d.barplot_descr_yaxis_label;
        barplot_data = data;
	barplot_series_beautifier = (fun x -> x);
	barplot_group_beautifier = (fun x -> x);
      }
      in
      add_graph { 
         graph_tag = "";  
         graph_title = graph_title; 
         graph_data = BarPlot barplot; }
   in begin
      let by_kind = make_buckets (fun (_,inputs) -> inputs) results2 in
      list_foreach by_kind (fun (inputs,results3) ->  
         let datas1 = List.map fst results3 in
         let reserved_keys = d.barplot_descr_reserved @ 
	                     d.barplot_descr_group_by @ 
			     d.barplot_descr_series_by in
         let not_reserved_keys = list_substract inputs reserved_keys in
         let by_graph = make_buckets (indexer_for_data not_reserved_keys) datas1 in
         list_foreach by_graph (fun (graph_params,datas2) ->
 	    let groups = create_group inputs graph_params datas2 in
	    let group_titles = create_group_titles inputs graph_params datas2 in
            create_graph graph_params (group_titles,groups))
      )
   end        


let scatter_build add_graph results1 d =
   let all_datas = List.map fst results1 in
   let results2 = results_filter d.scatter_descr_force results1 in

   let create_curve inputs curve_params curve_datas =
      let curve_title = title_of_params curve_params in
      let xkey = d.scatter_descr_xaxis.axis_label in
      let by_xval = make_buckets (data_float xkey) curve_datas in
      let points = build_list (fun add_point ->
         list_foreach by_xval (fun (xval,datas) ->
            let add yval =
               add_point (xval,yval) in
            try d.scatter_descr_eval inputs all_datas datas add
            with Missing_data -> ()))
         in
      (curve_title, points)
      in
   let create_graph graph_params curves = 
      let curves = list_ksort cmp_curve_title curves in 
      let graph_title = title_of_params graph_params ^ " " ^ d.scatter_descr_extra in
      let scatter = { 
         scatter_xaxis = d.scatter_descr_xaxis;
         scatter_yaxis = d.scatter_descr_yaxis;
         scatter_curves = curves;
         scatter_drawline = d.scatter_descr_line;
         scatter_mathcurves = d.scatter_descr_mathcurves;
         scatter_enriched = false; } 
         in
      add_graph { 
         graph_tag = "";  
         graph_title = graph_title; 
         graph_data = Scatter scatter; }
      in
   if d.scatter_descr_curve <> [] && d.scatter_descr_graph <> [] then
      failwith "option -curve is incompatible with option -graph"
   else if d.scatter_descr_curve <> [] then begin
      let by_kind = make_buckets (fun (_,inputs) -> inputs) results2 in
      list_foreach by_kind (fun (inputs,results3) ->  
         let datas1 = List.map fst results3 in
         let reserved_keys = d.scatter_descr_reserved @ d.scatter_descr_curve in
         let not_reserved_keys = list_substract inputs reserved_keys in
         let by_graph = make_buckets (indexer_for_data not_reserved_keys) datas1 in
         list_foreach by_graph (fun (graph_params,datas2) ->
            let by_curve = make_buckets (indexer_for_data d.scatter_descr_curve) datas2 in
            let by_curve = remove_common_params_in by_curve in
            let curves = list_map by_curve (fun (curve_params,datas3) ->
               create_curve inputs curve_params datas3) in
            create_graph graph_params curves)
      )
   end else begin
      let by_graph = make_buckets (indexer_for_results d.scatter_descr_graph) results2 in
      list_foreach by_graph (fun (graph_params,results3) ->
         let reserved_keys = d.scatter_descr_reserved @ d.scatter_descr_graph in
         (* 
         let not_reserved_keys = list_substract inputs reserved_keys in
         let by_curve = make_buckets (indexer_for_data not_reserved_keys) datas2 in
         *)
         let by_curve = make_buckets (indexer_for_results_all_inputs_but reserved_keys) results3 in       
         let by_curve = remove_common_params_in by_curve in
         let curves = list_map by_curve (fun (curve_params,results4) ->
            let datas = List.map fst results4 in
            let inputs = Custom.inputs_for_set results4 in
            create_curve inputs curve_params datas) in
         create_graph graph_params curves)
   end        
   (* ) *)
   (*  *)

   (*********************************************************)


type mscatter_descr = {
   mscatter_descr_extra : string;
   mscatter_descr_force : (stringp -> bool) list; 
   mscatter_descr_reserved : strings;
   mscatter_descr_xaxis : axis;
   mscatter_descr_yaxis : axis;
   mscatter_descr_line : bool;
   mscatter_descr_mathcurves : mathcurves;
   mscatter_descr_eval : (string * (strings -> datas -> datas -> (float->unit) -> unit)) list;
   }

let default_mscatter_descr = {
   mscatter_descr_extra = "";
   mscatter_descr_force = [];
   mscatter_descr_reserved = [];
   mscatter_descr_xaxis = axis "x";
   mscatter_descr_yaxis = axis "y";
   mscatter_descr_line = true;
   mscatter_descr_mathcurves = [];
   mscatter_descr_eval = [];
   }

(* like old_scatter_build, except supports several evaluation functions *)

let mscatter_build add_graph results1 d =
   let all_datas = List.map fst results1 in
   let reserved_keys = d.mscatter_descr_reserved in
   let results2 = results_filter d.mscatter_descr_force results1 in
   let by_kind = make_buckets (fun (_,inputs) -> inputs) results2 in
   list_foreach by_kind (fun (inputs,results3) ->
   let datas1 : ((string*string) list) list = List.map fst results3 in
   let not_reserved_keys = list_substract inputs reserved_keys in
   let by_graph = make_buckets (indexer_for_data not_reserved_keys) datas1 in
   list_foreach by_graph (fun (graph_params,datas2) ->
      let graph_title = title_of_params graph_params ^ " " ^ d.mscatter_descr_extra in
      let curves = list_map d.mscatter_descr_eval (fun (curve_title,curve_eval) ->
         let datas3 = datas2 in
         let xkey = d.mscatter_descr_xaxis.axis_label in
         let by_xval = make_buckets (data_float xkey) datas3 in
         let points = build_list (fun add_point ->
            list_foreach by_xval (fun (xval,datas4) ->
               let add yval =
                  add_point (xval,yval) in
               try curve_eval inputs all_datas datas4 add
               with Missing_data -> ())) 
            in
         (curve_title, points))
         in
      let scatter = { 
         scatter_xaxis = d.mscatter_descr_xaxis;
         scatter_yaxis = d.mscatter_descr_yaxis;
         scatter_curves = curves;
         scatter_drawline = d.mscatter_descr_line;
         scatter_mathcurves = d.mscatter_descr_mathcurves;
         scatter_enriched = false; } 
         in
      add_graph { 
         graph_tag = "";  
         graph_title = graph_title; 
         graph_data = Scatter scatter; }))




(*********************************************************)



let specific_params = 
  ["delay";"kappa";"syncfree";"artificial_fence";"taskset"]

(* todo: move*)
let unsome = function
   | Some o -> o
   | None -> failwith "unsome"

let get_max_value key results =
   let values = List.map (data_float key) results in
   List.fold_left max 0. values

let force_not_sequential =
   [ param_neq "proc" "0" ]

let get_datas_seq_using nbproc inputs all_datas datas =
   assert (datas != []);
   let data0 = List.hd datas in
   let fdata = list_filter data0 (fun (k,v) -> 
     list_mem inputs k && not (list_mem specific_params k)) in
   let fdata_seq = 
      try list_assoc_replace "proc" nbproc fdata 
      with Not_found -> failwith "no proc field in data" in
   datas_filter (params_to_force fdata_seq) all_datas

let get_datas_seq inputs all_datas datas =
   let datas_seq = get_datas_seq_using "0" inputs all_datas datas in
   if datas_seq <> [] then datas_seq else begin
   let datas_seq = get_datas_seq_using "1" inputs all_datas datas in
   if datas_seq = [] then failwith "cannot data for proc 0 in speedup computation";
   datas_seq   
   end

let get_data_speedup inputs all_datas datas =
   let datas_seq = get_datas_seq inputs all_datas datas in
   let value_seq = datas_mean "exectime" datas_seq in
   let value = datas_mean "exectime" datas in
   (value_seq, value)

let eval_speedup = fun inputs all_datas datas add ->
   let (value_seq, value) = get_data_speedup inputs all_datas datas in
   add (value_seq /. value)

let eval_efficiency = fun inputs all_datas datas add ->
   let procs = list_map datas (fun data -> data_float "proc" data) in
   let proc = List.hd procs in
   if not (list_for_all procs (fun p -> p = proc))
      then failwith "efficiency requires proc to be the same by curve";
   let (value_seq, value) = get_data_speedup inputs all_datas datas in
   add (value_seq /. (proc *. value))

let eval_speedup_extra key = fun inputs all_datas datas add ->
   let (value_seq, value) = get_data_speedup inputs all_datas datas in
   let keyvalue = datas_mean key datas in
   add (value_seq /. (value *. keyvalue))

(* wrong formula
   let proc = datas_find_uniform data_int "proc" datas in
   let value = datas_mean key datas in
   add (float_of_int proc *. value)
*)

let eval_speedup_nonidle = eval_speedup_extra "relative_non_idle"

let eval_speedup_sequential = eval_speedup_extra "relative_sequential"

let eval_overhead = fun inputs all_datas datas add ->
   let datas_seq = get_datas_seq inputs all_datas datas in
   let value_seq = datas_mean "exectime" datas_seq in
   let value = datas_mean "exectime" datas in
   add (100. *. (value /. value_seq -. 1.0))

let eval_taskcost = fun inputs all_datas datas add ->
   let datas_seq = get_datas_seq inputs all_datas datas in
   (*assert (List.length datas_seq = 1);*)
   let value_seq = datas_mean "exectime" datas_seq in
   let value = datas_mean "exectime" datas in
   let tasks = datas_mean "task_create" datas in
   add ((value -. value_seq) /. tasks *. 1000000000.0)

let eval_mean ykey = fun inputs all_datas datas add -> 
   add (datas_mean ykey datas)


let eval_cst get_cst = fun inputs all_datas datas add ->
   add (list_mean (List.map get_cst datas))

let eval_cst_steals = eval_cst (fun data ->
   let proc = data_float "proc" data in
   if proc = 0. then raise Not_found;
   let fork_depth = data_float "fork_depth" data in
   if fork_depth = 0. then failwith "fork depth should not be zero";
   let task_send = data_float "task_send" data in
   task_send /. proc /. fork_depth)

let eval_cst_waiting = eval_cst (fun data ->
   let proc = data_float "proc" data in
   if proc = 0. then raise Not_found;
   let fork_depth = data_float "fork_depth" data in
   if fork_depth = 0. then failwith "fork depth should not be zero";
   let total_wait = data_float "total_wait" data in
   let delta = (data_float "delta" data) /. 1000000. in
   total_wait /. proc /. delta /. fork_depth)


(*********************************************************)

(* temporary copy paste *)
let mode_speedup add_graph args results =
   if args.xlog <> args.ylog 
      then failwith "in speedup mode, xlog and ylog must be similar";
   let islog = args.xlog in
   let datas = List.map fst results in (*later improve-> per curve *)
   let upper = get_max_value "proc" datas in
   let scatter = { default_scatter_descr with
      scatter_descr_force = force_not_sequential;
      scatter_descr_reserved = ["proc"];
      scatter_descr_graph = list_of_list_option args.graph_fields;
      scatter_descr_curve = list_of_list_option args.curve_fields;
      scatter_descr_xaxis = axis_zero ~islog:islog "proc";
      scatter_descr_yaxis = axis_zero ~islog:islog ~upper:(Some upper) "speedup";
      scatter_descr_mathcurves = [ Mathcurve_abline(0.,1.) ];
      scatter_descr_eval = eval_speedup;
    } in
  scatter_build add_graph results scatter


let mode_speedups add_graph args results =
   if args.xlog <> args.ylog 
      then failwith "in speedup mode, xlog and ylog must be similar";
   let islog = args.xlog in
   let datas = List.map fst results in (*later improve-> per curve *)
   let upper = get_max_value "proc" datas in 
   if args.curve_fields <> None 
      then failwith "in speedups mode, no curve argument is allowed";
   let mscatter = { default_mscatter_descr with
      mscatter_descr_force = force_not_sequential;
      mscatter_descr_reserved = ["proc"];
      mscatter_descr_xaxis = axis_zero ~islog:islog "proc";
      mscatter_descr_yaxis = axis_zero ~islog:islog ~upper:(Some upper) "speedup";
      mscatter_descr_mathcurves = [ Mathcurve_abline(0.,1.) ];
      mscatter_descr_eval = 
         [ "speedup measured", eval_speedup; 
           "speedup without idle time", eval_speedup_nonidle;
           "speedup without parallel code", eval_speedup_sequential ];
    } in
  mscatter_build add_graph results mscatter

open Custom

exception Missing_data_for_enriched

let mode_enriched add_chart args resultsA = (* todo: share code with above *)
   let maxproc = List.fold_left max 0. (list_map resultsA (fun r -> get "proc" r)) in
   let baseproc = List.fold_left min 10000 (list_map resultsA (fun r -> get_int "proc" r)) in
   if baseproc > 1 then failwith "speedup needs data for proc=0 or proc=1";
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true ~upper:(Some maxproc) "speedup";
      scatter_xaxis = axis ~iszero:true ~upper:(Some maxproc) "proc";
      scatter_mathcurves = [Mathcurve_abline(0.,1.)];
      scatter_enriched = true } 
      in
  graph_by_not ["proc"] add_chart scatter resultsA (fun resultsG add_curve ->
     let resultsB = list_filter resultsG (fun r -> (get_int "proc" r) <> baseproc) in
     let points_speedup = ref [] in
     let points_inflation = ref [] in
     let points_idle = ref [] in
     let points_overhead = ref [] in     
     let add_point (proc, (speedup,idle,overhead,inflation)) =
        add_to_list_ref points_speedup (proc,speedup);
        add_to_list_ref points_inflation (proc,inflation);
        add_to_list_ref points_idle (proc,idle);
        add_to_list_ref points_overhead (proc,overhead)
        in
     try    
     point_by "proc" add_point resultsB (fun resultsP ->
        try 
        let results_proc0 = select_like resultsP [("proc", string_of_int 0)] resultsG in
        let results_proc1 = select_like resultsP [("proc", string_of_int 1)] resultsG in
        let baseline0 = average results_proc0 (fun r -> get "exectime" r) in
        let baseline1 = average results_proc1 (fun r -> get "exectime" r) in
        let proc = float_of_string (get_string_of_set "proc" resultsP) in
        let idletime = average resultsP (fun r -> get "total_idle_time" r) in
        let speedup = average resultsP (fun r -> baseline0 /. get "exectime" r) in
        let idle = proc *. baseline0 /. (baseline1 +. idletime) in
        let overhead = proc *. baseline0 /. baseline1 in
        let tp = average resultsP (fun r -> get "exectime" r)  in
	let inflation = proc *. baseline0 /. (proc *. tp -. idletime) in
        (speedup, idle, overhead, inflation)
        with Missing_data -> raise Missing_data_for_enriched 
        );
     add_curve ([], !points_speedup);
     add_curve ([], !points_inflation);
     add_curve ([], !points_idle);
     add_curve ([], !points_overhead);
     with Missing_data_for_enriched -> ()
     )


let mode_fenriched add_chart args resultsA = (* todo: share code with above *)
   let maxproc = List.fold_left max 0. (list_map resultsA (fun r -> get "proc" r)) in
   let baseproc = List.fold_left min 10000 (list_map resultsA (fun r -> get_int "proc" r)) in
   if baseproc > 1 then failwith "speedup needs data for proc=0 or proc=1";
   let scatter = { scatter_default with
      scatter_yaxis = axis ~iszero:true ~upper:(Some maxproc) "speedup";
      scatter_xaxis = axis ~iszero:true ~upper:(Some maxproc) "proc";
      scatter_mathcurves = [Mathcurve_abline(0.,1.)];
      scatter_enriched = true } 
      in
  graph_by_not ["proc";"fakeproc"] add_chart scatter resultsA (fun resultsG add_curve ->
     let resultsB = list_filter resultsG (fun r -> (get_int "proc" r) <> baseproc) in
     let resultsF = list_filter resultsB (fun r -> 
	try let _f = (get_int "fakeproc" r) in false with Missing_data -> true) in
     let points_speedup = ref [] in
     let points_idle = ref [] in
     let points_overhead = ref [] in
     let add_point (proc, (speedup,idle,overhead)) =
        add_to_list_ref points_speedup (proc,speedup);
        add_to_list_ref points_idle (proc,idle);
        add_to_list_ref points_overhead (proc,overhead)
        in
     try    
     point_by "proc" add_point resultsF (fun resultsP ->
        try 
        let results_proc0 = select_like resultsP [("proc", string_of_int 0)] resultsG in
        let proc = int_of_string (get_string_of_set "proc" resultsP) in
        let results_proc1 = keep [("fakeproc", string_of_int proc)] resultsB in
        let baseline0 = average results_proc0 (fun r -> get "exectime" r) in
        let baseline1 = average results_proc1 (fun r -> get "exectime" r) in
        let idletime = average resultsP (fun r -> get "total_idle_time" r) in
        let speedup = average resultsP (fun r -> baseline0 /. get "exectime" r) in
        let idle = (float_of_int proc) *. baseline0 /. (baseline1 +. idletime) in
        let overhead = (float_of_int proc) *. baseline0 /. baseline1 in
        (speedup, idle, overhead)
        with Missing_data -> raise Missing_data_for_enriched 
        );
     add_curve ([], !points_speedup);
     add_curve ([], !points_idle);
     add_curve ([], !points_overhead)
     with Missing_data_for_enriched -> ()
     )

let prepare_mode_basic args results =
   if args.xkey = None || args.ykey = None
      then failwith "must specify -x and -y";
   let xkey = unsome args.xkey in
   let ykey = unsome args.ykey in
   let xlower = if args.xzero then Some 0. else None in
   let ylower = if args.yzero then Some 0. else None in
   { default_scatter_descr with
      scatter_descr_force = [];
      scatter_descr_reserved = [xkey; ykey] @ args.reserved_keys;
      scatter_descr_graph = list_of_list_option args.graph_fields;
      scatter_descr_curve = list_of_list_option args.curve_fields;
      scatter_descr_xaxis = axis ~lower:xlower ~islog:args.xlog xkey;
      scatter_descr_yaxis = axis ~lower:ylower ~islog:args.ylog ykey;
      scatter_descr_eval = eval_mean ykey
    }


let adapt_exectime args results scatter =
  { scatter with
    scatter_descr_yaxis = { scatter.scatter_descr_yaxis 
       with axis_lower = Some 0. }
   }

let adapt_speedup args results scatter =
  { scatter with
    scatter_descr_force = force_not_sequential;
    scatter_descr_eval = eval_speedup;
    scatter_descr_yaxis = { scatter.scatter_descr_yaxis 
       with axis_lower = Some 0. }
   }

let adapt_efficiency args results scatter =
  { scatter with
    scatter_descr_mathcurves = [ Mathcurve_abline(1.0,0.) ];
    scatter_descr_force = force_not_sequential;
    scatter_descr_eval = eval_efficiency;
    scatter_descr_yaxis = { scatter.scatter_descr_yaxis 
       with axis_lower = Some 0. }
   }

let adapt_overhead args results scatter =
  { scatter with
    scatter_descr_force = [ param_eq "proc" "1" ];
    scatter_descr_mathcurves = [ Mathcurve_abline(0.,0.) ];
    scatter_descr_eval = eval_overhead;
    scatter_descr_yaxis = { scatter.scatter_descr_yaxis 
       with axis_label = "overhead (percentage)" }
   }

let adapt_taskcost args results scatter =
  { scatter with
    scatter_descr_force = [ param_eq "proc" "1" ];
    scatter_descr_eval = eval_taskcost;
    scatter_descr_yaxis = { scatter.scatter_descr_yaxis 
       with axis_label = "per-task overhead (nanoseconds)";
            axis_lower = Some 0. }
   }

let adapt_cst_steals args results scatter =
  { scatter with
    scatter_descr_mathcurves = [ Mathcurve_abline(2.7,0.) ];
    scatter_descr_eval = eval_cst_steals;
    scatter_descr_yaxis = { scatter.scatter_descr_yaxis with
       axis_lower = Some 0.;
       axis_upper = Some 5.;
       axis_label = "constant for the steals" }
   }

let adapt_cst_waiting args results scatter =
  let scatter' = adapt_cst_steals args results scatter in
  { scatter' with
    scatter_descr_eval = eval_cst_waiting;
    scatter_descr_yaxis = { scatter'.scatter_descr_yaxis 
       with axis_label = "constant for the waiting time" }
  }

let mode_basic_extended add_graph args results =
  let scatter_base = prepare_mode_basic args results in
  let adapter = match args.ykey with
      | Some "exectime" -> 
          adapt_exectime
      | Some "speedup" -> 
          adapt_speedup 
      | Some "efficiency" -> 
          adapt_efficiency 
      | Some "overhead" -> 
          adapt_overhead
      | Some "pertask_overhead" ->
          adapt_taskcost
      | Some "cst_steals" ->
          adapt_cst_steals
      | Some "cst_waiting" ->
          adapt_cst_waiting
      | _ -> (fun args results scatter -> scatter)
     in
  let scatter = adapter args results scatter_base in
  scatter_build add_graph results scatter

let mode_barplot add_graph args results =
  let group_by = Cmdline.parse_or_default_list_string "group_by" ["prog"] in
  let series_by = Cmdline.parse_or_default_list_string "series_by" ["proc"] in
  let xkey = String.concat "," series_by in
  let ykey = match args.ykey with
    | None -> "exectime"
    | Some s -> s
  in
  let (eval, force) = 
    if ykey = "speedup" then
      (eval_speedup, force_not_sequential)
    else
      (eval_mean ykey, [])
  in
  let barplot = { (* default_barplot_descr with *)
      barplot_descr_xaxis_label = [xkey];
      barplot_descr_yaxis_label = [ykey];
      barplot_descr_force = force;
      barplot_descr_reserved = args.reserved_keys;
      barplot_descr_graph = list_of_list_option args.graph_fields;
      barplot_descr_eval = eval;
      barplot_descr_group_by = group_by;
      barplot_descr_series_by = series_by;
   }
  in
  barplot_build add_graph results barplot

(*

let mode_exectime add_graph args results =
   args.xkey <- Some "proc"; 
   args.ykey <- Some "exectime";
   mode_basic add_graph args results

let mode_efficiency args =
*)


(*********************************************************)

let mode_custom add_graph args results =
   failwith "custom mode unimplemented yet"

(*********************************************************)


let modes_builders = 
   [("basic", mode_basic_extended);
    ("custom", mode_custom);
    ("speedup", mode_speedup);
    ("speedups", mode_speedups);
    ("enriched", fun add_graph -> mode_enriched (fun c -> match c with Chart_graph g -> add_graph g | _ -> failwith "unexpected"));
    ("fenriched", fun add_graph -> mode_fenriched (fun c -> match c with Chart_graph g -> add_graph g | _ -> failwith "unexpected"));
    ("barplot", mode_barplot);
    (* ("efficiency", mode_efficiency);*) ]

let get_args () = 
   let args = {
   mode = Cmdline.parse_or_default_string "mode" "basic";
   xkey = Cmdline.parse_optional_string "x";
   ykey = Cmdline.parse_optional_string "y";
   custom = Cmdline.parse_optional_string "custom";
   xlog = Cmdline.mem_flag "xlog";
   ylog = Cmdline.mem_flag "ylog";
   xzero = Cmdline.mem_flag "xzero";
   yzero = Cmdline.mem_flag "yzero";
   reserved_keys = Cmdline.parse_or_default_list_string "ignore" [];
   curve_fields = Cmdline.parse_optional_list_string "curve";
   graph_fields = Cmdline.parse_optional_list_string "graph";
   } in
   if Cmdline.mem_flag "xylog" then begin
      args.xlog <- true;
      args.ylog <- true;
   end;
   if Cmdline.mem_flag "xyzero" then begin
      args.xzero <- true;
      args.yzero <- true;
   end;
   if args.xkey = None then begin
      args.xkey <- Some "proc"; (* default *)
   end;
   list_iter (List.map fst modes_builders) (fun mode -> 
      if Cmdline.mem_flag mode then args.mode <- mode);
   if (args.custom <> None)
      then args.mode <- "custom";
   args

let create_graphs args results =
   if results = [] 
      then failwith "no results in input file";
   let builder = 
      try List.assoc args.mode modes_builders 
      with Not_found -> failwith "unknown mode"
      in
   build_list (fun add_graph ->  
      builder add_graph args results)
      
let _ =
   parse_plot_options();
   let args = get_args () in
   let results = read_results_from_input_file() in
   let graphs = create_graphs args results in
   pdf_of_graphs graphs;
   if Cmdline.mem_flag "open" 
      then ignore (system (sprintf "evince %s &" !arg_plot_output))


