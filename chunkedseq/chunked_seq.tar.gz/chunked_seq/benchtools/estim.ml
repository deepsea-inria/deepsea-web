open Shared
open Scanf
open Printf
open Graphics
open Benchmark

let debug = ref false

let msg x =
   print_string x; print_newline(); flush stdout




(****************************************************)

type time = float
type pointer = Int64.t

type evttype = 
  | Evt_estim_name of pointer * string
  | Evt_estim_report of pointer * int * float * float
  | Evt_estim_update of pointer * float 
  | Evt_other

let estim_of_event = function
  | Evt_estim_name (ptr,_) -> Some ptr
  | Evt_estim_report (ptr,_,_,_) -> Some ptr
  | Evt_estim_update (ptr,_) -> Some ptr
  | Evt_other -> None


(****************************************************)



let parse_event ch =
   let time = float_of_int (Int64.to_int (read_int64 ch)) (* read_double ch *)in
   let proc = Int64.to_int (read_int64 ch) in
   let code = Int64.to_int (read_int64 ch) in
   let evttype = match code with
      | 12 -> 
         let ptr = read_int64 ch in
         let name = read_string ch in
         Evt_estim_name (ptr, name)
      | 13 -> Evt_other (* predict *)
      | 14 -> 
         let ptr = read_int64 ch in
         let comp = Shared.read_int ch in
         (*let duration = read_double ch in*)
         let duration = (float_of_int (Shared.read_int ch)) /. 1000.0 in
         let newcst = read_double ch in
         (*
         msg "---";
         msg (sprintf "%d" (Int64.to_int ptr));
         msg (sprintf "%d" comp);
         msg (sprintf "%f" duration);
         (*msg (sprintf "%f" newcst);*)
         *)
         Evt_estim_report (ptr, comp, duration, newcst)
      | 15 -> 
         let ptr = read_int64 ch in
         let value = read_double ch in
         Evt_estim_update (ptr, value)
      | _ -> Evt_other
      in
   (time,proc,evttype)

let parse_logfile filename =
   let ch = open_in_bin filename in
   let evts = build_list (fun add ->
      try while true do
         add (parse_event ch)
      done with End_of_file -> ()
      ) in
   close_in ch;
   evts


(****************************************************)

type info = {
   mutable name : string;
   mutable updates : (time * float) list;
   mutable reports : (time * int * float) list;
   }

let empty_info = {
   name = "<unnamed>";
   updates = [];
   reports = [] }

let infos_of_events events =
   let info_of_ptr = Hashtbl.create 10 in
   let get_info ptr =
      try Hashtbl.find info_of_ptr ptr
      with Not_found -> 
         Hashtbl.add info_of_ptr ptr empty_info;
         Hashtbl.find info_of_ptr ptr
      in
   list_foreach (list_rev_notrec events) (fun (time,proc,evttype) ->
      match evttype with
     | Evt_estim_name (ptr,name) -> 
         let inf = get_info ptr in
         inf.name <- name
     | Evt_estim_report (ptr,comp,duration,newcst) -> 
         let inf = get_info ptr in
         inf.reports <- (time,comp,duration)::inf.reports
     | Evt_estim_update (ptr,value) -> 
         let inf = get_info ptr in
         inf.updates <- (time,value)::inf.updates
     | Evt_other -> ());
   let infos = ref [] in
   Hashtbl.iter (fun k v -> add_to_list_ref infos v) info_of_ptr;
   !infos


(****************************************************)

let make_graph info title scatter = 
  { graph_tag = "";  
    graph_title = sprintf "%s for: %s" title info.name; 
    graph_data = Scatter scatter; }

let take_one_every n xs = 
   if n < 1 then failwith "invalid arguments take_one_every";
   let rec aux i xs = 
      match i, xs with 
      | _, [] -> []
      | 0, x::xt -> x :: aux (n-1) xt
      | i, x::xt -> aux (i-1) xt
      in
   aux n xs

let bound_data_size data = (* target 600 items in total *)
   let head_length = 100 in
   let rest_length = 500 in  
   let length = List.length data in
   if length <= head_length+rest_length then 
      data 
   else begin
      let head,rest = list_take_drop head_length data in
      let fraction = 1 + (length-head_length) / rest_length in
      msg (sprintf "Warning: printing only %d first measures then 1 every %d" head_length fraction);
      let select = take_one_every fraction rest in
      head @ select     
   end 

let create_graphs info = 
   let data1 = bound_data_size info.reports in
   let points1 = list_map data1 (fun (time,comp,duration) -> (time,duration)) in
   let g1 = make_graph info "Duration of sequential tasks" { 
      scatter_xaxis = axis_zero "timeline";
      scatter_yaxis = axis_zero ~islog:true "duration";
      scatter_curves = ["", points1];
      scatter_drawline = false;
      scatter_mathcurves = [] } 
      in

   let points2 = list_map data1 (fun (time,comp,duration) -> (float_of_int comp, duration)) in
   let g2 = make_graph info "Duration versus complexity" { 
      scatter_xaxis = axis ~islog:true "complexity";
      scatter_yaxis = axis_zero ~islog:true "duration";
      scatter_curves = ["", points2];
      scatter_drawline = false;
      scatter_mathcurves = [] } 
      in

   let points3 = list_map info.updates (fun (time,value) -> (time,value)) in
   let g3 = make_graph info "Updates " { 
      scatter_xaxis = axis_zero "timeline";
      scatter_yaxis = axis_zero ~islog:true "value";
      scatter_curves = ["", points3];
      scatter_drawline = false;
      scatter_mathcurves = [] } 
      in
   [ g1; g2; g3 ]


(****************************************************)

let _ =
   parse_plot_options();
   let logfile = !arg_plot_input in 
   let events_by_time = parse_logfile logfile in
   let nb_events = List.length events_by_time in
   let infos = infos_of_events events_by_time in
   let graphs = list_concat_map create_graphs infos in
   pdf_of_graphs graphs;
   if Cmdline.mem_flag "open" 
      then ignore (system (sprintf "evince %s &" !arg_plot_output))


(****************************************************)





