open Shared
open Benchmark
open Printf
open Results
open Custom
open Myplot_funcs


(*********************************************************************************)
(* Parameters *)

let psched = ref "../" (* /home/mrainey/pscheduler/*)
(*let path_to_input_data = ref "/var/tmp/pbbsdata/"*)
let get_path_to_input_data _ =
  "/home/data/"
let email = ref ""
let should_gen_input_data = ref false
let should_build_all = ref false
let explicitly_selected_benchmarks = ref ([] : string list)
let path_to_results_file = ref ""
let pasl_binary_postfix = ref ".sta" 

(*********************************************************************************)
(* Utilities *)

let list_map_and_flatten xs f = List.flatten (list_map xs f)

let print_msg s = printf "*---------------- %s\n" s

let path_to_pbbs _ = !psched ^ "pbbs/"

let time_at_start_of_experiment = ref 0.0

let get_path_to_results _ = 
  if !path_to_results_file = "" then
    !psched ^ (sprintf "/results_%f/" !time_at_start_of_experiment)
  else
    !path_to_results_file

let verbose_cmd s = 
  let _ = printf "%s\n" s in
  if not !arg_virtual then
    system s
  else
    Unix.WEXITED 0

let verbose_cmd_norc s = ignore(verbose_cmd s)

let build_all _ = 
  let cmd = sprintf "%s/pasl/bench/ppopp13_build.sh \"%s\"" !psched !psched in
  verbose_cmd cmd

let send_email_notification experiment elapsed =
  if !email <> "" then
    let cmd = sprintf "echo \"took %f seconds to complete experiment %s on
	               `hostname`; results in %s \" | mail -s \"Experiment 
                       completed\" %s" 
                      elapsed experiment !email (get_path_to_results()) in
    verbose_cmd_norc cmd

let split_string_by_slash str = Str.split (Str.regexp "/") str

let filename_from_path str = 
  List.hd (List.rev (split_string_by_slash str))

let create_symlink src tgt =
  verbose_cmd (sprintf "ln -f -s %s %s" src tgt)


(*********************************************************************************)

type run = {
   prog : string;
   runs : int;
   timeout : int; 
   params : params; } 

let mk_run prog runs timeout params =
  { prog = prog; runs = runs; timeout = timeout; 
    params = params }

let create_benchrun run =
 { benchrun_bench = {
      bench_vmachine = "local"; 
      bench_prog = run.prog;
      bench_params = run.params;
      };
   benchrun_timeout = run.timeout;
   benchrun_nbruns = run.runs;
   benchrun_max_retry = 1;
   benchrun_batchid = nobatchid;
   }

let get_path_to_results_file basename =
  get_path_to_results() ^ basename ^ ".txt"

let get_path_to_plot_file basename =
  get_path_to_results() ^ basename ^ ".pdf"

let get_path_to_r_output_file basename =
  get_path_to_results() ^ basename ^ ".r"

let get_path_to_all () =
 get_path_to_results() ^"/all.txt"

let ppopp13_run basename runs =
  if !path_to_results_file = "" then begin
    let results_file =  get_path_to_results_file basename in
    let results_dir = get_path_to_results() in
    verbose_cmd_norc (sprintf "mkdir %s" results_dir);
    arg_run_output := results_file;
    execute_benchruns (List.map create_benchrun runs);
    if not !arg_virtual then begin
      let results = file_get_contents results_file in
      let all_results_file = get_path_to_all () in
      verbose_cmd (sprintf "touch %s" all_results_file);
      file_append_contents all_results_file results
    end
    else ()
  end
  else ()

(*
let ppopp13_plot basename title_opt to_ignore plot_cmd =
  arg_run_output := get_path_to_results_file basename;
  let path_to_results = get_path_to_results() in
  let pdffile = path_to_results ^ basename ^ ".pdf" in
  let rfile = path_to_results ^ basename ^ ".r" in
  let ignore_opt = 
    if to_ignore = "" then "" 
    else sprintf "-ignore %s" to_ignore
  in
  let cmd = sprintf "./plot %s -input %s -output %s -routput %s %s %s" 
    ignore_opt !arg_run_output pdffile rfile
    (match title_opt with None -> "" | Some t -> sprintf "-title %s" t)
    plot_cmd in
   msg_newline cmd;
   verbose_cmd cmd;
   verbose_cmd (sprintf "cp %s.* %s" basename path_to_results);
   let generatedtargetdir = (path_to_results^basename) in
   verbose_cmd (sprintf "mkdir %s" generatedtargetdir);
   verbose_cmd (sprintf "cp -r %s %s" "generated/*" generatedtargetdir);
   ()
*)

let pdf_of_charts_for_builder builder results =
    let charts = build_list (fun add_chart ->  
      builder add_chart results) in
    pdf_of_charts charts



let ppopp13_plot builder id =
  let results_file = get_path_to_results_file id in
  let output_file = get_path_to_plot_file id in
  let r_output_file = get_path_to_r_output_file id in
  if not !arg_virtual then (
    arg_plot_output := output_file;
    arg_plot_routput := r_output_file;
    let results = read_results_from_file results_file in
    let _  = if results = [] then printf "Warning: empty results list" in
    pdf_of_charts_for_builder builder results 
   )
  else 
    ()

let run_and_plot basename title_opt to_ignore plot_cmd runs = failwith "todo1"
(*
let run_and_plot basename title_opt to_ignore plot_cmd runs =
  let plotonly = Cmdline.parse_or_default_bool "plotonly" false in
  (if not plotonly then ignore(ppopp13_run basename runs);
   ppopp13_plot basename title_opt to_ignore plot_cmd)
*)

(*********************************************************************************)
(* Input data *)

let input_data = 
  [ 
    ("maximalMatching/graphData/randLocalGraph -d 3 -m          200000000 40000000", "egrlg");
    ("maximalMatching/graphData/rMatGraph -a .5 -b .1 -m        200000000 40000000", "egrmat");
    ("maximalMatching/graphData/gridGraph -d 2                  40000000", "eggrid2d");
    ("breadthFirstSearch/graphData/randLocalGraph -j -m         150000000 40000000", "rlg");
    ("breadthFirstSearch/graphData/rMatGraph -j -a .5 -b .1 -m  90000000  30000000", "rmat");
    ("breadthFirstSearch/graphData/gridGraph -j -d 3            40000000", "grid3d");
    ("breadthFirstSearch/graphData/gridGraph -j -d 2            40000000", "grid2d");
    ("convexHull/geometryData/uniform -d 2                      100000000", "uniform2d");
    ("convexHull/geometryData/plummer -d 2                      100000000", "plummer2d");

    ("comparisonSort/sequenceData/randomSeq -t double           240000000", "randdblseq");
    ("comparisonSort/sequenceData/exptSeq -t double             240000000", "exptseq");
    ("comparisonSort/sequenceData/almostSortedSeq -t double     240000000", "almostsortedseq");

    ("comparisonSort/sequenceData/randomSeq -t int              240000000", "randintseq");
    ("comparisonSort/sequenceData/exptSeq -t int                240000000", "exptintseq");
    ("comparisonSort/sequenceData/almostSortedSeq -t int        240000000", "almostsortedintseq");

  ]

let gen_input_data () =
  verbose_cmd_norc ("mkdir " ^ (get_path_to_input_data()));
  let gen_one (cmd, tgt) = 
    let cmd' = sprintf "%s%s %s%s" (path_to_pbbs()) cmd (get_path_to_input_data()) tgt in
    verbose_cmd_norc cmd'
  in
  print_msg "generating input data" ;
  List.iter gen_one input_data

let path_of_input_data d = (get_path_to_input_data()) ^ d

(*********************************************************************************)
(* Experiments *)

(*-----------------------------------------------------*)
(* Shared parameters *)

let all_proc = ref [0;1;8;16;24;30]
let all_delta = ref [50;300;1000;3000;30000;300000;1000000]
let all_nb_runs = ref 5
let all_timeout = 100000
let dflt_delta = ref 30
let all_taskset = ref ["cas_si_poisson";"cas_ri";"shared_deques"]
let all_input_types = ""               (* graph,points*)

let get_pasl_binary_postfix _ = !pasl_binary_postfix
let cilk_binary_postfix = ".cilk"

let paths_to_binaries = ref ([] : (string*string*string) list)
let add_to_paths_to_binaries path = 
  paths_to_binaries := path :: !paths_to_binaries
let cilk_binary_alias name = "cilk/"^(filename_from_path name)^".cilk"
let input_data_binary_alias name = "data/"^(filename_from_path name)

let create_symlinks_for_binaries _ = (
  verbose_cmd_norc (sprintf "rm -rf cilk data");
  verbose_cmd_norc (sprintf "mkdir cilk");
  verbose_cmd_norc (sprintf "mkdir data");
  List.iter 
    (fun (btype,name,path) -> 
      match btype with
      | "cilk" -> 
	  let path = (*Sys.getcwd() ^ "/" ^ *) path in
	  ignore(create_symlink path (cilk_binary_alias name))
      | "data" -> ignore(create_symlink path (input_data_binary_alias name))
      | _ -> failwith "create_symlinks_for_binaries")
    !paths_to_binaries)

let pasl_binary name = "examples/" ^ name ^ (get_pasl_binary_postfix())
let pbbs_binary name = 
  let path = !psched ^ "/pbbs/" ^ name in
  add_to_paths_to_binaries("cilk",name, path);
  cilk_binary_alias name
let cilkplus_binary name = 
  let path = !psched ^ "/cilkplus/examples/" ^ name ^ cilk_binary_postfix in
  add_to_paths_to_binaries("cilk",name, path);
  cilk_binary_alias name

let is_pasl_binary bin = 
  let len = String.length bin in
  let tl = String.sub bin (len-4) 4 in
  tl = (get_pasl_binary_postfix())

let mk_input_data_arg g = 
  let path = path_of_input_data g in
  add_to_paths_to_binaries ("data", g, path);
  Dyn.String (input_data_binary_alias g)

let mk_normal_run prog proc input =
  mk_run prog !all_nb_runs all_timeout
    ([("proc", Dyn.Int proc);("delta", Dyn.Int !dflt_delta)] @ input)

let connectivity_graphs =
  [[("graph", mk_input_data_arg "rlg")];
   [("graph", mk_input_data_arg "rmat")];
   [("graph", mk_input_data_arg "grid3d")]]

let using_cutoff cutoff inputs = 
  List.map (fun input -> ("cutoff", Dyn.Int cutoff)::input) inputs 

type input = string * Dyn.t
type benchmark = (string * string list * input list list)
let all_benchs = ref ([] : benchmark list)

let get_all_benchs _ =
  ((match !all_benchs with 
  | [] -> 
  (all_benchs := 
    [("fib", 
    [pasl_binary "fib"; cilkplus_binary "fib"], 
    using_cutoff 18 [[("n", Dyn.Int 50)]]);
   ("quickhull", 
    [pasl_binary "hull"; pbbs_binary "convexHull/quickHull/hull"],
    using_cutoff 1024
      [[("points", mk_input_data_arg "uniform2d")]; 
       [("points", mk_input_data_arg "plummer2d")];]);
(*
   ("bellman_ford", 
    [pasl_binary "bellman_ford"; cilkplus_binary "bellman_ford"],
    using_cutoff 3000
      (List.map (fun seed -> [("nb_nodes", Dyn.Int 20000);("seed", Dyn.Int seed)]) [1;2;4;5]));
*)
(*
   ("bfs",
    [pasl_binary "BFS"; pbbs_binary "/breadthFirstSearch/ndBFS/BFS"],
    using_cutoff 256 connectivity_graphs);
*)
   ("dfs",
    [pasl_binary "dfs"],
    connectivity_graphs);
   ("matmul",
    [pasl_binary "matmul"; cilkplus_binary "matmul"],
    using_cutoff 128 [[("n", Dyn.Int 3500)]]);
   ("mis",
    [pasl_binary "MIS"; pbbs_binary "/maximalIndependentSet/incrementalMIS/MIS"],
    using_cutoff 256
      [[("graph", mk_input_data_arg "rlg")];
       [("graph", mk_input_data_arg "rmat")];
       [("graph", mk_input_data_arg "grid2d")]]);
   ("maxmatch",
    [pasl_binary "matching"; pbbs_binary "/maximalMatching/incrementalMatching/matching"],
    using_cutoff 256
      [[("graph", mk_input_data_arg "egrlg")];
       [("graph", mk_input_data_arg "egrmat")];
       [("graph", mk_input_data_arg "eggrid2d")]]);

   ("cilksort",
    [pasl_binary "cilksort"; cilkplus_binary "cilksort"],
    let mergesize = ("mergesize", Dyn.Int 1024) in
    let quicksize = ("quicksize", Dyn.Int 1024) in
    let sequences = [[("sequence", mk_input_data_arg "randintseq")];
		     [("sequence", mk_input_data_arg "exptintseq")];
		     [("sequence", mk_input_data_arg "almostsortedintseq")]]
    in
    List.map (fun input -> mergesize::quicksize::input) sequences
   );
   ("sample_sort",
    [pasl_binary "sort"; pbbs_binary "/comparisonSort/sampleSort/sort"],
    let sequences =
      [[("sequence", mk_input_data_arg "randdblseq")];
       [("sequence", mk_input_data_arg "exptseq")];
       [("sequence", mk_input_data_arg "almostsortedseq")]]
    in
    using_cutoff 2048 sequences);
  ])
  | _ -> ());
  !all_benchs)

let sel_benchmarks ids = 
  let sel (id,_,_) = List.exists (fun id' -> id' = id) ids in
  List.filter sel (get_all_benchs())

let get_default_benchmarks _ =
  match !explicitly_selected_benchmarks with
  | [] -> (get_all_benchs())
  | benchs -> sel_benchmarks benchs

let filter_benchmarks ids benchs =
  let sel (id,_,_) = List.for_all (fun id' -> not (id' = id)) ids in
  List.filter sel benchs

(*-----------------------------------------------------*)
(* 1. Shootout *)

let contains s1 s2 =
  let re = Str.regexp_string s2 in
  try (ignore (Str.search_forward re s1 0); true)
  with Not_found -> false

let shootout _ =
  let benchs = get_default_benchmarks() in
  let benchs = filter_benchmarks ["dfs"] benchs in
  let proc = list_last !all_proc in
  List.iter (fun (bench, progs, inputs) ->
    let id = sprintf "shootout_%s" bench in
    ppopp13_run
      id
      (list_map_and_flatten inputs (fun input ->
	(list_map_and_flatten progs (fun prog ->
	  if contains prog ".cilk" then 
	    [mk_normal_run prog proc input]
	  else
	    (list_map_and_flatten !all_taskset (fun taskset ->
	      (list_map [0] (fun deal_heuristic ->
		let input' = ("taskset", Dyn.String taskset)::
		  (*("deal_heuristic", Dyn.Int deal_heuristic)::*)input in
		mk_normal_run prog proc input'))))))));
    ppopp13_plot (mode_sched_vs_cilk_by "proc") id;
    ())
    benchs;
  if not !arg_virtual then begin
    let output_file = get_path_to_plot_file "all_vs_cilk" in
    arg_plot_output := output_file;
    let all_results_file = get_path_to_all () in
    let results = read_results_from_file all_results_file in 
(*    pdf_of_charts_for_builder mode_table_vs_ours results *)
()
  end
  else ()


(*-----------------------------------------------------*)
(* 2. DFS *)

let dfs _ =
  let id = "dfs" in
  match sel_benchmarks ["dfs"] with
  | [(bench,progs,inputs)] -> (
      ppopp13_run
	id
	(list_map_and_flatten !all_proc (fun proc ->
	  (list_map_and_flatten progs (fun prog ->
	    (list_map inputs (fun input ->
	      let input' = 
		("steal_half", Dyn.Int 1) 
		:: ("use_naive_dfs", Dyn.Int 0)
		:: input in
	      mk_normal_run prog proc input'))))));
      ppopp13_plot (mode_speedup []) id;
      ())
  | _ -> failwith "dfs: impossible"

(*-----------------------------------------------------*)
(* 3. All PASL speedups  *)

let all_pasl_speedups _ =
  let benchs = get_default_benchmarks() in
  List.iter (fun (bench, progs, inputs) ->
    let id = sprintf "all_pasl_speedups_%s" bench in
    ppopp13_run
      id
      (list_map_and_flatten (List.filter is_pasl_binary progs) (fun prog ->
	(list_map_and_flatten !all_proc (fun proc ->
	  (list_map inputs (fun input ->
	    mk_normal_run prog proc input))))));
    ppopp13_plot (mode_speedup []) id )
    benchs
    
(*-----------------------------------------------------*)
(* 4.1. Impact of delay on program execution time by nb procs *)

let delay_on_exectime_by_proc _ =
  let id = "delay_on_exectime" in
  let bench_names = ["bellman_ford";"cilksort";"matmul"] in
  run_and_plot
    id
    (Some id)
    all_input_types
    "-y exectime -x delta -curve proc"
    (list_map_and_flatten (sel_benchmarks bench_names) (fun (bench, progs, inputs) ->
      (list_map_and_flatten !all_proc (fun proc ->
	(list_map_and_flatten !all_delta (fun delta ->
	  (list_map_and_flatten progs (fun prog ->
	    (list_map inputs (fun input ->
	      mk_run prog !all_nb_runs all_timeout
		([("proc", Dyn.Int proc);("delta", Dyn.Int delta)] @ input)))))))))))

(*-----------------------------------------------------*)
(* 4.2. Impact of delay on program execution time *)

let delay_on_exectime_by_prog _ =
  let id = "delay_on_exectime_by_prog" in
  let benchs = get_default_benchmarks() in
  run_and_plot
    id
    (Some id)
    all_input_types
    "-y exectime -x delta -curve prog"
    (list_map_and_flatten benchs (fun (bench, progs, inputs) ->
      (list_map_and_flatten !all_proc (fun proc ->
	(list_map_and_flatten !all_delta (fun delta ->
	  (list_map_and_flatten progs (fun prog ->
	    (list_map inputs (fun input ->
	      mk_run prog !all_nb_runs all_timeout
		([("proc", Dyn.Int proc);("delta", Dyn.Int delta)] @ input)))))))))))


(*-----------------------------------------------------*)
(* 5. Cost of interrupts *)

let cost_of_interrupts _ =
  let id = "cost_of_interrupts" in
  let proc = 1 in
  let delta = 100000000 in
  let ping = 1000 in
  run_and_plot
    id
    (Some id)
    all_input_types
    "-y exectime -x delta -curve proc"
    (list_map_and_flatten (sel_benchmarks ["fib"]) (fun (bench, progs, inputs) ->
      (list_map_and_flatten [0;1] (fun interrupts ->
	(list_map_and_flatten (List.filter is_pasl_binary progs) (fun prog ->
	  (list_map inputs (fun input ->
	    mk_run prog !all_nb_runs all_timeout
	      ([("proc", Dyn.Int proc);
		("interrupts", Dyn.Int interrupts);
		("ping", Dyn.Int ping);
		("delta", Dyn.Int delta)] @ input)))))))))

(*********************************************************************************)
(* Committing results to an SVN repository *)

let verbose_cmd_assert s =
  match verbose_cmd s with
  | Unix.WEXITED 0 -> ()
  | _ -> failwith(sprintf "Failed on command: %s" s)

let svn_commit _ = 
  let path_to_working_copy = Cmdline.parse_or_default_string "svn_commit" "" in
  let path_to_results = get_path_to_results() in
  if path_to_working_copy <> "" then
    (verbose_cmd_assert(sprintf "cp -r %s %s" path_to_results path_to_working_copy);
     verbose_cmd_assert(sprintf "cd %s && svn add %s && svn ci -m \"new results\"" 
			  path_to_working_copy 
			  (filename_from_path path_to_results));
     ())
  else ()

(*********************************************************************************)
(* Entry point *)

let should_run_experiment exp exps = 
  List.length exps = 0 || List.exists (fun e -> exp = e) exps

let all_experiments =
  [("shootout", shootout);
   ("dfs", dfs);
   ("all_pasl_speedups", all_pasl_speedups);
   ("delay_on_exectime_by_proc", delay_on_exectime_by_proc);
   ("delay_on_exectime_by_prog", delay_on_exectime_by_prog);
   ("cost_of_interrupts", cost_of_interrupts);
 ]
    
let _ =
  parse_plot_options();
  psched := Sys.getcwd() ^ "/../";
  all_nb_runs := Cmdline.parse_or_default_int "runs" 3;
  email := Cmdline.parse_or_default_string "email" "";
  pasl_binary_postfix := Cmdline.parse_or_default_string "pasl_postfix" ".opt";
  get_all_benchs();
  arg_virtual := Cmdline.parse_or_default_bool "virtual" false;
  should_gen_input_data := Cmdline.parse_or_default_bool "gen_input_data" false;
  should_build_all := Cmdline.parse_or_default_bool "build_all" false;
  explicitly_selected_benchmarks := Cmdline.parse_or_default_list_string "benchmark" [];
  path_to_results_file := Cmdline.parse_or_default_string "path_to_results_file" "";
  all_proc := Cmdline.parse_or_default_list_int "proc" !all_proc;
  all_taskset := Cmdline.parse_or_default_list_string "taskset" !all_taskset;
  all_delta := Cmdline.parse_or_default_list_int "delta" !all_delta;
  (*-----------*)
  if !should_build_all then (build_all(); exit 0);
  if !should_gen_input_data then (gen_input_data(); exit 0);
  (*-----------*)
  time_at_start_of_experiment := Unix.time();
  create_symlinks_for_binaries();
  (*-----------*)
  let experiments = Cmdline.parse_or_default_list_string "experiment" [] in
  let run_experiment exp_name exp =
    print_msg(sprintf "starting experiment %s" exp_name);
    let start_time = Unix.gettimeofday() in
    exp();
    let elapsed = Unix.gettimeofday() -. start_time in
    print_msg (sprintf "results stored in %s" (get_path_to_results()));
    print_msg (sprintf "completed experiment %s in %f seconds" exp_name elapsed);
    send_email_notification exp_name elapsed;
    ()
  in
  List.iter 
    (fun (exp_name, exp) -> 
      if should_run_experiment exp_name experiments then run_experiment exp_name exp)
    all_experiments;  
  (*-----------*)
  svn_commit();
  ()
