(* Benchmarking script for "Reporting parallel speedups: the good 
 * the bad, and the better"
 * To be submitted to PPoPP 2014
 * 
 * Command-line arguments
 *
 *
 *)


open Shared
open Benchmark
open Printf
open Results
open Custom
open Myplot_funcs



(*********************************************************************************)
(* Parameters *)

let path_to_pasl = ref "../pasl/"
let path_to_all_results = ref "../results/"
let path_to_current_results = ref ""
let pasl_binary_suffix = ref ".opt"
let all_timeout = ref 100000
let all_nb_runs = ref 3
let plotonly = ref false
let finalversion = ref false
let hostname = ref ""
let all_cores = ref [0;1;8;16;24;32;39]
let all_cores_but_one = ref [0;8;16;24;32;39]
let all_hyperthreads = ref [0;1;8;16;24;32;39]
let all_hyperthreads_but_one = ref [0;8;16;24;32;39]

(*********************************************************************************)
(* Utilities *)

let list_map_and_flatten xs f = List.flatten (list_map xs f)

let print_msg s = printf "*---------------- %s\n" s

let time_at_start_of_experiment = ref 0.0

let verbose_cmd s = 
  let _ = printf "%s\n" s in
  if not !arg_virtual then
    system s
  else
    Unix.WEXITED 0

let verbose_cmd_norc s = ignore(verbose_cmd s)

let get_speedup_experiment_prog _ = 
  !path_to_pasl ^ "/examples/speedup_experiments" ^ !pasl_binary_suffix

let build_benchmark _ =
  begin
    verbose_cmd_norc (sprintf "make -C %s clean" !path_to_pasl);
    verbose_cmd_norc (sprintf "make -j -C %s examples/speedup_experiments.opt" !path_to_pasl);
    verbose_cmd_norc (sprintf "make -j -C %s examples/speedup_experiments.sta" !path_to_pasl);
  end

let get_path_to_generated_folder _ =
  !path_to_current_results ^ "/generated"
let get_path_to_results_file experiment_name =
  !path_to_current_results ^ "/" ^ experiment_name ^ ".txt"
let get_path_to_pdf experiment_name =
  !path_to_current_results ^ "/" ^ experiment_name ^ ".pdf"
let get_path_to_r_file experiment_name =
  !path_to_current_results ^ "/" ^ experiment_name ^ ".r"

let configure_for_machine _ =
  hostname := localhost_name;
  let nb_cores = 
    if !hostname = "teraram" then 40 
    else if !hostname = "cadmium" then 48
    else 40 
  in
  let nb_hyperthreads =
    if !hostname = "teraram" then 80
    else if !hostname = "cadmium" then nb_cores
    else nb_cores
  in
  begin
    all_cores := int_range 0 nb_cores;
    all_hyperthreads := int_range 0 nb_hyperthreads;
    let shorten = List.filter (fun p -> p = 1 || p mod 8 = 0) in
    if not(!finalversion) then begin
      all_cores := shorten !all_cores;
      all_hyperthreads := shorten !all_hyperthreads;
    end;
    let all_but_one = List.filter (fun p -> p <> 1) in
    all_cores_but_one := all_but_one !all_cores;
    all_hyperthreads_but_one := all_but_one !all_hyperthreads;
    ()
  end

(*********************************************************************************)
(* Experiment runs *)

type run = {
   prog : string;
   runs : int;
   timeout : int; 
   params : params; } 

let is_sequential_run_param param =
  match param with
  | ("proc", Dyn.Int p) -> p = 0 || p = 1
  | _ -> false

let is_sequential_run run = 
  List.exists is_sequential_run_param run.params

let mk_run prog runs timeout params =
  { prog = prog; runs = runs; timeout = timeout; 
    params = params }

let mk_typical_run params =
  let prog = get_speedup_experiment_prog () in
  let nb_runs = 
    if List.exists is_sequential_run_param params then 
      1 
    else 
      !all_nb_runs 
  in
  mk_run prog nb_runs !all_timeout params

let add_params_to_run params run =
  mk_run run.prog run.runs run.timeout (params @ run.params)

let add_param_to_run param run =
  add_params_to_run [param] run

let create_benchrun run =
 { benchrun_bench = {
      bench_vmachine = "local"; 
      bench_prog = run.prog;
      bench_params = run.params;
      };
   benchrun_timeout = run.timeout;
   benchrun_nbruns = run.runs;
   benchrun_max_retry = 1;
   benchrun_batchid = nobatchid;
   }

let my_mkdir path = 
  if not(Sys.file_exists path) then begin verbose_cmd_norc (sprintf "mkdir %s" path) end

let create_results_folders () =
    List.iter my_mkdir [!path_to_all_results; 
			!path_to_current_results; 
			get_path_to_generated_folder ()]

let ppopp14_run_phase experiment_name phase_name runs =
  if not(!plotonly) then begin
  create_results_folders();
  let results_file = get_path_to_results_file experiment_name in
  let tmp_results_file =  results_file ^ "_" ^ phase_name in  
  arg_run_output := tmp_results_file;
  execute_benchruns (List.map create_benchrun runs);
  if not !arg_virtual then begin
    let results = file_get_contents tmp_results_file in
    verbose_cmd_norc (sprintf "touch %s" results_file);
    file_append_contents results_file results;
    verbose_cmd_norc (sprintf "mv %s %s" tmp_results_file (get_path_to_generated_folder()))
  end
  else ()
  end

let ppopp14_run experiment_name runs = 
  let (seq_runs, par_runs) = List.partition is_sequential_run runs in
  ppopp14_run_phase experiment_name "seq" seq_runs;
  ppopp14_run_phase experiment_name "par" par_runs

let default_cutoff = 10000
let default_par_repeat = 1

let mk_proc p = ("proc", Dyn.Int p)
let mk_size s = ("size", Dyn.Int s)
let mk_gap g = ("gap", Dyn.Int g)
let mk_cutoff c = ("cutoff", Dyn.Int c)
let mk_op oper = ("op", Dyn.String oper)
let mk_par_repeat r = ("par_repeat", Dyn.Int r)
let mk_computation c = ("computation", Dyn.Int c)

let mk_speedup_experiment name procs cutoffs sizes ops gaps par_repeats computations =
  (list_map_and_flatten procs (fun proc ->
    (list_map_and_flatten cutoffs (fun cutoff ->
      (list_map_and_flatten sizes (fun size ->
	(list_map_and_flatten ops (fun oper ->
	  (list_map_and_flatten gaps (fun gap ->
	    (list_map_and_flatten par_repeats (fun par_repeat ->
	    (list_map_and_flatten computations (fun computation ->
	      [mk_typical_run [mk_proc proc; mk_cutoff cutoff;
			      mk_size size; mk_op oper; 
			      mk_gap gap; mk_par_repeat par_repeat;
			      mk_computation computation]]))))))))))))))

(*********************************************************************************)
(* Plotting *)

let pdf_of_charts_for_builder builder results =
    let charts = build_list (fun add_chart ->  
      builder add_chart results) in
    pdf_of_charts charts

let ppopp14_plot builder name =
  let results_file = get_path_to_results_file name in
  let output_file = get_path_to_pdf name in
  let r_output_file = get_path_to_r_file name in
  if not !arg_virtual then (
    arg_plot_output := output_file;
    arg_plot_routput := r_output_file;
    let results = read_results_from_file results_file in
    let _  = if results = [] then printf "Warning: empty results list" in
    pdf_of_charts_for_builder builder results 
   )
  else 
    ()


(*********************************************************************************)
(* Experiments *)
    
(*-----------------------------------------------------*)
(* 5.1 Speedup versus amount of computation *)

let speedup_vs_amount_of_computation_no_bottleneck _ =
  let name = "speedup_vs_amount_of_computation--no_bottleneck" in
  let procs = !all_cores_but_one in
  let cutoffs = [default_cutoff] in
  let sizes = [600000000] in
  let ops = ["incr"] in
  let gaps = [256] in
  let par_repeats = [default_par_repeat] in
  let computations = [1;5;20;40;100;200] in
  let runs = mk_speedup_experiment name procs cutoffs sizes ops gaps par_repeats computations in
  ppopp14_run name runs;
  ppopp14_plot (mode_speedup []) name

let speedup_vs_amount_of_computation_bottleneck _ =
  let name = "speedup_vs_amount_of_computation--bottleneck" in
  let procs = !all_cores_but_one in
  let cutoffs = [default_cutoff] in
  let sizes = [600000000] in
  let ops = ["incr"] in
  let gaps = [1] in
  let par_repeats = [default_par_repeat] in
  let computations =  [1;2;5;6;7;8;15;20;30] in
  let runs = mk_speedup_experiment name procs cutoffs sizes ops gaps par_repeats computations in
  ppopp14_run name runs;
  ppopp14_plot (mode_speedup []) name
	    
(*-----------------------------------------------------*)
(* 5.2 Input data size and locality *)

let allocation_policy_versus_speedup _ =
  let name = "allocation_policy_versus_speedup" in
  let procs = !all_cores in
  let cutoffs = [default_cutoff] in
  let sizes = [3000000000] in
  let ops = ["incr"] in
  let gaps = [1(*;64;256*)] in
  let par_repeats = [default_par_repeat] in
  let computations = [0] in
  let basic_runs = mk_speedup_experiment name procs cutoffs sizes ops gaps par_repeats computations in
  let runs = 
    list_map_and_flatten [0;1] (fun i -> 
      list_map_and_flatten [0;1] (fun b -> 
	List.map (add_params_to_run [("force_sequential_init_array", Dyn.Int b);
				     ("force_numa_interleave", Dyn.Int i)]) basic_runs))
  in
  ppopp14_run name runs;
  ppopp14_plot (mode_speedup []) name

let vary_input_size _ =
  let name = "vary_input_size" in
  let sizes_and_par_repeats = [(400000000,1);(200000000,2);(80000000,5);(40000000,10);
			       (16000000,25);(8000000,50);(4000000,100);(2000000,200);
			       (1000000,400);(500000,800);(250000,1600);] in
  list_foreach sizes_and_par_repeats (fun (size, par_repeat) ->
    let procs = if !hostname = "teraram" then [0;10;20;30;40] else [0;10;20;30;48] in
    let cutoffs = [default_cutoff] in
    let sizes = [size] in
    let ops = ["read"] in
    let gaps = [32] in
    let par_repeats = [par_repeat] in
    let computations = [0] in
    let basic_runs = mk_speedup_experiment name procs cutoffs sizes ops gaps par_repeats computations in
    let runs = 
      list_map_and_flatten [0] (fun b -> 
	List.map (add_param_to_run ("force_sequential_init_array", Dyn.Int b)) basic_runs)
    in
    ppopp14_run name runs);
  ppopp14_plot (fun add_chart resultsA -> 
    mode_ppopp14_vary_input_size [] add_chart resultsA;
    mode_ppopp14_vary_input_size_extra [] add_chart resultsA; 
    mode_ppopp14_vary_input_size_speedup [] add_chart resultsA) name

(*-----------------------------------------------------*)
(* 5.2 Thread placement *)
  
let placement _ =
  let name = "placement" in
  let procs = !all_hyperthreads_but_one in
  let cutoffs = [default_cutoff] in
  let sizes = [600000000] in
  let ops = ["incr"] in
  let gaps = [1(*;64;256*)] in
  let par_repeats = [default_par_repeat] in
  let computations = [1] in
  let basic_runs = mk_speedup_experiment name procs cutoffs sizes ops gaps par_repeats computations in
  let hyperthreading_modes = if !hostname = "cadmium" then ["disabled"] else ["disabled";"ifneeded";"useall";] in
  let runs = 
    list_map_and_flatten hyperthreading_modes (fun h ->
      list_map_and_flatten ["sparse";"dense";"none"] (fun b -> 
	let p1 = ("hyperthreading", Dyn.String h) in
	let p2 = ("numa_binding_policy", Dyn.String b) in
	List.map (add_params_to_run [p1;p2]) basic_runs))
  in
  ppopp14_run name runs;
  ppopp14_plot (mode_speedup ["numa_binding_policy"]) name

(*********************************************************************************)
(* Main *)

let should_run_experiment exp exps = 
  List.length exps = 0 || List.exists (fun e -> exp = e) exps

let all_experiments =
  [("speedup_vs_amount_of_computation--no_bottleneck", speedup_vs_amount_of_computation_no_bottleneck);
   ("speedup_vs_amount_of_computation--bottleneck", speedup_vs_amount_of_computation_bottleneck);
   ("allocation_policy_versus_speedup", allocation_policy_versus_speedup);
   ("vary_input_size", vary_input_size);
   ("placement", placement);
  ]

let _ =
  parse_plot_options();

  configure_for_machine ();

  finalversion := Cmdline.parse_or_default_bool "finalversion" false;
  plotonly := Cmdline.parse_or_default_bool "plotonly" false;
  arg_virtual := Cmdline.parse_or_default_bool "virtual" false;
  all_nb_runs := Cmdline.parse_or_default_int "runs" 3;

  path_to_pasl := Cmdline.parse_or_default_string "path_to_pasl" !path_to_pasl;
  pasl_binary_suffix := Cmdline.parse_or_default_string "pasl_binary_suffix" !pasl_binary_suffix;

  path_to_all_results := Cmdline.parse_or_default_string "path_to_all_results" !path_to_all_results;
  time_at_start_of_experiment := Unix.time();
  let p = sprintf "%s/%f" !path_to_all_results !time_at_start_of_experiment in
  path_to_current_results := Cmdline.parse_or_default_string "path_to_current_results" p;

  let experiments = Cmdline.parse_or_default_list_string "experiment" [] in

  if Cmdline.parse_or_default_bool "build_benchmark" false then
    build_benchmark ()
  else ();

  let run_experiment exp_name exp =
    print_msg(sprintf "starting experiment %s" exp_name);
    let start_time = Unix.gettimeofday() in
    exp();
    let elapsed = Unix.gettimeofday() -. start_time in
    print_msg (sprintf "results stored in %s" !path_to_current_results);
    print_msg (sprintf "completed experiment %s in %f seconds" exp_name elapsed);
    ()

in
List.iter 
  (fun (exp_name, exp) -> 
    if should_run_experiment exp_name experiments then run_experiment exp_name exp)
  all_experiments; 
()
