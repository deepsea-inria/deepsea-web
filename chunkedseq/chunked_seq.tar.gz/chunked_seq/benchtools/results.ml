open Shared
open Benchmark
open Printf

(*********************************************************)

let param_eq k v (k',v') = 
   if k = k' then v = v' else true
let param_neq k v (k',v') = 
   if k = k' then v <> v' else true

exception Missing_data

let data_string key data =
   try List.assoc key data
   with Not_found -> raise Missing_data

let data_float key data =
   float_of_string (data_string key data)

let data_int key data =
   int_of_string (data_string key data)

let data_bool key data =
   bool_of_string (data_string key data)

let datas_mean key datas =
   let values = list_map datas (data_float key) in 
   list_mean values


let datas_find_uniform data_func key datas =
   match datas with
   | [] -> failwith "empty list for datas_find_uniform"
   | data::datas' ->
      let value = data_func key data in
      list_foreach datas' (fun data' ->
         let value' = data_func key data' in
         if value <> value' then failwith "nonuniform values for datas_find_uniform");
      value

let params_to_force params =
   List.map (fun (key,value) -> param_eq key value) params

let eval_force force data =
   list_for_all force (fun f ->
      list_for_all data f)

let datas_filter force datas =
   list_filter datas (fun data -> 
      eval_force force data)

let results_filter force results =
   list_filter results (fun (data,_) -> 
      eval_force force data)
      

let print_data data = 
   List.iter (fun (k,v) -> printf "%s %s\n" k v) data

let print_datas datas =
   list_iter datas print_data;
   print_newline()

let print_results results =
   list_iter results (fun (data,inputs) ->
      print_data data);
   print_newline()

(*********************************************************)

let data_string_opt key data =
   try Some (data_string key data)
   with Missing_data -> None 

let indexer_for_data variables = fun data ->
   List.fold_left (fun acc key ->   
      try (key, data_string key data)::acc
      with Missing_data -> acc)
      [] variables 

let indexer_for_results variables = fun (data,inputs) ->
   indexer_for_data variables data

let indexer_for_results_all_inputs_but reserved_keys = fun (data,inputs) ->
   let variables = list_substract inputs reserved_keys in
   indexer_for_data variables data



let list_buckets f l =
   let rec insert k v r = 
      match r with
      | [] -> [k,[v]]
      | (k',vs)::r' -> if k = k' then (k',v::vs)::r' else (k',vs)::(insert k v r')
      in
   let add_elem acc v =
      try 
         let k = f v in
         insert k v acc 
      with Missing_data -> acc (* todo: error? *)
      in
   List.fold_left add_elem [] (List.rev l)


let make_buckets f l =
   list_ksort cmp_values (list_buckets f l)



let title_of_params params =
  string_of_list ", " (fun (key,value) -> sprintf "%s=%s" key value) params

let cmp_curve_title a b =
  let b = 
     try   
      let x = Scanf.sscanf a "%[^=]=%f" (fun _ f -> f) in
      let y = Scanf.sscanf b "%[^=]=%f" (fun _ f -> f) in
      x < y
      with _ -> a < b
     in
  if b then -1 else 1



(***************************************************************)
(** * Functions for custom plotting *)

(* note: type results = (datas*inputs) *)

module Custom = struct

let axis_default = 
   axis ~lower:None ~islog:false "untitled"

let scatter_default = {
   scatter_xaxis = axis_default;
   scatter_yaxis = axis_default;
   scatter_curves = [];
   scatter_drawline = true;
   scatter_mathcurves = [];
   scatter_enriched = false; }  

let scatter_xzero_for scatter = 
   { scatter with scatter_xaxis =
       { scatter.scatter_xaxis with axis_lower = Some 0. } }

let scatter_yzero_for scatter = 
   { scatter with scatter_yaxis =
       { scatter.scatter_yaxis with axis_lower = Some 0. } }

let scatter_xlog_for scatter = 
   { scatter with scatter_xaxis =
       { scatter.scatter_xaxis with axis_islog = true } }

let scatter_ylog_for scatter = 
   { scatter with scatter_yaxis =
       { scatter.scatter_yaxis with axis_islog = true } }


let bucket keys results =
   make_buckets (indexer_for_results keys) results

let curve title make_points =
   let points = build_list make_points in
   (title, points)

let graph title scatter make_curves =
   let curves_with_params = build_list make_curves in
   let common_params =
      if curves_with_params = [] then [] else begin
         let params_set = list_map curves_with_params fst in
         list_filter (List.hd params_set) (fun p ->
            list_for_all params_set (fun params ->
               List.mem p params))
      end in
   let curves = list_map curves_with_params (fun (params,points) ->
      let params' = list_substract params common_params in
      (title_of_params params' ,points))
      in
      (* todo : sort curves *)
   let scatter = { scatter with scatter_curves = curves } in
   { graph_tag = "";  
      graph_title = sprintf "%s -- %s" title (title_of_params common_params); 
      graph_data = Scatter scatter; }

let satisfy fixed_data (data,inputs) =
   list_for_all fixed_data (fun (k,d) -> 
       try (data_string k data) = d 
       with Missing_data -> false)

let keep fixed_data results =
   list_filter results (fun result ->
     satisfy fixed_data result)
 
let remove fixed_data results =
   list_filter results (fun result ->
     not (satisfy fixed_data result))

let input_data result =
   let (data,inputs) = result in 
   list_map inputs (fun key -> 
      try (key, data_string key data)
      with Not_found -> failwith "select_like missing keys")

let string_of_data data =
  string_of_list "," (fun (k,v) -> sprintf "%s=%s" k v) data

let input_data_for_set_ignoring ignored_keys results =
   if results = [] then failwith "input_data_for_set given the empty list";
   let remove_ignored data = 
      list_filter data (fun (k,v) -> not (List.mem k ignored_keys)) in
   let indatas = list_map results (fun r -> remove_ignored (input_data r)) in
   let indata = List.hd indatas in
   if not (list_for_all indatas (fun indata' -> 
      let b = indata' = indata in
      if not b then
      printf "%s\n%s\n---\n" (string_of_data indata) (string_of_data indata'); 
      b))
      then failwith "input_data_for_set_ignoring: input data differs (look above to see which keys mismatch)";
   indata

let inputs_for_set results =
   if results = [] then failwith "inputs_for_set given the empty list";
   let inputs_set = List.map snd results in
   let inputs = List.hd inputs_set in
   if not (list_for_all inputs_set (fun inputs' -> inputs' = inputs))
      then begin
         msg (string_of_list "\n" (string_of_list "," (fun x-> x))(List.rev inputs_set));
         failwith "inputs_for_set: input keys differs:\n"
         end;
   inputs

let select_like_ignoring ignored_keys results_model updated_data results_from =
   let indata = input_data_for_set_ignoring ignored_keys results_model in
   let fixed_data = List.fold_left (fun acc (k,v) ->
         try list_assoc_replace k v acc 
         with Not_found -> failwith "select_like: data key to update not found"
      ) indata updated_data 
     in
   (* todo: isolate function out of above *)
   (* let fixed_data = list_filter fixed_data (fun (k,v) -> not (List.mem k ignored_keys)) in*)
   keep fixed_data results_from
   
let select_like results_model updated_data results_from =
   select_like_ignoring [] results_model updated_data results_from
 

let plot add_point x y =
   add_point (x,y)

let get key (result:result) =
   let (data,inputs) = result in
   try data_float key data
   with Missing_data -> raise Missing_data 
      (* failwith (sprintf "data is missing key %s" key) *)

let get_string key (result:result) =
   let (data,inputs) = result in
   try data_string key data
   with Missing_data -> raise Missing_data 
      (* failwith (sprintf "data is missing key %s" key)*)

let get_int key (result:result) =
   let value = get_string key result in
   try int_of_string value
   with _ -> failwith (sprintf "cannot convert key %s (value %s) to an int" key value)

let get_string_of_set key results =
   let values = list_map results (get_string key) in
   if values = [] then raise Missing_data;
   let value = List.hd values in
   if not (list_for_all values (fun v -> v = value))
      then failwith "get_string_of_set: not unique value" ;
   value

let evaluate results (eval:result->float) =
   let ovalues = list_map results (fun r -> 
      try Some (eval r)
      with Missing_data -> None)
      in
   let values = List.map unsome (list_filter ovalues ((<>) None)) in
   if values = [] then raise Missing_data;
   values

(* depreacted *)
let average results (eval:result->float) =
   let values = evaluate results eval in
   list_mean values

let mean values =
   list_mean values

let range values =
   let fold op s = List.fold_left op s values in 
   (fold min infinity, fold max neg_infinity)

let maxdev values =
   let (mi,ma) = range values in
   max (abs_float mi) (abs_float ma)

let stddev values =
   let mean = list_mean values in
   let sumsq = List.fold_left (fun acc x -> acc +. x *. x) 0. values in
   sqrt (sumsq -. mean *. mean)

let mean_stddev values =
   (mean values, stddev values)

let sorted values =
   List.sort (fun x y -> if x < y then -1 else 1) values

let graph_by_keys_for_buckets add_chart scatter results make_curves_for buckets =
   list_iter buckets (fun (bucket_fixed, bucket_results) ->
      let title = title_of_params bucket_fixed in
      add_chart (Chart_graph (graph title scatter (make_curves_for bucket_results))))

let graph_by keys add_chart scatter results make_curves_for =
   let buckets = bucket keys results in
   graph_by_keys_for_buckets add_chart scatter results make_curves_for buckets

let graph_by_not keys add_chart scatter results make_curves_for =
   let buckets = make_buckets (indexer_for_results_all_inputs_but keys) results in
   graph_by_keys_for_buckets add_chart scatter results make_curves_for buckets

let curve_by_for_buckets add_curve make_points_for buckets =
   list_iter buckets (fun (bucket_fixed, bucket_results) ->
      let points = build_list (make_points_for bucket_results) in
      (* msg (sprintf "nbpoints = %d\n" (List.length points)); *)
      add_curve (bucket_fixed, points))

let curve_by keys add_curve (*curveopt*) results make_points_for =
   let buckets = bucket keys results in
   curve_by_for_buckets add_curve make_points_for buckets

let curve_by_not keys add_curve (*curveopt*) results make_points_for =
   (* let inputs = inputs_for_set results in
   if not (list_included keys inputs)
      then failwith "curve_by_not: keys are not int the set of inputs"; 
   printf "inputs:%s\n" 
         (string_of_list ", " (fun x -> x) inputs);
     printf "bucketsby:%s\n" 
         (string_of_list ", " (fun x -> x) (list_substract inputs keys));
    *)
   let buckets = make_buckets (indexer_for_results_all_inputs_but keys) results in
   curve_by_for_buckets add_curve make_points_for buckets

let point_by key add_point results make_ycoord_for =
   let buckets = bucket [key] results in 
   list_iter buckets (fun (bucket_fixed, bucket_results) ->
      match bucket_fixed with
      | [(key',xstring)] ->
         let x = 
            try float_of_string xstring 
            with _ -> failwith "point_by on a non float value" 
            in
         begin try 
            let y = make_ycoord_for bucket_results in
            add_point (x, y)
         with Missing_data -> ()
         end
      | _ -> assert false)

let multipoint_by key add_point results make_ycoord_for =
   let buckets = bucket [key] results in 
   list_iter buckets (fun (bucket_fixed, bucket_results) ->
      match bucket_fixed with
      | [(key',xstring)] ->
         let x = 
            try float_of_string xstring 
            with _ -> failwith "point_by on a non float value" 
            in
         list_iter bucket_results (fun result -> 
            begin try 
               let y = make_ycoord_for [result] in
               add_point (x, y)
            with Missing_data -> () 
            end)
         
      | _ -> assert false)




end

