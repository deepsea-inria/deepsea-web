The tools                         {#mainpage}
============

Conducting experiments with the `run` tool
=====================================

The script`./run` is an alias for `run.out` and it is used to 
execute a series of runs of one or several programs with
various options. By default, the results are stored in a
file called `results.txt` which can be read manually or 
used by the plotting tool.

\remark The run script makes a dummy run to start with in
order to warm up the machine --usually this first run is 
noticeably slowler than the others. Use option `--nodummy`
to deactivate this behavior.


Option                                            | Description
--------------------------------------------------|-------------------
`--virtual`                                       | only prints the list of commands to be executed
`--silent`                                        | produce less output
`--append`                                        | append the results to `results.txt` instead of overwriting it.
`-output` \a filename                             |   specify another file than `results.txt` to store the results
`-prog` \a filepath    e.g. `../examples/fib.opt` | specify the name of the program
`-timeout` \a nbseconds                           |   specify the timeout; default is 10 seconds
`-runs` \a nbruns                                 | specify the number of time to execute each combination of parameters; default is 1.
`--nodummy`                                       |  do not do a dummy run at the beginning of the benchmark

Other options are handled as described next.

If an option `-key val1,val2` is provided then two runs are made, 
one for `-key val1` and one for `-key val2`

If an argument `X` is provided directly, it is interpreted as
`-prog ../examples/X.exe`

For example, 

     ./run -prog ./examples/fib.opt -proc 0,1,4 -n 30,40 -timeout 40

will execute

     ./examples/fib.opt -proc 0 -n 30 -timeout 40
     ./examples/fib.opt -proc 0 -n 40 -timeout 40
     ./examples/fib.opt -proc 1 -n 30 -timeout 40
     ./examples/fib.opt -proc 1 -n 40 -timeout 40
     ./examples/fib.opt -proc 4 -n 30 -timeout 40
     ./examples/fib.opt -proc 4 -n 40 -timeout 40

\remark If the option `-proc` is not provided, then the 
list 0,1,4,8,16,24,30 is used. It is defined in `bench/run.ml`.

\remark `./run fib.opt` is interpreted as a shorthand for
        `./run -prog examples/fib.opt`.

Plotting with the `plot` tool
=====================================

The plotting tool can be used to visual the output of the run
command. It takes as argument the file containing the results,
which by default is `results.txt`. 

Option                            | Description
----------------------------------|----------------
`-mode` \a name                   | to use a special function defined in `bench/plot.ml` for generating the plot
`--speedup`                       | shorthand for `-mode speedup`, which produces a  speedup curve.
`-input` \a filename              | specifies the name of the input text file containing the results to plot
`-output` \a filename             | specifies the name of the output PDF file
`-routput` \a filename            | specifies the name of the output R file
`-width` \a nbcentimeters         | specifies the width of the plot
`-height` \a nbcentimeters        | specifies the height of the plot
`--no_title`                      | don't generate any title for the plots
`--separate`                      | create separate .r files for each plots; in `/generated`
`--silent`                        | don't print anything
`--open`                          | for opening the output PDF using `evince`

Scatter plot (mode `basic`)
-------------------

Option                    | Description
--------------------------|----------------
`-x` \a key               | specify the parameter to go on the xaxis (proc by default)
`-y` \a key               | specify the parameter to go on the yaxis; in addition to output parameters of the program, the key for the yaxis may correspond to a predefined function (implemented in `bench/plot.ml`), among: `exectime`; `speedup`; `overhead`; `pertask_overhead`  
`-curve`                  | specify the parameter to use as index for the curves that are shown on a same plot; none by default
`--xlog`                  | to force log scale on the xaxis
`--ylog`                  | to force log scale on the yaxis
`--xzero`                 | to force the xaxis to start at zero
`--yzero`                 | to force the yaxis to start at zero

Bar plot (mode `barplot`)
-------------------

Option                | Description
----------------------|----------------
`-group_by` \a key    | specify the parameter by which to group values
`-series_by` \a key   | specify the parameter by which to separate values
`-y` \a key           | specify the parameter to go on the yaxis (default `exectime`; if `speedup`, the axis corresponds to the speedup)

### Example #1 ###

     ./run.out -prog fib.sta,fib.opt -proc 0,1,2 -n 40
     ./plot.out -mode barplot -group_by prog -series_by proc -y exectime

![Output](../../barplot01.jpg)

Visualizing activity of processors using the `view` tool
=====================================

The `view` program is an alias for `bench/view.out`, which helps
visualizing the activity/idle time of processors during a run.

The input of view program is a log file in binary format.
This log file is generated when the option `--view` (or `--log_phases`)
is enabled during the execution of the program.
If you also log other events, it is likely that the log file
will get too big and that the view program will not be able
to handle it.

The view program is usually called without arguments,
but you can specify a different log file if you want.

Option                                  | Description
----------------------------------------|-----------------
`-input` \a filename                    | name of the binary log file; default is `LOG_BIN`
`-width` \a nbpixels; default=1000      | specifies the width of the windows
`-height` \a nbpixels; default=1000     | specifies the height of the windows
`-proc_height` \a nbpixels; default=30  | specifies the height of a line describing one processor

The controls to be used in the program are:
  - click to zoom-in
  - spacebar to reinitialize zoom
  - press 'o' to zoom-out one step
  - press 'r' to reload the log file (for example, after a new run)
  - press 'q' to quit



Examples
=====================================

\remark If you get a timeout when running the examples, then 
use `-timeout 60` to raise the timeout from 10 to 60 seconds.

To tune
-----------------

     ./examples/fib.sta -n 50 -proc 4
      (if you don't seem to have enough processors *)
     ./examples/fib.sta -n 50 -proc 2 -no0 0   


Viewing of the activity
-----------------

     make examples/fib.log
     ./examples/fib.log -proc 16 -n 42 --view
     ./view & 

Speedup curve for `fib`
-----------------

     make examples/fib.opt
     ./run fib.opt -n 43 -proc 0,1,4,16,24,30  
     ./plot --speedup
     evince plots.pdf &

Same as above but with a single command line:
-----------------

     make examples/fib.opt && \
     ./run fib.opt -proc 0,1,4,16,24,30 -n 43 -timeout 40 && \
     ./plot --speedup && evince plots.pdf &

Several speedup curves at once 
-----------------

     ./run fib.opt -n 45 -proc 0,1,4,16,30
     ./run string_search.opt -pattern_size 20 -text_size 500000000 -proc 0,1,4,16,30 --append
     ./run array_max.opt -n 1000000000 -proc 0,1,4,16,30 --append
     ./plot --speedup 

Measuring the impact of the cutoff
-----------------

     make examples/fib.opt
     ./run fib.opt -proc 16 -n 40 -cutoff 8,10,12,14,16,18,20,30,35,40
     ./plot -x cutoff -y exectime -curve n
     evince plots.pdf &

Logging of all events in a text file
-----------------

     ./examples/fib.log -proc 3 -n 10 -cutoff 5 --log_all --log_text
     gedit LOG &

Effect of the cutoff
-----------------

     make -j examples/string_search.opt
     ./run string_search.opt -pattern_size 20 -text_size 500000000 -proc 16 -kappa 25,50,100,500,1000,10000,100000,1000000
     ./plot -x kappa -y exectime --xlog 

Comparison between different schedulers (curves are nearly identical)
-----------------

     make -j examples/string_search.opt
     ./run string_search.opt -proc 0,1,16,30 -pattern_size 20 -text_size 500000000 -cutoff 10000 -kappa 300 -balstrategy stdws,siws,sf_siws
     ./plot --speedup -curve balstrategy
