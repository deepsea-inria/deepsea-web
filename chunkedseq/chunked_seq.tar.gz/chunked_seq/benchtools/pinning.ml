open Shared
open Scanf
open Printf

(* takes as argument 
   -ids  used_ids_file
   -topo topo_file
   -dir [both|hori|verti]

   where file used_ids_file contains a list of proc ids, one per line,
   where topo_file contains the output of "lstopo --of console"
   (ids.txt and topo.txt are default names)
   where dir indicates how to print the output
  
   example use  (from folder bench/):
     make pinning
     lstopo --of console > topo.txt
     ../pasl/examples/everycore.dbg -proc 60 -hyperthreading if_needed > ids.txt
     ./pinning.out -ids ids.txt -topo topo.txt -dir both
*)

let read_ids file =
   let lines = file_get_lines file in
   try List.map (fun line -> Scanf.sscanf line " %d" (fun x -> x)) lines
   with _ -> failwith "cannot parse ids file"

let max_nb_units = 1000

let read_topo file =
   let lines = file_get_lines file in
   let is_numa_line s =
      let r = Str.regexp ".*NUMANode.*" in
      Str.string_match r s 0 
      in
   let is_l2_line s =
      let r = Str.regexp ".*L2.*" in
      Str.string_match r s 0 
      in
   let get_id_line s = (*returns option*)
      let r = Str.regexp ".*PU.*(P#\\([0-9]*\\)).*" in
      if not (Str.string_match r s 0)
         then None
         else Some (Str.matched_group 1 s)
      in
   try 
      let units = Array.init max_nb_units (fun i -> Array.make 4 0) in
      let id_numa = ref (-1) in
      let id_core = ref (-1) in
      let id_thread = ref (-1) in
      let id_unit = ref (-1) in
      list_iter lines (fun s -> 
         if is_numa_line s then (incr id_numa; id_core := -1; id_thread := -1);
         if is_l2_line s then (incr id_core; id_thread := -1);
         match get_id_line s with
         | None -> ()
         | Some id_str -> 
            let id = Scanf.sscanf id_str " %d" (fun x -> x) in
            incr id_unit;
            incr id_thread;
            let t = units.(!id_unit) in
            t.(0) <- id;
            t.(1) <- !id_thread;
            t.(2) <- !id_core;
            t.(3) <- !id_numa;
      );
      Array.sub units 0 !id_unit
   with e -> (warning "cannot parse topo file\n"; raise e)


(*

let _ =
   let test r s = 
      warning (if Str.string_match (Str.regexp r) s 0 then "ok" else "fail") in
   test ".*NUMANode.*" "  NUMANode L#0 (P#0 256GB) + Socket L#0 + L3 L#0 (30MB)";
   test ".*L2.*" "  L2 L#18 (256KB) + L1 L#18 (32KB) + Core L#18";
   test ".*PU.*(P#\\([0-9]*\\)).*" "     PU L#1 (P#40)";
   (* should fail *)
   test ".*NUMANode.*" "  L2 L#18 (256KB) + L1 L#18 (32KB) + Core L#18";
   test ".*NUMANode.*" "  PU L#1 (P#40)";
   print_newline();
   exit 0
*)

let _ =
   let topo_file = Cmdline.parse_or_default_string "topo" "topo.txt" in 
   let ids_file = Cmdline.parse_or_default_string "ids" "ids.txt" in 
   let dir = Cmdline.parse_or_default_string "dir" "hori" in 
   let dir_hori = (dir = "hori" || dir = "both") in
   let dir_verti = (dir = "verti" || dir = "both") in
   let topo = read_topo topo_file in
   let ids = read_ids ids_file in
   
   let used = Array.make max_nb_units (-1) in
   list_iteri (fun i id -> used.(id) <- i) ids;
      
   if dir_hori then begin
      Array.iter (fun t -> printf "%d" t.(3)) topo; print_newline();
      Array.iter (fun t -> printf "%d" t.(2)) topo; print_newline();
      (* Array.iter (fun t -> printf "%d" t.(1)) topo; print_newline(); *)
      (* Array.iter (fun t -> printf "%d " t.(0)) topo; print_newline();*)
      Array.iter (fun t -> 
          let k = t.(0) in 
          let id = used.(k) in
          if id = -1 then printf "-" else printf "x")
        topo;
      print_newline();
      print_newline()
   end;  
   
   if dir_verti then begin
      Array.iter (fun t -> 
         printf "%d %d %d " t.(3) t.(2) t.(1);
         let k = t.(0) in 
         let id = used.(k) in
         if id = -1 then printf "--" else printf "%d" id;
         print_newline()
         ) topo; 
      print_newline();
   end

   (* file_put_lines filename "\n" lines ----> output*)
