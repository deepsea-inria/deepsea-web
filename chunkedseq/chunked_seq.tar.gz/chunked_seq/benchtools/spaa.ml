open Printf
open Shared
open Benchmark

type run = {
   prog : string;
   runs : int;
   timeout : int; 
   params : params; } 

let run prog runs timeout params =
  { prog = prog; runs = runs; timeout = timeout; params = params }

let create_benchrun run =
 { benchrun_bench = {
      bench_vmachine = "local"; 
      bench_prog = run.prog;
      bench_params = run.params;
      };
   benchrun_timeout = run.timeout;
   benchrun_nbruns = run.runs;
   benchrun_max_retry = 1;
   benchrun_batchid = nobatchid;
   }

let spaa_run basename runs =
  arg_run_output := basename ^ ".txt";
  let plotonly = Cmdline.parse_or_default_bool "plotonly" false in
  (if not plotonly then
    execute_benchruns (List.map create_benchrun runs)
  else
    ())

let spaa_plot basename title_opt plot_cmd =
  arg_run_output := basename ^ ".txt";
  let pdffile = basename ^ ".pdf" in
  let rfile = basename ^ ".r" in
  let cmd = sprintf "./plot -input %s -output %s -routput %s %s %s" 
    !arg_run_output pdffile rfile
    (match title_opt with None -> "" | Some t -> sprintf "-title %s" t)
    plot_cmd in
   msg_newline cmd;
   ignore (system cmd);
   let scratchdir = Cmdline.parse_or_default_string "resdir" "/home/mrainey/Scratch/" in
   let resdir = scratchdir^"xp/" in
   let _ = system (sprintf "mkdir %s" resdir) in
   let cppdf = sprintf "cp %s.* %s" basename resdir in
   printf "%s\n" cppdf;
   ignore (system cppdf);
   let cp_run_output = sprintf "cp %s %s" !arg_run_output resdir in
   printf "%s\n" cp_run_output;
   ignore (system cp_run_output);
   let generatedtargetdir = (scratchdir^basename) in
   let generatetargetdircmd = sprintf "mkdir %s" generatedtargetdir in
   printf "%s\n" generatetargetdircmd;
   ignore (system generatetargetdircmd);
   let cp_generated = sprintf "cp -r %s %s" "generated/*" generatedtargetdir in
   printf "%s\n" cp_generated;
   ignore (system cp_generated);
   ()

let run_plot basename title_opt plot_cmd runs =
  spaa_run basename runs; spaa_plot basename title_opt plot_cmd

let all_proc = [0;8;16;30]
let all_par_proc = List.filter (fun proc -> proc > 1) all_proc
let all_delta = [50;300;1000;3000;30000;300000;1000000]
let all_nb_runs = ref 5
let all_timeout = 800
let dflt_delta = 50

let all_taskset = ["sf_siws";"stdws"]

let fib_n = 44
let fib_cutoff = 21
let array_max_n = 1000000000
let array_max_cutoff = 400000

(* graphs *)
let graphsdir = "/var/tmp/mrainey/graphs/"
let cage15 = graphsdir^"cage15/cage15.mtx"
let freescale1 = graphsdir^"Freescale1/Freescale1.mtx"
let kkt_power = graphsdir^"kkt_power/kkt_power.mtx"

let all_progs = 
  [("examples/fib.exe",          [("n", Dyn.Int fib_n);("cutoff", Dyn.Int fib_cutoff)]);
   ("examples/array_max.exe",    [("n", Dyn.Int array_max_n);("cutoff", Dyn.Int array_max_cutoff)]);
   ("examples/cilksort.exe",     [("n", Dyn.Int 800000000)]);
   ("examples/matmul.exe",     [("n", Dyn.Int 5000)]);
   ("examples/dfs.exe",          [("graphmm", Dyn.String cage15);("cutoff", Dyn.Int 128)]);
   ("examples/bellman_ford.exe", [("nb_nodes", Dyn.Int 2500);("cutoff", Dyn.Int 10000)]);
   ("examples/heat.exe",         [("benchmark", Dyn.Int 4)]);
   ("examples/cilkcholesky.exe", [("n", Dyn.Int 7000);("z", Dyn.Int 60000)]);
 ]

let tbb_progs =
  [("examples/tbb_fib.exe",          [("n", Dyn.Int fib_n);("cutoff", Dyn.Int fib_cutoff)]);
   ("examples/tbb_array_max.exe",    [("n", Dyn.Int array_max_n);("cutoff", Dyn.Int array_max_cutoff)])]

let dfs_with_graphs =
  (("examples/dfs.exe", [("cutoff", Dyn.Int 128)]),
   [("benchmark", Dyn.Int 1);
    ("benchmark", Dyn.Int 2);
    ("benchmark", Dyn.Int 3);
    ("benchmark", Dyn.Int 4)
  ])

(*
  let subst_param (k1, v1) (k2, v2) =
    if k1 = k2 then (k1, v1) else (k2, v2)

  let subst_cutoff (prog, input) = 
    let input = List.map (subst_param ("cutoff", Dyn.Int 2)) input in
    let input = List.map (subst_param ("n", Dyn.Int 39)) input in
    (prog, input)
*)

let select_prog n =
  List.find (fun (prog,_) -> prog = "examples/"^n^".exe") all_progs

let delayexp_run (prog, input) proc delta = 
    run prog !all_nb_runs all_timeout 
      ([("proc", Dyn.Int proc);("delta", Dyn.Int delta)] @ input)

(* 1.a. Impact of delay *)
(*--------------------------------------------------------------*)
let delay_a _ =
  let proc = 30 in
  let id = "xp/delay_a" in
  run_plot
    id
    (Some "delay_a")
    "-y total_wait -x delta --xlog --ylog -curve prog"
    (List.flatten (
     (list_map all_progs (fun prog ->
       ((*delayexp_run prog 0 dflt_delta :: *)
	list_map all_delta (delayexp_run prog proc))))))

(* 1.b. Impact of delay (continued) *)
(*--------------------------------------------------------------*)
let delay_b _ =
  let proc = 30 in
  let id = "xp/delay_b" in
  run_plot
    id
    (Some "delay_b")
    "-y exectime -x delta --xlog -curve prog"
    (List.flatten (
     (list_map all_progs (fun prog ->
       (list_map all_delta (delayexp_run prog proc))))))

let delay _ = (delay_a () ; delay_b ())

(* 2. Cost of memory fence *)
(*--------------------------------------------------------------*)
let fence _ =
  let id = "xp/fence" in
  let aw = run "examples/fjarray_write.fjexe" !all_nb_runs all_timeout in
  let nb_writes_per_task = [2;3;4;5;6;7;8;9;10;16;32;64] in
  let proc = 7 in
  let par taskset = 
    list_map nb_writes_per_task (fun nb ->
      aw ([
	  ("n", Dyn.Int 100000000 (*500000000*));
	  ("binding_policy", Dyn.String "node_dense");
	  ("proc", Dyn.Int proc);("nb_writes_per_task",Dyn.Int nb);
	  ("taskset", Dyn.String taskset)])) in
  run_plot
    id
    (Some "fence")
    "-y exectime -x nb_writes_per_task -curve taskset --xlog"
    (par "sf_siws" @ par "sf_afsiws" @ par "stdws")

(* 3. Speedup curves *)
(*--------------------------------------------------------------*)
let speedups _ =
  let id = "xp/speedups" in
  let all_progs = [ select_prog "bellman_ford"
(*select_prog "cilksort"; select_prog "bellman_ford"; 
		   select_prog "cilkcholesky"  *)
]
  in
  run_plot
    id
    None
    "--speedup -curve taskset"
    (List.flatten (
     list_map all_progs (fun (prog,input) ->
       List.flatten (
       list_map all_proc (fun proc ->
	 list_map all_taskset (fun taskset ->
	   run prog !all_nb_runs all_timeout (("proc", Dyn.Int proc)::
					     ("taskset", Dyn.String taskset)::
					     input)))))))


(* 4. Number of steals *)
(*--------------------------------------------------------------*)
let steals _ =
  let id = "xp/steals" in
  let doprog (prog, input) proc =
    run prog !all_nb_runs all_timeout (("proc", Dyn.Int proc)::input) in
  run_plot
    id
    (Some "steals")
    "-y task_send -x proc -curve prog"
    (List.flatten (
     (list_map all_progs (fun prog ->
       list_map (List.filter (fun p -> p <> 0) all_proc) (doprog prog)))))

(* 5. Ours versus TBB (speedups) *)
(*--------------------------------------------------------------*)
let tbb _ =
  let id = "xp/tbb" in
  let doprog (prog, input) proc = 
    run prog !all_nb_runs all_timeout (("proc", Dyn.Int proc)::input) in
  let filt (n,_) = n = "examples/fib.exe" || n = "examples/array_max.exe" in
  run_plot
    id
    (Some "tbb")
    "--speedup -curve prog"
    (List.flatten (
     list_map (tbb_progs @ (List.filter filt all_progs)) (fun prog ->
       list_map all_proc (doprog prog))))

(* 6. DFS *)
(*--------------------------------------------------------------*)
let dfs _ =
  let id = "xp/dfs" in
  let dorun all_dataset (prog,input) =
    spaa_run
      id
      (List.flatten (
       list_map all_dataset (fun dataset ->
	 (list_map all_proc (fun proc ->
	   run prog !all_nb_runs all_timeout (("proc", Dyn.Int proc)::
					     ("taskset", Dyn.String "sf_siws")::
					     dataset::
					     input))))))
  in
  let doplot xaxis prog =
    spaa_plot
      id
      (Some ("dfs"^prog))
      (sprintf "-y speedup %s -curve proc" xaxis)
  in
  let doit xaxis all_taskset (bench, bench_dataset) = 
    dorun bench_dataset bench;
    doplot xaxis (fst bench);
  in
  begin
    doit "-x benchmark" (List.filter (fun taskset -> taskset <> "stdws") all_taskset) dfs_with_graphs;
    ()
  end

(* 7. Speedup versus input size *)
(*--------------------------------------------------------------*)
let speedupvsinput _ =
  let proc = 30 in
  let id = "xp/speedupvsinput" in
  let cilksort =
    (("examples/cilksort.exe",     []),
     [("n", Dyn.Int 100000);
      ("n", Dyn.Int 1000000);
      ("n", Dyn.Int 10000000);
      ("n", Dyn.Int 100000000)])
  in
  let bellman_ford =  
    (("examples/bellman_ford.exe", [("cutoff", Dyn.Int 6000)]),
     [("nb_nodes", Dyn.Int 500);
      ("nb_nodes", Dyn.Int 1000);
      ("nb_nodes", Dyn.Int 2000);
      ("nb_nodes", Dyn.Int 3000)])
  in
  let dorun proc all_taskset all_dataset (prog,input) =
    arg_append := true;
    spaa_run
      (id^prog)
      (List.flatten (
       list_map all_dataset (fun dataset ->
	 (list_map all_taskset (fun taskset ->
	   run prog !all_nb_runs all_timeout (("proc", Dyn.Int proc)::
					     ("taskset", Dyn.String taskset)::
					     dataset::
					     input))))))
  in
  let doplot xaxis prog =
    spaa_plot
      (id^prog)
      (Some ("speedupvsinput_"^prog))
      (sprintf "-y speedup %s -curve taskset" xaxis)
  in
  let seq_taskset = ["sf_siws"] in
  let doit xaxis all_taskset (bench, bench_dataset) = 
    dorun 0 seq_taskset bench_dataset bench;
    dorun proc all_taskset bench_dataset bench;
    doplot xaxis (fst bench);
  in
  begin
    doit "-x n --xlog" all_taskset cilksort;
    doit "-x nb_nodes" all_taskset bellman_ford;
    doit "-x benchmark" (List.filter (fun taskset -> taskset <> "stdws") all_taskset) dfs_with_graphs;
    ()
  end

(* 8. Exectime versus delay by proc *)
(*--------------------------------------------------------------*)
let timevsdelaybyproc _ =
  let id = "xp/timevsdelaybyproc" in
  let all_prog = [select_prog "cilkcholesky";
		  (*select_prog "cilksort";*) ]
  in
  let all_proc = List.rev (4::all_par_proc) in
  run_plot
    id
    (Some "timevsdelaybyproc")
    "-y exectime -x delta --xlog --ylog -curve proc"
    (List.flatten 
       (list_map all_prog (fun prog ->
	 (List.flatten 
	    (list_map all_proc (fun proc ->
	      (list_map all_delta (delayexp_run prog proc))))))))


(* main() *)
let _ =
  all_nb_runs := Cmdline.parse_or_default_int "nb_runs" 10;
  let bench = Cmdline.parse_or_default_string "bench" "all" in
  if bench = "delay" then
    delay ()
  else if bench = "fence" then
    fence ()
  else if bench = "speedups" then
    speedups ()
  else if bench = "steals" then
    steals ()
  else if bench = "tbb" then
    tbb()
  else if bench = "speedupvsinput" then
    speedupvsinput()
  else if bench = "dfs" then
    dfs()
  else if bench = "timevsdelaybyproc" then
    timevsdelaybyproc()
  else if bench = "all" then (
    delay();
    fence();
    speedups();
    steals ();
    tbb();
    speedupvsinput();
    dfs();
    timevsdelaybyproc())
  else
    printf "bogus argument\n"
(*
  run_plot 
    "fib_speedup" 
    "--speedup"
    (list_map [0;1;4;8;16;30] (fun proc ->
      run "examples/fib.exe" 1 30 [("proc", Dyn.Int proc);("n", Dyn.Int 42)]))
*)
(* or:
      { prog = "examples/fib.exe"; runs = 3; timeout = 30;
        params = [("proc", Dyn.int p) ("n", Dyn.Int 45)]; }))
*)


(*
(* 4. Waiting time *)
(*--------------------------------------------------------------*)
let waiting _ =
  let id = "xp/waiting" in
  let proc = 30 in
  let doprog (prog, input) delta =
    run prog !all_nb_runs all_timeout (("proc", Dyn.Int proc)::
				      ("delta", Dyn.Int delta)::input) in
  run_plot
    id
    (Some "waiting")
    "-y total_wait -x delta --xlog --ylog -curve prog"
    (List.flatten (
     (list_map all_progs (fun prog ->
       (list_map all_delta (doprog prog))))))
*)
