open Printf
open Shared
open Benchmark

(* let default_procs = [0; 1; 4; 8; 16; 24; 30] 

let default_procs_str =
   String.concat "," (List.map string_of_int default_procs)
   *)

let retry =
   let x = Cmdline.parse_or_default_int "retry" 1 in
   List.iter Cmdline.remove_arg ["retry"];
   x

let create_benchrun timeout runs prog params =
 { benchrun_bench = {
      bench_vmachine = "local"; 
      bench_prog = prog;
      bench_params = params;
      };
   benchrun_timeout = timeout;
   benchrun_nbruns = runs;
   benchrun_max_retry = retry;
   benchrun_batchid = nobatchid;
   }

let create_params_list () =
   let flags = Cmdline.get_flags () in
   let flags_params = List.map (fun flag -> (flag, Dyn.Int 1)) flags in
   let args = Cmdline.get_args () in
   (* let args = if List.mem_assoc "proc" args 
                 then args 
                 else args @ [("proc", default_procs_str)] in *)
   build_list (fun add ->
      let rec aux params = function
         | [] -> add params
         | (key,value)::rest ->
            let values = split_args value in
            list_iter values (fun value -> 
              aux ((key, Dyn.String value)::params) rest)
         in
      aux flags_params args)

let default_executable prog =
   sprintf "./examples/%s" prog

let create_benchruns () =
   let progs = 
      try Cmdline.parse_list_string "prog" 
      with Cmdline.Argument_not_found _ ->
         match Cmdline.get_others() with
         | [] -> failwith "please specify program name"
         | [progs] -> List.map default_executable (split_args progs)
         | _ -> failwith "please specify program names separated by commas"
      in
   let timeout = Cmdline.parse_or_default_int "timeout" 500 in 
   let runs = Cmdline.parse_or_default_int "runs" 1 in 
   List.iter Cmdline.remove_arg ["prog";"timeout";"runs";"output"];
   (* build benchruns *)
   let params_list = create_params_list() in
   build_list (fun add ->
      list_foreach progs (fun prog ->
      list_foreach params_list (fun params ->
         add (create_benchrun timeout runs prog params))))

let _ =
   parse_run_options ();
   execute_benchruns (create_benchruns())


(* 
;"proc";"kappa"
   let procs = Cmdline.parse_or_default_list_int "proc" default_procs in
   let kappas = Cmdline.parse_or_default_list_float "kappa" 150.0 in

   build_list (fun add ->
      foreach (list_prod_3 progs procs kappas) (fun (prog,(proc,kappa)) ->
         add (create_benchrun timeout runs prog proc kappa)));


         "proc", Dyn.Int proc;
         "kappa", Dyn.Float kappa; ] 
*)