open Shared
open Benchmark
open Printf
open Results

(*********************************************************)

type col_descr = {
   col_descr_field : string;
   col_descr_label : string;
   col_descr_eval : (strings -> datas -> datas -> (float->unit) -> unit);
   }

type table_descr = {
   table_descr_reserved : strings;
   table_descr_force : (stringp -> bool) list;
   table_descr_row : strings;
   table_descr_col : col_descr list;
   table_descr_row_sep : string;
   table_descr_col_sep : string;
   }

let default_table_descr = {
   table_descr_reserved = [];
   table_descr_force = [];
   table_descr_row = [];
   table_descr_col = [];
   table_descr_row_sep = "\n";
   table_descr_col_sep = "\t\t";
   }

let table_exectime proc =
  let eval p  = fun inputs all_datas datas add -> 
    let datas' = List.filter (List.exists (param_eq "proc" (string_of_int p))) datas in
    add (datas_mean "exectime" datas')
  in
  let cols = List.map (fun p -> {col_descr_field = "exectime";
				 col_descr_label = "proc="^string_of_int p;
				 col_descr_eval = eval p;
				}) proc
  in
  { default_table_descr with
    table_descr_reserved = ["exectime"; "proc"; "prog";];
    table_descr_row = ["prog"];
    table_descr_col = cols;
  }

let table_render d rows =
  let rec add_seps xs =
    match xs with
      | [] -> [d.table_descr_row_sep]
      | x::xs -> x::d.table_descr_col_sep::add_seps xs
  in
  List.map add_seps rows

let table_build add_table results1 d =
   let all_datas = List.map fst results1 in
   let reserved_keys = d.table_descr_reserved @ d.table_descr_row in
   let results2 = results_filter d.table_descr_force results1 in
   let by_kind = make_buckets (fun (_,inputs) -> inputs) results2 in
   list_foreach by_kind (fun (inputs,results3) ->
   let datas1 : ((string*string) list) list = List.map fst results3 in
   let not_reserved_keys = list_substract inputs reserved_keys in
   let by_table = make_buckets (indexer_for_data not_reserved_keys) datas1 in
   list_foreach by_table (fun (table_params,datas2) ->
      let by_row = make_buckets (indexer_for_data d.table_descr_row) datas2 in
      let rows = list_map by_row (fun (row_params,datas3) ->
	 let cols = build_list (fun add_col ->
	   list_foreach d.table_descr_col (
	     fun {col_descr_field = col_descr_field; col_descr_label = col_descr_label; col_descr_eval = col_descr_eval} ->
	       try col_descr_eval inputs all_datas datas3 add_col
	       with Missing_data -> ()))
         in
	 let row_id = String.concat " " (List.map (fun (k, v) -> v) row_params) in
         row_id :: List.map string_of_float cols)
      in
      let hdrs = String.concat " " d.table_descr_row :: 
	List.map (fun {col_descr_label=col_descr_label} -> col_descr_label) d.table_descr_col
      in
      let rows' = table_render d (hdrs::rows) in
      add_table { 
         (* table_tag = "";  *)
         table_title = "";
         table_data = rows'; }))

let create_tables results =
   if results = [] 
      then failwith "no results in input file";
   let builder = table_exectime in
   build_list (fun add_graph ->  
      let table = builder [0;2] in
      table_build add_graph results table)

let print_table rows =
  list_foreachi rows (fun i cols ->
    list_foreachi cols (fun i col ->
      printf "%s" col))

(*
let _ =
  parse_plot_options();
  let results = read_results_from_input_file() in
  let tables = create_tables results in
  list_foreachi tables (fun i {table_tag; table_title; table_data} -> print_table table_data)
*)
