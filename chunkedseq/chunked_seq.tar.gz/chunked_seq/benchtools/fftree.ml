(* Fast Finger Tree benchmarking script
 * 
 * Command-line arguments
 *
 *  -path_to_results_file path
 *     skips the runs of the benchmark programs and just generates
 *     plots for the given results file pointed to by path

 * -experiment experiments
 *     selects the given subset of experiments

 *)


open Shared
open Benchmark
open Printf
open Results
open Custom
open Myplot_funcs

(*********************************************************************************)
(* Parameters *)

let path_to_results_file = ref ""
let explicitly_selected_benchmarks = ref ([] : string list)
let all_nb_runs = ref 5
let all_timeout = 100000
let email = ref ""
let plot_relative = ref false
let use_ropes = ref false

(*********************************************************************************)
(* Utilities *)


let list_map_and_flatten xs f = List.flatten (list_map xs f)

let print_msg s = printf "*---------------- %s\n" s

let time_at_start_of_experiment = ref 0.0

let get_path_to_results _ = 
  if !path_to_results_file = "" then
    (sprintf "results_%f/" !time_at_start_of_experiment)
  else
    !path_to_results_file

let verbose_cmd s = 
  let _ = printf "%s\n" s in
  if not !arg_virtual then
    system s
  else
    Unix.WEXITED 0

let verbose_cmd_norc s = ignore(verbose_cmd s)

let send_email_notification experiment elapsed =
  if !email <> "" then
    let cmd = sprintf "echo \"took %f seconds to complete experiment %s on
	               `hostname`; results in %s \" | mail -s \"Experiment 
                       completed\" %s" 
                      elapsed experiment !email (get_path_to_results()) in
    verbose_cmd_norc cmd

let split_string_by_slash str = Str.split (Str.regexp "/") str

let filename_from_path str = 
  List.hd (List.rev (split_string_by_slash str))

let create_symlink src tgt =
  verbose_cmd (sprintf "ln -f -s %s %s" src tgt)

let eval_mean ykey = fun inputs all_datas datas add -> 
   add (datas_mean ykey datas)

let specific_params = 
  ["delay";"kappa";"syncfree";"artificial_fence";"taskset"]

let get_datas_for_baseline key value inputs all_datas datas =
   assert (datas != []);
   let data0 = List.hd datas in
   let fdata = list_filter data0 (fun (k,v) -> 
     list_mem inputs k && not (list_mem specific_params k)) in
   let fdata_base = 
      try list_assoc_replace key value fdata 
      with Not_found -> failwith "no proc field in data" in
   datas_filter (params_to_force fdata_base) all_datas

let get_data_for_normalized ykey key value inputs all_datas datas =
   let datas_base = get_datas_for_baseline key value inputs all_datas datas in
   let value_base = datas_mean ykey datas_base in
   let value = datas_mean ykey datas in
   (value_base, value)

let eval_normalized ykey key value = fun inputs all_datas datas add ->
   let (value_base, value) = get_data_for_normalized ykey key value inputs all_datas datas in
   add (value /. value_base)

(*********************************************************************************)
(* Committing results to an SVN repository *)

let verbose_cmd_assert s =
  match verbose_cmd s with
  | Unix.WEXITED 0 -> ()
  | _ -> failwith(sprintf "Failed on command: %s" s)

let svn_commit _ = 
  let path_to_working_copy = Cmdline.parse_or_default_string "svn_commit" "" in
  let path_to_results = get_path_to_results() in
  if path_to_working_copy <> "" then
    (verbose_cmd_assert(sprintf "cp -r %s %s" path_to_results path_to_working_copy);
     verbose_cmd_assert(sprintf "cd %s && svn add %s && svn ci -m \"new results\"" 
			  path_to_working_copy 
			  (filename_from_path path_to_results));
     ())
  else ()

(*********************************************************************************)

type run = {
   prog : string;
   runs : int;
   timeout : int; 
   params : params; } 

let mk_run prog runs timeout params =
  { prog = prog; runs = runs; timeout = timeout; 
    params = params }

let create_benchrun run =
 { benchrun_bench = {
      bench_vmachine = "local"; 
      bench_prog = run.prog;
      bench_params = run.params;
      };
   benchrun_timeout = run.timeout;
   benchrun_nbruns = run.runs;
   benchrun_max_retry = 1;
   benchrun_batchid = nobatchid;
   }

let get_path_to_results_file basename =
  get_path_to_results() ^ basename ^ ".txt"

let get_path_to_plot_file basename =
  get_path_to_results() ^ basename ^ ".pdf"

let get_path_to_r_output_file basename =
  get_path_to_results() ^ basename ^ ".r"

let get_path_to_all () =
 get_path_to_results() ^"/all.txt"

let fftree_binary name = "../fftree/benchmark/" ^ name

let graph_binary name = "../graph/bench/" ^ name

let mk_normal_run prog input =
  mk_run prog !all_nb_runs all_timeout
    ([(*("proc", Dyn.Int 1);*)] @ input)

let fftree_run basename runs =
  if !path_to_results_file = "" then begin
    let results_file =  get_path_to_results_file basename in
    let results_dir = get_path_to_results() in
    verbose_cmd_norc (sprintf "mkdir %s" results_dir);
    arg_run_output := results_file;
    execute_benchruns (List.map create_benchrun runs);
    if not !arg_virtual then begin
      let results = file_get_contents results_file in
      let all_results_file = get_path_to_all () in
      ignore(verbose_cmd (sprintf "touch %s" all_results_file));
      file_append_contents all_results_file results;
      ()
    end
    else ()
  end
  else ()

let pdf_of_charts_for_builder builder results =
    let charts = build_list (fun add_chart ->  
      builder add_chart results) in
    pdf_of_charts charts

let fftree_plot builder id =
  let results_file = get_path_to_results_file id in
  let output_file = get_path_to_plot_file id in
  let r_output_file = get_path_to_r_output_file id in
  if not !arg_virtual then (
    arg_plot_output := output_file;
    arg_plot_routput := r_output_file;
    let results = read_results_from_file results_file in
    let _  = if results = [] then printf "Warning: empty results list" in
    pdf_of_charts_for_builder builder results 
   )
  else 
    ()

let pdf_of_graphs_for_builder builder results =
    let charts = build_list (fun add_chart ->  
      builder add_chart results) in
    pdf_of_graphs charts

let fftree_barplot builder id =
  let results_file = get_path_to_results_file id in
  let output_file = get_path_to_plot_file id in
  let r_output_file = get_path_to_r_output_file id in
  if not !arg_virtual then (
    arg_plot_output := output_file;
    arg_plot_routput := r_output_file;
    let results = read_results_from_file results_file in
    let _  = if results = [] then printf "Warning: empty results list" in
    pdf_of_graphs_for_builder builder results 
   )
  else 
    ()

(*********************************************************************************)
(* Experiments *)

let path_to_graph_data = "~/graphdata/"
let get_path_to_graph_data name = path_to_graph_data ^ name
let get_path_to_graph_data' (name, source, bits) = (get_path_to_graph_data name, source, bits)

let name_of_generator_output n =  n ^ ".adj_bin"

let graph_generators =
  [(*"chain";*) (*"parallel_paths"; "phased"; "rmat"; *) "square_grid"; (*"cube_grid";*) "tree"; (*"star";*)]

let synthetic_graphgen_cmds =
  let g n = [
    ("generator", Dyn.String n); 
    ("bits", Dyn.Int 64);
    ("proc", Dyn.Int 1);
    ("outfile", Dyn.String (get_path_to_graph_data (name_of_generator_output n)));
  ]  
  in
  [
(*    g "chain"          @ [("nb_edges_target", Dyn.Int 400000000);];*)
    g "square_grid"    @ [("nb_edges_target", Dyn.Int 400000000);];  (* length of diagonal roughly 565685424 *)
    g "tree"           @ [("nb_edges_target", Dyn.Int 400000000);];
(*
    g "parallel_paths" @ [("nb_edges_target", Dyn.Int 40000000);];
    g "phased"         @ [("nb_edges_target", Dyn.Int 100000000);];
    g "rmat"           @ [("nb_edges_target", Dyn.Int 40000000);];
    g "cube_grid"      @ [("nb_edges_target", Dyn.Int 100000000);];
    g "star"           @ [("nb_edges_target", Dyn.Int 40000000);];
 *)
  ]

let graphfile_exe = "../graph/bench/graphfile.opt2"

let gen_synthetic_graph_files _ =
  List.iter (fun params -> verbose_cmd_norc(String.concat " " (graphfile_exe :: List.map arg_of_param params))) synthetic_graphgen_cmds

let external_graph_descr = [
(*  ("wikipedia-20070206.adj_bin", 0, 32, "http://supertech.csail.mit.edu/papers/pbfs.pdf (page 6)", ""); *)
(*  ("livejournal1.adj_bin", 0, 32, "http://snap.stanford.edu/data/soc-LiveJournal1.html", ""); *)
  ("friendster.adj_bin", 123, 64, "http://snap.stanford.edu/data/com-Friendster.html", "http://snap.stanford.edu/data/bigdata/communities/com-friendster.ungraph.txt.gz");
(*  ("twitter.adj_bin", 12, 64, "", "");*)
] 

let graph_descr = 
  external_graph_descr @
  List.map (fun gen -> (name_of_generator_output gen, 0, 64, gen, "")) graph_generators

let graph_files = List.map (fun (fname, source, bits, _, _) -> (fname, source, bits)) graph_descr

let show_graph_descr _ =
  let p (graph, source, bits, url, fileurl) = 
    printf "graph=%s \t source=%d \t bits=%d \t url=%s file_url=%s\n" graph source bits url fileurl;
    ()
  in
  List.iter p graph_descr

let prune_ext_of_fname ext fname =
  let len = String.length fname - String.length ext in
  String.sub fname 0 len

let download_graphfile (graph, _, _, _, fileurl) =
  let basefname = prune_ext_of_fname ".adj_bin" graph in
  let gzfname = sprintf "%s.snap.gz" basefname in 
  let dstgz = sprintf "%s%s" path_to_graph_data gzfname in
  let _ = verbose_cmd_norc(sprintf "wget %s -O %s" fileurl dstgz) in
  let _ = verbose_cmd_norc(sprintf "(cd %s; gunzip %s)" path_to_graph_data gzfname) in
  ()

let convert_from_snap_to_adj_bin (graph, _, bits, _, fileurl) =
  let basefname = prune_ext_of_fname ".adj_bin" graph in
  let snapfname = sprintf "%s.snap" basefname in
  let dst = sprintf "%s%s.adj_bin" path_to_graph_data basefname in
  verbose_cmd_norc (sprintf "%s -infile %s%s -outfile %s -bits %d" graphfile_exe path_to_graph_data snapfname dst bits)

let pretty_graphfile_name name =
  let startpos = String.length (sprintf "infile=%s" path_to_graph_data) in
  let len = String.length name - String.length ".adj_bin" - startpos in
  String.sub name startpos len


let graph_bench_ignores = ["algo"; (*"bits"; "source"; *)]

(*-----------------------------------------------------*)
(* FIFO *)

let fifo _ =
  let rs = [1000000;1000;1] in
  let seqs = [(*"circular_array";*)"fftree_deque_ptrx";"bootseq_deque_ptrx";"deque";] in
  let seqs = if !use_ropes then "rope" :: seqs else seqs in
  let id = "fifo" in
  begin
  fftree_run id
    (list_map_and_flatten rs (fun r ->
      (list_map_and_flatten seqs (fun seq ->
         let input = 
	   [("test", Dyn.String "real_fifo");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 1000000000);
	    ("r", Dyn.Int r);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe_fifolifo") input)]))));
  fftree_plot (mode_scatter_plot "exectime" "length" false true "seq" []) id;
  ()
  end

(*-----------------------------------------------------*)
(* LIFO *)

let lifo _ =
  let rs = [1000000;1000;1] in
  let seqs = ["deque";"fftree_stack";"bootseq_stack";(*"vector";*)] in
  let seqs = if !use_ropes then "rope" :: seqs else seqs in
  let id = "lifo" in
  begin
  fftree_run id
    (list_map_and_flatten rs (fun r ->
      (list_map_and_flatten seqs (fun seq ->
         let input = 
	   [("test", Dyn.String "real_lifo");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 1000000000);
	    ("r", Dyn.Int r);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe_fifolifo") input)]))));
  fftree_plot (mode_scatter_plot "exectime" "length" false true "seq" []) id;
  ()
  end

(*-----------------------------------------------------*)
(* Chunk size *)

let chunk_size _ =
  let chunk_sizes = [64;128;256;512;1024;2048;4096;8192;] in
  let seqs = ["bootseq_deque_ptr";] in
  let id = "chunk_size" in
  begin
  fftree_run id (
    (list_map_and_flatten seqs (fun seq ->
      (list_map_and_flatten chunk_sizes (fun chunk_size ->
	 let input = 
	   [("test", Dyn.String "real_fifo");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 100000000);
	    ("r", Dyn.Int 1);
	    ("chunk", Dyn.Int chunk_size);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe_chunksize") input)]))))
    @
    (list_map_and_flatten seqs (fun seq ->
      (list_map_and_flatten chunk_sizes (fun chunk_size ->
	 let input = 
	   [("test", Dyn.String "split_merge");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 100000000);
	    ("r", Dyn.Int 100000);
	    ("p", Dyn.Int 5);
	    ("chunk", Dyn.Int chunk_size);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe_chunksize") input)])))));
    fftree_plot (mode_scatter_plot "exectime" "chunk" false true "test" []) id
    end

(*-----------------------------------------------------*)
(* Split / merge *)

let split_merge _ =
  let hs = [0;10;100;1000;] in
  let seqs = ["fftree_deque_ptr";"bootseq_deque_ptr";"rope";] in
  let id = "split_merge" in
  begin
  fftree_run id
    (list_map_and_flatten hs (fun h ->
      (list_map_and_flatten seqs (fun seq ->
         let input = 
	   [("test", Dyn.String "split_merge");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 100000000);
	    ("r", Dyn.Int 200000);
	    ("p", Dyn.Int 5);
	    ("h", Dyn.Int h);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe_splitmerge") input)]))));
  fftree_barplot (mode_barplot [] [""] ["exectime"]  (eval_mean "exectime") ["seq"] ["h"] []) id;
  ()
  end

(*-----------------------------------------------------*)
(* Linear search *)

let linear_search _ =
  let rs = [1;10;30;60;80;100;] in
  let seqs = ["deque";"fftree_deque_ptr";(*"vector";*)"rope"] in
  let id = "linear_search" in
  begin
  fftree_run id
    (list_map_and_flatten rs (fun r ->
      (list_map_and_flatten seqs (fun seq ->
         let input = 
	   [("test", Dyn.String "linear_search");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 1000000);
	    ("r", Dyn.Int r);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe") input)]))));
  fftree_plot (mode_scatter_plot "exectime" "r" false false "seq" []) id;
  ()
  end

(*-----------------------------------------------------*)
(* Random access *)
(* The larger the p the more accesses are linear. *)

let random_access _ =
  let ps = [10;100;1000;10000;100000;] in
  let seqs = ["deque";"fftree_deque_ptr";(*"vector";*)"rope"] in
  let id = "random_access"  in
  begin
  fftree_run id
    (list_map_and_flatten ps (fun p ->
      (list_map_and_flatten seqs (fun seq ->
         let input = 
	   [("test", Dyn.String "random_access");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 100000000);
	    ("r", Dyn.Int 10000000);
	    ("p", Dyn.Int p);  
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe") input)]))));
  fftree_plot (mode_scatter_plot "exectime" "p" false false "seq" []) id;
  ()
  end

(*-----------------------------------------------------*)
(* Filter *)

let filter_exp _ =
  let rs = [1000000;1000;1] in
  let seqs = [(*"vector";*)"deque";"fftree_deque_ptr";"bootseq_deque_ptr";"rope";] in
  let seqs = if !use_ropes then "rope" :: seqs else seqs in
  let id = "filter" in
  begin
  fftree_run id
    (list_map_and_flatten rs (fun r ->
      (list_map_and_flatten seqs (fun seq ->
         let input = 
	   [("test", Dyn.String "filter");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 1000000000);
	    ("r", Dyn.Int r);
	    ("cutoff", Dyn.Int 2048);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe_filter") input)]))));
  fftree_plot (mode_scatter_plot "exectime" "length" false true "seq" []) id;
  ()
  end

(*-----------------------------------------------------*)
(* DFS *)

let dfs _ =
  let fnames = graph_files in
  let fnames = List.map get_path_to_graph_data' fnames in
  let algo = [(*"dfs_by_vertexid_array";*) "dfs_by_vertexid_frontier";] in
  let baseline = "foo" in
  let frontier = ["stl_deque"; (*"stl_vector";*) "fftree_stack"; "bootseq_stack";] in
  let id =  "dfs" in
  begin
  fftree_run id
    (list_map_and_flatten algo (fun algo ->
      (list_map_and_flatten frontier (fun frontier ->
        (list_map_and_flatten fnames (fun (fname, source, bits) ->
           let frontier = if algo = baseline then "default" else frontier in
	   let input = 
	     [
	       ("bits", Dyn.Int bits);
	       ("load", Dyn.String "from_file");
	       ("infile", Dyn.String fname);
	       ("algo", Dyn.String algo);
	       ("frontier", Dyn.String frontier);
	       ("source", Dyn.Int source);
	     ] in
  	   [(mk_normal_run (graph_binary "search.elision3") input)]))))));
  let eval = if !plot_relative then 
	       eval_normalized "exectime" "frontier" "default"
	     else
	       eval_mean "exectime"
  in
  fftree_barplot (mode_barplot ~series_beautifier:pretty_graphfile_name graph_bench_ignores [""] ["exectime"]  eval ["frontier"] ["infile"] []) id;
  ()
  end

(*-----------------------------------------------------*)
(* BFS *)

let bfs _ =
  let fnames = graph_files in
  let fnames = List.map get_path_to_graph_data' fnames in
  let algo = [(*"bfs_by_dual_arrays";*) "bfs_by_dual_frontiers_and_foreach";] in
  let baseline = "foo" in
  let frontier = ["stl_deque"; "fftree_deque";  "bootseq_deque";] in
  let id =  "bfs" in
  begin
  fftree_run id
    (list_map_and_flatten algo (fun algo ->
      (list_map_and_flatten frontier (fun frontier ->
        (list_map_and_flatten fnames (fun (fname, source, bits) ->
           let frontier = if algo = baseline then "default" else frontier in
	   let input = 
	     [
	       ("bits", Dyn.Int bits);
	       ("load", Dyn.String "from_file");
	       ("infile", Dyn.String fname);
	       ("algo", Dyn.String algo);
	       ("frontier", Dyn.String frontier);
	       ("source", Dyn.Int source);
	     ] in
  	   [(mk_normal_run (graph_binary "search.elision3") input)]))))));
  let eval = if !plot_relative then 
	       eval_normalized "exectime" "frontier" "default"
	     else
	       eval_mean "exectime"
  in
  fftree_barplot (mode_barplot ~series_beautifier:pretty_graphfile_name graph_bench_ignores [""] ["exectime"] eval ["frontier"] ["infile"] []) id;
  ()
  end


(*-----------------------------------------------------*)
(* PBFS *)

let pbfs _ =
  let fnames = graph_files in
  let fnames = List.map get_path_to_graph_data' fnames in
  let algo = "pbfs" in
  let frontier = ["ls_bag"; "stl_deque"; "fftree_bag"; "bootseq_deque"; (*"stl_vector";*)] in
  let frontier = if !use_ropes then "stl_rope" :: frontier else frontier in
  let baseline = "foo" in
  let id =  "pbfs" in
  begin
  fftree_run id
    (list_map_and_flatten frontier (fun frontier ->
      (list_map_and_flatten fnames (fun (fname, source, bits) ->
	 let input = 
	   [
	     ("bits", Dyn.Int bits);
	     ("load", Dyn.String "from_file");
	     ("infile", Dyn.String fname);
	     ("algo", Dyn.String algo);
	     ("frontier", Dyn.String frontier);
	     ("idempotent", Dyn.Int 1);
	     ("pbfs_cutoff", Dyn.Int 2048);
             ("source", Dyn.Int source);
	   ] in
	 [(mk_normal_run (graph_binary "search.elision2") input)]))));
  let eval = if !plot_relative then 
	       eval_normalized "exectime" "frontier" baseline
	     else
	       eval_mean "exectime"
  in
  fftree_barplot (mode_barplot ~series_beautifier:pretty_graphfile_name graph_bench_ignores [""] ["exectime"] eval ["frontier"] ["infile"] []) id;
  ()
  end


(*-----------------------------------------------------*)
(* Split / merge deque vs fftree *)

let split_merge_deque _ =
  let hs = [0;1;10;100;1000;5000;10000;] in
  let seqs = ["fftree_deque_ptr";"deque";] in
  let id = "split_merge_deque" in
  begin
  fftree_run id
    (list_map_and_flatten hs (fun h ->
      (list_map_and_flatten seqs (fun seq ->
         let input = 
	   [("test", Dyn.String "split_merge");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int 5000);
	    ("r", Dyn.Int 20000);
	    ("p", Dyn.Int 5);
	    ("h", Dyn.Int h);
	    ("should_pop", Dyn.Int 1);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe_splitmerge") input)]))));
  fftree_barplot (mode_barplot [] [""] ["exectime"]  (eval_mean "exectime") ["seq"] ["h"] []) id;
  ()
  end

(*-----------------------------------------------------*)
(* Diverge deque *)

let diverge_deque _ =
  let ns = [0;10000;50000;100000;500000;1000000;5000000] in
  let seqs = ["fftree_deque_ptr";"deque";] in
  let id = "diverge_deque" in
  begin
  fftree_run id
    (list_map_and_flatten ns (fun n ->
      (list_map_and_flatten seqs (fun seq ->
         let input = 
	   [("test", Dyn.String "split_merge");
	    ("seq", Dyn.String seq);
	    ("n", Dyn.Int n);
	    ("r", Dyn.Int 200);
	    ("p", Dyn.Int 5);
	    ("h", Dyn.Int 0);
	    ("should_push", Dyn.Int 0);
	    ("should_pop", Dyn.Int 0);
	   ] in
	 [(mk_normal_run (fftree_binary "bench.exe_splitmerge") input)]))));
  fftree_plot (mode_scatter_plot "exectime" "n" false true "seq" []) id;
  ()
  end


(*********************************************************************************)
(* Entry point *)

let all_experiments =
  [
    ("fifo", fifo);
    ("lifo", lifo);
    ("chunk_size", chunk_size);
    ("split_merge", split_merge);
(*    ("linear_search", linear_search);
    ("random_access", random_access);
 *)
    ("filter", filter_exp);
    ("dfs", dfs);
    ("bfs", bfs);
    ("pbfs", pbfs);
(*    ("split_merge_deque", split_merge_deque);*)
(*    ("diverge_deque", diverge_deque);*)
  ]

let should_run_experiment exp exps = 
  List.length exps = 0 || List.exists (fun e -> exp = e) exps

let build_targets =
  ["-C ../graph/bench/ search.elision3 search.elision2 graphfile.elision2 graphfile.opt2 -j"; 
   "-C ../fftree/benchmark/ bench.exe_filter bench.exe_fifolifo bench.exe_chunksize bench.exe_splitmerge -j";]

let build_all _ =
  let mk cmd = ignore (verbose_cmd (sprintf "make %s" cmd)) in
  List.iter mk build_targets;
  exit 0;
  ()

let generate_input _ =
  begin
    verbose_cmd_norc (sprintf "mkdir %s" path_to_graph_data);
    gen_synthetic_graph_files();
    List.iter download_graphfile external_graph_descr;
    List.iter convert_from_snap_to_adj_bin external_graph_descr;
    ()
  end

let _ =
  arg_bench_folder := ".";
  parse_plot_options();
  use_ropes := Cmdline.parse_or_default_bool "use_ropes" false;
  all_nb_runs := Cmdline.parse_or_default_int "runs" 1;
  email := Cmdline.parse_or_default_string "email" "";
  arg_virtual := Cmdline.parse_or_default_bool "virtual" false;
  path_to_results_file := Cmdline.parse_or_default_string "path_to_results_file" "";
  plot_relative := Cmdline.parse_or_default_bool "plot_relative" false;
  if Cmdline.parse_or_default_bool "show_graph_data_descr" false then 
    begin
      show_graph_descr();
      exit 0
    end
  else if Cmdline.parse_or_default_bool "generate_input" false then
    begin
      generate_input();
      exit 0;
    end
  else if Cmdline.parse_or_default_bool "generate_graph_files" false then
    begin
      gen_synthetic_graph_files();      
      exit 0;
    end
  else ();
  if Cmdline.parse_or_default_bool "build" false
  then build_all()
  else ();
  time_at_start_of_experiment := Unix.time();
  let experiments = Cmdline.parse_or_default_list_string "experiment" [] in
  let run_experiment exp_name exp =
    print_msg(sprintf "starting experiment %s" exp_name);
    let start_time = Unix.gettimeofday() in
    exp();
    let elapsed = Unix.gettimeofday() -. start_time in
    print_msg (sprintf "results stored in %s" (get_path_to_results()));
    print_msg (sprintf "completed experiment %s in %f seconds" exp_name elapsed);
    send_email_notification exp_name elapsed;
    ()
  in
  List.iter 
    (fun (exp_name, exp) -> 
      if should_run_experiment exp_name experiments then run_experiment exp_name exp)
    all_experiments;  
  (*-----------*)
  svn_commit();
  ()
