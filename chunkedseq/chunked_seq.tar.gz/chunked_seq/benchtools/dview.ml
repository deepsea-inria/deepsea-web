open Shared
open Scanf
open Printf
open Graphics
open Visualize


(****************************************************)
(* Type of events *)

type evttype = 
  | Evt_enter_launch
  | Evt_exit_launch
  | Evt_enter_wait
  | Evt_exit_wait
  | Evt_other

(****************************************************)
(* Parsing of events *)

let parse_event ch =
   let time = float_of_int (read_int ch) in
   let proc = read_int ch in
   let code = read_int ch in
   let evttype = match code with
      | 0 -> Evt_enter_launch
      | 1 -> Evt_exit_launch
      | 2 -> Evt_enter_wait
      | 3 -> Evt_exit_wait
      | _ -> Evt_other
      in
   (time,proc,evttype)


(****************************************************)
(* Printing of events (for debug purposes only) *)

let string_of_evttype = function
  | Evt_enter_launch -> "enter_launch"
  | Evt_exit_launch -> "exit_launch"
  | Evt_enter_wait -> "enter_wait"
  | Evt_exit_wait -> "exit_wait"
  | Evt_other -> "other"

let print_event evt =
   let (time,proc,evttype) = evt in
   printf "%f %d %s\n" time proc (string_of_evttype evttype)

let print_events evts =
   List.iter print_event evts

(****************************************************)
(* Display of events *)

let drawing events range =
   let not_idle = -1. in
   let nbproc = get_nbproc() in
   let idle_since = Array.make nbproc not_idle in
   let height = get_proc_height() - 2 in
   let draw_launch proc timestamp =
      draw_box range proc blue 0 height timestamp timestamp in
   list_foreach events (fun (timestamp, proc, eventtype) ->
      match eventtype with 
      | Evt_enter_launch -> draw_launch proc timestamp
      | Evt_exit_launch -> draw_launch proc timestamp
      | Evt_enter_wait ->
         if idle_since.(proc) <> not_idle
            then warning "two consecutive enter_wait";
         idle_since.(proc) <- timestamp
      | Evt_exit_wait ->
         if idle_since.(proc) = not_idle then
            warning "exit_wait without prior enter_wait"
         else begin
            draw_box range proc red 1 (height-1) idle_since.(proc) timestamp;
            idle_since.(proc) <- not_idle
         end
      | Evt_other -> 
         draw_box range proc black 0 1 timestamp timestamp
      );
   nat_foreach nbproc (fun p ->
     if (idle_since.(p) <> not_idle) 
        then warning "missing exit_wait events")


(****************************************************)
(* Pre-processing of events *)

let preprocess_events events =
   (* for debugging: print_events events;*)
   let init_range = 
      let select_evt evt min_or_max init =
         List.fold_left (fun acc (t,p,s) ->
           if s = evt then min_or_max acc t else acc) init events in
      let t1 = select_evt Evt_enter_launch min infinity in
      let t2 = select_evt Evt_exit_launch max neg_infinity in
      if t1 = infinity || t2 = neg_infinity
         then failwith "cannot find enter_launch or exit_launch";
      (t1,t2)
      in   
   (events, extract_nb_proc events, init_range, extract_full_range events)


(****************************************************)
(* Main loop *)

let _ =
   let logfile = Cmdline.parse_or_default_string "input" "LOG_BIN" in
   let parse_events () =
      parse_item_list_from_file parse_event logfile in
   main_loop parse_events preprocess_events drawing

