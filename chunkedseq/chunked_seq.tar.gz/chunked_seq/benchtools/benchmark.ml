open Shared
open Printf
open Scanf

let msg s =
  print_string s; flush stdout

let msg_newline s =
  msg (s ^ "\n")

let system c =
   if true 
      then (let r = Unix.system c in r)
      else (let n = Sys.command c in Unix.WEXITED n)
      
(*      
      else (let x = ref 0 in for i = 1 to 200000000 do incr x done; msg (string_of_int !x))
  *)    

(***************************************************************)
(***************************************************************)
(***************************************************************)


(***************************************************************)
(** * Architecture description *)

type arch = {
   arch_nbproc : int; (* number of processors *)
}

(***************************************************************)
(** * Machine description *)

type 'a machine = {  
   machine_name : string;  (* name identifying the machine *)
   machine_cluster : string;  (* same as machine name if not in cluster *)
   machine_arch : 'a;  (* description of the hardware of the machine, possibly of type arch *)
   machine_exec : string -> string;  (* build command that ssh, goes to working dir and run argument *)
   machine_recup : string -> string;  (* build command to get a local copy of a remote file, assuming this command will get executed by machine_exec --todo:is this what we want?? *)
   }

type 'a machines = ('a machine) list 

let localhost_name =
   let name = Unix.gethostname() in
   List.hd (Str.split (Str.regexp_string ".") name)  (* todo: why is this needed? *)

let get_local_directory () =
   Sys.getcwd() ^ "/"

let get_svnversion () =
  let r = system "svnversion . > .svninfo" in 
  if r <> Unix.WEXITED 0 then begin
    msg_newline "Warning: failed to get subversion number"; 
    "NA"
  end else begin
    try
      file_get_contents ".svninfo"
    with _ -> failwith "cannot read svninfo"
  end

let machine_recup_implicit filename = 
   "" (* when working locally or on a NFS, no need to copy files *)

let machine_recup_scp filename =
  sprintf "scp %s %s:%s" filename (localhost_name) (get_local_directory()) 

let make_machine name ?(cluster=name) ?(dir=get_local_directory()) arch exec =
   { machine_name = name;
     machine_cluster = cluster;
     machine_arch = arch; 
     machine_exec = exec; 
     machine_recup = machine_recup_implicit; }

let exec_local cmd =
   cmd

let make_local_machine arch =
   { machine_name = localhost_name;
     machine_cluster = "local";
     machine_arch = arch;
     machine_exec = exec_local;
     machine_recup = machine_recup_implicit; }

let local_machine = make_local_machine ()

(* Find the machine with the given name, or a machine with the given cluster name *)

exception MachineNotFound of string

let find_machine machines vmachine = 
   try 
      List.find (fun m -> m.machine_name = vmachine) machines
   with Not_found -> 
   try 
      List.find (fun m -> m.machine_cluster = vmachine) machines
   with Not_found -> 
      raise (MachineNotFound vmachine)

(* Find the machine with the given name, or a machine with the given cluster name,
   but try to use the localhost if it has good name or good cluster name *)

let find_machine_trying_local machines vmachine = 
   let default () =
      find_machine machines vmachine in
   try 
      List.find (fun m -> 
         (* printf "trying %s against name=%s cluster=%s for target=%s\n" localhost_name m.machine_name m.machine_cluster vmachine;*)
          (m.machine_name = localhost_name)
          &&  (m.machine_name = vmachine
            || m.machine_cluster = vmachine)
         ) machines
   with Not_found -> default() 


(***************************************************************)
(** * Makefile invokation description *)

   (* later on : integrate support for "make" command on used benchmarks in here *) 

(***************************************************************)
(** * Batch identifiers *)

type batchid = int

let batchid_counter = ref 0

let new_batchid () : batchid =
  incr batchid_counter;
  !batchid_counter

let nobatchid = 0

(***************************************************************)
(** * Benchmark description *)

type strings = string list
type param = string * dyn
type params = param list

type bench = {
   bench_vmachine : string;  (* name of machine or cluster to use *)
   bench_prog : string;  (* name of the program, without arguments *)
   bench_params : params;  (* command line arguments for the program *)
   }

type benchrun = {
   benchrun_bench : bench;  (* benchmark to execute *)
   benchrun_timeout : int;  (* kill the program after the given number of seconds *)
   benchrun_nbruns : int;  (* number of times to run this benchmark *)
   benchrun_max_retry : int;  (* max number of times to rerun this benchmark *)
   benchrun_batchid : batchid;  (* benches of same batchid will run consecutively on a same machine *)
   }

type benches = bench list

(** Conversion function to convert a well-named parameter into a one letter parameter *)

let arg_of_param (key, dyn) =
   let value = Dyn.string_of_dyn dyn in
   if key = "" then value else sprintf "-%s %s" key value 

let bench_command bench =
   let exec = bench.bench_prog in
   String.concat " " (exec :: List.map arg_of_param bench.bench_params)

let string_of_key key =
   if key = "" then "" else Str.string_after key 1

let string_of_param (key,dyn) =
   sprintf "%s=%s" (string_of_key key) (Dyn.string_of_dyn dyn) 

let string_of_params params =
   String.concat ", " (List.map string_of_param params)


(***************************************************************)
(** * Benchmark selection *)

(** Helper function to use a default value when no list argument is provided *)

let use_if_not_nil list default =
   if list <> [] then list else default

let use_if_not_nil_eval list default_get =
   if list <> [] then list else default_get()


(** Helper function to use a default value when no int argument is provided *)

let int_void = -1000000
let float_void = -1000000.

let use_if_not void value default =
   if value <> void then value else default


(** Helper function for selecting good benchmarks *)

let if_param_exists_then_in_list list params key get_type =
    list = [] 
  || not (List.mem_assoc key params)
  || let value = get_type (List.assoc key params) in
     List.mem value list

   (* LATER: for filtering out
   list_filter all_benchruns (fun benchrun ->
      let bench = benchrun.benchrun_bench in
      let params = bench.bench_params in
         if_param_exists_then_in_list args.args_study params "iExperiment" Dyn.get_int)
    && if_param_exists_then_in_list args.args_proc params "iProc" Dyn.get_int
    && if_param_exists_then_in_list args.args_size params "iSize" Dyn.get_int
    *)

(***************************************************************)
(** * Ensure "/generated" folder exists *)

let ensure_generated_folder_exists () =
   if not (Sys.file_exists "generated")
      then ignore (system "mkdir generated")

(***************************************************************)
(** * Benchmark execution *)

(** Generic command line arguments *)

let arg_virtual = ref false
let arg_silent = ref false
let arg_verbose = ref false
let arg_append = ref false
let arg_notimeout = ref false
let arg_nodummy = ref true
let arg_plot = ref ""
let arg_noplot = ref true
let arg_run_output = ref "results.txt"
let arg_bench_folder = ref "../bench/"
let arg_mpi_params = ref ""
let arg_mpi = ref false
let arg_nointerleaving = ref false
let arg_multiple = ref false

let mpi_bench_command bench =
   let exec = bench.bench_prog in
   let nb_proc = find_param_as_int "proc" bench.bench_params in
   let proc = sprintf "-np %d" (if nb_proc = 0 then 1 else nb_proc) in
   String.concat " " ("mpirun" :: !arg_mpi_params :: proc :: exec :: List.map arg_of_param bench.bench_params)

let parse_run_options () =
   if Cmdline.mem_flag "virtual" then arg_virtual := true;
   if Cmdline.mem_flag "silent" then arg_silent := true;
   if Cmdline.mem_flag "verbose" then arg_verbose := true;
   if Cmdline.mem_flag "append" then arg_append := true;
   if Cmdline.mem_flag "nodummy" then arg_nodummy := true; (* for backward compatibility only *)
   if Cmdline.mem_flag "dummy" then arg_nodummy := false;
   if Cmdline.mem_flag "nointerleaving" then arg_nointerleaving := true;
   if Cmdline.mem_flag "mpi" then arg_mpi := true;
   List.iter Cmdline.remove_flag ["silent";"verbose";"virtual";"append";"nodummy";"mpi";"nointerleaving"];
   arg_run_output := Cmdline.parse_or_default_string "output" !arg_run_output;
   arg_bench_folder := Cmdline.parse_or_default_string "bench" !arg_bench_folder;
   arg_mpi_params := Cmdline.parse_or_default_string "mpiparams" !arg_mpi_params;
   List.iter Cmdline.remove_arg ["output"; "bench"; "mpiparams"]

(* DEPRECATED
let run_generic_options =
  [ ("-virtual", Arg.Set arg_virtual, "only simulates");
    ("-silent", Arg.Set arg_silent, "do not show the benchmark being executed");
    ("-append", Arg.Set arg_append, "keep data from output file");
    ("-plot", Arg.String (fun s -> arg_plot := s), "specify argument for plot script");
    ("-noplot", Arg.Set arg_noplot, "deactivate plotting");
    ("-notimeout", Arg.Set arg_notimeout, "deactivate time out");
    ("-output", Arg.String (fun s -> arg_run_output := s), "specify output file (plots.pdf will nevertheless be overwritten)"); ]
*)

(** Function to run the plot program *)

let try_exec_plot result_filename options = 
   if (not !arg_noplot) && (not !arg_virtual)
      then ignore (system (sprintf "./plot.out -input %s %s %s" result_filename options !arg_plot))


(* for later use
 ("-directory", Arg.String (fun s -> arg_dir := s), "path to the complexity-based-scheduling /script directory");
 ("-local-host-name", Arg.String (fun s -> arg_localhostname := s), "local host name");
*)


(** Helper function for building command line *)
         (* todo: can we use redirection or should we use write-in-file ? *)
let build_run_command machine timeout bench result_filename = 
   let bench_builder = if !arg_mpi then mpi_bench_command else bench_command in
   let bench_cmd = bench_builder bench in
   let timeout_cmd' = if !arg_mpi then sprintf "timeout %d %s" timeout bench_cmd
				  else sprintf "%s/timeout.out %d %s" !arg_bench_folder timeout bench_cmd in
   let timeout_cmd = if !arg_notimeout then bench_cmd else timeout_cmd' in
   (* let timed_cmd = sprintf "/usr/bin/time -f %s %s" "\"fUsertime %U\"" timeout_cmd in*)
   let timed_cmd = timeout_cmd in
   let redirect_cmd = sprintf "%s > %s" timed_cmd result_filename in (* TODO: was &> *)
   let recup_cmd = machine.machine_recup result_filename in
   let local_cmd = sprintf "%s; %s" redirect_cmd recup_cmd in
   let remote_cmd = machine.machine_exec local_cmd in
   bench_cmd, remote_cmd

(** Wait to ensure that file operations are completed *) 

let wait_a_bit () =
   ignore (system "sleep 1") (* todo: find a cross-plateform way of waiting 0.1sec *)  
   
(** Function to empty a file *)

let reset_file filename = 
   file_put_contents filename ""

(** Build a lines that describes the benchmark in the output file *)

let bench_descr_lines machine timeout bench = 
   let params = ("machine", Dyn.String machine.machine_name) ::
                ("vmachine", Dyn.String bench.bench_vmachine) :: 
                ("prog", Dyn.String bench.bench_prog) :: 
                (* ("timeout", Dyn.Int timeout) :: *)
                bench.bench_params in  (* add id_run *)
   let print_param (key, dyn) =
      sprintf "%s %s\n" key (Dyn.string_of_dyn dyn) in
   String.concat "" (List.map print_param params)

let extract_and_report_usertime content =
   let reg = Str.regexp "exectime .*" in
   let s = 
      try 
         let _ = Str.search_forward reg content 0 in
         Str.matched_string content (* use matched_group *)
      with Not_found -> "exectime NA"
     in
   msg_newline s

let contains_error content =
   begin
   let reg = Str.regexp "rror" in (* TODO: improve *)
   try let _ = Str.search_forward reg content 0 in true
   with Not_found -> false
   end ||
   begin
   let reg = Str.regexp "exectime ERROR" in (* TODO: improve *)
   try let _ = Str.search_forward reg content 0 in true
   with Not_found -> false
   end

(** Execute one benchrun
    --we use one output file per machine to avoid races on the output file *)

exception Success of string

let execute_benchrun dosave machine timeout nbretry bench add_output add_error =
   let machine_name = machine.machine_name in
   let svninfo = get_svnversion() in
   let result_filename = sprintf "generated/output-%s.txt" machine_name in
   let bench_cmd, full_cmd = build_run_command machine timeout bench result_filename in
   let full_cmd = if !arg_mpi 
       then (file_get_contents "environment_ssh") ^ full_cmd 
       else full_cmd in 
   let report_error () =
      msg (sprintf "Warning: failure on executing on %s\n\t%s\n" machine_name full_cmd); 
      add_error bench_cmd
      in
   if !arg_verbose then begin 
     msg (sprintf "%s \t%s\n" machine_name bench_cmd); 
      if !arg_verbose then msg (sprintf "\t%s\n" full_cmd);
   end else begin
     msg (sprintf "%s\n" bench_cmd); 
   end;
   if not !arg_virtual then begin
      reset_file result_filename;
      begin try 
         for trial = 0 to nbretry-1 do
            let retrying () =
              msg "failed...retyring\n" in
            let exitresult = system full_cmd in
            if exitresult <> Unix.WEXITED 0 then retrying() else begin
               if not !arg_virtual && machine.machine_cluster <> "local" then wait_a_bit();
               let content = file_get_contents result_filename in
               if content = "" || contains_error content 
                  then retrying()
                  else raise (Success content)
            end;
         done;
         report_error() 
      with Success content ->
         if dosave then begin
            add_output (bench_descr_lines machine timeout bench);
            add_output "---\n";
            add_output (content);
            add_output (sprintf "svninfo %s" svninfo);
            add_output "==========\n";
            extract_and_report_usertime content
         end
      end;
   end

(** Report errors from the execution of benchruns *)

let report_errors errors =
   if errors = [] then begin
     msg "Benchmark successful\n" 
   end else begin
     msg "Benchmark encountered errors on running the following commands:\n";
     list_foreach errors (fun s -> msg_newline s)
   end

open Unix

let backup_output () = 
   let tm = Unix.gmtime (Unix.time()) in
   let target = sprintf "generated/results_%d-%d-%d_%d-%d-%d.txt" 
      (1900+tm.tm_year) (1+tm.tm_mon) tm.tm_mday tm.tm_hour tm.tm_min tm.tm_sec in
   unix_command (sprintf "cp %s %s" !arg_run_output target)

(** Execute all benchruns *)

let execute_benchruns (*LATER:machines*) benchruns = 
   ensure_generated_folder_exists();
   let (add_output,end_output) =
      if not !arg_virtual then begin
         let old_contents = if !arg_append then file_get_contents_or_empty !arg_run_output else "" in
         let channel = open_out !arg_run_output in
         output_string channel old_contents;
         flush channel;
         let add_output content =
            output_string channel content;
            flush channel;
            in
         let end_output () =
            close_out channel;
            backup_output();
            in
         (add_output, end_output)
      end else
         ((fun s -> ()), (fun () -> ()))
      in
   let runs_linear () = build_list (fun add_run ->
      list_foreachi benchruns (fun idbenchrun benchrun ->
         repeat benchrun.benchrun_nbruns (fun idrun ->
            add_run benchrun))) 
      in
   let runs_interleaved () =
      if benchruns = [] then [] else begin
      let nbruns = (List.hd benchruns).benchrun_nbruns in
      list_foreach benchruns (fun benchrun ->
         if benchrun.benchrun_nbruns <> nbruns
            then failwith "interleaving of runs not possible because nbruns varies");
      build_list (fun add_run ->
         repeat nbruns (fun idrun ->
            list_foreachi benchruns (fun idbenchrun benchrun ->
               add_run benchrun)))
      end
      in
   let runs = if !arg_nointerleaving then runs_linear() else runs_interleaved() in
   let nb_runs = List.length runs in

   let do_dummy = (not !arg_nodummy) && (runs <> []) in
   let errors = build_list (fun add_error ->
      let run dosave benchrun =
         let machine = local_machine in
            (** LATER: find_machine_trying_local machines bench.bench_vmachine *)
         let bench = benchrun.benchrun_bench in
         execute_benchrun dosave machine benchrun.benchrun_timeout 
              benchrun.benchrun_max_retry bench add_output add_error 
         in
      if do_dummy then begin
         let benchrun = List.hd runs in 
         let progress = sprintf "[dummy run]" in
         if not !arg_silent then msg_newline progress;
         run false benchrun
      end;
      list_foreachi runs (fun idbenchrun benchrun ->
         let progress = sprintf "[%d/%d]" (idbenchrun+1) nb_runs in
         if not !arg_silent then msg_newline progress;
         run true benchrun))
      in
   if !arg_virtual
      then msg "Simulation completed\n"
      else report_errors errors;
   end_output()

(**LATER:
let execute_benchruns_local benchruns = 
   execute_benchruns [local_machine] benchruns
*)

   (* LATER: use a multi-threaded scheduler *)
   (* LATER: respect the bench.bench_batchid constraint *)


(***************************************************************)
(** * Benchmark results *)


(** Argument for plot program *)

let arg_plot_input = ref "results.txt"
let arg_plot_output = ref "plots.pdf"
let arg_plot_routput = ref "plots.r"
let arg_height = ref 6.
let arg_width = ref 6.
let arg_nopdf = ref false
let arg_silent = ref false
let arg_rsep = ref false
let arg_notitle = ref false
let arg_title = ref "" 
let arg_legend_position = ref "topleft"

(* DEPRECATED
let plot_generic_options =
  [ ("-input", Arg.String (fun s -> arg_plot_input := s), "specify result file used as input"); 
    ("-output", Arg.String (fun s -> arg_plot_output := s), "specify plot file used as output"); 
    --("-dim", Arg.Float (fun f -> arg_dimension := f), "specify graph size"); 
    ("-rsep", Arg.Set arg_rsep, "compile R files separately");     
    ("-nopdf", Arg.Set arg_nopdf, "do not create the output PDF"); 
    ("-notitle", Arg.Set arg_notitle, "do not place titles"); 
    ("-silent", Arg.Set arg_silent, "do not report on progress");
  ]
*)

let parse_plot_options () = 
   if Cmdline.mem_flag "no_title" then arg_notitle := true;
   if Cmdline.mem_flag "separate" then arg_rsep := true;
   if Cmdline.mem_flag "silent" then arg_silent := true;
   List.iter Cmdline.remove_flag ["no_title";"separate";"silent"];
   arg_plot_input := Cmdline.parse_or_default_string "input" !arg_plot_input;
   arg_plot_output := Cmdline.parse_or_default_string "output" !arg_plot_output;
   arg_plot_routput := Cmdline.parse_or_default_string "routput" !arg_plot_routput;
   arg_legend_position := Cmdline.parse_or_default_string "legend" !arg_legend_position;
   arg_width := Cmdline.parse_or_default_float "width" !arg_width;
   arg_height := Cmdline.parse_or_default_float "height" !arg_height;
   arg_title := Cmdline.parse_or_default_string "title" !arg_title;
   arg_bench_folder := Cmdline.parse_or_default_string "bench" !arg_bench_folder;
   List.iter Cmdline.remove_arg ["input";"output";"routput";"width";"height";"title";"legend";"bench"]


(** Parser for user-formatted results *)

let cannot_parse k s : dyn =
   failwith (sprintf "no user parser defined for key %s" s)

(** Loading of the results as a list of (string*dyn) from a list of lines.
    A line should either be a separator '===' or starts with a keyword and be followed by text.
    The first letter of the keyword indicates the type to be used for parsing the rest of the line:
    - i : for an int 
    - f : for a float 
    - s : for a string
    - u : for a line to be parsed by the user-defined parser
    *)

type stringp = string * string
type data = stringp list
type datas = data list
type inputs = string list
type result = data * inputs
type results = result list

exception CannotParse of string

let read_results_from_lines lines : results =
   build_list (fun (add_result:result->unit) ->
      let current_params = ref [] in
      let current_inputs = ref [] in
      let in_inputs = ref true in
      list_foreachi lines (fun id_line line ->
         if line = "==========" then begin
            add_result (!current_params, !current_inputs);
            current_params := [];
            current_inputs := [];
            in_inputs := true
         end else if line = "" then begin
            ()
         end else if line = "---" then begin
            in_inputs := false
         end else begin
            let space_index = 
               begin try String.index line ' ' 
               with Not_found -> 
               try String.index line '\t' 
               with Not_found -> raise (CannotParse (sprintf "no space or tab on line %d: %s" (id_line+1) line))
               end
               in
            try 
               let key = Str.string_before line space_index in
               let value = Str.string_after line (space_index+1) in
               if key = "sError"
                  then msg (sprintf "Error in result: %s\n" value);
               add_to_list_ref current_params (key,value);
               if !in_inputs
                  then add_to_list_ref current_inputs key;
            with _ -> raise (CannotParse (sprintf "error line %d: %s" (id_line+1) line))
            (* msg (sprintf "Error: could not parse line %d:\n%s\n" (id_line+1) line) *)
         end
         );
      if !current_params <> [] 
         then msg "Warning: incomplete benchmark results at end of file";
      )

let read_results_from_file filename =
   let lines = file_get_lines filename in
   try read_results_from_lines lines
   with CannotParse s -> raise (CannotParse (sprintf "%s: %s" filename s))

let read_results_from_input_file () =
   read_results_from_file !arg_plot_input


(***************************************************************)
(** * Plot description *)

(** Data type of plots *)

type point = float * float
type points = point list
type curve = string * points
type curves = curve list
type mathcurve = 
   | Mathcurve_abline of float * float
   (* other forms:  e.g. ("x", "sin(x)") *)
type mathcurves = mathcurve list

type axis = {
   axis_label : string;
   axis_islog : bool;
   axis_lower : float option;
   axis_upper : float option;
   }

type scatter = {
   scatter_xaxis : axis;
   scatter_yaxis : axis;
   scatter_curves : curves;
   scatter_drawline : bool;
   scatter_mathcurves : mathcurves;
   scatter_enriched : bool;
   }

type barplot_height = float
type barplot_series = string * barplot_height list
      (* series title; bar heights in series *)
type barplot = {
   barplot_xaxis_label : string;
   barplot_yaxis_label : string;
   barplot_data : string list * barplot_series list;
      (* title of each group; items by group *)
   barplot_series_beautifier : string -> string;
   barplot_group_beautifier : string -> string  
   }

let string_of_barplot_series ((label, heights) : barplot_series) =
  sprintf "\t series=%s\t%s" label (String.concat ", " (List.map string_of_float heights))

let string_of_barplot_data ((group_titles, seriess) : string list * barplot_series list) =
  sprintf "groups=%s\ndata=%s\n" 
    (String.concat "," group_titles) 
    (String.concat "\n" (List.map string_of_barplot_series seriess))

let string_of_barplot (b : barplot) =
  sprintf "label=%s\n%s\n%s\n" 
    (b.barplot_xaxis_label)
    (b.barplot_yaxis_label)
    (string_of_barplot_data b.barplot_data)

type graph_data = 
  | Scatter of scatter
  | BarPlot of barplot

type graph = {
   graph_tag : string;
   graph_title : string;
   graph_data : graph_data;
   }

type graphs = graph list

(** * Table description *)

type cols = string list
type rows = cols list

type table = {
   (* table_tag : string;  *)
   table_title : string;
   table_data : rows;
   }

type chart = 
   | Chart_graph of graph
   | Chart_table of table

(** Helper functions *)

let axis ?(islog=false) ?(lower=None) ?(upper=None) ?(iszero=false) label =
 { axis_label = label;
   axis_islog = islog;
   axis_lower = if iszero then Some 0. else lower;
   axis_upper = upper; }

let axis_zero ?(islog=false) label =
   axis ~islog:islog ~lower:(Some 0.) label

let axis_zero ?(islog=false) ?(upper=None) label =
   axis ~islog:islog ~lower:(Some 0.) ~upper:upper label

let scatter_graph tag title data =   
   { graph_tag = tag;
     graph_title = title;
     graph_data = Scatter data; }

let scatter_data xaxis yaxis ?(drawline=false) ?(mathcurves=[]) points =
 { scatter_xaxis = xaxis;
   scatter_yaxis = yaxis;
   scatter_curves = points;
   scatter_drawline = drawline;
   scatter_mathcurves = mathcurves;
   scatter_enriched = false; }

let cmp_points_x (x1,_) (y1,_) =
   if x1 < y1 then -1 else 1

let sort_points_x points =
   List.sort cmp_points_x points


(***************************************************************)
(** * Plot Generation *)

let cmp_values x y =
  if x < y then -1 else 1


(***************************************************************)
(** * Graph selection *)

let select_graphs_by_tag graphs tags =
   let hash = Hashtbl.create 100 in
   list_foreach graphs (fun graph -> 
      let tag = graph.graph_tag in
      if Hashtbl.mem hash tag 
         then msg (sprintf "Warning: duplicated tag: \n%s\n" tag);
      Hashtbl.add hash tag graph);
   build_list (fun add -> 
      list_foreach tags (fun tag ->
         try add (Hashtbl.find hash tag)
         with Not_found -> msg (sprintf "Warning: cannot find graph for tag: \n%s\n" tag)))


(***************************************************************)
(** * Graph plot to PDF using R *)

let rstring_of_float ?(islogscale=false) v =
   match classify_float v with 
   | FP_zero when islogscale -> "0.1" 
   | FP_normal | FP_subnormal | FP_zero -> sprintf "%f" v
   | FP_infinite | FP_nan -> "NA"

exception EmptyGraph 

let listify strs = 
   String.concat "," strs 

let stringify s = 
  sprintf "\"%s\"" s

let liststringify strs = 
  listify (List.map stringify strs) 

let rcolors nbcols =
  let vals = list_init nbcols (fun i -> sprintf "%d" (i+1)) in
  sprintf "cols <- as.vector(c(%s))" (listify vals)

let rscript_of_barplot_graph graphtitle barplot =
  let (group_titles, series) = barplot.barplot_data in
  
  let take1 heights = (List.map List.hd heights, List.map List.tl heights) in
  let rec takeN heights =
    match heights with
      | [] -> []
      | h::_ ->
        match h with
          | [] -> []
          | _ -> 
            let (hs, heights') = take1 heights in
            hs @ takeN heights'
  in

  let series' = List.map snd series in (* get rid of labels *)
  let all_heights = takeN series' in

  let ymax = List.fold_left max 0. all_heights in
  let ylim = Cmdline.parse_or_default_float "ylim" (2.*.ymax)in

  let out_height_vec =
    sprintf "data0 <- matrix(c(%s),ncol=%d)\n" 
      (listify (List.map string_of_float all_heights)) 
      (List.length group_titles)
  in

  let group_titles = List.map barplot.barplot_group_beautifier group_titles in
  let out_group_titles = sprintf "colnames(data0) <- c(%s)\n" (liststringify group_titles) in
  let series_titles = List.map fst series in
  let series_titles = List.map barplot.barplot_series_beautifier series_titles in
  let out_series_titles = sprintf "rownames(data0) <- c(%s)\n" (liststringify series_titles) in
  let out_table = sprintf "table0 <- t(as.table(data0))\n" in (*todo: option to control transpose*)
(*  let title = sprintf "\"%s\"" (if graphtitle = "" then "untitled" else graphtitle) in *)
  let special = sprintf "ylim=range(0,%f)" ylim in
  let out_barplot = 
     (*  space= # Amount of space between i) bars within a group, ii) bars between groups   *)
    (* use `las=2` to render series labels vertically *)
    sprintf "bp <- barplot(table0, beside=TRUE, space=c(0,2), las=2, col=cols, names.arg=colnames(table0), xlab=%s, ylab=%s, legend=rownames(table0), args.legend = list(x = %s), %s)"
       (stringify barplot.barplot_xaxis_label) 
       (stringify barplot.barplot_yaxis_label) 
       (stringify !arg_legend_position)
       special
   (* font.lab=2  border="black"*)
    in
  (*let out_text_labels = sprintf "text(bp, 0, round(table0, 1), cex=1, pos=3)" in*)
  (*let nbseries = List.length series in*)
  [ (*"cols <- as.vector(c(\"white\", \"red\",\"blue\",\"yellow\"))"; *) (* rcolors 16; *)
    rcolors (List.length group_titles);
   out_height_vec; 
   out_series_titles;
   out_group_titles;
   out_table;
   "par(mar=c(12, 4, 4, 2) + 0.4)";
   out_barplot;
      (* specific *)
(*   "abline(1.,0,lty=2,col='black')" *)

   (*out_text_labels*) ]

let batchname i = 
  sprintf "data%d" i

let rscript_of_scatter_graph_all_but_curves batches graphtitle scatter =
   let islogx = scatter.scatter_xaxis.axis_islog in
   let islogy = scatter.scatter_yaxis.axis_islog in
   let logoption = 
      if islogx && islogy then ", log='xy'" 
      else if islogx then ", log='x'"
      else if islogy then ", log='y'"
      else "" in
   let define_data i points =
      (*if points = [] then [ sprintf "%s <- matrix()" (batchname i) ] else *)
      let points = sort_points_x points in (* later: an option for disabling sorting of points *)
      let xs,ys = List.split points in
      let list_of_values islogscale vs =
         String.concat "," (List.map (rstring_of_float ~islogscale:islogscale) vs) in
      [ sprintf "%s <- matrix(c(%s,%s),ncol=2)" (batchname i) (list_of_values islogx xs) (list_of_values islogy ys) ] in
   let bound optvalue islog =
      match optvalue with
      | Some 0. when islog -> "1."
      | Some v -> sprintf "%f" v
      | None -> "NA" 
      in
   let corner1 = 
      sprintf "corner1 <- matrix(c(%s,%s),ncol=2)"
         (bound scatter.scatter_xaxis.axis_lower islogx) 
         (bound scatter.scatter_yaxis.axis_lower islogy) in
   let corner2 = 
      sprintf "corner2 <- matrix(c(%s,%s),ncol=2)"
         (bound scatter.scatter_xaxis.axis_upper islogx) 
         (bound scatter.scatter_yaxis.axis_upper islogy) in
   let plot =
      sprintf "plot(rbind(%s), type='n', xlab='%s', ylab='%s'%s%s%s)" 
        (String.concat "," (list_mapi (fun i _ -> batchname i) batches) ^ ",corner1,corner2")
        scatter.scatter_xaxis.axis_label 
        scatter.scatter_yaxis.axis_label
        "" (* add support for xlim=c(a,b) here *)
        "" (* add support for ylim=c(a,b) here *)
        logoption in
   let draw_mathcurve m =
      match m with
      | Mathcurve_abline (intersect,slope) ->
         sprintf "abline(%f,%f,col='gray')" intersect slope 
      in 
   let mathcurves =      
      List.map draw_mathcurve scatter.scatter_mathcurves in 
   List.concat (list_mapi define_data batches)
   @ [ rcolors 16;
       "pchs <- as.vector(c(4,19,17,15,0,2,5,6,3,1,7,8,9,10,24,23))";
       corner1;
       corner2;
       plot ]
   @ mathcurves


let rscript_of_scatter_graph_enriched graphtitle scatter =
   let legends,batches = List.split scatter.scatter_curves in
   let (_curve_a,_curve_b,_curve_c,_curve_d) = 
     match batches with a::b::c::d::[] -> (a,b,c,d) | _ -> failwith "not right nb of curves for enriched" in
   let curves = 
      [ 
        sprintf "points(%s,col='red',pch=15,type='l')" (batchname 3);
        sprintf "points(%s,col='red',pch=15,type='l',lty=5)" (batchname 2);
        sprintf "points(%s,col='red',pch=4,type='p')" (batchname 2);
        sprintf "points(%s,col='blue',pch=15,type='l',lty=2)" (batchname 1);
        sprintf "points(%s,col='blue',pch=15,type='l')" (batchname 0);
        sprintf "points(%s,col='blue',pch=15,type='p')" (batchname 0) ]
      in
  let core = rscript_of_scatter_graph_all_but_curves batches graphtitle scatter in
  core @ curves

let rscript_of_scatter_graph graphtitle scatter =
   if scatter.scatter_enriched then (* todo improve dispatch technique *)
     rscript_of_scatter_graph_enriched graphtitle scatter
   else begin
   let curves = scatter.scatter_curves in
   let curves =
      if List.length curves <= 16 then curves else begin
        msg (sprintf "Warning: cannot plot more than 16 curves on one graph; trimming data for %s\n" graphtitle);
         take 16 curves
      end in
   let curves = List.filter (fun (legend,points) -> points <> []) curves in
   if curves = [] then raise EmptyGraph;
   let legends,batches = List.split curves in
   let legend = 
      (*   bottomri
ght bottom bottomleft left topleft top topright right center *)
      if legends = [""] then "" else
         sprintf "legend('%s', c(%s), col=cols, pch=pchs)" 
         !arg_legend_position
         (String.concat "," (List.map (fun s -> sprintf "'%s'" s) legends)) in
   let draw_batch_mode mode i points =
      (*if points = [] then [] else*)
      [ sprintf "points(%s,col=cols[%d],pch=pchs[%d],type='%s')" (batchname i) (i+1) (i+1) mode ] in
   let draw_batch i points =
      if scatter.scatter_drawline 
         then draw_batch_mode "l" i points @ draw_batch_mode "p" i points
         else draw_batch_mode "p" i points
      in
  let core = rscript_of_scatter_graph_all_but_curves batches graphtitle scatter in
  let curves = List.concat (list_mapi draw_batch batches) in
  core @ [ legend ] @ curves
  end

let rscript_of_graph graph =
   (* TODO: use main=.. parameter of plot to handle the title *)
   let r_title = 
      if !arg_notitle then [] 
      else
        let title = if !arg_title <> "" then !arg_title else graph.graph_title in
        [ sprintf "title(main='%s', col.main='black', font.main=1, cex.main=0.5)" title ] 
      in
   let r_plot = match graph.graph_data with
      | Scatter scatter -> rscript_of_scatter_graph graph.graph_title scatter
      | BarPlot barplot -> rscript_of_barplot_graph graph.graph_title barplot
      in
   r_plot @ r_title 


(* image extension should be "pdf" or "eps"; 
   rscript should be a list of lines *)
let rscript_wrap_image rscript basename extension =
   let format = match extension with
      | "pdf" -> "pdf"
      | "eps" -> "postscript"
      | _ -> failwith ("unsupported image format:" ^ extension)
      in
   let imgfilename = basename ^ "." ^ extension in
   let lines = List.concat [
      [ sprintf "%s('%s', height=%f, width=%f)" format imgfilename !arg_height !arg_width ];
      rscript;
      [ "dev.off()" ] ] in
   String.concat "\n" lines

let execute_rscript rscript rfilename =
   file_put_contents rfilename rscript;
   file_put_contents !arg_plot_routput rscript;
   let cmd = sprintf "R --silent --file=%s > null" rfilename in
   let c = system cmd in
   if c <> Unix.WEXITED 0  
      then msg (sprintf "Warning: failure on executing R on file: %s\n" rfilename)

(** Construction of a latex table *)

let generate_table table =
   let rows = table.table_data in 
   if rows = [] then raise EmptyGraph;
   let output = ref [] in
   let put s = add_to_list_ref output s in
   put "\\begin{verbatim}";
   put table.table_title;
   put "\\end{verbatim}";
   let nbcols = List.fold_left (fun acc row -> max acc (List.length row)) 0 rows in
   let col_descr = list_init (nbcols) (fun i -> if i = 0 then "l|" else "c|") in
   put (sprintf "\\begin{tabular}{|%s}" (String.concat "" col_descr));
   list_iter rows (fun cols ->
      if cols = [] then put "\\hline" else begin
         list_foreachi cols (fun i item ->
            put item;
            if i < nbcols-1 then put "&";
         );
         put "\\\\";
      end
   );
   put "\\end{tabular}";
   String.concat "\n" (List.rev !output) 
   
let generate_table_into_file filename table =
   file_put_contents filename (generate_table table)


(** Construction of a set of graphs into a PDF *)

let pdf_of_charts_exec charts =
   ensure_generated_folder_exists();
   let imgscripts = ref [] in
   let counter = ref 0 in
   let tags = ref [] in 
   let includes = build_list (fun add_include ->
      list_foreach charts (fun chart ->
         incr counter;
         match chart with 
         | Chart_graph graph ->
            let basename = sprintf "generated/chart-%d" !counter in
            add_to_list_ref tags graph.graph_tag;
            begin try let rscript = rscript_of_graph graph in
                let imgrscript = rscript_wrap_image rscript basename "pdf" in
                if !arg_rsep then begin
                   let rfilename = basename ^ ".r" in
                   execute_rscript imgrscript rfilename;
                   if not !arg_silent then msg (sprintf "Graph printed: %s.pdf\n" basename);
                end else begin
                   add_to_list_ref imgscripts imgrscript;
                   end;
                add_include (sprintf "\\myfig{%s.pdf}\n" basename);
            with EmptyGraph -> 
              msg (sprintf "Warning: no data for: %s\n" graph.graph_title)
             (* ()
                   msg (sprintf "Warning: no data for graph %s\n" graph.graph_title) *)
            end
         | Chart_table table ->
            begin try    
               let filename = sprintf "generated/table-%d.tex" !counter in
               generate_table_into_file filename table;
               add_include (sprintf "\\mytable{%s}\n" filename);
            with EmptyGraph -> 
              msg (sprintf "Warning: no data for table\n")
            end
        )) in
   let _ = 
      if !imgscripts <> [] then begin
         let fullscript = String.concat "\n" (List.rev !imgscripts) in
         execute_rscript fullscript "generated/chart-all.r"
      end in
   if (not !arg_silent) && includes = [] 
      then msg "Warning: no plots to output!\n";
   (* let tag_lines = List.map (fun s -> s) (List.rev !tags) in *)
   (* file_put_lines "tags.txt" "\n" tag_lines; *)
   file_put_lines "list.tex" "" includes;
   unix_command (sprintf "pdflatex -interaction=batchmode %s/plots.tex > null" !arg_bench_folder);
   if !arg_plot_output <> "plots.pdf" 
      then unix_command (sprintf "mv plots.pdf %s" !arg_plot_output)

let pdf_of_charts charts =
   if !arg_nopdf then msg "Skipping plot generation.\n" else begin
      if not !arg_silent then msg (sprintf "Starting to generate %d charts.\n" (List.length charts));
      pdf_of_charts_exec charts;
      if not !arg_silent then msg (sprintf "File %s written.\n" !arg_plot_output);
   end

let pdf_of_graphs graphs =
  pdf_of_charts (list_map graphs (fun g -> Chart_graph g))




(***************************************************************)
(** * DEBUG

let benchruns_dummy args =
   build_list (fun add_benchrun -> 
   add_benchrun {
      benchrun_bench = {
         bench_vmachine = "local";
         bench_prog = "dummy.out";
         bench_params = [ ("iMyParam", Dyn.Int 1) ]; };
      benchrun_timeout = args.args_timeout;
      benchrun_nbruns = args.args_nbruns;
      benchrun_batchid = nobatchid;
   })

*)

(* par(mfrow=c(2,2)) *)

