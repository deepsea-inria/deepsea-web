================
WORK IN PROGRESS
================


module Custom = struct

type prim = 
   (* core *)
   | Prim_data
   | Prim_let
   | Prim_in
   | Prim_list
   | Prim_options
   | Prim_iter
   | Prim_graph
   | Prim_curve
   | Prim_plot
   | Prim_line
   | Prim_unique
   | Prim_average
   | Prim_min
   | Prim_max
   | Prim_bucket
   | Prim_keep
   | Prim_remove
   | Prim_modify
   | Prim_add
   | Prim_sub
   | Prim_mul
   | Prim_div
   (* derivable *)
   | Prim_foreach
   | Prim_group
   | Prim_select
   | Prim_graphby
   | Prim_curveby

let prim_of_string = function
   | "data" -> Prim_data
   | "let" -> Prim_let
   | "in" -> Prim_in
   | "list" -> Prim_list
   | "opt" -> Prim_options
   | "options" -> Prim_options
   | "inter" -> Prim_iter
   | "graph" -> Prim_graph
   | "curve" -> Prim_curve
   | "plot" -> Prim_plot
   | "line" -> Prim_line
   | "unique" -> Prim_unique
   | "average" -> Prim_average
   | "min" -> Prim_min
   | "max" -> Prim_max
   | "keep" -> Prim_keep
   | "remove" -> Prim_remove
   | "modify" -> Prim_modify
   | "add" -> Prim_add
   | "sub" -> Prim_sub
   | "mul" -> Prim_mul
   | "div" -> Prim_div
   | "foreach" -> Prim_foreach
   | "group" -> Prim_group
   | "bucket" -> Prim_bucket
   | "select" -> Prim_select
   | "graphby" -> Prim_graphby
   | "curveby" -> Prim_curveby
   | _ -> raise Not_found

let print_prim = function
   | Prim_data -> "data"
   | Prim_let -> "let"
   | Prim_in -> "in"
   | Prim_list -> "list" 
   | Prim_options -> "options"
   | Prim_iter -> "iter"
   | Prim_graph -> "graph"
   | Prim_curve -> "curve"
   | Prim_plot -> "plot"
   | Prim_line -> "line"
   | Prim_unique -> "unique"
   | Prim_average -> "average"
   | Prim_min -> "min"
   | Prim_max -> "max"
   | Prim_keep -> "keep"
   | Prim_remove -> "remove"
   | Prim_modify -> "modify"
   | Prim_add -> "add"
   | Prim_sub -> "sub"
   | Prim_mul -> "mul"
   | Prim_div -> "div"
   | Prim_foreach -> "foreach"
   | Prim_group -> "group" 
   | Prim_bucket -> "bucket"
   | Prim_select -> "select"
   | Prim_graphby -> "graphby"
   | Prim_curveby -> "curveby"


type expr = 
   | Expr_var of string
   | Expr_float of float
   | Expr_string of string
   | Expr_app of prim * expr list

type value = 
   | Value_unit
   | Value_float of float
   | Value_string of string
   | Value_prim of prim
   | Value_list of value list
   | Value_options of (string*value) list
   | Value_data of datas 

let rec print_value = function
   | Value_unit -> "_"
   | Value_float f -> string_of_float f
   | Value_string s -> s 
   | Value_prim f -> print_prim f
   | Value_list vs -> sprintf "[%s]" 
         (string_of_list ";" print_value vs)
   | Value_options kvs ->
      let print_pair (k,v) =
         sprintf "(%s,%s)" k (print_value v)
         in
      sprintf "[[%s]]" (string_of_list "; " print_pair kvs)
   | Value_data d -> 
       sprintf "<data:%d>" (List.length d)

type ctx = (string * value) list

type stack_item = 
   | Stack_expr of expr 
   | Stack_open_par
   | Stack_coma

let rec print_expr e =
   match e with
   | Expr_var x -> sprintf "_%s" x
   | Expr_string x -> x
   | Expr_float f -> string_of_float f
   | Expr_app (f,vs) ->
      sprintf "%s(%s)" (print_prim f)
         (string_of_list ", " print_expr vs)

let print_stack_item = function
  | Stack_expr e -> print_expr e
  | Stack_open_par -> "]"
  | Stack_coma -> ","

let prim_of_expr = function
  | Expr_string x -> 
      begin 
      try prim_of_string x
      with Not_found -> failwith (sprintf "unknown function %s" x)
      end
  | _ -> failwith "function must be a string"

let print_stack s =
   print_string (string_of_list " :: " print_stack_item s);
   print_newline()

let parse s = 
   let tokens = Str.full_split (Str.regexp "[,( )]") s in
   (* list_iter tokens (fun x -> printf "%s\n" x) *)
   let stack = ref [] in
   let push e =
      add_to_list_ref stack (Stack_expr e)
      in
   let close_par () =
      let rec aux vs s =
         match s with
         | Stack_expr e :: Stack_coma :: s' -> 
            aux (e::vs) s'
         | Stack_open_par :: Stack_expr f :: s' ->
            if vs <> [] then failwith "syntax error (empty argument)";
            (Stack_expr (Expr_app(prim_of_expr f, vs)) :: s')
         | Stack_expr e :: Stack_open_par :: Stack_expr f :: s' -> 
            (Stack_expr (Expr_app(prim_of_expr f, e::vs)) :: s')
         (*
         | [] 
            -> failwith "closing parenthesis without opening one"
         | Stack_coma :: _ 
            -> failwith "unexpected coma"
         | Stack_open_par :: [] 
            -> failwith "parenthesis without function in front"

         | Stack_open_par :: Stack_open_par :: s' 
         | Stack_expr e :: Stack_open_par :: Stack_open_par :: s' 
            -> failwith "double opening parenthesis"
         *)
         | _ -> failwith "syntax error"
         in
      stack := aux [] !stack
      in
   let process t =
      match t with 
      | Str.Delim "(" ->
         add_to_list_ref stack Stack_open_par
      | Str.Delim ")" ->
         close_par()
      | Str.Delim "," ->
         add_to_list_ref stack Stack_coma
      | Str.Delim _ ->
         ()
      | Str.Text x ->
         try push (Expr_float (float_of_string x))
         with _ ->
            if x = "" then failwith "syntax error: empty string";
            if x.[0] = '_'
               then push (Expr_var (Str.string_after x 1))
               else push (Expr_string x)
      in
   list_iter tokens (fun t -> process t ; (* print_stack !stack *) );
   let e =
      match !stack with
      | [] -> failwith "could not parse: final stack size is zero";
      | [Stack_expr e] -> e
      | _ -> failwith "could not parse: final stack size <> 1";
      in
   print_string (print_expr e);
   e


let op_eval_key f key datas =
   let values = list_map datas (data_float key) in 
   if values = [] then failwith (sprintf "no data for key %s" key);
   match f with 
   | Prim_unique -> 
      let x = List.hd values in
      if not (list_for_all values ((=) x)) 
         then failwith (sprintf "not unique for key %s" key);
      x
   | Prim_average -> list_mean values
   | Prim_min -> List.fold_left min infinity values 
   | Prim_max -> List.fold_left max neg_infinity values 
   | _ -> failwith "invalid argument op_eval_key"

type env = {
   env_datas : datas;
   env_scope : (string * value) list;
   env_add_graph : graph -> unit;
   env_add_curve : curve -> unit;
   env_add_point : point -> unit;
   env_add_mathcurve : mathcurve -> unit;
   }

let no_func x =
   failwith "function env_add_* unregistered" 

let init_env datas add_graph = {
   env_datas = datas;
   env_scope = [];
   env_add_graph = add_graph;
   env_add_curve = no_func;
   env_add_point = no_func;
   env_add_mathcurve = no_func;
   }

let options_get error key value =
   match value with
   | Value_options kvs ->
      list_assoc_option key kvs
      (*
      let rec find = function
         | [] -> None
         | kv::kvs' -> 
            begin match kv with
            | Value_list [Value_string k;v] when k = key -> Some v
            | _ -> find kvs'
            end
         in
      find kvs
       *)
   | _ -> error "invalid argument for options_get"
   
let options_get_as_bool error key value =
   match options_get error key value with
   | Some (Value_float f) when f <> 0. -> true
   | _ -> false

let options_get_string error key value =
   match options_get error key value with
   | Some (Value_string s) -> Some s
   | _ -> None


let gen_variable =
   let n = ref 0 in
   (fun () -> incr n; sprintf "__%d" (!n))

let check_unit error = function
  | Value_unit -> ()
  | _ -> failwith "unit value was expected"

let rec run env expr = 
   let r = run env in
   let error msg =
      failwith (sprintf "%s : %s" msg (print_expr expr)) in
   match expr with
   | Expr_var x -> 
      begin
      try List.assoc x env.env_scope
      with Not_found -> failwith (sprintf "unbound variable %s" x)
      end
   | Expr_string x -> 
      Value_string x
   | Expr_float f -> 
      Value_float f
   | Expr_app (f,es) ->
      let bad_arguments () =
         error "bad arguments for call" in
      match f with
      | Prim_data ->
         Value_data env.env_datas
      | Prim_let ->
         begin match es with
         | [ Expr_var x; e1; e2] ->
            let v1 = r e1 in
            let s = (x,v1)::env.env_scope in
            run {env with env_scope = s} e2
         | _ -> bad_arguments()
         end
      | Prim_in ->
         begin match es with
         | [ e1 ; e2 ] ->
            let datas' = match r e1 with
              | Value_data d -> d
              | _ -> error "first argument of in does not evaluate to a data set"
              in
            run {env with env_datas = datas'} e2
         | _ -> bad_arguments()
         end
      | Prim_list ->
         let vs = list_map es r in
         Value_list vs
      | Prim_options ->
         let kvs = list_map es r in
         let rec aux = function
            | [] -> []
            | Value_string s :: v :: rest -> (s,v)::(aux rest)
            | _ -> error "bad argument in params"
            in
         Value_options (aux kvs)
      | Prim_iter ->
         begin match es with
         | [ Expr_var x; e1; e2] ->
            let vs = match r e1 with
              | Value_list vs -> vs
              | _ -> error "second argument of iter does not evaluate to a list"
              in
            let env_for v = 
               {env with env_scope = (x,v)::env.env_scope} in
            list_iter vs (fun v -> check_unit error (run (env_for v) e2));
            Value_unit
         | _ -> bad_arguments()
         end
         
      | Prim_graph ->
         begin match es with
         | [ e1; e2 ] ->
            let options = r e1 in
            let curves = build_list (fun add_curve -> 
               check_unit error (run {env with env_add_curve = add_curve} e2)) in
            let curves = list_ksort cmp_curve_title curves in
            let graph_title = unsome_or "untitled" (options_get_string error "title" options) in
            let xaxis_title = unsome_or "untitled" (options_get_string error "xlabel" options) in
            let yaxis_title = unsome_or "untitled" (options_get_string error "ylabel" options) in
            let xlog = options_get_as_bool error "xlog" options in
            let ylog = options_get_as_bool error "ylog" options in            
            let xlower = if options_get_as_bool error "xzero" options then Some 0. else None in
            let ylower = if options_get_as_bool error "yzero" options then Some 0. else None in
            let scatter = { 
               scatter_xaxis = axis ~lower:xlower ~islog:xlog xaxis_title;
               scatter_yaxis = axis ~lower:ylower ~islog:ylog yaxis_title;
               scatter_curves = curves;
               scatter_drawline = true;
               scatter_mathcurves = [] }  (* TODO *)
               in
            let graph = { 
               graph_tag = "";  
               graph_title = graph_title; 
               graph_data = Scatter scatter; }
               in
            env.env_add_graph graph;
            Value_unit
         | _ -> bad_arguments()
         end
    
      | Prim_curve ->
         begin match es with
         | [ e1; e2 ] ->
            let options = r e1 in
            let title = unsome_or "untitled" (options_get_string error "title" options) in
            let points = build_list (fun add_point ->
               run {env with env_add_point = add_point} e2) in
            env.env_add_curve (title, points)
         | _ -> bad_arguments()
         end;
         Value_unit

      | Prim_plot ->
         begin match es with
         | [ e1; e2 ] ->
             let v1 = r e1 in
             let v2 = r e2 in
             begin match (v1,v2) with
             | Value_float f1, Value_float f2 -> 
               env.env_add_point (f1,f2)
             | _ -> error "non-float arguments to add_point" 
             end
         | _ -> bad_arguments()
         end;
         Value_unit

      | Prim_line ->  failwith "todo"

      | Prim_unique 
      | Prim_average
      | Prim_min 
      | Prim_max -> 
         let key = match es with 
            | [Value_string k] -> k 
            | _ -> bad_arguments()
            in
         op_eval_key f key datas

      | Prim_add
      | Prim_sub
      | Prim_mul
      | Prim_div ->
         begin match es with 
         | [e1,e2] -> 
             let v1 = r e1 in
             let v2 = r e2 in
             begin match (v1,v2) with
             | Value_float f1, Value_float f2 -> 
                 begin match f with 
                | Prim_add -> f1 +. f2
                | Prim_sub -> f1 -. f2
                | Prim_mul -> f1 *. f2
                | Prim_div -> f1 /. f2
                end
             | _ -> error "non-float arguments to math operation" 
             end
         | _ -> bad_arguments() 
         end

      | Prim_bucket ->
         begin match es with 
         | [e1] -> 
             begin match (r e1) with
             | Value_list vs -> 
                let ks = list_map vs (function
                   | Value_string s -> s
                   | _ -> error "expects list of strings in bucket") 
                   in
                let indexed_datas = make_buckets ks env.env_datas in
                Value_data (list_map indexed_datas snd)
             | _ -> error "invalid arguments"
             end
         | _ -> bad_arguments() 
         end
      | Prim_keep
      | Prim_remove ->
         begin match es with 
         | [e1; e2] -> 
             begin match (r e1) with
             | Value_options kvs -> 
                 let kfs = list_map kvs (fun (k,v) ->
                   match v with 
                   | Value_float f -> (k,f)
                   | _ -> error "cannot extract float in keep")
                   in
                 let datas' = list_filter env.env_datas (fun params ->
                    list_for_all kfs (fun (k,f) -> 
                      let b = 
                         try (data_float k params) = f
                         with Missing_data -> false 
                         in
                      begin match f with 
                      | Prim_keep -> b
                      | Prim_remove -> not b
                      | _ -> assert false 
                      end))
                    in
                 run {env with env_datas = datas'} e2
             | _ -> error "invalid arguments" 
             end
         | _ -> bad_arguments() 
         end

      | Prim_modify -> failwith "todo"

      | Prim_group ->
         begin match es with 
         | [e1;e2;e3] -> 
            let x = gen_variable() in
            r (Expr_app (Prim_let, [
               Expr_var x; 
               Expr_app(Prim_bucket, [e1]);
               Expr_app(Prim_foreach, [Expr_var x; e2]) ]))
         | _ -> bad_arguments() 
         end

      | Prim_foreach ->
         begin match es with 
         | [e1;e2] -> 
            let x = gen_variable() in
            r (Expr_app (Prim_iter, [Expr_var x; e1; Expr_app(Prim_in, [Expr_var x; e2]) ]))
         | _ -> bad_arguments() 
         end
         
      | Prim_select -> failwith "todo"
      | Prim_graphby -> failwith "todo"
      | Prim_curveby -> failwith "todo"


let exec expr =
   msg (print_value (run init_env code))

end 

let mode_custom add_graph args results =
   let expr = Custom.parse (unsome_or_failwith "custom none" args.custom) in
   Custom.exec expr

