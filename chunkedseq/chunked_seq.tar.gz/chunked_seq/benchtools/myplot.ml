open Shared
open Benchmark
open Printf
open Results
open Custom
open Myplot_funcs
      
let _ =
   parse_plot_options();
   let mode = Cmdline.parse_or_default_string "mode" "default" in
   let ignores = Cmdline.parse_or_default_list_string "ignore" [] in
   let results = read_results_from_input_file() in
   let results = list_map results (fun (data,inputs) ->
      let data' = list_filter data (fun (k,v) -> not (List.mem k ignores)) in
      let inputs' = list_substract inputs ignores in
      (data',inputs')
      ) in
   let bykey = Cmdline.parse_or_default_string "by" "nokey" in
   let charts = create_charts mode results bykey in
   pdf_of_charts charts;
   if Cmdline.mem_flag "open" 
      then ignore (system (sprintf "evince %s &" !arg_plot_output))
