/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file benchmark.hpp
 *
 */

#ifndef _PASL_BENCHMARK_H_
#define _PASL_BENCHMARK_H_

#include "cmdline.hpp"
#include "threaddag.hpp"
#include "native.hpp"

namespace pasl {
namespace sched {

/***********************************************************************/
  
template <class Body>
void launch(const Body& body) {
  threaddag::launch(native::new_multishot_by_lambda([&] { body(); }));
}

template <class Init, class Run, class Output, class Destroy>
void launch(const Init& init, const Run& run, const Output& output,
            const Destroy& destroy) {
  bool sequential = (util::cmdline::parse_or_default_int("proc", 1) == 0);
  bool report_time = util::cmdline::parse_or_default_bool("report_time", true);
#ifdef NUMA_ALLOC
  numa_set_interleave_mask(numa_all_nodes_ptr);
#endif
  //LATER: if (! sequential)
  threaddag::init();
  launch(init);
#ifdef NUMA_ALLOC
  numa_set_interleave_mask(numa_no_nodes_ptr);
#endif
  uint64_t start_time = util::microtime::now();
  launch([&] { run(sequential); });
  double exec_time = util::microtime::seconds_since(start_time);
  if (report_time)
    printf ("exectime %lf\n", exec_time);
  STAT_IDLE(sum());
  STAT(dump(stdout));
  STAT_IDLE(print_idle(stdout));
#ifdef SEQUENTIAL_ELISION
  std::cout << "sequential_elision\t1" << std::endl;
#endif
  launch(output);
  launch(destroy);
  threaddag::destroy();
}

template <class Init, class Run, class Output, class Destroy>
void launch(int argc, char** argv,
            const Init& init, const Run& run, const Output& output,
            const Destroy& destroy) {
  util::cmdline::set(argc, argv);
  launch(init, run, output, destroy);
}

/***********************************************************************/

} // end namespace
} // end namespace

      
#endif /*! _PASL_BENCHMARK_H_ */