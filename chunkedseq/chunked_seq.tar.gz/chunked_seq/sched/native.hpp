/* COPYRIGHT (c) 2011 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file multishot.hpp
 * \brief Defines the interface for multi-shot threads.
 *
 */

#ifndef _PASL_NATIVE_H_
#define _PASL_NATIVE_H_

#include <utility>

#include "thread.hpp"
#include "threaddag.hpp"
#include "control.hpp"

namespace pasl {
namespace sched {
namespace native {
  
/***********************************************************************/
  
/*---------------------------------------------------------------------*/
  
namespace ucxt = util::control;

class multishot : public thread {
public:
  
  typedef multishot* multishot_p;
  
protected:
  
  typedef ucxt::context_type context_type;
  
  static multishot* ONE() {
    return (multishot*)0x1;
  };
  
  //! pointer to the call stack
  char* stack;
  
  context_type cxt;
  
  char* parent_stack;

  void jump_to_scheduler() {
    ucxt::swap(ucxt::addr(cxt), ucxt::my_cxt(), ONE());
  }
  
  void prepare() {
    threaddag::reuse_calling_thread();
  }
  
  void prepare_and_jump_to_scheduler() {
    prepare();
    jump_to_scheduler();
  }
  

public:
  
  multishot()
  : thread(), stack(NULL)  {
    parent_stack = (char*)0x1;
  }
  
  ~multishot() {
    if (stack == NULL || stack == parent_stack)
      return;
    free(stack);
    stack = NULL;
  }
  
  virtual void run() = 0;
  
  void yield() {
    threaddag::continue_with(this);
    prepare_and_jump_to_scheduler();
  }

  void jump_to_thread() {
    ucxt::swap(ucxt::my_cxt(), ucxt::addr(cxt), this);
  }
  
  void exec() {
    if (stack == NULL)
      stack = ucxt::spawn(ucxt::addr(cxt), this);
    jump_to_thread();
  }
  
  static void enter(multishot* t) {
    t->run();
    ucxt::throw_to(ucxt::my_cxt(), ONE());
  }
  
  void async(multishot_p thread, multishot_p join) {
    threaddag::fork(thread, join);
    yield();
  }
  
  void finish(multishot_p thread) {
    instrategy::distributed* dist = new instrategy::distributed(this);
    threaddag::unary_fork_join(thread, this, dist);
    prepare_and_jump_to_scheduler();
  }
  
  void fork2(multishot_p thread0, multishot_p thread1) {
    prepare();
    threaddag::binary_fork_join(thread0, thread1, this);
    if (ucxt::capture<multishot*>(ucxt::addr(cxt)))
      return;
    scheduler_p sched = threaddag::my_sched();
    multishot_p t = thread0;
    while (t != NULL) {
      if (! sched->try_del_thread(t))
        break;
      t->stack = parent_stack;
      t->in = instrategy::ready_new();
      sched->add_thread(t);
      t->jump_to_scheduler();
      t->run();
      t = (t == thread0) ? thread1 : NULL;
      if (t == thread1) {
        LOG_THREAD(THREAD_EXEC, t);
        STAT_COUNT(THREAD_EXEC);
      }
    }
    jump_to_scheduler();
  }
  
};

template <class Function>
class multishot_by_lambda : public multishot {
private:
  Function f;
  
public:
  
  multishot_by_lambda(const Function& f) : f(f) { }
  
  void run() {
    f();
  }
  
  THREAD_COST_UNKNOWN
};
  
template <class Function>
multishot_by_lambda<Function>* new_multishot_by_lambda(const Function& f) {
  return new multishot_by_lambda<Function>(f);
}

static inline multishot* my_thread() {
  multishot* t = (multishot*)threaddag::my_sched()->get_current_thread();
  assert(t != NULL);
  return t;
}
  
// todo
static inline int my_deque_size() {
  return 60;
}
  
/*---------------------------------------------------------------------*/
      
template <class Exp1, class Exp2>
void fork2(const Exp1& exp1, const Exp2& exp2) {
#ifndef SEQUENTIAL_ELISION
  my_thread()->fork2(new_multishot_by_lambda(exp1),
                     new_multishot_by_lambda(exp2));
#else
  exp1();
  exp2();
#endif
}

template <class Body>
void async(const Body& body, multishot* join) {
  multishot* thread = new_multishot_by_lambda(body);
  my_thread()->async(thread, join);
}

template <class Body>
void finish(const Body& body) {
  multishot* join = my_thread();
  multishot* thread = new_multishot_by_lambda([&] { body(join); });
  join->finish(thread);
}

template <class Input, class Input_env, class Is_done, class Fork_input,
class Should_fork, class Body>
void _parallel_while(Input& in, const Input_env& in_env,
                     const Is_done& is_done, const Fork_input& fork_in,
                     const Should_fork& should_fork, multishot* join,
                     const Body& body) {
  while (! is_done(in)) {
    if (should_fork()) {
      Input* in2 = new Input(in_env);
      fork_in(in, *in2);
      async([&] { _parallel_while(*in2, in_env, is_done, fork_in, should_fork, join, body); }, join);
      continue;
    }
    body(in);
  }
  delete &in;
}
  
  template <class Input>
  class parallel_while_state {
  public:

    enum {
      PROCESSING, SIZE_REQUEST, SPLIT_REQUEST
    } state;
    Input data;
    int64_t size;
    
    
    
  };
  
  template <class Input, class Is_done, class Fork_input, class Body>
  void myparallel_while(const Is_done& is_done, const Fork_input& fork_in,
                        parallel_while_state<Input>* state,
                        multishot* join,
                        const Body& body) {
    multishot* thread = my_thread();
    Input in;
    in.swap(state->data);
    while (! is_done(in)) {
      switch (state->state) {
        case parallel_while_state<Input>::PROCESSING: {
          body(in);
          break;
        }
        case parallel_while_state<Input>::SIZE_REQUEST: {
          state->size = int64_t(in.size());
          break;
        }
        case parallel_while_state<Input>::SPLIT_REQUEST: {
          fork_in(in, state->data);
          break;
        }
      };
      thread->yield();
    }
  }

template <class Input, class Input_env, class Is_done, class Fork_input,
class Should_fork, class Body>
void parallel_while(Input& in, const Input_env& in_env,
                    const Is_done& is_done, const Fork_input& fork_in,
                    const Should_fork& should_fork, const Body& body) {
  finish([&] (multishot* join) {
    _parallel_while(in, in_env, is_done, fork_in, should_fork, join, body);
  });
}

template <class Input, class Input_env, class Is_done, class Fork_input,  class Body>
void parallel_while(Input& in, const Input_env& in_env,
                    const Is_done& is_done,  const Fork_input& fork_in,
                    const Body& body) {
  auto should_fork = [] {
    return false;
  };
  parallel_while(in, in_env, is_done, fork_in, should_fork, body);
}

// later: find a clean way to eliminate the code duplication below
template <class Input, class Output,
class Cutoff, class Fork_input, class Join_output,
class Body>
void reduce(Input& in, Output& out,
            const Cutoff& cutoff, const Fork_input& fork, const Join_output& join,
            const Body& body) {
  if (cutoff(in)) {
    body(in, out);
  } else {
    Input in2;
    Output out2;
    fork(in, in2);
    fork2([&] { reduce(in,  out,  cutoff, fork, join, body); },
          [&] { reduce(in2, out2, cutoff, fork, join, body); });
    join(out, out2);
  }
}

template <class Input, class Output, class Input_env, class Output_env,
class Cutoff, class Fork_input, class Join_output,
class Body>
void reduce(Input& in, Output& out, const Input_env& in_env, const Output_env& out_env,
            const Cutoff& cutoff, const Fork_input& fork, const Join_output& join,
            const Body& body) {
  if (cutoff(in)) {
    body(in, out);
  } else {
    Input in2(in_env);
    Output out2(out_env);
    fork(in, in2);
    fork2([&] { reduce(in,  out,  in_env, out_env, cutoff, fork, join, body); },
          [&] { reduce(in2, out2, in_env, out_env, cutoff, fork, join, body); });
    join(out, out2);
  }
}

extern int loop_cutoff;

template <class Number, class Output, class Join_output, class Body, class Cutoff>
void tabulate(Number lo, Number hi, Output& out, const Join_output& join,
              const Body& body, const Cutoff& cutoff) {
  using range_type = std::pair<Number, Number>;
  range_type in(lo, hi);
  auto fork = [] (range_type& src, range_type& dst) {
    Number mid = (src.first + src.second) / 2;
    dst.first = mid;
    dst.second = src.second;
    src.second = mid;
  };
  auto _body = [&body] (range_type r, Output& out) {
    Number lo = r.first;
    Number hi = r.second;
    for (; lo < hi; lo++)
      body(lo, out);
  };
  reduce(in, out, cutoff, fork, join, _body);
}

template <class Number, class Output, class Join_output, class Body>
void tabulate(Number lo, Number hi, Output& out, const Join_output& join,
              const Body& body) {
  using range_type = std::pair<Number, Number>;
  auto cutoff = [] (range_type r) {
    return r.second - r.first <= loop_cutoff;
  };
  tabulate(lo, hi, out, join, body, cutoff);
}

template <class Number, class Body>
void parallel_for(Number lo, Number hi, const Body& body) {
#ifndef SEQUENTIAL_ELISION
  struct { } output;
  using output_type = typeof(output);
  auto join = [] (output_type,output_type) { };
  auto _body = [&body] (Number i, output_type) {
    body(i);
  };
  tabulate(lo, hi, output, join, _body);
#else
  for ( ; lo < hi; lo++)
    body(lo);
#endif
}

template <class Number, class Body>
void parallel_for1(Number lo, Number hi, const Body& body) {
#ifndef SEQUENTIAL_ELISION
  struct { } output;
  using range_type = std::pair<Number, Number>;
  auto cutoff = [] (range_type r) {
    return r.second - r.first <= 2;
  };
  using output_type = typeof(output);
  auto join = [] (output_type,output_type) { };
  auto _body = [&body] (Number i, output_type) {
    body(i);
  };
  tabulate(lo, hi, output, join, _body, cutoff);
#else
  for ( ; lo < hi; lo++)
    body(lo);
#endif
}
  
/***********************************************************************/


} // end namespace
} // end namespace
} // end namespace

#endif //! _PASL_NATIVE_H_
