/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Associative container built on top of fftree
 * \file fftmap.hpp
 * \example fftmap.hpp
 * \ingroup fftree
 *
 */

#ifndef _PASL_DATA_FFTMAP_H_
#define _PASL_DATA_FFTMAP_H_

#include <iostream>
#include <fstream>
#include <map>

#include "fftree.hpp"

namespace pasl {
namespace data {

/***********************************************************************/

/*---------------------------------------------------------------------*/
//! [option]
template <class Item, class Item_swap>
class option {
public:
  
  Item item;
  bool no_item;
  
  option()
  : item(), no_item(true) { }
  
  option(const Item& item)
  : item(item), no_item(false) { }
  
  option(const option& other)
  : item(other.item), no_item(other.no_item) { }
  
  void swap(option& other) {
    Item_swap::swap(item, other.item);
    std::swap(no_item, other.no_item);
  }
  
  bool operator<(const option& y) const {
    if (no_item && y.no_item)
      return false;
    if (no_item)
      return true;
    if (y.no_item)
      return false;
    return item < y.item;
  }
  
};
//! [option]
  
/*---------------------------------------------------------------------*/
//! [second]
template <class Option>
class second {
public:
  
  typedef Option value_type;
  
  static constexpr bool is_group = false;
  
  static void reduce(value_type* left, const value_type* right) {
    if (right->no_item)
      return;
    new (left) value_type(*right);
  }
  
  static void identity(value_type* p) {
    new (p) value_type();
  }
  
  static void inverse(value_type* p) {
    assert(false);
  }
  
};
//! [second]
  
/*---------------------------------------------------------------------*/
//! [map_cache]
template <class Vector, class Size, class Key_swap>
class map_cache {
public:
  
  typedef Size size_type;
  typedef typename Vector::value_type value_type;
  typedef typename value_type::first_type key_type;
  typedef option<key_type, Key_swap> option_type;
  typedef second<option_type> algebra_type;
  typedef typename algebra_type::value_type measured_type;
  
  class measure_type {
  public:
    
    void operator()(const value_type& v, measured_type& dst) const {
      key_type k = v.first;
      new (&dst) measured_type(k);
    }

    void operator()(const value_type* lo, const value_type* hi,
                    measured_type& dst) const {
      if (hi - lo == 0) {
        dst = option_type();
        return;
      }
      const value_type* last = hi - 1;
      key_type k = last->first;
      new (&dst) measured_type(k);
    }
    
  };
  
  static void swap(measured_type& m1, measured_type& m2) {
    m1.swap(m2);
  }
  
};
//! [map_cache]
  
/*---------------------------------------------------------------------*/
//! [utils]
template <class Item>
class std_swap {
public:
  
  static void swap(Item& x, Item& y) {
    std::swap(x, y);
  }
  
};
  
template <class Item, class Measured>
class default_printer {
public:
  
  static std::string string_of_item(const Item& item) {
    return "...";
  }
  
  static std::string string_of_cached(const Measured& cached) {
    return "...";
  }
  
};
//! [utils]
  
/*---------------------------------------------------------------------*/
/* Associative map with STL-style interface */
  
//! [fftmap]
template <class Key,
          class Item,
          class Compare = std::less<Key>,
          class Key_swap = std_swap<Key>,
          class Alloc = std::allocator<std::pair<const Key, Item> >,
          class Printer = default_printer<Key, Item> >
class fftmap {
public:
  
  typedef Key key_type;
  typedef Key_swap key_swap_type;
  typedef Item mapped_type;
  typedef std::pair< Key, Item> value_type;
  typedef Compare key_compare;
  //todo value_compare
  typedef Alloc allocator_type;
  typedef typename allocator_type::reference reference;
  typedef typename allocator_type::const_reference const_reference;
  typedef typename allocator_type::pointer pointer;
  typedef typename allocator_type::const_pointer const_pointer;
  //todo iterator const_iterator
  //todo reverse_iterator const_reverse_iterator
  //  typedef typename std::iterator_traits<iterator>::difference_type difference_type;
  typedef int difference_type;
  typedef size_t size_type;
  typedef Printer printer_type;
  
private:
  
  static constexpr int vector_capacity = 8;
  typedef fixedcapacity::heap_allocator<value_type, vector_capacity> array_allocator_type;
  typedef fixedcapacity::stack<array_allocator_type> vector_type;
  typedef map_cache<vector_type, size_type, key_swap_type> cache_type;
  typedef typename cache_type::measured_type option_type;
  typedef fftree_base::deque_with_size_plus<cache_type, vector_type, 4> fftree_config_type;
  typedef fftree_base::fftree<fftree_config_type> fftree_type;
  typedef typename fftree_type::iterator iterator;
  
  class option_compare {
  public:
    bool operator()(const option_type& x, const option_type& y) const {
      return x < y;
    }
  };
  
  mutable fftree_type fft;
  option_compare comp;
  mutable iterator it;
  
public:
  
  fftmap() {
    it = fft.begin();
  }
  
  size_type size() const {
    return fft.size();
  }
  
  void find(const key_type& k) const {
    option_type opt(k);
    auto c = [&] (const option_type& key) {
      return ! comp(opt, key);
    };
    it.search_by(c);
  }
  
  mapped_type& operator[](const key_type& k) const {
    find(k);
    if (it == fft.end() || (*it).first != k) {
      value_type val;
      val.first = k;
      it = fft.insert(it, val);
    }
    return (*it).second;
  }
  
  std::ostream& stream(std::ostream& out) {
    out << "[";
    for (auto it = fft.begin(); it != fft.end(); it++)
      if (it == fft.end() - 1)
        out << "(" << (*it).first << "," << (*it).second << ")";
      else
        out << "(" << (*it).first << "," << (*it).second << ")" <<  ", ";
    return out << "]";
  }
  
  void graphviz(std::string fname) {
    debug::output_graphviz<fftree_type, printer_type>(fname, fft);
  }
  
};
//! [fftmap]
  
/*---------------------------------------------------------------------*/

template <class Item, class Item_swap>
std::ostream& operator<<(std::ostream& out, option<Item, Item_swap>& opt) {
  Item val;
  if (opt.no_item)
    val = -1;
  else
    val = opt.item;
  return out << val;
}

template <class Key, class Item>
class prim_printer {
public:
  
  static std::string string_of_item(const std::pair<int, int>& item) {
    return std::to_string(item.first);
  }
  
  static std::string string_of_cached(const pasl::data::option<int, pasl::data::std_swap<int>>& cached) {
    if (cached.no_item)
      return "";
    return std::to_string(cached.item);
  }
  
};

template <class Key,
class Item,
class Compare,
class Key_swap,
class Alloc,
class Printer>
std::ostream& operator<<(std::ostream& out,  fftmap<Key, Item, Compare, Key_swap, Alloc, Printer>& xs) {
  return xs.stream(out);
}

/***********************************************************************/

}
}

#endif /*! _PASL_DATA_FFTMAP_H_ */
