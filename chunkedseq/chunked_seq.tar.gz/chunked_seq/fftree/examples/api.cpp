//! [api]
#include <iostream>
#include <random>
#include "fftree.hpp"

using namespace pasl::data;

template <class Item>
using myringbuffer = fixedcapacity::ringbuffer_idx<Item, 512>;

template <class Item>
using myfftree =
  fftree_base::fftree<
       fftree_base::deque_with_just_size<myringbuffer<Item>, size_t> >;

int main(int argc, const char * argv[]) {
  myfftree<int> fft;
  for (int i = 0; i < 1000000; i++)
    fft.push_back(i);
  for (int i = 0; i < 5000; i++) {
    size_t pos = rand() % fft.size();
    fft.insert(fft.begin() + pos, i);
  }
  std::cout << fft.size() << std::endl; // prints 1005000
  return 0;
}
//! [api]
