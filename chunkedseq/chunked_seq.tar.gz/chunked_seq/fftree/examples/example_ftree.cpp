/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Finger tree example
 * \file ftree.cpp
 * \example ftree.cpp
 * \ingroup ftree
 *
 */

#include <iostream>
#include "ftree.hpp"

using namespace pasl::data;

//! [ftree_example]
int main(int argc, const char * argv[]) {
  //! \todo write example
  return 0;
}
//! [ftree_example]

