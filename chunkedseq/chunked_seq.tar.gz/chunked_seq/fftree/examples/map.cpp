

#include "fftmap.hpp"


typedef pasl::data::fftmap<int, int, std::less<int>, pasl::data::std_swap<int>, std::allocator<std::pair<const int, int> >, pasl::data::prim_printer<int, int> > map_type;

int cnt = 0;
void dumpit(map_type& mp) {
  std::string fname = "/Users/rainey/Scratch/foo" + std::to_string(cnt++) + ".gv";
  mp.graphviz(fname);
}

int main(int argc, const char * argv[])
{
  
  map_type mp;
  

  int nb = 100;
  int key_range = 10 * nb;
  int val_range = 100 * key_range;
  for (int i = 0; i < nb; i++) {
    int k = rand() % key_range;
    int v = rand() % val_range;
    mp[k] = v;
  }
  dumpit(mp);
  
  return 0;
  
  int xxx = 3;
  mp[xxx] = 33;
  dumpit(mp);

  std::cout << mp << std::endl;
  mp[8] = 88;
  dumpit(mp);

  std::cout << mp << std::endl;
  mp[5] = 55;
  dumpit(mp);

  std::cout << mp << std::endl;
  mp[1] = 11;
  dumpit(mp);

  std::cout << mp << std::endl;
  mp[14] = 110;
  std::cout << mp << std::endl;
  mp[10] = 144;
  std::cout << mp << std::endl;
  mp[0] = 66;
  std::cout << mp << std::endl;
  mp[33] = 33;
  std::cout << mp << std::endl;
  mp[12] = 4444;
  std::cout << mp << std::endl;
  dumpit(mp);

  mp[6] = 3;
  std::cout << mp << std::endl;
  dumpit(mp);
  



  printf("mp[%d]=%d\n",3,mp[3]);
  std::cout << mp << std::endl;
  
  printf("mp[%d]=%d\n",8,mp[8]);
  std::cout << mp << std::endl;
  
  mp[6] = 66;

  printf("mp[%d]=%d\n",5,mp[5]);
  std::cout << mp << std::endl;
  
  printf("mp[%d]=%d\n",6,mp[6]);
  std::cout << mp << std::endl;


    return 0;
}

