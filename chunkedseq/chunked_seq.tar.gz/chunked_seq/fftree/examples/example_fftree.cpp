/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Fast finger tree example
 * \file fftree.cpp
 * \example fftree.cpp
 * \ingroup fftree
 *
 */

#include <iostream>

#include "fftree.hpp"

using namespace pasl::data;

//! \todo give one example call for each method of fftree
//! [fftree_example]
static const int leaf_capacity = 16;

template <class Item>
using myringbuffer = fixedcapacity::ringbuffer_idx<Item, leaf_capacity>;

template <class Item>
using myfftree =
  fftree_base::fftree<fftree_base::deque_with_just_size<myringbuffer<Item>, size_t> >;

int main(int argc, const char * argv[]) {
  myfftree<int> fft;
  int n = 30;
  for (int i = 0; i < n; i++) {
    if (i <= n)
      assert(fft.size() == i);
    fft.push_back(i);
  }
  for (auto it = fft.begin(); it != fft.end(); it++)
    printf("it[%d]=%d ",(int)it.size(),*it);
  printf("\n");
  return 0;
}
//! [fftree_example]

