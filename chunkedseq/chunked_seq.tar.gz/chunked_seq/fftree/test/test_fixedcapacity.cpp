/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Unit tests for fixed-capacity buffers
 * \file fixedcapacity.cpp
 *
 */

#include <iostream>

#include "properties.hpp"

using namespace quickcheck;
using namespace pasl::data;

static int nb_tests = 1000;

using alloc = pasl::data::fixedcapacity::heap_allocator<int, 4>;
typedef pasl::data::fixedcapacity::ringbuffer_ptrx<alloc> ringbuffer_t;
typedef pasl::data::fixedcapacity::stack<alloc> mystack_t;
typedef fixedcapacity_properties<ringbuffer_t, std::deque<int> > ringbuffer_properties;
typedef fixedcapacity_properties<mystack_t, std::deque<int> > stack_properties;

template <class properties>
void doit() {
  
  std::cout << "for_each_segment" << std::endl;
  typename properties::for_each_segment foreach;
  foreach.check(nb_tests);

  
  return;
  
  std::cout << "segment_index_cancels" << std::endl;
  typename properties::segment_index_cancels seg;
  seg.check(nb_tests);
 
  std::cout << "push_pop" << std::endl;
  typename properties::push_pop_same push_pop;
  push_pop.check(nb_tests);

  std::cout << "front_to_back" << std::endl;
  typename properties::transfer_front_to_back_same front_to_back;
  front_to_back.check(nb_tests);
  
  std::cout << "back_to_front" << std::endl;
  typename properties::transfer_back_to_front_same back_to_front;
  back_to_front.check(nb_tests);


  
  std::cout << "pushn" << std::endl;
  typename properties::pushn pushn;
  pushn.check(nb_tests);

  std::cout << "pushn3" << std::endl;
  typename properties::pushn3 pushn3;
  pushn3.check(nb_tests);

  std::cout << "pushn2" << std::endl;
  typename properties::pushn2 pushn2;
  pushn2.check(nb_tests);

  std::cout << "popn" << std::endl;
  typename properties::popn popn;
  popn.check(nb_tests);

  printf("All done\n");
 
  return;
}

int main(int argc, const char * argv[]) {
  
  doit<ringbuffer_properties>();
  //doit<stack_properties>();
  
  return 0;
}


