/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Unit tests for finger tree
 * \file ftree.cpp
 *
 */

#include "properties.hpp"

using namespace quickcheck;
using namespace pasl::data;

/***********************************************************************/

static const int nb_tests = 3000;

int main() {
  
  typedef ftree_properties<tftree<int>, std::deque<int> > properties;
  
  /*
  tftree<int> ft;
  ft.push_front(1);
  ft.push_front(2);
  ft.push_front(3);
  tftree<int> ft2(ft);
  ft2.pop_front();

  std::cout << ft << std::endl;
  std::cout << ft2 << std::endl;

  
  return 0; */
  
  typename properties::push_pop_same push_pop;
  push_pop.check(nb_tests);
  
  typename properties::random_access_same random;
  random.check(nb_tests);
  
  typename properties::split_same split;
  split.check(nb_tests);


  typename properties::insert_same insert;
  insert.check(nb_tests);


  typename properties::append_same append;
  append.check(nb_tests);
  
  printf("All done\n");
  
  return 0;
}

/***********************************************************************/
