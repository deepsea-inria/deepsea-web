/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Unit tests
 * \file properties.hpp
 *
 */

#ifndef _PASL_FTREE_PROPERTIES_H_
#define _PASL_FTREE_PROPERTIES_H_

#include <deque>
#include <algorithm>

#include "generators.hpp"

namespace pasl {
namespace data {

/***********************************************************************/
  
/*---------------------------------------------------------------------*/

template <class Container2, class value_type>
void pushn_back_container2(Container2& c, const value_type* xs, int nb) {
  for (int i = 0; i < nb; i++)
    c.push_back(xs[i]);
}

template <class Container2, class value_type>
void pushn_front_container2(Container2& c, const value_type* xs, int nb) {
  for (int i = 0; i < nb; i++)
    c.push_front(xs[nb - i - 1]);
}

template <class Container2, class value_type>
void popn_back_container2(Container2& c, value_type* dst, int nb) {
  for (int i = 0; i < nb; i++) {
    dst[nb - i - 1] = c.back();
    c.pop_back();
  }
}

template <class Container2, class value_type>
void popn_front_container2(Container2& c, value_type* dst, int nb) {
  for (int i = 0; i < nb; i++) {
    dst[i] = c.front();
    c.pop_front();
  }
}

template <class value_type>
bool same_array(int nb, const value_type* a1, const value_type* a2) {
  for (int i = 0; i < nb; i++)
    if (a1[i] != a2[i])
      return false;
  return true;
}
  
template <class value_type>
void print_array(value_type* array, int nb) {
  for (int i = 0; i < nb; i++)
    printf("a[%d]=%d\t\t",i,array[i]);
  printf("\n");
}
  
/*---------------------------------------------------------------------*/
/* Properties for testing fast finger trees */

/* assumes that Container1 is ftree (untrusted) and Container2 is
 * trusted (e.g., std::deque)
 */
template <class Container1, class Container2>
class ftree_properties {
public:
  
  typedef Container1 container1_type;
  typedef container_pair<Container1, Container2> container_pair_t;
  typedef typename container_pair_t::value_type value_type;
  
  class random_access_same : public quickcheck::Property<size_t, container_pair_t> {
  public:
    int nb = 0;
    bool holdsFor(const size_t& _i, const container_pair_t& _xs) {
      nb++;
      /*
      if (nb == 165)
        std::cout << "error" << std::endl;
       */
      if (_xs.size() == 0)
        return true;
      container_pair_t xs(_xs);
      size_t i = _i % xs.size();
      auto x = xs.container1[i];
      return x == xs.container2[i];
    }
  };
  
  class push_pop_same : public quickcheck::Property<value_type, container_pair_t> {
  public:
    bool holdsFor(const value_type& x, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      if (! _xs.same()) {
        return _xs.same();
      }
      if (! xs.same()) {
        std::cout << _xs << std::endl;
        std::cout << xs << std::endl;
        return xs.same();
      }
      size_t which_end;
      quickcheck::generate(1, which_end);
      size_t whether_push_or_pop;
      quickcheck::generate(1, whether_push_or_pop);
      if (which_end == 0) {
        if (whether_push_or_pop == 0) {
          xs.container1.push_back(x);
          xs.container2.push_back(x);
        } else {
          if (xs.size() != 0) {
            if (xs.container1.back() != xs.container2.back())
              return false;
            xs.container1.pop_back();
            xs.container2.pop_back();
          }
        }
      } else {
        if (whether_push_or_pop == 0) {
          xs.container1.push_front(x);
          xs.container2.push_front(x);
        } else {
          if (xs.size() != 0) {
            if (xs.container1.back() != xs.container2.back())
              return false;
            xs.container1.pop_back();
            xs.container2.pop_back();
          }
        }
      }
      if (! xs.same()) {
        int sz1 = (int)xs.container1.size();
        int sz2 = (int)xs.container2.size();
        std::cout << xs << " " << sz1 << " " << sz2 << std::endl;
        return xs.same();
      }
      return true;
    }
  };
  
  class pushn_same : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t nb = _nb % 2048;
      value_type vs[nb];
      for (int i = 0; i < nb; i++)
        quickcheck::generate(2048, vs[i]);
      size_t which_end;
      quickcheck::generate(1, which_end);
      if (which_end == 0) {
        xs.container1.pushn_front(vs, nb);
        pushn_front_container2(xs.container2, vs, (int)nb);
      } else {
        xs.container1.pushn_back(vs, nb);
        pushn_back_container2(xs.container2, vs, (int)nb);
      }
      if (! xs.same()) {
        std::cout << xs << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class popn_same : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t sz = xs.container1.size();
      assert(sz == xs.container2.size());
      if (sz == 0)
        return true;
      size_t nb = _nb % sz;
      value_type vs1[nb];
      value_type vs2[nb];
      size_t which_end;
      quickcheck::generate(1, which_end);
      if (which_end == 0) {
        xs.container1.popn_front(vs1, nb);
        popn_front_container2(xs.container2, vs2, (int)nb);
      } else {
        xs.container1.popn_back(vs1, nb);
        popn_back_container2(xs.container2, vs2, (int)nb);
      }
      if (! xs.same()) {
        std::cout << xs.container1 << "\n" << xs.container2 << std::endl;
        return false;
      }
      if (! same_array((int)nb, vs1, vs2)) {
        print_array(vs1, (int)nb);
        print_array(vs2, (int)nb);
        return false;
      }
      return true;
    }
  };
  
  class pushn_tab : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t nb = _nb;
      if (xs.container1.size() == 0)
        return true;
      int maxn = xs.container1.size();
      nb = nb % maxn;
      xs.container1.clear();
      xs.container2.clear();
      value_type* vs = new value_type[nb];
      for (int i = 0; i < nb; i++) {
        value_type x;
        quickcheck::generate(1<<30, x);
        vs[i] = x;
      }
      auto body = [&] (size_t i, int& v) {
        v = vs[i];
      };
      typedef typename container_pair_t::container1_type::allocator_type alloc;
      xs.container1.pushn_back(body, (int)nb);
      pushn_back_container2(xs.container2, vs, (int)nb);
      delete [] vs;
      if (xs.container1.size() != xs.container2.size())
        return false;
      if (! xs.same()) {
        std::cout << xs.container1 << "\n" << xs.container2 << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class pushn_const : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t nb = _nb;
      if (xs.container1.size() == 0)
        return true;
      int maxn = (size_t)xs.container1.size();
      nb = nb % maxn;
      value_type val = 1234;
//      quickcheck::generate(1<<30, val);
      value_type* vs = new value_type[nb];
      for (int i = 0; i < nb; i++) {
        vs[i] = val;
      }
      typedef typename container_pair_t::container1_type::allocator_type alloc;
      xs.container1.pushn_back(val, (int)nb);
      pushn_back_container2(xs.container2, vs, (int)nb);
      delete [] vs;
      if (! xs.same()) {
        std::cout << xs.container1 << "\n" << xs.container2 << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class backn : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      using size_type = typename Container1::size_type;
      if (xs.container1.size() == 0)
        return true;
      size_type nb = size_type(_nb) % xs.container1.size();
      value_type array[nb];
      xs.container1.backn(array, nb);
      xs.container1.popn_back(nb);
      xs.container1.pushn_back(array, nb);
      if (_xs.container1 != xs.container1) {
        std::cout << _xs.container1 << std::endl;
        std::cout << xs.container1 << std::endl;
        std::cout << _xs.container1.size() << std::endl;
        std::cout << xs.container1.size() << std::endl;
        std::cout << (_xs.container1 != xs.container1) << std::endl;

        return false;
      }
      return true;
    }
  };
  
  class frontn : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      using size_type = typename Container1::size_type;
      if (xs.container1.size() == 0)
        return true;
      size_type nb = size_type(_nb) % xs.container1.size();
      value_type array[nb];
      xs.container1.frontn(array, nb);
      xs.container1.popn_front(nb);
      xs.container1.pushn_front(array, nb);
      if (_xs.container1 != xs.container1) {
        std::cout << _xs.container1 << std::endl;
        std::cout << xs.container1 << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class append_same : public quickcheck::Property<container_pair_t, container_pair_t> {
  public:
    bool holdsFor(const container_pair_t& _xs, const container_pair_t& _ys) {
      container_pair_t xs(_xs);
      container_pair_t ys(_ys);
      xs.container1.transfer_to_back(ys.container1);
      copy_to2(ys.container2, xs.container2);
      ys.container2.clear();
      if (ys.container1.size() != 0)
        return false;
      if (! xs.same()) {
        std::cout << "begin append" << std::endl;
        std::cout << _xs.container1 << std::endl;
        std::cout << _ys.container1 << std::endl;
        std::cout << _xs.container2 << std::endl;
        std::cout << _ys.container2 << std::endl;
        
        std::cout << "fftree  " << xs.container1 << std::endl;
        std::cout << "deque   " << xs.container2 << std::endl;
        std::cout << "end append" << std::endl;
        return false;
        
      }
      if (! ys.same())
        return false;
      return true;
    }
  };
  
  class split_same : public quickcheck::Property<size_t, container_pair_t> {
  public:
    int nb = 0;
    bool holdsFor(const size_t& _i, const container_pair_t& _xs) {
      nb++;
      /*
      if (nb == 165)
        std::cout << "error" << std::endl;
       */
      if (_xs.size() == 0)
        return true;;
      container_pair_t xs(_xs);
      size_t i = _i % xs.size();
      size_t sz1 = i;
      Container1 tmp;
      auto it = xs.container1.begin() + i;
      xs.container1.transfer_from_back_to_front_by_position(tmp, it);
      if (xs.container1.size() != sz1) {
        std::cout << "actual=" << xs.container1.size() << " target=" << sz1 << std::endl;
        std::cout << _xs.container1 << std::endl;
        std::cout << xs.container1 << std::endl;
        std::cout << tmp << std::endl;
        return false;
      }
      if (tmp.size() != _xs.size() - sz1) {
        std::cout << tmp.size() << " " << _xs.size() << " " << sz1 << " " << _xs.size() - sz1 << std::endl;

        return false;
      }
      if (xs.container1.size() + tmp.size() != _xs.size())
        return false;
      Container2 c2;
      copy_to(xs.container1, c2);
      copy_to(tmp, c2);
      if (xs.container2 != c2) {
        std::cout << _xs.container1 << std::endl;
        std::cout << _xs.container2 << std::endl;
        std::cout << c2 << "\n c2" << std::endl;
        std::cout << xs.container2 << "\n xs.contaier2" << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class insert_same : public quickcheck::Property<size_t, value_type, container_pair_t> {
  public:
    int nb = 0;
    bool holdsFor(const size_t& _i, const value_type& v, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      nb++;
      if (nb == 4)
        std::cout << "" << std::endl;
      size_t i = (xs.size() == 0) ? 0 : _i % xs.size();
      auto it1 = xs.container1.insert(xs.container1.begin() + i, v);
      auto it2 = xs.container2.insert(xs.container2.begin() + i, v);
      if (!xs.same()) {
        std::cout << xs << std::endl;
        return false;
      }
      value_type x1 = *it1;
      value_type x2 = *it2;
      size_t s1 = it1.size();
      size_t s2 = it2 - xs.container2.begin() + 1;
      if (s1 != s2) {
        return false;
      }
      if (x1 != x2) {
        std::cout << _xs.container1 << std::endl;
        std::cout << xs.container1 << std::endl;
        std::cout << xs.container2 << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class foreach : public quickcheck::Property<container_pair_t> {
  public:
    bool holdsFor(const container_pair_t& _xs) {

      container_pair_t xs(_xs);
      xs.container1.for_each([] (size_t i, int& x) {
        x = (int)i;
        //std::cout << x << " " ;
      });
      //std::cout << std::endl;
    
      int i = 0;
      auto it2 = xs.container2.begin();
      for (; it2 != xs.container2.end(); it2++) {
        *it2 = i;
        i++;
      }
      
      //std::cout << xs.container2 << std::endl;
      
      if (! xs.same()) {
        std::cout << xs << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class foreach2 : public quickcheck::Property<size_t, size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _beg, const size_t& _end, const container_pair_t& _xs) {
      
      container_pair_t xs(_xs);
      
      using size_type = typename Container1::size_type;
      using value_type = typename Container1::value_type;
      using segment_type = typename Container1::segment_type;
      size_type sz = xs.container1.size();
      if (sz == 0)
        return true;
      size_type lo = size_type(_beg) % sz;
      size_type nb = sz - lo;
      size_type hi = size_type(_end) % std::max(nb, size_type(1));
      hi += lo;
      
      xs.container1.for_each(xs.container1.begin() + lo, xs.container1.begin() + hi,
                            [] (size_t i, int& x) {
                              x = (int)i;
                            });
      
      int i = lo;
      auto it2 = xs.container2.begin() + lo;
      for (; it2 != xs.container2.begin() + hi; it2++) {
        *it2 = i;
        i++;
      }
      
      //std::cout << xs.container2 << std::endl;
      
      if (! xs.same()) {
        std::cout << xs << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class erase_same : public quickcheck::Property<size_t, size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _ix1, const size_t& _ix2, const container_pair_t& _xs) {
      size_t ix1 = (_xs.size() == 0) ? 0 : _ix1 % _xs.size();
      size_t ix2 = (_xs.size() == 0) ? 0 : _ix2 % _xs.size();
      container_pair_t xs(_xs);
      size_t first = std::min(ix1, ix2);
      size_t last = std::max(ix1, ix2);
      xs.container1.erase(xs.container1.begin() + first, xs.container1.begin() + last);
      xs.container2.erase(xs.container2.begin() + first, xs.container2.begin() + last);
      if (xs.container1.size() != xs.container2.size()) {
        std::cout << xs.container1.size() << " " << xs.container2.size() << std::endl;
        return false;
        
      }
      if (!xs.same()) {
        
        std::cout << xs.container1 << "\n\n" << xs.container2 << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class find_same : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _i, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      if (xs.size() == 0)
        return true;
      size_t i = _i % xs.size();
      value_type& v = xs.container1[i];
      v = 999;
      xs.container2[i] = 999;
      auto it1 = std::find(xs.container1.begin(), xs.container1.end(), 999);
      auto it2 = std::find(xs.container2.begin(), xs.container2.end(), 999);
      if (*it1 != 999)
        return false;
      if (*it2 != 999)
        return false;
      v = 998;
      xs.container2[i] = 998;
      it1 = std::find(xs.container1.begin(), xs.container1.end(), 999);
      it2 = std::find(xs.container2.begin(), xs.container2.end(), 999);
      if (it2 == xs.container2.end()) {
        if (it1 != xs.container1.end())
          return false;
        else
          return true;
      }
      if (*it2 != 999)
        return false;
      if (it1 == xs.container1.end())
        return false;
      if (*it1 != 999)
        return false;
      return true;
    }
  };
  
  class shuffle_same : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _i, const container_pair_t& _xs) {
      container_pair_t xs(_xs);

      size_t sz = xs.size();
      if (sz == 0)
        return true;

      size_t nb = _i % xs.size();
      
      for (size_t i = 0; i < nb; i++) {
        xs.container1.push_back(value_type(i));
        xs.container2.push_back(value_type(i));
      }
      for (size_t i = 0; i < sz; i++) {
        size_t j = rand() % sz;
        std::swap(xs.container1[i], xs.container1[j]);
        std::swap(xs.container2[i], xs.container2[j]);
      }

      return xs.same();
    }
  };
  
  /* \todo make a unit test to check that we handle properly fftrees with
   * caches that have noncommutative algebras
   */
  
  class foreach_segment_correct : public quickcheck::Property<size_t, size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _beg, const size_t& _end, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      using size_type = typename Container1::size_type;
      using value_type = typename Container1::value_type;
      using segment_type = typename Container1::segment_type;
      size_type sz = xs.container1.size();
      if (sz == 0)
        return true;
      size_type lo = size_type(_beg) % sz;
      size_type nb = sz - lo;
      size_type hi = size_type(_end) % std::max(nb, size_type(1));
      hi += lo;
      xs.container1.for_each_segment(xs.container1.begin()+lo, xs.container1.begin() + hi,
                                     [&] (size_type ix, segment_type& seg) {
                                       size_type j = ix;
                                       for (value_type* i = seg.middle; i < seg.end; i++)
                                         *i = value_type(j++ + size_type(3));
                                     });
      for (size_type i = lo; i < hi; i++)
        xs.container2[i] = value_type(i + size_type(3));
      Container2 c2;
      copy_to(xs.container1, c2);
      if (c2 != xs.container2) {
        std::cout << "lo=" << lo << " hi=" << hi << std::endl;
        std::cout << "fftree\t" << xs.container1 << std::endl;
        std::cout << " deque\t" << xs.container2 << std::endl;
        return false;
      }
      return true;
    }
    
  };
  
};
  
/*---------------------------------------------------------------------*/
/* Fixed-capacity buffer properties */
  
  // container2 trusted
template <class Container1, class Container2>
class fixedcapacity_properties {
public:
  
  typedef Container1 untrusted_container_type;
  typedef Container2 trusted_container_type;
  
  typedef fixedcapacity_container_pair<untrusted_container_type, trusted_container_type> container_pair_t;
  typedef typename container_pair_t::value_type value_type;
  
  class push_pop_same : public quickcheck::Property<value_type, container_pair_t> {
  public:
    bool holdsFor(const value_type& x, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t which_end;
      quickcheck::generate(1, which_end);
      size_t whether_push_or_pop;
      if (xs.container1.full())
        whether_push_or_pop = 1;
      else if (xs.container1.empty())
        whether_push_or_pop = 0;
      else
        quickcheck::generate(1, whether_push_or_pop);
      
      if (which_end == 0) {
        if (whether_push_or_pop == 0) {
          xs.container1.push_back(x);
          xs.container2.push_back(x);
        } else {
          if (xs.container1.size() != 0) {
            if (xs.container1.back() != xs.container2.back())
              return false;
            xs.container1.pop_back();
            xs.container2.pop_back();
          }
        }
      } else {
        if (whether_push_or_pop == 0) {
          xs.container1.push_front(x);
          xs.container2.push_front(x);
        } else {
          if (xs.container1.size() != 0) {
            if (xs.container1.back() != xs.container2.back())
              return false;
            xs.container1.pop_back();
            xs.container2.pop_back();
          }
        }
      }
      bool same = xs.same();
      if (! same) {
        std::cout << "not same" << std::endl;
        std::cout << "untrusted: " << xs.container1 << std::endl;
        std::cout << "  trusted: " << xs.container2 << std::endl;
      }
      return same;
    }
  };
  
  class pushn : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t nb = _nb;
      if (xs.container1.full())
        return true;
      int maxn = xs.container1.capacity - xs.container1.size();
      nb = nb % maxn;
      value_type vs[nb];
      for (int i = 0; i < nb; i++) {
        value_type x;
        quickcheck::generate(1<<30, x);
        vs[i] = x;
      }
      size_t which_end;
      quickcheck::generate(1, which_end);
      if (which_end == 0) {
        xs.container1.pushn_back(vs, (int)nb);
        pushn_back_container2(xs.container2, vs, (int)nb);
      } else {
        xs.container1.pushn_front(vs, (int)nb);
        pushn_front_container2(xs.container2, vs, (int)nb);
      }
      bool same = xs.same();
      if (! same) {
        std::cout << "nb=" << (int)nb << std::endl;
        std::cout << "not same" << std::endl;
        std::cout << "untrusted: " << xs.container1 << std::endl;
        std::cout << "  trusted: " << xs.container2 << std::endl;
      }
      return same;
    }
  };
  
  class popn : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t nb = _nb;
      if (xs.container1.empty())
        return true;
      nb = nb % xs.container2.size();
      assert(xs.container1.size() == xs.container2.size());
      assert(xs.same());
      value_type vs1[nb];
      value_type vs2[nb];
      size_t which_end;
      quickcheck::generate(1, which_end);
      
      if (which_end == 0) {
        xs.container1.popn_back(vs1, (int)nb);
        popn_back_container2(xs.container2, vs2, (int)nb);
      } else {
        xs.container1.popn_front(vs1, (int)nb);
        popn_front_container2(xs.container2, vs2, (int)nb);
      }
      if (! same_array(int(nb), vs1, vs2)) {
        std::cout << "untrusted" << std::endl;
        for (int i = 0; i < int(nb); i++)
          std::cout << vs1[i] << ", ";
        std::cout << std::endl;
        std::cout << "  trusted" << std::endl;
        for (int i = 0; i < int(nb); i++)
          std::cout << vs2[i] << ", ";
        std::cout << std::endl;
        return false;
      }
      bool same = xs.same();
      if (! same) {
        std::cout << "nb=" << (int)nb << std::endl;
        std::cout << "not same" << std::endl;
        std::cout << "untrusted: " << xs.container1 << std::endl;
        std::cout << "  trusted: " << xs.container2 << std::endl;
      }
      return same;
    }
  };
  
  class pushn2 : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t nb = _nb;
      if (xs.container1.full())
        return true;
      int maxn = xs.container1.capacity - xs.container1.size();
      nb = nb % maxn;
      value_type* vs = new value_type[nb];
      for (int i = 0; i < nb; i++) {
        value_type x;
        quickcheck::generate(1<<30, x);
        vs[i] = x;
      }
      auto body = [&] (size_t i, int& v) {
        v = vs[i];
      };
      typedef typename container_pair_t::container1_type::allocator_type alloc;
      xs.container1.pushn_back(fixedcapacity::apply_foreach_body<alloc, typeof(body)>(body), (int)nb);
      pushn_back_container2(xs.container2, vs, (int)nb);
      delete [] vs;
      bool same = xs.same();
      if (! same) {
        std::cout << "------------" << std::endl;
        std::cout << "untrusted\t" << xs.container1 << std::endl;
        std::cout << "  trusted\t" << xs.container2 << std::endl;
        std::cout << "------------" << std::endl;
      }
      return same;
    }
  };
  
  class pushn3 : public quickcheck::Property<size_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      container_pair_t xs(_xs);
      size_t nb = _nb;
      if (xs.container1.full())
        return true;
      xs.container1.clear();
      xs.container2.clear();
      int maxn = xs.container1.capacity - xs.container1.size();
      nb = nb % maxn;
      value_type val;
      quickcheck::generate(1<<30, val);
      value_type* vs = new value_type[nb];
      for (int i = 0; i < nb; i++) {
        vs[i] = val;
      }
      typedef typename container_pair_t::container1_type::allocator_type alloc;
      fixedcapacity::const_foreach_body<alloc> body(val);
      xs.container1.pushn_back(body, (int)nb);
      pushn_back_container2(xs.container2, vs, (int)nb);
      delete [] vs;
      if (! xs.same()) {
        std::cout << xs.container1 << "\n" << xs.container2 << std::endl;
        return false;
      }
      return true;
    }
  };
  
  class for_each_segment : public quickcheck::Property<size_t, container_pair_t> {
  public:
    int cnt = 0;
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      cnt++;
      if (cnt == 267)
        std::cout << "hi" << std::endl;
      container_pair_t xs(_xs);
      int sz = xs.container1.size();
      if (sz < 1)
        return true;
      unsigned int lo;
      unsigned int hi;
      quickcheck::generate(sz-1, lo);
      quickcheck::generate(sz-1-lo, hi);
      hi += lo;
      
//      std::cout << "** " << sz << " " << lo << " " << hi << std::endl;
      
      xs.container1.for_each_segment(lo, hi, [] (int* lo, int* hi) {
        for (; lo < hi; lo++)
          (*lo)++;
      });
      for (int i = lo; i < hi; i++)
        xs.container2[i]++;
      
      bool same = xs.same();
      if (! same) {
        std::cout << xs.container1 << std::endl;
        std::cout << xs.container2 << std::endl;
      }
      return same;
    }
    
  };
  
  class segment_index_cancels : public quickcheck::Property<size_t, container_pair_t> {
  public:
    int nb = 0;
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs) {
      nb++;
      container_pair_t xs(_xs);
      int sz = xs.container1.size();
      if (sz == 0)
        return true;
      int i = std::abs(int(_nb));
      i = i % sz;
      auto seg = xs.container1.segment_by_index(i);
      int i2 = xs.container1.index_of_pointer(seg.middle);
      bool same = i == i2;
      if (! same) {
        std::cout << i << " " << i2 << std::endl;
      }

      return same;
    }
    
  };
  
  template <class Container>
  static void transfer_back_to_front(Container& src, Container& dst, int nb) {
    assert(src.size() >= nb);
    for (int i = 0; i < nb; i++) {
      value_type v = src.back();
      src.pop_back();
      dst.push_front(v);
    }
  }
  
  template <class Container>
  static void transfer_front_to_back(Container& src, Container& dst, int nb) {
    assert(src.size() >= nb);
    for (int i = 0; i < nb; i++) {
      value_type v = src.front();
      src.pop_front();
      dst.push_back(v);
    }
  }
  
  static trusted_container_type conv(untrusted_container_type src) {
    trusted_container_type dst;
    for (int i = 0; i < src.size(); i++)
      dst.push_back(src[i]);
    return dst;
  }
  
  class transfer_front_to_back_same : public quickcheck::Property<size_t, container_pair_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs, const container_pair_t& _ys) {
      container_pair_t xs(_xs);
      container_pair_t ys(_ys);
      int xs_sz = int(xs.container2.size());
      int ys_sz = int(ys.container2.size());
      int nb = std::abs(int(_nb));
      nb = std::min(nb, untrusted_container_type::capacity - ys_sz);
      nb = std::min(nb, xs_sz);
      transfer_front_to_back(xs.container2, ys.container2, nb);
      xs.container1.transfer_front_to_back(ys.container1, nb);
      bool same1 = conv(xs.container1) == xs.container2;
      bool same2 = conv(ys.container1) == ys.container2;
      return same1 && same2;
    }
  };
  
  class transfer_back_to_front_same : public quickcheck::Property<size_t, container_pair_t, container_pair_t> {
  public:
    bool holdsFor(const size_t& _nb, const container_pair_t& _xs, const container_pair_t& _ys) {
      container_pair_t xs(_xs);
      container_pair_t ys(_ys);
      int xs_sz = int(xs.container2.size());
      int ys_sz = int(ys.container2.size());
      int nb = std::abs(int(_nb));
      nb = std::min(nb, untrusted_container_type::capacity - ys_sz);
      nb = std::min(nb, xs_sz);
      transfer_back_to_front(xs.container2, ys.container2, nb);
      xs.container1.transfer_back_to_front(ys.container1, nb);
      bool same1 = conv(xs.container1) == xs.container2;
      bool same2 = conv(ys.container1) == ys.container2;
      return same1 && same2;
    }
  };
  
};
  
template <class Container1, class Container2>
class map_properties {
public:
  
  typedef map_pair<Container1, Container2> map_pair_t;
  
  class check1 : public quickcheck::Property<map_pair_t> {
  public:
    bool holdsFor(const map_pair_t& _xs) {
      map_pair_t mpp(_xs);
      if (! mpp.same())
        return false;
      int k;
      int v;
      quickcheck::generate(100000, k);
      quickcheck::generate(1000000, v);
      mpp.container1[k] = v;
      mpp.container2[k] = v;
      return mpp.same();
    }
  };
  
};
  
/***********************************************************************/

}
}

#endif /*! _PASL_FTREE_PROPERTIES_H_ */
