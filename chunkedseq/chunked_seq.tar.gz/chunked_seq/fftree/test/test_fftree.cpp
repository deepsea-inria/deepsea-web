/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Unit tests for fast finger tree
 * \file fftree.cpp
 *
 */

#include "cmdline.hpp"
#include "properties.hpp"

using namespace quickcheck;
using namespace pasl::data;

/***********************************************************************/

int nb_tests;

template <class properties>
void doit() {

  check<typename properties::insert_same>("insert is correct", nb_tests);
  
  //return;
  
  check<typename properties::split_same>("split is correct", nb_tests);
  
  check<typename properties::backn>("backn is correct", nb_tests);
  
  //return;
  
  check<typename properties::random_access_same>("random_access is correct", nb_tests);
  

  
  check<typename properties::pushn_const>("pushn const is correct" ,nb_tests);

  check<typename properties::popn_same>("popn is correct", nb_tests);
  
  check<typename properties::pushn_same>("pushn is correct", nb_tests);
  
  check<typename properties::push_pop_same>("interleavings of push and pop are correct", nb_tests);

  check<typename properties::append_same>("append is correct", nb_tests);
  check<typename properties::frontn>("frontn is correct", nb_tests);

  check<typename properties::foreach>("foreach is correct", nb_tests);
  check<typename properties::foreach2>("foreach in range (between two iterators) is correct", nb_tests);
  check<typename properties::foreach_segment_correct>("foreach segment is correct", nb_tests);
  
  check<typename properties::erase_same>("erase is correct", nb_tests);
  check<typename properties::shuffle_same>("stl shuffle on fftree is correct", nb_tests);

  check<typename properties::find_same>("stl find on fftree is correct", nb_tests);
  printf("All done\n");
}

int main(int argc, char** argv) {
  pasl::util::cmdline::set(argc, argv);
  nb_tests = (int) pasl::util::cmdline::parse_or_default_int("nb_tests", 1000);
  std::string datastruct = pasl::util::cmdline::parse_or_default_string("dt", "fftree_ringbuffer");

  typedef ftree_properties<fftree_with_stack<int>, std::deque<int> > stack_properties;
  typedef ftree_properties<fftree_with_ringbuffer<int>, std::deque<int> > ringbuffer_properties;
  typedef ftree_properties<bootstrap_fftree_with_stack<int>, std::deque<int> > boot_stack_properties;
  typedef ftree_properties<bootstrap_fftree_with_ringbuffer<int>, std::deque<int> > boot_ringbuffer_properties;
  //typedef ftree_properties<bootseq<int>, std::deque<int> > bootchunkseq_properties;
  
/*
 bootseq<int> b;
  for (int i = 0; i < 30; i++)
    b.push_front(i+1);
  
  for (int i = 0; i < 5; i++)
    b.push_back(i+1);
  
  std::cout << "before " << b.size() << std::endl;
  
  bootseq<int> b2;
  
  b.split_by_index(b2, 13);
  std::cout << "after " << b.size() << std::endl;
  
  b.push_back(33333);
  b.transfer_to_back(b2);
  
  while (! b.empty()) {
    std::cout << b.pop_back() << std::endl;
  }
  
  return 0; */
  
  if (datastruct == "fftree_stack")
    doit<stack_properties>();
  else if (datastruct == "fftree_ringbuffer")
    doit<ringbuffer_properties>();
  else if (datastruct == "fftree_boot_ringbuffer")
    doit<boot_ringbuffer_properties>();
  //else if (datastruct == "bootchunkseq")
  //  doit<bootchunkseq_properties>();
  else
    assert(false);
  
  return 0;
}

/***********************************************************************/
