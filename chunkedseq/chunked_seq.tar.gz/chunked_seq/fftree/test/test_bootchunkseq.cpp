/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Unit tests for fast finger tree
 * \file fftree.cpp
 *
 */

#include "cmdline.hpp"
#include "fixedcapacity.hpp"
using namespace pasl::data;


#define BOOTCHUNKSEQ_TESTING 1
#define BOOTCHUNKSEQ_CHECKINV 1

// comment out next line for fewer display
// #define BOOTCHUNKSEQ_TEST 1

// comment out next line for fewer display
// #define BOOTCHUNKSEQ_TEST_ALL 1


// comment out next line for testing unweighted version
// #define TEST_WEIGHTED_VERSION 1



#ifndef TEST_WEIGHTED_VERSION 
/*------------------------------------------------*/
// Unweighted version
   // ---> current version has memory leaks!

/*
#include "bootchunkseq.hpp"
static const int top_chunk_capacity = 2;
static const int rec_chunk_capacity = 2;

using weight_type = size_t; 

template<class Item, int capacity>
using mychunk = fixedcapacity::ringbuffer_ptrx< fixedcapacity::heap_allocator<Item, capacity+1 > >;

using value_type = int;

using seq = bootchunkseq::bootchunkseq<value_type, mychunk, top_chunk_capacity, rec_chunk_capacity>;

value_type obj(int& v) {
  return v;
}

int val(value_type& v) {
  return v;
}

*/

#include "fftree.hpp"

template <class Item, int capacity>
using myheapalloc = pasl::data::fixedcapacity::heap_allocator<Item, capacity>;

template <class Item, int capacity>
using myringbuffer_ptr = pasl::data::fixedcapacity::ringbuffer_ptr<myheapalloc<Item, capacity>>;

template <class Item, int capacity>
using bootseq_deque = pasl::data::fftree_base::fftree<
  pasl::data::fftree_base::bootsequence<myringbuffer_ptr<Item, capacity>, size_t>>;

using weight_type = size_t; 

using value_type = int;

value_type obj(int& v) {
  return v;
}

int val(value_type& v) {
  return v;
}

static constexpr int capacity = 3;
using seq = bootseq_deque<value_type, capacity>;



#else
/*------------------------------------------------*/
// Weighted version

#include "bootchunkseq_weighted.hpp"

using weight_type = uint64_t; // must be compatible with def in bootchunkseq

static const int chunk_capacity = 2;

template<class Item, int capacity>
using mychunk = fixedcapacity::ringbuffer_ptrx< fixedcapacity::heap_allocator<Item, capacity+1 > >;

// Object wrapping around an integer, with weight equal to 1
class int_item {
public:
  weight_type w;
  int value;

  int_item(int& v) {
    w = 1;
    value = v;
  }

  ~int_item() { }

  void print() {
    printf("%d", value);
  }

};

using value_type = int_item*;

using seq = bootchunkseq_weighted::bootchunkseq<value_type, mychunk, chunk_capacity>;


value_type obj(int& v) {
  return new int_item(v);
}

int val(value_type& v) {
  int x = v->value;
  delete v;
  return x;
}


#endif



/***********************************************************************/


int main(int argc, char** argv) {
  pasl::util::cmdline::set(argc, argv);

  seq s;
  //s.check();

  /* ========= push pop ===========
  printf("------------\nStarting\n");
  int nb = 35;
  bool lifo = true;
  lifo = true;
  for (int i = 0; i < nb; i++) {
    printf("-------------\nPushing %d\n", i);
    s.push_front(obj(i));
    s.print();
  }
  
  for (int i = nb-1; i >= 0; i--) {
    s.print();
    printf("-------------\nPopping %d\n", i);
    value_type r;
    if (lifo)
      r = s.pop_front();
    else
      r = s.pop_back();
    printf("  =%d\n", val(r));
  }
 */
  /**/
  /* */
  auto push = [](seq& s, int nb, int offset) { 
    for (int i = 0; i < nb; i++) {
      int j = offset+i;
      value_type x = obj(j);
      s.push_back( x ); 
    }
  };

  /* ========= concat =========== 

  seq t;
  int nbs = 5;
  int nbt = 2;
  push(s, nbs, 0);
  s.print();
  push(t, nbt, nbs);
  t.print();
  s.concat(t);
  printf("ok");
  s.print();
  printf("ok");

  s.check();
  t.check();

 */
  /* ========= split =========== 

  int nb = 32;
  weight_type pos = 9;

  for (int i = 0; i < nb; i++) {
    seq t;
    seq u;
    //seq::debug_alloc();
    push(t, nb, 0);
    t.print();
    value_type r;
    //seq::debug_alloc();
    t.split(pos, r, u);
    //seq::debug_alloc();
    t.print();
    printf("=============\n= %d\n", val(r));
    u.print();
    printf("=============\n");
  } 
  */


  int nb = 16;
  size_t pos = 9;

  for (int i = 0; i < nb; i++) {
    seq t;
    seq u;
    //seq::debug_alloc();
    push(t, nb, 0);
    value_type r;
    //seq::debug_alloc();
    t.split_by_index(u, pos);
    //seq::debug_alloc();
    printf("=============\n= %d\n", u.pop_front());
    printf("=============\n");
    break;
  } 

  /* ========= split and concat ===========
  
 
  // requires commenting out BOOTCHUNKSEQ_TEST to be fast enough
  for (int nb = 1; nb < 125; nb++) {
    printf("%d\n", nb);
    seq t;
    seq u;
    push(t, nb, 0);
    for (weight_type pos = 0; pos < nb; pos++) {
      printf("*****========Splitting %d=====*****\n", pos);
      t.split(pos, u);
      //t.print();
      //u.print();
       printf("*****========Concatenating %d=====*****\n", pos);
      t.concat(u);
      //t.print();
      assert(t.size() == nb);
      //t.check();
    }
    //t.print();
  }  */

  /* ========= check at end =========== */

  //seq::debug_alloc();

  return 0;
}

/***********************************************************************/
