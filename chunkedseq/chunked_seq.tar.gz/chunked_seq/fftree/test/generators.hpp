/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Random data generators for unit tests
 * \file generators.hpp
 *
 */

#ifndef _PASL_FTREE_GENERATORS_H_
#define _PASL_FTREE_GENERATORS_H_

#include <deque>
#include <map>

#include "tftree.hpp"
#include "fftree.hpp"
#include "fftmap.hpp"
#include "bootchunkseq.hpp"

namespace pasl {
namespace data {

/***********************************************************************/
/* Forward declarations (must appear before quickcheck.hh) */
  
template <class Array_allocator>
bool operator==(const fixedcapacity::ringbuffer_idx<Array_allocator>& lhs,
                const fixedcapacity::ringbuffer_idx<Array_allocator>& rhs) {
  if (lhs.size() != rhs.size())
    return false;
  for (int i = 0; i < lhs.size(); i++)
    if (lhs[i] != rhs[i])
      return false;
  return true;
}
    
//! \todo: avoid code duplication
template <class Array_allocator>
bool operator==(const fixedcapacity::ringbuffer_ptr<Array_allocator>& lhs,
                const fixedcapacity::ringbuffer_ptr<Array_allocator>& rhs) {
  if (lhs.size() != rhs.size())
    return false;
  for (int i = 0; i < lhs.size(); i++)
    if (lhs[i] != rhs[i])
      return false;
  return true;
}

template <class Array_allocator>
bool operator==(const fixedcapacity::ringbuffer_ptrx<Array_allocator>& lhs,
                const fixedcapacity::ringbuffer_ptrx<Array_allocator>& rhs) {
  if (lhs.size() != rhs.size())
    return false;
  for (int i = 0; i < lhs.size(); i++)
    if (lhs[i] != rhs[i])
      return false;
  return true;
}

template <class Array_allocator>
bool operator==(const fixedcapacity::stack<Array_allocator>& lhs,
                const fixedcapacity::stack<Array_allocator>& rhs) {
  if (lhs.size() != rhs.size())
    return false;
  for (int i = 0; i < lhs.size(); i++)
    if (lhs[i] != rhs[i])
      return false;
  return true;
}
  
static const int chunk_capacity = 4;
  
template <class Item>
using array_allocator_type = fixedcapacity::heap_allocator<Item, chunk_capacity>;
  
template <class Item>
using myringbuffer = fixedcapacity::ringbuffer_ptr<array_allocator_type<Item>>;
  
template <class Item>
using mystack = fixedcapacity::stack<array_allocator_type<Item>>;
  
template <class Vector>
using fftree_basic = fftree_base::fftree<
fftree_base::deque_with_just_size<Vector, size_t> >;
  
template <class Item>
using fftree_with_stack = fftree_basic<mystack<Item> >;

template <class Item>
using fftree_with_ringbuffer = fftree_basic<myringbuffer<Item> >;
  
template <class Vector>
using bootstrap_fftree_basic = fftree_base::fftree<fftree_base::bootstrap_deque_with_just_size<Vector, size_t> >;
  
template <class Item>
using bootstrap_fftree_with_stack = bootstrap_fftree_basic<mystack<Item> >;

template <class Item>
using bootstrap_fftree_with_ringbuffer = bootstrap_fftree_basic<myringbuffer<Item> >;
  
template <class Item>
using bootseq =  fftree_base::fftree<pasl::data::fftree_base::bootsequence<myringbuffer<Item>, size_t>>;


template <class Vector1, class Vector2>
void copy_to(const Vector1& _src, Vector2& dst) {
  using size_type = typename Vector1::size_type;
  using value_type = typename Vector1::value_type;
  Vector1 src(_src);
  src.for_each([&] (size_type, value_type v) {
    dst.push_back(v);
  });
  /*
  for (auto it = src.begin(); it != src.end(); it++)
    dst.push_back(*it);
   */
}
  
template <class Item, class Vector2>
void copy_to2(const std::deque<Item>& src, Vector2& dst) {
 for (auto it = src.begin(); it != src.end(); it++)
   dst.push_back(*it);
}

template <class Container1, class Container2>
class container_pair {
public:
  typedef Container1 container1_type;
  typedef typename Container1::value_type value_type;
  Container1 container1;
  Container2 container2;
  bool same_size() const {
    return container1.size() == container2.size();
  }
  bool same() const {
    if (! same_size())
      return false;
    Container2 tmp;
    copy_to(container1, tmp);
    return tmp == container2;
  }
  void check() const {
    assert(same_size());
  }

  size_t size() const {
    return container1.size();
  }
};
  
template <class Container1, class Container2>
class fixedcapacity_container_pair {
public:
  fixedcapacity_container_pair() : container1() { }
  fixedcapacity_container_pair(const Container1& c1, const Container2& c2)
  : container1(c1),
  container2(c2) {}
  typedef Container1 container1_type;
  typedef typename Container1::value_type value_type;
  Container1 container1;
  Container2 container2;
  
  void my_copy_to(const Container1& src, Container2& dst) {
    dst.resize(src.size());
    for (int i = 0; i < src.size(); i++) {
      dst[i] = src[i];
    }
  }
  
  bool same()  {
    Container2 tmp;
    my_copy_to(container1, tmp);
    return tmp == container2;
  }
  
};
  
template <class Container1, class Container2>
class map_pair {
public:
  typedef Container1 container1_type;
  typedef typename Container1::key_type key_type;
  typedef typename Container1::mapped_type mapped_type;
  Container1 container1;
  Container2 container2;
  bool same_size() const {
    return container1.size() == container2.size();
  }
  bool same() const {
    if (container1.size() != container2.size())
      return false;
    for (auto it = container2.begin(); it != container2.end(); ++it) {
      key_type k = it->first;
      mapped_type v = it->second;
      mapped_type v2 = container1[k];
      if (v2 != v)
        return false;
    }
    return true;
  }
  void check() const {
    assert(same_size());
  }
  
  size_t size() const {
    return container1.size();
  }
};
  
template <typename int_t>
void generate(size_t& n, tftree<int_t>& dst);
  
template <class Container1, class Container2>
void generate(size_t& n, container_pair<Container1, Container2>& dst);

void generate(size_t& n, std::map<int,int>& dst);

template <typename int_t>
void generate(size_t& n, fftmap<int,int>& dst);

template <class Container1, class Container2>
void generate(size_t& n, map_pair<Container1, Container2>& dst);
  
template <typename int_t>
std::ostream& operator<<(std::ostream& out, const tftree<int_t>& src);

template <class Array_allocator>
std::ostream& operator<<(std::ostream& out, const fixedcapacity::ringbuffer_idx<Array_allocator>& src);

template <class Container1, class Container2>
std::ostream& operator<<(std::ostream& out, const fixedcapacity_container_pair<Container1, Container2>& xs);
  
std::ostream& operator<<(std::ostream& out, const std::map<int,int>& src);
  
std::ostream& operator<<(std::ostream& out, const fftmap<int,int>& src);
  
template <class Container1, class Container2>
std::ostream& operator<<(std::ostream& out, const map_pair<Container1, Container2>& src);

/***********************************************************************/

}
}

#include "quickcheck.hh"

namespace pasl {
namespace data {

/***********************************************************************/

template <class Container>
void generate_with_container(size_t& n, Container& dst) {
  typedef typename Container::value_type int_t;
  size_t how_many;
  quickcheck::generate(n, how_many);
  for (size_t i = 0; i < how_many; i++) {
    int_t what_value;
    quickcheck::generate(1<<30, what_value);
    size_t which_end;
    quickcheck::generate(1, which_end);
    if (which_end == 0) {
      dst.container1.push_back(what_value);
      dst.container2.push_back(what_value);
    } else {
      dst.container1.push_front(what_value);
      dst.container2.push_front(what_value);
    }
  }
}
  
template <typename int_t>
void generate(size_t& n, tftree<int_t>& dst) {
  generate_with_container(n, dst);
}

template <class Container1, class Container2>
void generate(size_t& n, container_pair<Container1, Container2>& dst) {
  generate_with_container(n, dst);
}

template <class Container1, class Container2>
void generate(size_t& n, fixedcapacity_container_pair<Container1, Container2>& dst) {
  /*
  size_t force_wrap;
  quickcheck::generate(1, force_wrap);
  if (force_wrap == 0) {
    for (size_t i = 0; i < 5; i++) {
      if (dst.container1.full())
        continue;
      dst.container1.push_front(i+1);
      dst.container2.push_front(i+1);
    }
    for (size_t i = 0; i < 5; i++) {
      if (dst.container1.full())
        continue;
      dst.container1.push_back(i+1);
      dst.container2.push_back(i+1);
    }
  } */
  size_t how_many;
  quickcheck::generate(n % 500, how_many);
  for (size_t i = 0; i < how_many; i++) {
    size_t which_end;
    quickcheck::generate(1, which_end);
    size_t how_many2;
    quickcheck::generate(100, how_many2);
    for (size_t j = 0; j < how_many2; j++) {
      size_t push_or_pop;
      quickcheck::generate(1, push_or_pop);
      if (push_or_pop == 0) {
        if (dst.container1.empty())
          continue;
        if (which_end == 0) {
          dst.container1.pop_back();
          dst.container2.pop_back();
        } else {
          dst.container1.pop_front();
          dst.container2.pop_front();
        }
      } else {
        if (dst.container1.full())
          continue;
        typename Container1::value_type what_value;
        quickcheck::generate(1<<30, what_value);
        if (which_end == 0) {
          dst.container1.push_back(what_value);
          dst.container2.push_back(what_value);
        } else {
          dst.container1.push_front(what_value);
          dst.container2.push_front(what_value);
        }
      }
    }
  }
}

template <class Container1, class Container2>
std::ostream& operator<<(std::ostream& out, const map_pair<Container1, Container2>& src) {
  printf("todo\n");
  return out;
}
  
template <class Item>
std::ostream& operator<<(std::ostream& out, const tftree<Item>& xs) {
  out << "[";
  for (auto it = xs.begin(); it != xs.end(); it++)
    if (it == xs.end() - 1)
      out << *it;
    else
      out << *it << ", ";
  return out << "]";
}
  

  
template <class Item>
std::ostream& operator<<(std::ostream& out, const std::deque<Item>& xs) {
  out << "[";
  for (auto it = xs.begin(); it != xs.end(); it++)
    if (it == xs.end() - 1)
      out << *it;
    else
      out << *it << ", ";
  return out << "]";
}

template <class Container1, class Container2>
std::ostream& operator<<(std::ostream& out, const container_pair<Container1, Container2>& xs) {
  return out << "\n\tftree:\t" << xs.container1 << "\n" << "\tdeque:\t" << xs.container2 << "\n";
}
  
//! \todo share code

template <class Array_allocator>
std::ostream& operator<<(std::ostream& out, const fixedcapacity::ringbuffer_idx<Array_allocator>& src) {
  out << "[";
  for (int i = 0; i < src.size(); i++)
    if (i == src.size() - 1)
      out << src[i];
    else
      out << src[i] << ", ";
  return out << "]";
}
  
template <class Array_allocator>
std::ostream& operator<<(std::ostream& out, const fixedcapacity::ringbuffer_ptr<Array_allocator>& src) {
  out << "[";
  for (int i = 0; i < src.size(); i++)
    if (i == src.size() - 1)
      out << src[i];
    else
      out << src[i] << ", ";
  return out << "]";
}

template <class Array_allocator>
std::ostream& operator<<(std::ostream& out, const fixedcapacity::ringbuffer_ptrx<Array_allocator>& src) {
  out << "[";
  for (int i = 0; i < src.size(); i++)
    if (i == src.size() - 1)
      out << src[i];
    else
      out << src[i] << ", ";
  return out << "]";
}

template <class Array_allocator>
std::ostream& operator<<(std::ostream& out, const fixedcapacity::stack<Array_allocator>& src) {
  out << "[";
  for (int i = 0; i < src.size(); i++)
    if (i == src.size() - 1)
      out << src[i];
    else
      out << src[i] << ", ";
  return out << "]";
}
  
template <class Container1, class Container2>
std::ostream& operator<<(std::ostream& out, const fixedcapacity_container_pair<Container1, Container2>& xs) {
  return out << "\nfixedcapacity:\t" << xs.container1 << "\n" << "deque:\t\t" << xs.container2 << "\n";
}

template <class Container1, class Container2>
void generate(size_t& n, map_pair<Container1, Container2>& dst) {
  int range = 10000;
  size_t how_many;
  quickcheck::generate(n, how_many);
  for (size_t i = 0; i < how_many; i++) {
    int key;
    int value;
    quickcheck::generate(range, key);
    quickcheck::generate(10000000, value);
    dst.container1[key] = value;
    dst.container2[key] = value;
  }
}
  
/***********************************************************************/

}
}

#endif /*! _PASL_FTREE_GENERATORS_H_ */
