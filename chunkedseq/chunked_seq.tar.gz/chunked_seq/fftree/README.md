Package description                         {#mainpage}
============

This package consists of a C++ library providing a family of data
structures whose purpose is to maintain large, dynamically resiazable
sequences of items.

Although they are sequential (i.e., not thread safe), our data
structures are nevertheless useful for parallel programming, in
particular fork-join / divide-and-conquer algorithms, because our data
structures can both be split and merged in logarithmic time and can be
accessed efficiently in a serial fashion.

Data structure       | Description
-------------------- | ----------
\ref ftree           | Our `ftree` is an adaptation of and extension to a purely-functional data structure called the 2-3 Finger Tree [1]. The `ftree` supports deque operations in constant time and splitting and concatenation in time logarithmic in the size of the smaller piece. Unlike the Finger Tree, which is persistent and intended for functional programming, `ftree` is an ephemeral data structure and is intended for imperative programming. The `ftree` is, like the finger tree of Hinze and Patterson, a flexible balanced tree data structure that can, for instance, serve as priority queue, search tree, priority search queue, and more.
\ref fftree          | Our `fftree` is a chunked variant of the `ftree`. Internally, `fftree` is represented by an `ftree` with small fixed-capacity vectors of items at the leaves, along with side vectors. The purpose of the chunks and side vectors is to amortize relatively expensive `ftree` operations by treating small groups of items close together in space and time. The interface of `fftree` resembles the interface of the STL `deque` [2]. Like the STL deque, `ftree` supports fast insertion and deletion of items from either of the ends of the container. But unlike the STL deque, `fftree` offers spliting and concatenation in time logarithmic in the size of the smaller piece.

API Example
=================

\snippet examples/api.cpp api

Credits
=================

`fftree` is being developed at the [INRIA Rocquencourt](http://inria.fr/)
in the [Deepsea Project](http://deepsea.inria.fr/).
Its primary authors are [Umut
Acar](http://umut-acar.org), [Arthur
Chargueraud](http://chargueraud.org), and [Michael
Rainey](http://gallium.inria.fr/~rainey).

Bibliography
=================

[1] [Finger Trees: A Simple General-purpose Data Structure](http://www.soi.city.ac.uk/~ross/papers/FingerTree.html)
By Ralf Hinze and Ross Paterson;
in Journal of Functional Programming;

[2] [Standard Template Library: deque](http://www.cplusplus.com/reference/deque/deque/)


\image html ./logo.jpg

\defgroup ftree Finger tree
@{

The 2-3 Finger Tree is the creation of Hinze and Patterson. Their 
original data structure is a purely functional data structure that
provides:

- push and  pop operations, both at  the front and the back of the
  sequence in (amortized) constant time
- concatenation in logarithmic time
- random access and split operations in logarithmic time
- space usage not in excess of a small constant factor of the space
  required to represent the items stored in the sequence

Furthermore, thanks to its purely functional definition, the purely
functional 2-3 Finger Tree has a confluently persistent semantics and,
assuming certain use of lazy evaluation, the asymptotic bounds hold in
the persistent setting.

Our ftree brings all of the same features of the purely functional
2-3 Finger Tree to the imperative world of C++ -- except for
persistence. That is, unlike the functional 2-3 Finger Tree, our
imperative ftree is an ephemeral data structure, meaning that each
update to the data structure simultaneously creates a new version
of the data structure and destroys the old one.

The rest of this page discusses the properties of and concepts
relating to our `ftree`. The API of `ftree` is documented by 
\ref pasl::data::ftree.

Ephemeral versus persistent
============

We chose the ephemeral semantics for our fast finger tree because, in
the imperative setting, it is simpler to implement and use the
ephemeral semantics. Nevertheless, our fast finger tree could be made
persistent by applying techniques from Driscoll et. al. ("Making Data
Structures Persistent"; 1989). Their technique is powerful enough to
guarantee essentially the same asymptotic bounds in the persistent
setting. However, it is not known whether the constant factors would
be prohibitive in practice. Moreover, the techniques of Driscoll
et. al. apply only to data structures that are accessed
serially. Whether these techniques scale well in parallel settings is
not known.

Client-defined leaf items and cached measurements {#custom_leaf}
=================

Items contained in the `ftree` are stored exclusively in the leaf
nodes of the tree. Internal nodes are annotated with cached
measurements, which are values of a client-defined type, whose purpose
is to summarize the contents of the items in the leaves.

The type of the leaf items and the method for computing the cached
measurements is determined by the client of the `ftree`: the client is
required to pass as the first template parameter of the `fftree` the
type `Leaf_item`. This section describes what the client needs to do
to correctly insantiate `ftree` with their own custom type of leaf
item and cached measurement.

Cached measurements {#cached_measurements}
------------------------------------------

In addition to storing items, `ftree` stores cached measurements of
items. A cached measurement is a value whose purpose is to summarize
the contents of zero or more items. For instance, a common cached
measurement is the weight measurement, which is simply an integer that
represents the combined weights of zero or more items. Supposing we
define the weights of all leaf items as one, then the cached weight of
the leaf node equals one. The cached weight of an internal node, then,
is the sum of the cached weights of its children. In general, the
definition of the cached measurement consists of the type
`measured_type`, which represents the set of cached measurements, and
the type `algebra_type`, which represents the combining operators that
are required to combine cached measurements of internal nodes.

Algebras {#algebras}
-------------------

In mathematics, a _monoid_ is an algebraic structure that consists of a
set _T_, an associative binary operation _OP_ on the items of _T_, and
an identity item _I_. That is, (_T_, _OP_, _I_) is a monoid if:

- _OP_ is associative: for every _x_, _y_ and _z_ in _T_, _x_ _OP_ (_y_ _OP_ _z_) = (_x_ _OP_ _y_) _OP_ _z_
- _I_ is the identity for _OP_: for every _x_ in _T_, _x_ _OP_ _I_ = _I_ _OP_ _x_ = _x_

Examples of monoids include the following:

- Values = the set of all integers; Operation = addition; Identity = 0
- Values = the set of all 32-bit unsigned integers; Operation = addition modulo 2<SUP>32</SUP>; Identity = 0
- Values = the set of all strings; Operation = concatenation; Identity = the empty string

A _group_ is a closely related algebraic structure. Any monoid is also
a group if the monoid has an inverse operation _INV_:

- _INV_ is inverse for _OP_: for every _x_ in _T_, there is an item _y_ = _INV_(_x_) in _T_ such that _x_ _OP_ _y_ = _I_

Example of groups:

- Values = the set of all integers; Operation = addition; Identity = 0; Inverse of _x_ = - _x_
- Values = the set of all 32-bit unsigned integers; Operation = addition module 2<SUP>32</SUP>; Identity = 0; Inverse of _x_ = - _x_

### The algebra class ###

An algebra class defines either a monoid or a group (and provides a
flag to indicate which one of the two it implements). The purpose of
the algebra class is to give the finger tree the information needed to
create, initialize, merge, and destroy cached measurement
instances. It must provide a typedef, which denotes the set of items
in the algebra:

Type           | Description
---------------|-------------
`value_type`   | type of value component in the algebraic structure

It must provide the following static members:

Member                                                    | Description
----------------------------------------------------------|-------------
`is_group`                                                | equals `true` if an inverse is defined and `false` otherwise
`reduce(value_type* left, const value_type* right)`       | evaluates `*left = *left OP *right`
`identity(value_type* p)`                                 | constructs the identity value into the uninitialized memory pointed to by `p`.
`inverse(value_type* p)`                                  | evaluates `*p =` _INV_`(*p`) if `is_group() == true`; the behavior is undefined otherwise.

### Example: group with integers together with addition operation ###

\snippet include/algebra.hpp sum_int

### Example: trivial noop group

Observe that we do not necessarily have to store anything in the
cached measurement field. However, if we store nothing, we limit the
function of the finger tree: split and item search can find only the
first or last item in the sequence. The push, pop, and append
operations are unaffected.

\snippet include/algebra.hpp noop

### Example: combiner algebra ### {#combiner_algebra}

Suppose we wish to cache not only the size but also an abstract weight
measurement. For example, if our finger tree stores strings, we may
wish to cache the total number of individual strings as well as the
total number of characters in the strings.

Fortunately, it is easy to combine any two algebras to get the result
we want. The idea is to simply let the result set be the product of
the two given sets and to synthesize the result algebra
accordingly. For more details, see the documentation associated with
the class \ref pasl::data::algebra::combiner.

\snippet include/algebra.hpp combiner

### Why associativity is necessary ###

The cached value of an internal node _k_ is computed by
(_c<SUB>1</SUB>_ _OP_ _c<SUB>2</SUB>_ _OP_ ... _OP_ _c<SUB>n</SUB>_),
where [_c<SUB>1</SUB>_, ... _c<SUB>n</SUB>_] represents the cached
values of the leaf nodes in the subtree below node _k_. When this
reduction is performed by the internal operations of the finger tree,
this expression is broken up into a set of subexpressions, for
example: ((_c<SUB>1</SUB>_ _OP_ _c<SUB>2</SUB>_) _OP_ (_c<SUB>3</SUB>_
_OP_ _c<SUB>4</SUB>_ _OP_ (_c<SUB>5</SUB>_ _OP_ _c<SUB>6</SUB>_))
... _OP_ _c<SUB>n</SUB>_). The partitioning into subexpressions and
the order in which the subexpressions are combined depends on the
particular shape of the underlying finger tree. Moreover, the
particular shape is determined uniquely by the history of update
operations that created the finger tree. As such, we could build two
finger trees by, for example, using different sequences of push and
pop operations and end up with two different finger tree structures
that represent the same sequence of items. Even though the two finger
trees represent the same sequence, the cached measurements of the two
finger trees are combined up to the root of the finger tree by two
different partitionings of combining operations. However, if _OP_ is
associative, it does not matter: regardless of how the expression are
broken up, the cached measurement at the root of the finger tree is
guaranteed to be the same for any two finger trees that represent the
same sequence of items.

### Why the inverse operation can improve performance ###

Suppose we have a cached measurement _C_ = (_c<SUB>1</SUB>_ _OP_
_c<SUB>2</SUB>_ _OP_ ... _OP_ _c<SUB>n</SUB>_). Now, suppose that we
wish to remove the first item from our sequence of measurements,
namely _c_<SUB>1</SUB>. Without an inverse operation, the only way to
compute the new cached value is to recompute (_c<SUB>2</SUB>_ _OP_
... _OP_ _c<SUB>n</SUB>_). If the inverse operation is cheap, it would
be much more efficient to instead compute _INV_ (_c<SUB>1</SUB>_) _OP_
_C_.

This situation occurs in several places in our implementation of
finger trees, in particular where there is a node that stores the
cached value summarizing several measurements of nodes in
substrucures. To optimize these cases, we use inverse operations, when
permitted by the algebra (i.e., when the algebra is identified as a
group).

- - - 
*This discussion of the algebra interface (as well as the design
of the algebra interface itself) was adapted from a similar discussion
(and design) of the [Cilk Plus
language](http://software.intel.com/sites/products/documentation/doclib/iss/2013/compiler/cpp-lin/GUID-275AA577-EE90-4829-B1EA-01B7EB64C26F.htm).*
- - -

The leaf-item class
------------------------

The finger tree class is parameterized over the type
`Leaf_item`. Values of this type provide the information needed by the
finger tree to allocate and deallocate leaf nodes and to measure and
combine cached measurements. It must define typedefs for the following
types.

Type                  | Description
----------------------|-------------
`measured_type`       | type of cached measurements that are to adorn internal nodes of the tree
`algebra_type`        | type of the algebra class used to combine measured values of type `measured_type`

It must provide public fields for storing an item and a cached
measurement of the corresponding item.

Field                 | Type                  | Description
----------------------|-----------------------|-------------
`item`                | `value_type`          | item stored in the leaf node
`cached`              | `measured_type`       | the measured value of the contents of `item`

It must provide empty and value constructors.

Constructor                                          | Description
-----------------------------------------------------|-------------
`Leaf_item()`                                        | empty constructor
`Leaf_item(const value_type& v)`                     | value constructor

It must define several public methods. The first two provide a pointer
to the cached measurement field. The third method is a static method
that swaps the contents of any two given references to
cached-measurement objects. The fourth method clears and deallocates
the contents of the item.

Function                                               | Description
-------------------------------------------------------|-------------
`get_cached()`                                         | returns a pointer to the cell containing the cached measurement of the leaf
`cget_cached()`                                        | const version of above
`swap_measured(measured_type& m1, measured_type& m2)`  | swaps the contents of the values pointed to by the two given references
`clear()`                                              | erases and deallocates the contents of the leaf

Example: a leaf-item type with a singleton value and a size measurement
-----------

The following class satisfies all of the requirements of our leaf-item
type. The leaf stores a value of type `Item` and defines the measured
value of all individual items as one. Our choice of algebra, in this
case the monoid consisting  of the set of integers with the identity
element zero and the associative combining operator plus, implies that
the cached measurement of any given internal node of the tree equals
the number of items contained in the leaves of the subtree of the
node. As we see later, this size measurement is useful because we can
use the size to implement an indexing operator for our instantiation
of the finger tree.

\snippet include/tftree.hpp tleaf

Tree search
============

Tree search is a process of navigating through the finger tree to find
a target item. The target item is selected by repeatedly querying
cached measurements stored along a path in the finger tree. 

Predicates {#predicates}
--------------

A predicate is a functor (i.e., class which defines the call operator)
and satisfies the interface:

Function     | Description
-----------|----------
`operator(const measured_type& m)` | returns `true` if `m` satisfies the predicate and `false` otherwise

For example, the simplest predicate is the predicate which ignores its
argument and always returns a fixed boolean value:

\snippet include/predicate.hpp always_predicate

In search in a finger tree, the first and last item of the sequence is
the target of the predicate `always<true>` and `always<false>`,
respectively.

In general, tree search partitions the sequence represented by the
finger tree into two subsequences:

1. the subsequence preceding the
first item _x_ for which the predicate is satisfied
2. the subsequence including and following _x_.

For example, consider a finger tree that contains ten items and whose
cached measurement is the size (i.e., number of items). Let
_C<SUB>i</SUB>_ denote the sum of the cached measurements of the items
in the range of positions [0, _i_]. Suppose our predicate returns
`true` if its argument is an even number and `false` if odd. Then the
partition created by the tree search for this predicate and finger
tree is (1) the subsequence which contains the first item and (2) the
subsequence which contains the rest of the items (second to tenth).

index                      | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 
---------------------------| - | - | - | - | - | - | - | - | - | -
(size) _C<SUB>i</SUB>_     | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10
`p(` _C<SUB>i</SUB>_ `)`   | f | t | f | t | f | t | f | t | f | t

Finger search
-------------

Finger search is a technique to speed up searches in the tree. The
idea is to expose to the client of the data structure a pointer to
interior nodes in the tree. By starting a search via a given node
pointer, the client can reach the target node through as many or
fewer links than by simply starting every search via the root one.

Our finger search exposes to the client pointers to only the leaf
nodes. This restriction does not reduce the power of the finger
search because in the ftree items are stored on the leaves only.

Example: STL-style container for finger tree with singleton leaf and size measurement
==================

We conclude our discussion by showing the code of an STL-style deque
container, named `tftree`, that is built on top of `ftree`.

The `tftree` provides push and pop operations from both ends in
amortized constant time, split and append in logarithmic time.

It also provides an insert operation. The insert operation takes
logarithmic time as well, because insert is implemented on top of
split and append. 

Indexing takes logarithmic time thanks to tree search.

It also provides an STL-style iterator. The iterator supports
constant-time traversal of the items thanks to the finger-search
property. That is, the finger search guides the iterator traversal of
the tree along the fringe of the finger tree.

The iterator object has two fields: a leaf-node pointer and a size
value. The leaf-node pointer points to the target leaf node and the
size value represents the size of the subsequence up to and including
the target item. Alternatively, it would suffice to store only the
leaf-node pointer (and not the size field). However, this
representation would somehow have to distinguish positions in the
sequence from the position one past the end of the sequence (i.e.,
`end())`), which is not immediately provided by the leaf-node
pointer. An additional bit would be necessary. This complication is
why we use the size field for this example.

\snippet include/tftree.hpp tftree


@}

\defgroup fixedcapacity Fixed-capacity vectors
@{

Type                   | Description
-----------------------|----------
`allocator_type`       | STL-style allocator class
`size_type`            | `size_t`
`value_type`           | type of items to be stored in the container
`reference`            | `allocator_type::reference`
`const_reference`      | `allocator_type::const_reference`
`pointer`              | `allocator_type::pointer`
`const_pointer`        | `allocator_type::const_pointer`

Member                                                                                    | Description
------------------------------------------------------------------------------------------|-------------
`capacity`                                                                                | integer value which denotes the maximum number items that can be contained in the chunk
`full() const`                                                                            | returns true iff the container is full (i.e., reached capacity)
`empty() const`                                                                           | returns true iff the container is empty
`size() const`                                                                            | returns the number of items in the container
`back() const`                                                                            | returns a reference to the last item in the container
`front() const`                                                                           | returns a reference to the first item in the container
`push_back(const value_type& x)`                                                          | adds value `x` to the last position of the container
`push_front(const value_type& x)`                                                         | adds value `x` to the first position of the container
`pop_back()`                                                                              | removes the value from the last position of the container
`pop_front()`                                                                             | removes the value from the first position of the container
`backn(value_type* xs, size_type nb)`                                                     | copies the last `nb` items from the container to the memory pointed to by `xs`
`frontn(value_type* xs, size_type nb)`                                                    | copies the first `nb` items from the container to the memory pointed to by `xs`
`pushn_back(const value_type* xs, size_type nb)`                                          | pushes on the back of the container the `nb` items from the memory pointed to by `xs`
`pushn_front(const value_type* xs, size_type nb)`                                         | pushes on the front of the container the `nb` items from the memory pointed to by `xs`
`pushn_back(const Body& body, size_type nb)`                                              | pushes on the back of the container `nb` uninitialized items (i.e., default-constructed items), then initializes each item `i` in the underlying vector `vec` by applying `body(i, vec[i])` (behavior is undefined if `size() + nb > capacity`)
`popn_front(size_type nb)`                                                                | removes the first `nb` items from the container
`popn_back(size_type nb)`                                                                 | removes the last `nb` items from the container
`popn_front(value_type* xs, size_type nb)`                                                | removes the first `nb` items from the container and leaves the contents in the memory pointed to by `xs`
`popn_back(value_type* xs, size_type nb)`                                                 | removes the last `nb` items from the container and leaves the contents in the memory pointed to by `xs`
`swap(Other_chunk& other)`                                                                | swaps the contents of the chunk with the contents of another chunk of type `Other_chunk`
`transfer_back_to_front(chunk& target, size_type nb)`                                     | moves the last `nb` items from this chunk to the front of the target chunk
`transfer_front_to_back(chunk& target, size_type nb)`                                     | moves the first `nb` items from this chunk to the back of the target chunk
`get_vec()`                                                                               | returns a reference to the underlying vector container
`clear()`                                                                                 | erases and deallocates the contents of the container
`operator[](size_type ix) const`                                                          | returns a reference to the item at position `ix` in the container
`segment_by_index(size_type ix) const`                                                    | returns the segment relative to the given index `ix`. in particular, the middle of the result segment points to the cell at index `ix` in the container and beginning and end point to the first and one past the last cell respectively that are both in the same contiguous chunk as the middle cell
`index_of_pointer(const value_type* p) const`                                             | returns the index in the sequence corresponding to pointer `p`

Segments {#segments}
=====================

A _segment_ is a struct value that consists of three pointers:
`beginning`, `middle`, and `end`. The `beginning` and `end` pointers
point, respectively, to the start and to the cell one past the end of
a region of contiguous memory in a vector. The `middle` pointer can
point anywhere in the range [`beginning`, `end`].

\snippet include/fixedcapacity.hpp segment

The purpose of the segment is to expose to the internals and clients
of the fast finger tree ranges of consecutive items that reside in
contiguous memory. Having access to contiguous chunks can enable use
of hardware vector primitives (i.e., SIMD operations) that can speedup
item processing.

For-each loops {#foreach_loop_body}
=================

The for-each loop operation offers sequential access to the items of a
vector. To use the for-each loop, the client must apply the `for_each`
method of the vector, providing the body of the loop as the argument.
If it accesses items read only, the body of the loop must provide the
following method:

Member function                                     | Description
----------------------------------------------------|---------------
`operator()(size_type ix, const_reference v) const` | represents the action of the loop body for the item in the container at position `ix` along with the reference `v` to the cell at position `ix`.

Example: using for-each loop to compute a sum of the items of a vector `vec`
-------------------------------------

    int sum = 0;
    vec.for_each([&sum] (size_type ix, const_reference v) {
        sum += v;
    });

If it requires write access to items, the body of the loop must
provide the following method.

Member function                               | Description
----------------------------------------------|----------
`operator()(size_type ix, reference v) const` | represents the action of the loop body for the item in the container at position `ix` along with the reference `v` to the cell at position `ix`.

Example: using for-each loop to increment the items of a vector `vec`
-------------------------------------

    vec.for_each([&sum] (size_type ix, reference v) {
        v++;
    });

Implementations of fixed-capacity vectors provided by our library {#basic-fixed-capacity}
==========================

This library provides two implementations of fixed-capacity vectors:
the \ref pasl::data::fixedcapacity::stack and the \ref
pasl::data::fixedcapacity::ringbuffer. Both export the same interface,
namely the interface of the fixed-capacity vector, but each has
different performance characteristics. The `ringbuffer` offers
slightly slower but still fast constant-time access to both ends of
the container. The `stack` is biased to offer fast access to the end
of the container. The disadvantage is that the `stack` imposes a
linear-time cost to push an item on the front of the container. That
is, the contents of the container must be shifted right by one
position each time an individual item is pushed on the front of the
container. However, the contents of the `stack` need to be shifted
right by _n_ positions in order to push _n_ items in bulk at once.

Example: fixed-capacity stack
=====================

\snippet include/fixedcapacity.hpp fixedcapacitystack

@}

\defgroup fftree Fast finger tree
@{

An `fftree` is a sequence container representing arrays that can change
in size and split and concatenate in logarithmic time.

Unlike STL vectors, fftrees use non-contiguous storage for their
items. Items are stored by the fftree in a number of small,
fixed-capacity _chunks_ that may be optimized to take advantage of
their compact representation.

In specific, a chunk is a small container that consists of a
fixed-capacity vector and a corresponding cached measurement. We refer
to this vector specifically as the _underlying vector_ of the chunk,
because sometimes we need to access specific features that are
provided only by the vector. The details of our fixed-capacity
vectors are described in \ref fixedcapacity.

Internally, fftrees use the \ref ftree (ftree) data structure with the
leaves instantiated by chunks. The ftree gives amortized constant-time
push and pop to the ends of the container as well as logarithmic time
split and concatenation.

Compared to STL vectors, or arrays, fftrees consume more memory in
exchange for the ability to both grow and shrink dynamically and split
and concatenate efficiently.

Compared to other dynamic containers, such as STL vectors or STL
deques, fftrees are not as efficient for accessing items in in the
middle but are as efficient for inserting or removing items at the
beginning or end. However, fftrees can be split and concatenated in
logarithmic time, whereas STL vectors require linear time for these
operations.

The rest of this page discusses the properties of and concepts
relating to our `fftree`. The API of `fftree` is documented by 
\ref pasl::data::fftree_base::fftree.

Container properties {#container_properties}
=====================

Sequence
------------
Items in sequence containers are ordered in a strict linear
sequence. Individual items are accessed by their position in the
sequence.

Dynamic array
-------------
The container allows direct access to any item in the container, even
through pointer arithmetics, and provides relatively fast
addition/removal of item at the beginning and end of the container.

Substructure access
--------------------
To encourage data locality, the fftree provides to the client of the
data structure direct access to contiguous _segments_ of memory that
are contained in its chunks. The client may access the \ref segments
via the STL-style iterator of the fftree (i.e., \ref
pasl::data::fftree_base::fftree::iterator).

Average chunk density
-------------------------------

`compaction_group_sz`
if negative, use the "bag semantics"; explain implications of this parameter in terms of density and copying overhead

\todo document

Cached measurement {#fftree_cached_measurement}
=================

You can write a custom cached measurement class if the supplied
cached-measurement classes does not satisfy your requirements.

If you are not yet familiar with these concepts, see \ref
cached_measurements and \ref algebras.

The cached measurement of the fftree is a policy that consists of three
parts:

1. a function that computes the measured value of a given container
  item (or sequence of container items)
2. an algebra that determines how measured values are combined and
  stored in the internal nodes of the fftree
3. an operation that can swap the contents of two given references to
  measured values

The measurement function
-----------------------------

The measurement function is actually represented in fftree by a
_functor_, which is a class in C++ that provides one or more call
operators. A _call operator_ is just a method like `operator()` that
enables instances of the class to be called like functions.

This particular functor must implement two call operators with two
different types: the first is for measuring individual items and the
second is for measuring sequences of multiple items at once.

In certain cases, it is much more efficient to measure multiple items
simultaneously than to measure each individually. For example, the
size measurement, which simply computes the number of items in a given
sequence, can be much more efficiently computed in bulk because the
number of items is often cached somewhere else (e.g., inside the
underlying vector container) where it can be accessed efficiently in
constant time. For another example, the max of a number of items can
be computed more efficiently in bulk if the sequence is known in
advance to be in ascending order: in this case, the max is just the
last item.

Measure functor                                                                   | Description
----------------------------------------------------------------------------------|-------------
`operator()(const value_type& v, measured_type& dst) const`                       | computes the measure of the value `v` and puts the result into the uninitialized memory pointed to by `dst`
`operator()(const value_type* lo const value_type* hi, measured_type& dst) const` | computes the measure of the items pointed to in the range `[lo,hi)`

The algebra and related types
------------------------------

The cached-measurement policy must define the following typedefs.

Type                 | Description
---------------------|------------
`size_type`          | alias for `size_t`
`algebra_type`       | type of the the algebra used for combining cached measurements
`measured_type`      | alias for `algebra::value_type`
`value_type`         | type of the individual values to be measured
`measure_type`       | type of the measurement functor

The swap operation
------------------

The cached-measurement policy must define the following static method:

Static method                                | Description
---------------------------------------------|-------------
`swap(measured_type& m1, measured_type& m2)` | swaps the contents of the values pointed to by the two given references

Example: cached measurement that computes the number of items
-------------------------------------

This policy effectively counts the number of items in the container:
the first call operator of the `measure_type` specifies that an
individual item counts for one, and the second specifies that _n_
items count for _n_.

\snippet include/fftreecache.hpp size

Example: the empty cached measurement
-------------------------------------------

This policy can be useful to reduce the size of the container: the
cached measurements to be stored in the internal nodes of the finger
tree are all zero-byte structures. However, the space savings comes at
the cost of limiting what the container can do. Without size, it is
not possible to call the `size()` and indexing operations, nor is it
possible to use the iterator. Only push, pop, concatenation, and empty
checks are possible.

\snippet include/fftreecache.hpp zero_byte

Example: the cached-measurement combiner
-----------------------------------------

Sometimes one type of cached measurement is not enough. In \ref
combiner_algebra, we show an "algebra combiner" that can combine two
given algebras. The same can combiner concept extends to the cached
measurement policy of the fftree.

\snippet include/fftreecache.hpp combiner

Chunks  {#chunks}
=================

The chunk class must provide the following typedefs.

Member type                       | Description
----------------------------------|----------
`self_type`                       | type of the chunk class
`cache_type`                      | type of the cached measurement
`vector_type`                     | type of the underlying vector container
`value_type`                      | type of the items to store in the container
`reference`                       | alias for `allocator_type::reference`
`const_reference`                 | alias for `allocator_type::const_reference`
`pointer`                         | alias for `allocator_type::pointer`
`const_pointer`                   | alias for `allocator_type::const_pointer`
`allocator_type`                  | alias for `vector_type::allocator_type`
`size_type`                       | alias for `cache_type::size_type`
`measured_type`                   | alias for `cache_type::measured_type`
`algebra_type`                    | alias for `cache_type::algebra_type`
`measure_type`                    | alias for `cache_type::measure_type`
`fftree_config_type`              | type of the configuration of the fftree (see \ref fftree_config)
`inner_cache_type`                | alias for `fftree_config_type::inner_cache_type`
`outer_cache_type`                | alias for `fftree_config_type::outer_cache_type`

The chunk class must provide a default constructor and the member
variables and methods in the table below..

The behavior of any chunk operation is undefined if the operation
creates either an overflow or underflow condition. An operation
overflows if the operation tries to increase the size of the full
container. An operation underflows if the operation tries to decrease
the size of the empty container.

Member                                                                                    | Description
------------------------------------------------------------------------------------------|-------------
`capacity`                                                                                | integer value which denotes the maximum number items that can be contained in the chunk
`full() const`                                                                            | returns true iff the container is full (i.e., reached capacity)
`empty() const`                                                                           | returns true iff the container is empty
`size() const`                                                                            | returns the number of items in the container
`back() const`                                                                            | returns a reference to the last item in the container
`front() const`                                                                           | returns a reference to the first item in the container
`push_back(const measure_type& meas, const value_type& x)`                                | adds value `x` to the last position of the container
`push_front(const measure_type& meas, const value_type& x)`                               | adds value `x` to the first position of the container
`pop_back(const measure_type& meas)`                                                      | removes the value from the last position of the container
`pop_front(const measure_type& meas)`                                                     | removes the value from the first position of the container
`backn(value_type* xs, size_type nb)`                                                     | copies the last `nb` items from the container to the memory pointed to by `xs`
`frontn(value_type* xs, size_type nb)`                                                    | copies the first `nb` items from the container to the memory pointed to by `xs`
`pushn_back(const measure_type& meas, const value_type* xs, size_type nb)`                | pushes on the back of the container the `nb` items from the memory pointed to by `xs`
`pushn_front(const measure_type& meas, const value_type* xs, size_type nb)`               | pushes on the front of the container the `nb` items from the memory pointed to by `xs`
`pushn_back(const measure_type& meas, const Body& body, size_type nb)`                    | pushes on the back of the container `nb` uninitialized items (i.e., default-constructed items), then initializes each item `i` in the underlying vector `vec` by applying `body(i, vec[i])` (behavior is undefined if `size() + nb > capacity`)
`popn_front(const measure_type& meas, size_type nb)`                                      | removes the first `nb` items from the container
`popn_back(const measure_type& meas, size_type nb)`                                       | removes the last `nb` items from the container
`popn_front(const measure_type& meas, value_type* xs, size_type nb)`                      | removes the first `nb` items from the container and leaves the contents in the memory pointed to by `xs`
`popn_back(const measure_type& meas, value_type* xs, size_type nb)`                       | removes the last `nb` items from the container and leaves the contents in the memory pointed to by `xs`
`swap(Other_chunk& other)`                                                                | swaps the contents of the chunk with the contents of another chunk of type `Other_chunk`
`transfer_back_to_front(const measure_type& meas, chunk& target, size_type nb)`           | moves the last `nb` items from this chunk to the front of the target chunk
`transfer_front_to_back(const measure_type& meas, chunk& target, size_type nb)`           | moves the first `nb` items from this chunk to the back of the target chunk
`get_vec()`                                                                               | returns a reference to the underlying vector container
`split(chunk& dst, const Pred& p, const measure_type& meas, const measured_type& prefix)` | let _C<SUB>i</SUB>_ denote the sum of the content of `prefix` along with the cached measurements from the items in the range of positions [0, _i_]; erases the contents of the container after the first position _i_ to satisfy the predicate `p(` _C<SUB>i</SUB>_ `)`; pushes to the back of the given container `dst` the contents that were erased; updates the content of  `prefix` to the value _C<SUB>i-1</SUB>_ if _i_ > 0 and leaves the content untouched otherwise
`clear()`                                                                                 | erases and deallocates the contents of the container
`operator[](size_type ix) const`                                                          | returns a reference to the item at position `ix` in the container
`segment_by_index(size_type ix) const`                                                    | returns the segment relative to the given index `ix`. in particular, the middle of the result segment points to the cell at index `ix` in the container and beginning and end point to the first and one past the last cell respectively that are both in the same contiguous chunk as the middle cell
`index_of_pointer(const value_type* p) const`                                             | returns the index in the sequence corresponding to pointer `p`
`get_cached()`                                                                            | returns a pointer to the cached measurement of the container
`cget_cached() const`                                                                     | const version of the above
`swap_measured(measured_type& m1, measured_type& m2)`                                     | swaps the contents of the values pointed to by the two given references

Example: chunk with size and cached measurement
------------------------------------------------

This class is the default chunk class of the fftree.

\snippet include/chunk.hpp chunk_example

Configuration of fast finger tree {#fftree_config}
===================================

The fast finger tree class is parameterized by a configuration class
`FFTree_config`. The purpose of this configuration class is to
determine the types and properties relating to the chunks to be stored
in the leaves and to the cache-measurement policy.

This configuration class must define the following types:

Member type                       | Description
----------------------------------|----------
`self_type`                       | type of the configuration class
`vector_type`                     | type of the vector to be used as the underlying representation of the chunk
`outer_cache_type`                | type of cached measurement to use for the chunks that represent the front and back ends of the container and are kept by the fast finger tree outside the underlying finger tree (must satisfy the requirements of \ref cached_measurement)
`inner_cache_type`                | type of the cached measurement to use for the chunks that occur in the leaves of the underlying finger tree (must satisfy the requirements of \ref cached_measurement)
`value_type`                      | alias for `outer_cache_type::value_type`
`size_type`                       | alias for `outer_cache_type::size_type`
`outer_chunk_type`                | type of the chunk with the outer cache measurement
`inner_chunk_type`                | type of the chunk chunk with the inner cache measurement
`client_measured_type`             | alias for `outer_cache_type::measured_type`
`internal_measured_type`             | alias for `inner_cache_type::measured_type`
`internal_measure_type`              | alias for `inner_cache_type::measure_type`
`client_measure_type`              | alias for `outer_cache_type::measure_type`

It must define the following static members.

Various swap methods are required because, internally, the finger tree
stores two types of chunks:

 - inner chunks are the chunks that are stored in the leaves of the ftree
 - outer chunks are the chunks that are stored on the outside of the ftree

Inner and outer chunks may have one of two different types of cached
measurements. The swap methods define the necessary conversions
between cached measurements of inner and outer chunks.

Static member                                                                                                | Description
-------------------------------------------------------------------------------------------------------------|-------------
`chunk_capacity`                                                                                             | integer value to determine the chunk capacity
`compaction_group_sz`                                                                                        | integer value to control the average density of the chunks in the leaves of the underlying finger tree; if this value is negative, the fftree uses the "bag semantics"; for details, see \ref container_properties
`swap_measured(client_measured_type& m1, client_measured_type& m2)`                                            | swaps the contents of the values pointed to by the two given references
`swap_measured(internal_measured_type& m1, internal_measured_type& m2)`                                            | same as above
`swap_measured(const vector_type& vec, client_measured_type& m1, internal_measured_type& m2)`                    | same as above
`swap_measured(const vector_type& vec, internal_measured_type& m1, internal_measured_type& m2)`                    | same as above
`swap(vector_type& vec1, vector_type& vec2, client_measured_type& m1, internal_measured_type& m2)`               | same as above
`swap(vector_type& vec1, vector_type& vec2, internal_measured_type& m1, client_measured_type& m2)`               | same as above
`swap(vector_type& vec1, vector_type& vec2, client_measured_type& m1, client_measured_type& m2)`               | same as above
`swap(vector_type& vec1, vector_type& vec2, internal_measured_type& m1, internal_measured_type& m2)`               | same as above
`size(internal_measured_type& inner)`                                                                           | returns a reference to the size component of the given cached measurement
`csize(const internal_measured_type& inner)`                                                                    | returns the size componenet of the given cached measurement
`client_measured(internal_measured_type& inner)`                                                                | returns a reference to the client-defined component of the given cached measurement
`cclient_measured(const internal_measured_type& inner)`                                                         | const version of above

Example: fast finger tree with size plus client-supplied cached measurement
---------------------------------------------------------------------------

The class `deque_with_size_plus` satisfies the basic requirements of
the fast finger tree configuration. Moreover, the class configures the
fftree to cache the size, i.e., number of items, in the container (as
well as in subtrees of the container). 

Observe that the size is cached by the inner chunks but not by the
outer chunks. The purpose of this policy is to avoid redundant size
computation: the chunks themselves already maintain the size
information and as such we do not need to maintain cached size
information for the chunks outside the fftree.

The configuration represented by `deque_with_size_plus` is still
incomplete because the class is parameterized by the client-cache
policy and by the type of the vector to put in the chunks. The next
examples demonstrate how to instantiate these parameters to make a
complete configuration.

\snippet include/fftree.hpp deque_with_size_plus

Using the fast finger tree
==========================

This section shows how to instantiate and finally to start using the
fftree.

Example: deque with cached size only
---------------------------------------

Let us first partially instantiate our fftree so that the resulting
structure caches only size measurements.

\snippet include/fftree.hpp deque_with_just_size

This program creates one more partial instantiation of the fftree:
this time, the fftree type, namely `myfftree`, is parameterized by
only the type of item. The fftree type is configured to use ring
buffers to represent the fixed-capacity vectors in the container.

\snippet examples/api.cpp api

Example: dynamic dictionary (i.e., map)
---------------------------------------

\snippet examples/fftmap.hpp option

\snippet examples/fftmap.hpp second

\snippet examples/fftmap.hpp map_cache

\snippet examples/fftmap.hpp utils

\snippet examples/fftmap.hpp fftmap

@}
