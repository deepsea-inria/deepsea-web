/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Benchmarking for fast finger tree
 * \file fftree.cpp
 *
 */

#include <vector>
#include <deque>

// nodepend:  missing included folders for this... #include "benchmark.hpp"
#include "native.hpp"

// #include "ftree.hpp"
// #include "leafbuffer.hpp"
// #include "fftree.hpp"

/***********************************************************************/

typedef size_t result_t;
typedef std::function<result_t ()> thunk_t;


/***********************************************************************/

class bytes_1 {
  char data;
  bytes_64(size_t i) {
    data = (char) (i % 256);
  }
  size_t get() {
    return (size_t) data;
  }
};

class bytes_8 {
  uint_64t data;
  bytes_64(size_t i) {
    data = i;
  }
  size_t get() {
    return data;
  }
};

class bytes_64 {
  int_64t data[8];
  bytes_64(size_t i) {
    for (int k = 0; k < 8; k++)
      data[k] = i;
  }
  size_t get() {
    return data[0];
  }
};

/***********************************************************************/

template<class item>
class vector_wrapper {
  vector<item> v;
  vector_wrapper() {}
  void push(item i) {
    v.push_back(i);
  }
  item pop() { 
    item i = v.back();
    v.pop_back();
    return i;
  }
};

/***********************************************************************/

template<class item, class datastruct>
thunk_t scenario_fifo_all() {
  size_t nb_total = (size_t) cmdline::parse_or_default_int("nb_total", 1000);
  return [=] {
    datastruct d;
    for (size_t i = 0; i < nb_total; i++) {
      d.push(item(i));
    }
    size_t result = 0;
    for (size_t i = 0; i < nb_total; i++) {
      result += d.pop();
    }
    return result;
  }
}

/***********************************************************************/


template<class item, class datastruct>
thunk_t dispatch3() {
    cmdline::argmap<thunk_t> tmg;
    tmg.add("fifo_all", scenario_fifo_all<item,datastruct>());
    // TODO: more
    tmg.find_by_arg("scenario")();
}

template<class item>
thunk_t dispatch2() {
    cmdline::argmap<thunk_t> tmg;
    tmg.add("vector", [=] { return dispatch3<item,vector_wrapper<item>>() });
    // tmg.add("queue", dipatch3<<item,queue_wrapper<item>>());
    tmg.find_by_arg("datastruct")();
}

thunk_t dispatch1() {
  size_t itemsize = (size_t) cmdline::parse_or_default_int("itemsize", 8);
  if (itemsize == 1)
    dispatch2<bytes_1>();
  else if (itemsize == 8)
    dispatch2<bytes_8>();
  else if (itemsize == 64)
    dispatch2<bytes_64>();
  else
    atomic::die("itemsize should be 1, 8 or 64.");
}


/*---------------------------------------------------------------------*/

class fftree_benchmark : public benchmark::basic {
private:
  
  thunk_t computation;
  result_t result;

public:
  
  fftree_benchmark() : benchmark::basic() { }
  
  void init () {
    computation = dispatch1();
  }
  
  void run() {
    result = computation();
  }
  
  void output () {
    printf("%ld\n", result);
  }
  
  void destroy() {}
  
  /* todo: default
  void fail() {
    printf("bogus argument\n");
    exit(0);
  }
  */
  
};

/*---------------------------------------------------------------------*/

int main(int argc, char** argv) {
  cmdline::set(argc, argv);
  (new fftree_benchmark())->all();
  return 0;
}

/***********************************************************************/