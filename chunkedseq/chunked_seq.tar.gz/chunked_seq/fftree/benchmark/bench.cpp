/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Benchmarking for fast finger tree
 * \file fftree.cpp
 *
 */

#include <functional>
#include <random>
#include <algorithm>
#include <assert.h>

#include "tftree.hpp"
#include "fftree.hpp"
#include "ls_bag.hpp"
#include "cmdline.hpp"
#include "atomic.hpp"
#include "microtime.hpp"
#include "container.hpp"
#include "fixedcapacity.hpp"

#ifdef USE_MALLOC_COUNT
#include "malloc_count.h"
#endif

using namespace pasl::util;






/***********************************************************************/

template <class Item, int capacity>
using myheapalloc = pasl::data::fixedcapacity::heap_allocator<Item, capacity>;

template <class Item, int capacity>
using mystack = pasl::data::fixedcapacity::stack<myheapalloc<Item, capacity>>;

template <class Item, int capacity>
using myringbuffer_idx = pasl::data::fixedcapacity::ringbuffer_idx<myheapalloc<Item, capacity>>;

// Note: myringbuffer_ptr chunk size is actually one less than what is asked for.
template <class Item, int capacity>
using myringbuffer_ptr = pasl::data::fixedcapacity::ringbuffer_ptr<myheapalloc<Item, capacity>>;

// Note: myringbuffer_ptrx chunk size is actually one less than what is asked for.
template <class Item, int capacity>
using myringbuffer_ptrx = pasl::data::fixedcapacity::ringbuffer_ptrx<myheapalloc<Item, capacity>>;

template <class Item, int capacity>
using fftree_stack = pasl::data::fftree_base::fftree<
pasl::data::fftree_base::deque_with_just_size<mystack<Item, capacity>, size_t> >;

template <class Item, int capacity>
using fftree_deque_idx = pasl::data::fftree_base::fftree<
  pasl::data::fftree_base::deque_with_just_size<myringbuffer_idx<Item, capacity>, size_t> >;

template <class Item, int capacity>
using fftree_deque_ptr = pasl::data::fftree_base::fftree<
  pasl::data::fftree_base::deque_with_just_size<myringbuffer_ptr<Item, capacity>, size_t> >;

template <class Item, int capacity>
using fftree_deque_ptrx = pasl::data::fftree_base::fftree<
  pasl::data::fftree_base::deque_with_just_size<myringbuffer_ptrx<Item, capacity>, size_t> >;

template <class Item, int capacity>
using fftree_bag = pasl::data::fftree_base::fftree<
  pasl::data::fftree_base::bag<mystack<Item, capacity>, size_t> >;

template <class Vector>
using bootstrap_fftree_basic = pasl::data::fftree_base::fftree<
  pasl::data::fftree_base::bootstrap_deque_with_just_size<Vector, size_t> >;

template <class Item, int capacity>
using bootstrap_fftree_stack = bootstrap_fftree_basic<mystack<Item, capacity> >;

template <class Item, int capacity>
using bootstrap_fftree_deque_ptr = bootstrap_fftree_basic<myringbuffer_ptr<Item, capacity> >;

template <class Item, int capacity>
using bootstrap_fftree_deque_ptrx = bootstrap_fftree_basic<myringbuffer_ptrx<Item, capacity> >;

template <class Item, int capacity>
using bootstrap_fftree_bag = pasl::data::fftree_base::fftree<
  pasl::data::fftree_base::bootstrap_bag<mystack<Item, capacity>, size_t> >;

template <class Item, int capacity>
using bootseq_stack = pasl::data::fftree_base::fftree<
pasl::data::fftree_base::bootsequence<mystack<Item, capacity>, size_t>>;

template <class Item, int capacity>
using bootseq_deque_ptr = pasl::data::fftree_base::fftree<
  pasl::data::fftree_base::bootsequence<myringbuffer_ptr<Item, capacity>, size_t>>;

template <class Item, int capacity>
using bootseq_deque_ptrx = pasl::data::fftree_base::fftree<
pasl::data::fftree_base::bootsequence<myringbuffer_ptrx<Item, capacity>, size_t>>;

/*

static const int rec_chunk_capacity = 32;

//#include "bootchunkseq_indirect.hpp"

template<class Item, int capacity>
using bootseq_chunk = pasl::data::fixedcapacity::ringbuffer_ptrx< pasl::data::fixedcapacity::heap_allocator<Item, capacity+1 > >;
// TODO: could be better to stick to powers of two?
template<class Item, int top_chunk_capacity>
using bootseq_deque = pasl::data::bootchunkseq::bootchunkseq<Item, bootseq_chunk, top_chunk_capacity, rec_chunk_capacity>;
*/

/*
template<class Item, int capacity>
using bootseq_chunk = pasl::data::fixedcapacity::ringbuffer_ptrx< pasl::data::fixedcapacity::inline_allocator<Item, capacity+1 > >;
*/
// later: could be better to stick to powers of two? => no difference

// Warning: bootseq_chunk belwo is in fact not used by bootchunkseq.hpp, but is used by bootchunkseq_indirect.hpp
// NOTE: can replace bootchunkseq_indirect with bootchunkseq but it's not faster...
/*
template<class Item, int top_chunk_capacity>
using bootseq_deque = pasl::data::bootchunkseq_indirect::bootchunkseq<Item, bootseq_chunk, top_chunk_capacity, rec_chunk_capacity>;
*/

template <class Item>
using tftree = pasl::data::tftree<Item>;


/***********************************************************************/
// TESTING BOOTSTRAP


/***********************************************************************/





typedef size_t result_t;

typedef std::function<void ()> thunk_t;

result_t res = 0;
double exec_time;

/*---------------------------------------------------------------------*/

/*
 * Pseudo-random generator defined by the congruence S' = 69070 * S
 * mod (2^32 - 5).  Marsaglia (CACM July 1993) says on page 107 that
 * this is a ``good one''.  There you go.
 *
 * The literature makes a big fuss about avoiding the division, but
 * for us it is not worth the hassle.
 */
static const unsigned RNGMOD = ((1ULL << 32) - 5);
static const unsigned RNGMUL = 69070U;
unsigned rand_seed;

unsigned myrand() {
  unsigned state = rand_seed;
  state = (unsigned)((RNGMUL * (unsigned long long)state) % RNGMOD);
  rand_seed = state;
  return state;
}

void mysrand(unsigned seed) {
  seed %= RNGMOD;
  seed += (seed == 0); /* 0 does not belong to the multiplicative
                        group.  Use 1 instead */
  rand_seed = seed;
}

/*---------------------------------------------------------------------*/

class bytes_1 {
public:
  char data;
  bytes_1() { }
  bytes_1(char c) : data(c) { }
  bytes_1(size_t i) {
    data = (char) (i % 256);
  }
  size_t get() const {
    return (size_t) data;
  }
  char get_char() const {
    return data;
  }
  bool operator==(const bytes_1 other) {
    return data == other.data;
  }
  operator unsigned char() const {
    return data;
  }
};

class bytes_8 {
public:
  uint64_t data;
  bytes_8() { }
  bytes_8(char c) {
    data = (uint64_t)c;
  }
  bytes_8(size_t i) {
    data = i;
  }
  size_t get() const {
    return data;
  }
  char get_char() const {
    return (char) (data % 256);
  }
  bool operator==(const bytes_8 other) {
    return data == other.data;
  }
};

class bytes_64 {
public:
  int64_t data[8];
  bytes_64() { }
  bytes_64(char c) {
    for (int k = 0; k < 8; k++)
      data[k] = (int64_t)c;
  }
  bytes_64(size_t i) {
    for (int k = 0; k < 8; k++)
      data[k] = i;
  }
  size_t get() const {
    return data[0];
  }
  char get_char() const {
    return (char) (data[0] % 256);
  }
  bool operator==(const bytes_64 other) {
    return data == other.data;
  }
};

/* reorders in a random fashion the items of the given container
 */
template <class Datastruct>
void shuffle(Datastruct& d) {
  size_t sz = d.size();
  for (size_t i = 0; i < sz; i++)
    std::swap(d[i], d[rand() % sz]);
}

/*---------------------------------------------------------------------*/
/* Scenarios */

template <class Datastruct, bool should_pop>
thunk_t scenario_real_lifo_with_or_without_pop() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t repeat = (size_t) cmdline::parse_or_default_int("r", 1000);
  size_t block = nb_total / repeat;
  return [=] {
    printf("length %lld\n",block);
    uint64_t start_time = microtime::now();
    Datastruct d;
    res = 0;
    for (size_t j = 0; j < repeat; j++) {
      for (size_t i = 0; i < block; i++)
        d.push_back(value_type(i));
      if (should_pop)
        for (size_t i = 0; i < block; i++)
          res += d.pop_back().get();
    }
    if (! should_pop)
      res += d.size();
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_real_lifo() {
  return scenario_real_lifo_with_or_without_pop<Datastruct, true>();
}

template <class Datastruct>
thunk_t scenario_fill_back() {
  return scenario_real_lifo_with_or_without_pop<Datastruct, false>();
}

template <class Datastruct>
thunk_t scenario_real_fifo() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t repeat = (size_t) cmdline::parse_or_default_int("r", 1000);
  size_t block = nb_total / repeat;
  return [=] {
    printf("length %lld\n",block);
    uint64_t start_time = microtime::now();
    Datastruct d;
    res = 0;
    for (size_t j = 0; j < repeat; j++) {
      for (size_t i = 0; i < block; i++)
        d.push_back(value_type(i));
      for (size_t i = 0; i < block; i++)
        res += d.pop_front().get();
    }
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_buffer_usage() {
  typedef typename Datastruct::value_type value_type;
  // size_t buffersize = (size_t) cmdline::parse_or_default_int("buffersize", 512);
  size_t chunk = (size_t) cmdline::parse_or_default_int("chunk", 512);
  size_t n = (size_t) cmdline::parse_or_default_int("n", 1000);
  size_t onlypushpop = (size_t) cmdline::parse_or_default_int("onlypushpop", 0); 
  size_t skipalloc = (size_t) cmdline::parse_or_default_int("skipalloc", 0); 
  //size_t repeat = (size_t) cmdline::parse_or_default_int("r", 1000);
  size_t repeat = n / chunk;
  return [=] {
    uint64_t start_time = microtime::now();
    res = 0;
    if (skipalloc) {
      Datastruct d;
      if (onlypushpop) {
        // note: only going to chunk-1 because of some ringbuffers needing empty cell
        for (size_t j = 0; j < repeat; j++) {
          for (size_t i = 0; i < chunk-1; i++)
            d.push_back(value_type(i));
          for (size_t i = 0; i < chunk-1; i++)
            res += d.pop_front().get();
        }
      } else {
        for (size_t j = 0; j < repeat; j++) {
          size_t i = 0;
          while (! d.full()) {
            d.push_back(value_type(i++));
          }
          while (! d.empty()) {
            res += d.pop_front().get();
          }
        }
      }
    } else {
      if (onlypushpop)
        atomic::die("onlypushpop requires -skipalloc 0");
      Datastruct* d;
      // todo: factorize code with above
      for (size_t j = 0; j < repeat; j++) {
        d = new Datastruct();
        size_t i = 0;
        while (! d->full()) {
          d->push_back(value_type(i++));
        }
        while (! d->empty()) {
          res += d->pop_front().get();
        }
        delete d;
      }
    }
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_empty_back() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 100000000);
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < nb_total; i++)
      d.push_back(value_type(i));
    uint64_t start_time = microtime::now();
    for (size_t i = 0; i < nb_total; i++)
      res += d.pop_back().get();
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_clear() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 100000000);
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < nb_total; i++)
        d.push_back(value_type(i));
    uint64_t start_time = microtime::now();
    d.clear();
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_pushn() {
  typedef typename Datastruct::value_type value_type;
  size_t n = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t m = (size_t) cmdline::parse_or_default_int("m", 0);
  return [=] {
    Datastruct d;
    value_type* items = (value_type*)malloc(sizeof(value_type)*n);
    for (size_t i = 0; i < n; i++)
      items[i] = value_type(i);
    for (size_t i = 0; i < m; i++)
      d.push_back(value_type(i));
    uint64_t start_time = microtime::now();
    d.pushn_back(items, n);
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_popn() {
  typedef typename Datastruct::value_type value_type;
  size_t n = (size_t) cmdline::parse_or_default_int("n", 100000000);
  double f = cmdline::parse_or_default_double("f", 0.1);
  double x = (double)n * f;
  size_t m = (size_t)x;
  return [=] {
    Datastruct d;
    value_type* items = (value_type*)malloc(sizeof(value_type)*m);
    for (size_t i = 0; i < n; i++)
      d.push_back(value_type(i));
    uint64_t start_time = microtime::now();
    d.popn_back(items, m);
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_random_lifo() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 10000000);
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_real_distribution<> dis(1, 2);
  return [=] {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(-0.5, 0.5);
    Datastruct d;
    d.push_back(value_type((size_t)0));
    res = 0;
    size_t max_size = 0;
    uint64_t start_time = microtime::now();
    for (size_t i = 0; i < nb_total; i++) {
      size_t sz = d.size();
      int64_t nb = (int64_t)(dis(gen) * (double)sz);
      if (nb >= 0) {
        nb = std::max(nb, (int64_t)1);
        for (int64_t i = 0; i < nb; i++)
          d.push_back(value_type((size_t)i));
      } else {
        for (int64_t i = 0; i < -1*nb; i++)
          res += d.pop_back().get();
      }
      max_size = std::max(sz, max_size);
    }
    exec_time = microtime::seconds_since(start_time);
    printf("max_size\t%lld\n", (long long)max_size);
  };
}

template <class Datastruct>
thunk_t scenario_linear_search() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 1000000);
  size_t repeat = (size_t) cmdline::parse_or_default_int("r", 100);
  size_t block = nb_total / repeat;
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < block; i++)
      d.push_back(value_type(i));
    shuffle(d);
    uint64_t start_time = microtime::now();
    for (size_t i = 0; i < repeat; i++)
      std::find(d.begin(), d.end(), value_type(i));
    exec_time = microtime::seconds_since(start_time);
    printf("block\t%lld\n",block);
  };
}

template <class Datastruct>
thunk_t scenario_random_insert() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 10000000);
  size_t repeat = (size_t) cmdline::parse_or_default_int("r", 10000);
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < nb_total; i++)
      d.push_back(i);
    uint64_t start_time = microtime::now();
    for (size_t i = 0; i < repeat; i++) {
      auto it = d.begin();
      size_t tgt = myrand() % d.size();
      d.insert(it + tgt, value_type(i));
    }
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_random_erase() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 10000000);
  size_t repeat = (size_t) cmdline::parse_or_default_int("r", 10000);
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < nb_total; i++)
      d.push_back(i);
    uint64_t start_time = microtime::now();
    for (size_t i = 0; i < repeat; i++) {
      auto it = d.begin();
      size_t tgt = myrand() % d.size();
      size_t nb = std::min(tgt, nb_total - 1);
      d.erase(it + tgt, it + tgt + nb);
    }
    exec_time = microtime::seconds_since(start_time);
  };
} 

template <class Datastruct>
thunk_t scenario_sort() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 100000000);
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < nb_total; i++) {
      d.push_back(value_type(i));
    }
    shuffle(d);
    uint64_t start_time = microtime::now();
    std::sort(d.begin(), d.end());
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_random_access() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t nb_access = (size_t) cmdline::parse_or_default_int("r", 10000000);
  size_t nb_random = (size_t) cmdline::parse_or_default_int("p", 1000);
  size_t nb_batch = nb_access / nb_random;
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < nb_total; i++)
      d.push_back(value_type(i));
    uint64_t start_time = microtime::now();
    for (size_t i = 0; i < nb_batch; i++) {
      size_t ix = rand() % nb_total;
      auto it = d.begin() + ix;
      for (size_t j = 0; j < nb_random; j++) {
        value_type v = *it;
        res += v.get();
        it++;
      }
    }
    exec_time = microtime::seconds_since(start_time);
  };
}

#ifdef HAVE_CORD
template <>
thunk_t scenario_random_access<cord_wrapper<bytes_1> >() {
  return [] { assert(false); };
}
template <>
thunk_t scenario_random_access<cord_wrapper<bytes_8> >() {
  return [] { assert(false); };
}
template <>
thunk_t scenario_random_access<cord_wrapper<bytes_64> >() {
  return [] { assert(false); };
}
#endif

template <class Datastruct>
thunk_t scenario_push_pop_at_offset() { 
  typedef typename Datastruct::value_type value_type;
  size_t nb_total = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t offset = (size_t) cmdline::parse_or_default_int("offset", 0);
  size_t conseq = (size_t) cmdline::parse_or_default_int("conseq", 1);
  size_t nb_rounds = nb_total / (2 * conseq);
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < offset; i++)
      d.push_back(value_type(i));
    uint64_t start_time = microtime::now();

    if (conseq == 1) {
      for (size_t i = 0; i < nb_rounds; i++) {
        d.push_back(value_type(i));
        atomic::compiler_barrier(); // =>  asm volatile("" ::: "memory");
        res += d.pop_back().get();
      }
    } else {
      for (size_t i = 0; i < nb_rounds; i++) {
        for (size_t c = 0; c < conseq; c++) {
          d.push_back(value_type(i+c));
          atomic::compiler_barrier(); // =>  asm volatile("" ::: "memory");
        }
        for (size_t c = 0; c < conseq; c++) {
          res += d.pop_back().get();
          atomic::compiler_barrier(); // =>  asm volatile("" ::: "memory");
        }
      }

    }
    exec_time = microtime::seconds_since(start_time);
  };
}

template <class Datastruct>
thunk_t scenario_foreach() {
  typedef typename Datastruct::value_type value_type;
  typedef typename Datastruct::size_type size_type;
  size_t n = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t r = (size_t) cmdline::parse_or_default_int("r", 1);
  return [=] {
    Datastruct d;
    for (size_t i = 0; i < n; i++)
      d.push_back(value_type(i));
    size_type sum = 0;
    uint64_t start_time = microtime::now();
    for (size_type k = 0; k < r; k++)
      d.for_each([&sum] (size_type i, const value_type& v){ sum += (size_type)v.get(); });
    exec_time = microtime::seconds_since(start_time);
    printf("sum\t%d\n", (int)sum);
  };
}

template <class Datastruct>
thunk_t scenario_fill() {
  typedef typename Datastruct::value_type value_type;
  typedef typename Datastruct::size_type size_type;
  size_t n = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t r = (size_t) cmdline::parse_or_default_int("r", 1);
  return [=] {
    size_type res;
    value_type val;
    uint64_t start_time = microtime::now();
    for (size_type k = 0; k < r; k++) {
      Datastruct d(n, val);
      value_type xx = d[0];
      res = (size_type)xx.get();
    }
    exec_time = microtime::seconds_since(start_time);
  };
}

// p should be 2 or more
template <class Datastruct, bool should_push, bool should_pop>
void _scenario_split_merge(Datastruct* ds, size_t n, size_t p, size_t r, size_t h) {
  typedef typename Datastruct::value_type value_type;
  typedef typename Datastruct::size_type size_type;
  
  srand(14);
  for (size_type i = 0; i < p; i++) {
    size_type nb = n / p;
    #ifndef DONT_COMPILE_BOOTSEQ_DEQUE 
    for (size_type j = 0; j < nb; j++) 
      ds[i].push_back(value_type((char)1));
    #else
    ds[i].pushn_back(value_type((char)1), nb);
    #endif
  }
  uint64_t start_time = microtime::now();
  for (size_type k = 0; k < r; k++) {
    size_type b1 = rand() % p;
    size_type b2 = rand() % (p-1);
    if (b2 >= b1)
      b2++;
    // b1 != b2
    ds[b1].transfer_to_back(ds[b2]);
    // ds[b2].empty() == true
    size_type b3 = rand() % (p-1);
    if (b3 >= b2)
      b3++;
    // b3 != b2
    Datastruct& src = ds[b3];
    if (src.size() > 1)
      src.split_approximate(ds[b2]);
    if (should_push)
      for (size_t i = 0; i < h; i++)
        src.push_back(value_type(i));
    if (should_pop)
      for (size_t i = 0; i < h; i++)
        res += (size_type)src.pop_front().get();
  }
  exec_time = microtime::seconds_since(start_time);
  res = 0;
  for (int i = 0; i < p; i++)
    res += ds[i].size();
}


template <class Datastruct>
thunk_t scenario_split_merge() {
  typedef typename Datastruct::value_type value_type;
  typedef typename Datastruct::size_type size_type;
  size_t n = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t p = (size_t) cmdline::parse_or_default_int("p", std::max(n/100, (size_type)2));
  size_t r = (size_t) cmdline::parse_or_default_int("r", 100000);
  size_t h = (size_t) cmdline::parse_or_default_int("h", 0);
  bool should_push = cmdline::parse_or_default_bool("should_push", true);
  bool should_pop = cmdline::parse_or_default_bool("should_pop", false);

  return [=] {
    Datastruct* ds = new Datastruct[p];
    if (should_push && should_pop)
      _scenario_split_merge<Datastruct,true,true>(ds, n, p, r, h);
    else if (! should_push && should_pop)
      _scenario_split_merge<Datastruct,false,true>(ds, n, p, r, h);
    else if (should_push && ! should_pop)
      _scenario_split_merge<Datastruct,true,false>(ds, n, p, r, h);
    else
      _scenario_split_merge<Datastruct,false,false>(ds, n, p, r, h);
    delete [] ds;
  };
}

template <class Datastruct, class Filter>
void filter(Datastruct& dst, Datastruct& src, const Filter& filt, int cutoff) {
  typedef typename Datastruct::value_type value_type;
  if (src.size() <= cutoff) {
    while (! src.empty()) {
      value_type item = src.pop_back();
      if (filt(item))
        dst.push_back(item);
    }
  } else {
//    int mid = src.size() / 2;
    Datastruct src2;
    Datastruct dst2;
    src.split_approximate(src2);
  //  src.transfer_from_back_to_front_by_position(src2, src.begin() + mid);
    filter(dst,  src,  filt, cutoff);
    filter(dst2, src2, filt, cutoff);
    dst.transfer_to_back(dst2);
  }
}

template <class Datastruct>
thunk_t scenario_filter() {
  typedef typename Datastruct::size_type size_type;
  typedef typename Datastruct::value_type value_type;
  size_t cutoff = cmdline::parse_or_default_int("cutoff", 8096);
  size_t n = cmdline::parse_or_default_int("n", 100000000);
  size_t r = (size_t) cmdline::parse_or_default_int("r", 1);
  size_t nb_total = n / r;
  const size_t m = 1<<30;
  return [=] {
    Datastruct src;
    Datastruct dst;
    for (size_t i = 0; i < nb_total; i++)
      src.push_back(value_type(i));
    auto filt = [] (value_type v) {
      return (v.get() % m) != 0;
    };
    uint64_t start_time = microtime::now();
    for (size_t i = 0; i < r; i++) {
      filter(dst, src, filt, cutoff);
      dst.swap(src);
    }
    exec_time = microtime::seconds_since(start_time);
    //assert(dst.size() == n - ((n+m-1)/m));
    printf("length %lld\n",nb_total);
  };
}

void failwith(std::string s) {
  std::cout << s << std::endl;
  exit(0);
}

/*
template <class Datastruct1, class Datastruct2>
void test_split_merge() {
  typedef typename Datastruct1::value_type value_type;
  typedef typename Datastruct1::size_type size_type;
  size_t n = (size_t) cmdline::parse_or_default_int("n", 100000000);
  size_t p = (size_t) cmdline::parse_or_default_int("p", std::max(n/100, (size_type)1));
  size_t r = (size_t) cmdline::parse_or_default_int("r", 100000);
 
  Datastruct1* ds1 = new Datastruct1[p]; 
  Datastruct2* ds2 = new Datastruct2[p]; 
  _scenario_split_merge<Datastruct1>(ds1);
  _scenario_split_merge<Datastruct2>(ds2);
  for (size_type i = 0; i < p; i++) {
    if (ds1[i].size() != ds2[i].size()) {
      failwith("bogus size\n");
    }
    for (size_type j = 0; j < ds1[i].size(); j++) {
      if (ds1[i][j].data != ds2[i][j].data)
	failwith("bogus value\n");
    }
  }
  delete [] ds1;
  delete [] ds2;
  printf("ok\n");
}
*/

/*---------------------------------------------------------------------*/

thunk_t bogus() {
  return [] {
    atomic::die("bogus scenario");
  };
}

template<class datastruct>
thunk_t profile_ringbuffer() {
  cmdline::argmap<thunk_t> tmg;
#ifndef DONT_COMPILE_BUFFER_USAGE
  tmg.add("buffer_usage", scenario_buffer_usage<datastruct>());
#endif
  return tmg.find_by_arg("test");
}

template<class datastruct>
thunk_t profile_basic() {
  cmdline::argmap<thunk_t> tmg;
#ifndef DONT_COMPILE_BUFFER_USAGE
  tmg.add("buffer_usage", bogus());
#endif
#ifndef DONT_COMPILE_SPLIT_MERGE
  tmg.add("split_merge", bogus());
#endif
#ifndef DONT_COMPILE_FIFO_LIFO
  tmg.add("real_fifo", scenario_real_fifo<datastruct>());
  tmg.add("real_lifo", scenario_real_lifo<datastruct>());
#endif
#ifndef DONT_COMPILE_OTHERS
  tmg.add("random_access", bogus());
  //  tmg.add("linear_search", bogus());
  tmg.add("fill_back", scenario_fill_back<datastruct>());
  tmg.add("filter", bogus());
#endif
#if FULLCOMPIL_SCENARIO
  tmg.add("fill", bogus());
  tmg.add("foreach", bogus());
  tmg.add("empty_back", scenario_empty_back<datastruct>());
  tmg.add("random_lifo", scenario_random_lifo<datastruct>());
  tmg.add("random_insert", bogus());
  tmg.add("clear", scenario_clear<datastruct>());
  //  tmg.add("pushn", bogus());
  //  tmg.add("popn", bogus());
  tmg.add("push_pop_at_offset", scenario_push_pop_at_offset<datastruct>());
#endif
 return tmg.find_by_arg("test");
}

//! \todo: find a technique to factorize without writing a wrapper if possible
template<class datastruct>
thunk_t profile_stl() {
  cmdline::argmap<thunk_t> tmg;
#ifndef DONT_COMPILE_BUFFER_USAGE
  tmg.add("buffer_usage", bogus());
#endif
#ifndef DONT_COMPILE_SPLIT_MERGE
  tmg.add("split_merge", scenario_split_merge<datastruct>());
#endif
#ifndef DONT_COMPILE_FIFO_LIFO
  tmg.add("real_fifo", scenario_real_fifo<datastruct>());
  tmg.add("real_lifo", scenario_real_lifo<datastruct>());
#endif
#ifndef DONT_COMPILE_OTHERS
  tmg.add("fill_back", scenario_fill_back<datastruct>());
  tmg.add("filter", scenario_filter<datastruct>());
  //tmg.add("random_access", scenario_random_access<datastruct>());
#endif

  //  tmg.add("linear_search", scenario_linear_search<datastruct>());
#if FULLCOMPIL_SCENARIO
  tmg.add("foreach", scenario_foreach<datastruct>());
  tmg.add("fill", scenario_fill<datastruct>());
  tmg.add("empty_back", scenario_empty_back<datastruct>());
  tmg.add("random_lifo", scenario_random_lifo<datastruct>());
  tmg.add("random_insert", scenario_random_insert<datastruct>());
  tmg.add("clear", scenario_clear<datastruct>());
  //  tmg.add("pushn", scenario_pushn<datastruct>());
  //  tmg.add("popn", scenario_popn<datastruct>());
  tmg.add("push_pop_at_offset", scenario_push_pop_at_offset<datastruct>());
#endif
  return tmg.find_by_arg("test");
}

template<class item, int chunksize>
void add_ringbuffer_cases(cmdline::argmap<thunk_t>& tmg) 
{
  return;
  tmg.add("ringbuffer_idx", profile_ringbuffer<myringbuffer_idx<item,chunksize>>());
  tmg.add("ringbuffer_ptr", profile_ringbuffer<myringbuffer_ptr<item,chunksize>>());
  tmg.add("ringbuffer_ptrx", profile_ringbuffer<myringbuffer_ptrx<item,chunksize>>());
}

template<class item>
void dispatch2() {
  cmdline::argmap<thunk_t> tmg;
  static const size_t capacity = 1024*1024*128;
  int chunk = cmdline::parse_or_default_int("chunk", 512);
  
#ifndef DONT_COMPILE_BOOTSTRAP_FFTREE_STACK
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("bootstrap_fftree_stack", profile_stl<bootstrap_fftree_stack<item,64>>());
  else if (chunk == 128)
    tmg.add("bootstrap_fftree_stack", profile_stl<bootstrap_fftree_stack<item,128>>());
  else
#endif
    if (chunk == 256)
      tmg.add("bootstrap_fftree_stack", profile_stl<bootstrap_fftree_stack<item,256>>());
    else if (chunk == 512)
      tmg.add("bootstrap_fftree_stack", profile_stl<bootstrap_fftree_stack<item,512>>());
    else if (chunk == 2048)
      tmg.add("bootstrap_fftree_stack", profile_stl<bootstrap_fftree_stack<item,2048>>());
    else if (chunk == 1024)
      tmg.add("bootstrap_fftree_stack", profile_stl<bootstrap_fftree_stack<item,1024>>());
#ifdef FULLCOMPIL_CHUNK
    else if (chunk == 4096)
      tmg.add("bootstrap_fftree_stack", profile_stl<bootstrap_fftree_stack<item,4096>>());
    else if (chunk == 8192)
      tmg.add("bootstrap_fftree_stack", profile_stl<bootstrap_fftree_stack<item,8192>>());
#endif
    else
      atomic::die("bogus argument for `chunk`\n");
#endif
  
#ifndef DONT_COMPILE_BOOTSTRAP_FFTREE_DEQUE_PTR
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("bootstrap_fftree_deque_ptr", profile_stl<bootstrap_fftree_deque_ptr<item,64>>());
  else if (chunk == 128)
    tmg.add("bootstrap_fftree_deque_ptr", profile_stl<bootstrap_fftree_deque_ptr<item,128>>());
  else
#endif
    if (chunk == 256)
      tmg.add("bootstrap_fftree_deque_ptr", profile_stl<bootstrap_fftree_deque_ptr<item,256>>());
    else if (chunk == 512)
      tmg.add("bootstrap_fftree_deque_ptr", profile_stl<bootstrap_fftree_deque_ptr<item,512>>());
    else if (chunk == 2048)
      tmg.add("bootstrap_fftree_deque_ptr", profile_stl<bootstrap_fftree_deque_ptr<item,2048>>());
    else if (chunk == 1024)
      tmg.add("bootstrap_fftree_deque_ptr", profile_stl<bootstrap_fftree_deque_ptr<item,1024>>());
#ifdef FULLCOMPIL_CHUNK
    else if (chunk == 4096)
      tmg.add("bootstrap_fftree_deque_ptr", profile_stl<bootstrap_fftree_deque_ptr<item,4096>>());
    else if (chunk == 8192)
      tmg.add("bootstrap_fftree_deque_ptr", profile_stl<bootstrap_fftree_deque_ptr<item,8192>>());
#endif
    else
      atomic::die("bogus argument for `chunk`\n");
#endif
  
#ifndef DONT_COMPILE_BOOTSTRAP_FFTREE_DEQUE_PTRX
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("bootstrap_fftree_deque_ptrx", profile_stl<bootstrap_fftree_deque_ptrx<item,64>>());
  else if (chunk == 128)
    tmg.add("bootstrap_fftree_deque_ptrx", profile_stl<bootstrap_fftree_deque_ptrx<item,128>>());
  else
#endif
    if (chunk == 256)
      tmg.add("bootstrap_fftree_deque_ptrx", profile_stl<bootstrap_fftree_deque_ptrx<item,256>>());
    else if (chunk == 512)
      tmg.add("bootstrap_fftree_deque_ptrx", profile_stl<bootstrap_fftree_deque_ptrx<item,512>>());
    else if (chunk == 2048)
      tmg.add("bootstrap_fftree_deque_ptrx", profile_stl<bootstrap_fftree_deque_ptrx<item,2048>>());
    else if (chunk == 1024)
      tmg.add("bootstrap_fftree_deque_ptrx", profile_stl<bootstrap_fftree_deque_ptrx<item,1024>>());
#ifdef FULLCOMPIL_CHUNK
    else if (chunk == 4096)
      tmg.add("bootstrap_fftree_deque_ptrx", profile_stl<bootstrap_fftree_deque_ptrx<item,4096>>());
    else if (chunk == 8192)
      tmg.add("bootstrap_fftree_deque_ptrx", profile_stl<bootstrap_fftree_deque_ptrx<item,8192>>());
#endif
    else
      atomic::die("bogus argument for `chunk`\n");
#endif
  
#ifndef DONT_COMPILE_BOOTSTRAP_FFTREE_BAG
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("bootstrap_fftree_bag", profile_stl<bootstrap_fftree_bag<item,64>>());
  else if (chunk == 128)
    tmg.add("bootstrap_fftree_bag", profile_stl<bootstrap_fftree_bag<item,128>>());
  else
#endif
    if (chunk == 256)
      tmg.add("bootstrap_fftree_bag", profile_stl<bootstrap_fftree_bag<item,256>>());
    else if (chunk == 512)
      tmg.add("bootstrap_fftree_bag", profile_stl<bootstrap_fftree_bag<item,512>>());
    else if (chunk == 2048)
      tmg.add("bootstrap_fftree_bag", profile_stl<bootstrap_fftree_bag<item,2048>>());
    else if (chunk == 1024)
      tmg.add("bootstrap_fftree_bag", profile_stl<bootstrap_fftree_bag<item,1024>>());
#ifdef FULLCOMPIL_CHUNK
    else if (chunk == 4096)
      tmg.add("bootstrap_fftree_bag", profile_stl<bootstrap_fftree_bag<item,4096>>());
    else if (chunk == 8192)
      tmg.add("bootstrap_fftree_bag", profile_stl<bootstrap_fftree_bag<item,8192>>());
#endif
    else
      atomic::die("bogus argument for `chunk`\n");
#endif


#ifndef DONT_COMPILE_BOOTSEQ_DEQUE
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("bootseq_deque_ptr", profile_stl<bootseq_deque_ptr<item,64>>());
  else if (chunk == 128)
    tmg.add("bootseq_deque_ptr", profile_stl<bootseq_deque_ptr<item,128>>());
  else
#endif
  if (chunk == 256)
    tmg.add("bootseq_deque_ptr", profile_stl<bootseq_deque_ptr<item,256>>());
  else if (chunk == 512)
    tmg.add("bootseq_deque_ptr", profile_stl<bootseq_deque_ptr<item,512>>());
  else if (chunk == 1024)
    tmg.add("bootseq_deque_ptr", profile_stl<bootseq_deque_ptr<item,1024>>());
#ifdef FULLCOMPIL_CHUNK
  else if (chunk == 2048)
    tmg.add("bootseq_deque_ptr", profile_stl<bootseq_deque_ptr<item,2048>>());
  else if (chunk == 4096)
    tmg.add("bootseq_deque_ptr", profile_stl<bootseq_deque_ptr<item,4096>>());
  else if (chunk == 8192)
    tmg.add("bootseq_deque_ptr", profile_stl<bootseq_deque_ptr<item,8192>>());
#endif
  else
    atomic::die("bogus argument for `chunk`\n");

#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("bootseq_deque_ptrx", profile_stl<bootseq_deque_ptrx<item,64>>());
  else if (chunk == 128)
    tmg.add("bootseq_deque_ptrx", profile_stl<bootseq_deque_ptrx<item,128>>());
  else
#endif  
  if (chunk == 256)
    tmg.add("bootseq_deque_ptrx", profile_stl<bootseq_deque_ptrx<item,256>>());
  else if (chunk == 512)
    tmg.add("bootseq_deque_ptrx", profile_stl<bootseq_deque_ptrx<item,512>>());
  else if (chunk == 1024)
    tmg.add("bootseq_deque_ptrx", profile_stl<bootseq_deque_ptrx<item,1024>>());
#ifdef FULLCOMPIL_CHUNK
  else if (chunk == 2048)
    tmg.add("bootseq_deque_ptrx", profile_stl<bootseq_deque_ptrx<item,2048>>());
  else if (chunk == 4096)
    tmg.add("bootseq_deque_ptrx", profile_stl<bootseq_deque_ptrx<item,4096>>());
  else if (chunk == 8192)
    tmg.add("bootseq_deque_ptrx", profile_stl<bootseq_deque_ptrx<item,8192>>());
#endif
  else
    atomic::die("bogus argument for `chunk`\n");

#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("bootseq_deque_stack", profile_stl<bootseq_stack<item,64>>());
  else if (chunk == 128)
    tmg.add("bootseq_deque_stack", profile_stl<bootseq_stack<item,128>>());
  else
#endif  
  if (chunk == 256)
    tmg.add("bootseq_stack", profile_stl<bootseq_stack<item,256>>());
  else if (chunk == 512)
    tmg.add("bootseq_stack", profile_stl<bootseq_stack<item,512>>());
  else if (chunk == 1024)
    tmg.add("bootseq_stack", profile_stl<bootseq_stack<item,1024>>());
#ifdef FULLCOMPIL_CHUNK
  else if (chunk == 2048)
    tmg.add("bootseq_deque_stack", profile_stl<bootseq_stack<item,2048>>());
  else if (chunk == 4096)
    tmg.add("bootseq_deque_stack", profile_stl<bootseq_stack<item,4096>>());
  else if (chunk == 8192)
    tmg.add("bootseq_deque_stack", profile_stl<bootseq_stack<item,8192>>());
#endif
  else
    atomic::die("bogus argument for `chunk`\n");
#endif

#ifndef DONT_COMPILE_RINGBUFFERS
  if (chunk == 512)
    add_ringbuffer_cases<item,512>(tmg);
  else if (chunk == 2048)
    add_ringbuffer_cases<item,2048>(tmg);
  else if (chunk == 4096)
    add_ringbuffer_cases<item,4096>(tmg);
  else
    atomic::die("bogus argument for `chunk`\n");
#endif
#ifndef DONT_COMPILE_DEQUE
  tmg.add("deque", profile_stl< pasl::data::stl::deque_seq<item>>());
#endif
#ifndef DONT_COMPILE_STACK
  tmg.add("circular_array", profile_basic<myringbuffer_ptr<item,capacity>>());
  tmg.add("stack", profile_basic<mystack<item,capacity>>());
#endif
#ifndef DONT_COMPILE_VECTOR
  tmg.add("vector", profile_stl<pasl::data::stl::vector_seq<item>>());
#endif
#ifndef DONT_COMPILE_BAGS
  tmg.add("fftree_bag", profile_stl<fftree_bag<item,512>>());
  tmg.add("ls_bag", profile_stl<pasl::data::Bag<item>>());
#endif
#ifndef DONT_COMPILE_TFTREE
  tmg.add("tftree", profile_stl<tftree<item>>());
#endif
#ifdef HAVE_ROPE
  tmg.add("rope", profile_stl<pasl::data::stl::rope_seq<item>>());
#endif
#ifdef HAVE_CORD
  tmg.add("cord", profile_stl<pasl::data::cord_wrapper<item>>());
#endif


#ifndef DONT_COMPILE_FFTREE_STACK
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("fftree_stack", profile_stl<fftree_stack<item,64>>());
  else if (chunk == 128)
    tmg.add("fftree_stack", profile_stl<fftree_stack<item,128>>());
  else 
#endif
  if (chunk == 256)
    tmg.add("fftree_stack", profile_stl<fftree_stack<item,256>>());
  else if (chunk == 512)
    tmg.add("fftree_stack", profile_stl<fftree_stack<item,512>>());
  else if (chunk == 2048)
    tmg.add("fftree_stack", profile_stl<fftree_stack<item,2048>>());
  else if (chunk == 1024)
    tmg.add("fftree_stack", profile_stl<fftree_stack<item,1024>>());
#ifdef FULLCOMPIL_CHUNK
  else if (chunk == 4096)
    tmg.add("fftree_stack", profile_stl<fftree_stack<item,4096>>());
  else if (chunk == 8192)
    tmg.add("fftree_stack", profile_stl<fftree_stack<item,8192>>());
#endif
  else
    atomic::die("bogus argument for `chunk`\n");
#endif

#ifndef DONT_COMPILE_FFTREE_DEQUE_IDX
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("fftree_deque_idx", profile_stl<fftree_deque_idx<item,64>>());
  else if (chunk == 128)
    tmg.add("fftree_deque_idx", profile_stl<fftree_deque_idx<item,128>>());
  else if (chunk == 256)
    tmg.add("fftree_deque_idx", profile_stl<fftree_deque_idx<item,256>>());
  else
#endif
  if (chunk == 512)
    tmg.add("fftree_deque_idx", profile_stl<fftree_deque_idx<item,512>>());
  else if (chunk == 2048)
    tmg.add("fftree_deque_idx", profile_stl<fftree_deque_idx<item,2048>>());
  else if (chunk == 4096)
    tmg.add("fftree_deque_idx", profile_stl<fftree_deque_idx<item,4096>>());
#ifdef FULLCOMPIL_CHUNK
  else if (chunk == 1024)
    tmg.add("fftree_deque_idx", profile_stl<fftree_deque_idx<item,1024>>());
  else if (chunk == 8192)
    tmg.add("fftree_deque_idx", profile_stl<fftree_deque_idx<item,8192>>());
#endif
  else
    atomic::die("bogus argument for `chunk`\n");
#endif

#ifndef DONT_COMPILE_FFTREE_DEQUE_PTR
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("fftree_deque_ptr", profile_stl<fftree_deque_ptr<item,64>>());
  else if (chunk == 128)
    tmg.add("fftree_deque_ptr", profile_stl<fftree_deque_ptr<item,128>>());
  else
#endif
  if (chunk == 256)
    tmg.add("fftree_deque_ptr", profile_stl<fftree_deque_ptr<item,256>>());
  else if (chunk == 512)
    tmg.add("fftree_deque_ptr", profile_stl<fftree_deque_ptr<item,512>>());
  else if (chunk == 2048)
    tmg.add("fftree_deque_ptr", profile_stl<fftree_deque_ptr<item,2048>>());
  else if (chunk == 4096)
    tmg.add("fftree_deque_ptr", profile_stl<fftree_deque_ptr<item,4096>>());
#ifdef FULLCOMPIL_CHUNK
  else if (chunk == 1024)
    tmg.add("fftree_deque_ptr", profile_stl<fftree_deque_ptr<item,1024>>());
  else if (chunk == 8192)
    tmg.add("fftree_deque_ptr", profile_stl<fftree_deque_ptr<item,8192>>());
#endif
  else
    atomic::die("bogus argument for `chunk`\n");
#endif

#ifndef DONT_COMPILE_FFTREE_DEQUE_PTRX
#ifdef FULLCOMPIL_CHUNK
  if (chunk == 64)
    tmg.add("fftree_deque_ptrx", profile_stl<fftree_deque_ptrx<item,64>>());
  else if (chunk == 128)
    tmg.add("fftree_deque_ptrx", profile_stl<fftree_deque_ptrx<item,128>>());
  else 
#endif
  if (chunk == 256)
    tmg.add("fftree_deque_ptrx", profile_stl<fftree_deque_ptrx<item,256>>());
  else if (chunk == 512)
    tmg.add("fftree_deque_ptrx", profile_stl<fftree_deque_ptrx<item,512>>());
  else if (chunk == 1024)
    tmg.add("fftree_deque_ptrx", profile_stl<fftree_deque_ptrx<item,1024>>());
  else if (chunk == 2048)
    tmg.add("fftree_deque_ptrx", profile_stl<fftree_deque_ptrx<item,2048>>());
  else if (chunk == 4096)
    tmg.add("fftree_deque_ptrx", profile_stl<fftree_deque_ptrx<item,4096>>());
#ifdef FULLCOMPIL_CHUNK
  else if (chunk == 8192)
    tmg.add("fftree_deque_ptrx", profile_stl<fftree_deque_ptrx<item,8192>>());
#endif
  else
    atomic::die("bogus argument for `chunk` x\n");
#endif

//! \todo: factorize copy paste
  tmg.find_by_arg("seq")();
}

void dispatch1() {
  size_t itemsize = (size_t) cmdline::parse_or_default_int("itemsize", 8);
  if (itemsize == 8)
    dispatch2<bytes_8>();
#ifdef FULLCOMPIL_ITEMSIZE
  else if (itemsize == 1)
    dispatch2<bytes_1>();
  else if (itemsize == 64)
    dispatch2<bytes_64>();
#endif
  else
    atomic::die("itemsize should be 1, 8 or 64.");
}

/*---------------------------------------------------------------------*/

int main(int argc, char** argv) {
  cmdline::set(argc, argv);
  if (! pasl::data::fixedcapacity::is_trivially_copyable<bytes_8>())
    printf("WARNING: type bytes_8 is not trivially copyable\n");
  
#ifdef HAVE_CORD
  GC_INIT();  // required by cord
#endif
  mysrand(233432432);
  res = 0;
  /*
  if (cmdline::parse_or_default_bool("test_split_merge", false))
    test_split_merge<fftree_stack<bytes_1,128>,deque_wrapper<bytes_1> >();
#ifdef HAVE_ROPE
  if (cmdline::parse_or_default_bool("test_rope", false))
    test_split_merge<rope_seq<bytes_1>,deque_wrapper<bytes_1> >();
#endif
#ifdef HAVE_CORD
  if (cmdline::parse_or_default_bool("test_cord", false))
    test_split_merge<cord_wrapper<bytes_1>,deque_wrapper<bytes_1> >();
#endif
  */
  dispatch1();
  printf ("exectime %lf\n", exec_time);
  printf("result %lld\n", res);
#ifdef USE_MALLOC_COUNT
  malloc_pasl_report();
#endif
  return 0;
}

/***********************************************************************/
