/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Benchmarking for fft map
 * \file fftmap.cpp
 *
 */

#include <functional>
#include <random>
#include <algorithm>

#include "fftmap.hpp"
#include "cmdline.hpp"
#include "atomic.hpp"
#include "microtime.hpp"


/*---------------------------------------------------------------------*/

/*
 * Pseudo-random generator defined by the congruence S' = 69070 * S
 * mod (2^32 - 5).  Marsaglia (CACM July 1993) says on page 107 that
 * this is a ``good one''.  There you go.
 *
 * The literature makes a big fuss about avoiding the division, but
 * for us it is not worth the hassle.
 */
static const unsigned RNGMOD = ((1ULL << 32) - 5);
static const unsigned RNGMUL = 69070U;
unsigned rand_seed;

unsigned myrand() {
  unsigned state = rand_seed;
  state = (unsigned)((RNGMUL * (unsigned long long)state) % RNGMOD);
  rand_seed = state;
  return state;
}

void mysrand(unsigned seed) {
  seed %= RNGMOD;
  seed += (seed == 0); /* 0 does not belong to the multiplicative
                        group.  Use 1 instead */
  rand_seed = seed;
}

/*---------------------------------------------------------------------*/

using namespace pasl::data;

typedef size_t result_t;

typedef std::function<void ()> thunk_t;

result_t res;
double exec_time;

template <class Datastruct>
thunk_t scenario_map_random_insert() {
  typedef typename Datastruct::value_type value_type;
  size_t nb_access = (size_t) cmdline::parse_or_default_int("nb_access", 100000);
  int range = cmdline::parse_or_default_int("nb_access", (int)nb_access);
  return [=] {
    Datastruct d;
    uint64_t start_time = microtime::now();
    for (size_t i = 0; i < nb_access; i++) {
      int k = myrand() % range;
      int v = (int)i;
      d[k] = v;
    }
    exec_time = microtime::seconds_since(start_time);
    printf("size\t%d\n", (int)d.size());
  };
}

template <class Datastruct>
thunk_t dispatch2() {
  cmdline::argmap<thunk_t> tmg;
  tmg.add("random_insert", scenario_map_random_insert<Datastruct>());
  return tmg.find_by_arg("scenario");
}

void dispatch1() {
  cmdline::argmap<thunk_t> tmg;
  tmg.add("stl",    dispatch2<std::map<int,int> >());
  tmg.add("fftmap", dispatch2<fftmap<int,int> >());
  tmg.find_by_arg("datastruct")();
}

int main(int argc, char** argv) {
  cmdline::set(argc, argv);
  mysrand(233432432);
  res = 0;
  dispatch1();
  printf ("exectime %lf\n", exec_time);
  return 0;
}