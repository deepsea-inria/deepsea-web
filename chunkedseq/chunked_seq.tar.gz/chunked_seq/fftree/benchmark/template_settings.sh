
all: bench.exe

# add -D=1 to OPTIM_LEVEL in your settings.sh file to allow for different chunk sizes (see bench.cpp)
# add USE_ROPE=1 and/or USE_CORD=1 if you want to enable ropes and/or chords
# For debugging optimizations, define TREEDUMP=1 in settings.sh

# to make compilation of bench faster add any of: -DDONT_COMPILE_FFTREE_STACK -DDONT_COMPILE_FFTREE_DEQUE_PTR -DDONT_COMPILE_FFTREE_DEQUE_PTRX -DDONT_COMPILE_FFTREE_DEQUE_IDX -DDONT_COMPILE_STACK -DDONT_COMPILE_VECTOR -DDONT_COMPILE_BAGS -DDONT_COMPILE_TFTREE -DDONT_COMPILE_DEQUE -DDONT_COMPILE_RINGBUFFERS


# todo: do the same trick as in ../test/Makefile
DEP=$(wildcard scheduler/*.hpp) $(wildcard scheduler/*.cpp) $(wildcard clib/*.hpp) $(wildcard clib/*.cpp) $(wildcard ../include/*.cpp) $(wildcard ../include/*.hpp) 




