/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Debugging
 * \file debug.hpp
 *
 */

#include <vector>
#include <utility>
#include <string>
#include <iostream>
#include <fstream>

#ifndef _PASL_DATA_DEBUG_H_
#define _PASL_DATA_DEBUG_H_

namespace pasl {
namespace data {
namespace debug {

/***********************************************************************/
  
typedef enum { ft_spine, ft_buff, ft_two_three, ft_leaf, fft, fft_buffer } node_enum;

template <class FFtree_config, class Printer>
class fftree_graphviz_draw {
public:
  
  typedef Printer printer_type;
  typedef FFtree_config fftree_config_type;
  typedef typename fftree_config_type::inner_leafbuffer_type inner_leafbuffer_type;
  typedef typename fftree_config_type::outer_leafbuffer_type outer_leafbuffer_type;
  typedef typename fftree_config_type::inner_leafbuffer_type::algebra_type inner_algebra_type;
  typedef typename fftree_config_type::outer_leafbuffer_type::algebra_type outer_algebra_type;
  typedef typename fftree_config_type::inner_measured_type inner_measured_type;
  typedef typename fftree_config_type::outer_measured_type outer_measured_type;
  
  typedef std::vector<void*> edge_set_type;
  
  class node_info {
  public:
    node_enum ty;
    void* node_id;
    outer_measured_type cached;
    union {
      inner_leafbuffer_type* inner;
      outer_leafbuffer_type* outer;
    } leaf_ptr;
    edge_set_type outedges;
    node_info() { }
    node_info(void* node_id, const inner_measured_type& cached, node_enum ty, const edge_set_type& outedges)
    : ty(ty), node_id(node_id), outedges(outedges) {
      this->cached = FFtree_config::cclient_measured(cached);
    }
    node_info(void* node_id, const inner_measured_type& cached, inner_leafbuffer_type& buffer)
    : ty(ft_leaf), node_id(node_id) {
      leaf_ptr.inner = &buffer;
      this->cached = FFtree_config::cclient_measured(cached);
    }
    node_info(void* node_id, const outer_measured_type& cached, outer_leafbuffer_type& buffer)
    : ty(fft_buffer), node_id(node_id), cached(cached) {
      leaf_ptr.outer = &buffer;
    }
  };

  typedef std::vector<node_info> node_info_set_type;
  
  class node_info_collector {
  public:
    
    typedef edge_set_type edge_set;
    
    node_info_set_type set;
    
    void operator()(void* node_id,
                    const inner_measured_type& cached,
                    inner_leafbuffer_type& buffer) {
      set.push_back(node_info(node_id, cached, buffer));
    }
    
    void operator()(void* node_id,
                    const outer_measured_type& cached,
                    outer_leafbuffer_type& buffer) {
      set.push_back(node_info(node_id, cached, buffer));
    }
    
    void operator()(void* node_id,
                    const inner_measured_type& cached,
                    node_enum ty,
                    const edge_set_type& outedges) {
      set.push_back(node_info(node_id, cached, ty, outedges));
    }
    
  };
  
  class fftree_info {
  public:
    node_info_set_type nodes;
    edge_set_type edges;
    
    std::string label_of_node_type(node_enum ty) {
      switch (ty) {
        case ft_spine:      return "box";
        case ft_buff:       return "triangle";
        case ft_two_three:  return "ellipse";
        case ft_leaf:       return "ellipse";
        case fft:           return "box";
        case fft_buffer:    return "ellipse";
      }
    }
    
    template <class Leaf>
    std::string string_of_leafbuffer(Leaf* leaf) {
      std::string str;
      for (int i = 0; i < leaf->size(); i++) {
        std::string ss = printer_type::string_of_item((*leaf)[i]);
        if (i != leaf->size() - 1)
          str += ss + ", ";
        else
          str += ss;
      }
      str += "]";
      return str;
    }
    
    std::ostream& outstream(std::ostream& out) {
      out << "digraph {\n";
      out <<  "nodesep=.5;";
      out << "nodedir=LR;";
      out << "ranksep=.75; size = \"7.5,7.5\";";
      out << "node [shape=record];\n";
      for (int i = 0; i < nodes.size(); i++) {
        node_info info = nodes[i];
        out << (size_t)info.node_id << " ";
        std::string cached_str = printer_type::string_of_cached(info.cached);
        switch (info.ty) {
          case fft:
          case ft_spine:
          case ft_buff:
          case ft_two_three: {
            std::string lab = label_of_node_type(info.ty);
            int arity = (int)info.outedges.size();
            std::string edge_labels;
            for (int i = 0; i < arity; i++) {
              edge_labels += " |<f" + std::to_string(i) + ">";
            }
            out << "[label=\"" << cached_str << edge_labels << "\"];\n";
            for (int i = 0; i < info.outedges.size(); i++)
              out << (size_t)info.node_id << ":f" << std::to_string(i) << " -> " << (size_t)info.outedges[i] << ";\n";
            break;
          }
          case fft_buffer:
          case ft_leaf: {
            std::string str;
            str += "[";
            if (info.ty == fft_buffer) {
              outer_leafbuffer_type* leaf = info.leaf_ptr.outer;
              str += string_of_leafbuffer(leaf);
            } else {
              inner_leafbuffer_type* leaf = info.leaf_ptr.inner;
              str += string_of_leafbuffer(leaf);
            }
            out << "[label=\"" << str << "\", shape=" << label_of_node_type(info.ty) << "];\n";
            break;
          }
        }
      }
      return out << "}";
    }
    
  };
  
};
  
/*---------------------------------------------------------------------*/

template <class FFTree, class Printer>
void output_graphviz(std::string fname, FFTree& fft) {
  typedef typename FFTree::fftree_config_type fftree_config_type;
  typedef fftree_graphviz_draw<fftree_config_type, Printer> draw_type;
  typedef typename draw_type::fftree_info fftree_info;
  typedef typename draw_type::node_info_collector node_info_collector;
  typedef typename draw_type::edge_set_type edge_set_type;
  fftree_info info;
  node_info_collector ns;
  fft.dump_debug(ns);
  info.nodes = ns.set;
  std::ofstream f(fname, std::ios::out);
  info.outstream(f);
  f.close();
}

/***********************************************************************/

}
}
}

#endif /*! _PASL_DATA_DEBUG_H_ */