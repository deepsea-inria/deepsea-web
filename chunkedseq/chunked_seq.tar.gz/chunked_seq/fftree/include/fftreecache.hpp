/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Fast finger tree cache maintenance
 * \file fftreecache.hpp
 *
 */

#include "algebra.hpp"

#ifndef _PASL_DATA_FFTREECACHE_H_
#define _PASL_DATA_FFTREECACHE_H_

namespace pasl {
namespace data {
namespace fftree_base {
namespace cache {

/***********************************************************************/
  
/*---------------------------------------------------------------------*/
//! [zero_byte]  
template <class Vector, class Size>
class zero_byte {
public:
  
  typedef Size size_type;
  typedef algebra::noop algebra_type;
  typedef typename algebra_type::value_type measured_type;
  typedef typename Vector::value_type value_type;
  
  class measure_type {
  public:
    
    void operator()(const value_type& v, measured_type& dst) const {
    }
    
    void operator()(const value_type* lo, const value_type* hi,
                    measured_type& dst) const {
    }
    
  };
  
  static void swap(measured_type& m1, measured_type& m2) {
    
  }
  
};
//! [zero_byte]  
  
/*---------------------------------------------------------------------*/
//! [size]
template <class Vector, class Size>
class size {
public:

  typedef Size size_type;
  typedef algebra::sum_int<size_type> algebra_type;
  typedef typename algebra_type::value_type measured_type;
  typedef typename Vector::value_type value_type;
  
  class measure_type {
  public:
    
    void operator()(const value_type& v, measured_type& dst) const {
      dst = 1;
    }
    
    void operator()(const value_type* lo, const value_type* hi,
                    measured_type& dst) const {
      dst = measured_type(hi - lo);
    }
    
  };
  
  static void swap(measured_type& m1, measured_type& m2) {
    std::swap(m1, m2);
  }
  
};
//! [size]  
/*---------------------------------------------------------------------*/
//! [combiner]  
template <class Cache1, class Cache2>
class combiner {
public:

  typedef typename Cache1::algebra_type algebra1_type;
  typedef typename Cache2::algebra_type algebra2_type;
  typedef typename Cache1::measure_type measure1_type;
  typedef typename Cache2::measure_type measure2_type;
  
  typedef typename Cache1::size_type size_type;
  typedef algebra::combiner<algebra1_type, algebra2_type> algebra_type;
  typedef typename algebra_type::value_type measured_type;
  typedef typename Cache1::value_type value_type;
  
  class measure_type {
  public:
    
    measure1_type meas1;
    measure2_type meas2;
    
    measure_type() { }
    
    measure_type(const measure1_type meas1)
    : meas1(meas1) { }
    
    measure_type(const measure2_type meas2)
    : meas2(meas2) { }
    
    measure_type(const measure1_type meas1, const measure2_type meas2)
    : meas1(meas1), meas2(meas2) { }
    
    void operator()(const value_type& v, measured_type& dst) const {
      meas1(v, dst.value1);
      meas2(v, dst.value2);
    }
    
    void operator()(const value_type* lo, const value_type* hi,
                    measured_type& dst) const {
      meas1(lo, hi, dst.value1);
      meas2(lo, hi, dst.value2);
    }
    
  };
  
  static void swap(measured_type& m1, measured_type& m2) {
    Cache1::swap(m1.value1, m2.value1);
    Cache2::swap(m1.value2, m2.value2);
  }
  
};
//! [combiner]  

/***********************************************************************/

} // end namespace
} // end namespace
} // end namespace
} // end namespace

#endif /*! _PASL_DATA_FFTREECACHE_H_ */
