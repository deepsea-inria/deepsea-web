
#include "fixedcapacity.hpp"

#ifndef _PASL_DATA_BOOTCHUNKSEQ_WEIGHTED_H_
#define _PASL_DATA_BOOTCHUNKSEQ_WEIGHTED_H_

namespace pasl {
namespace data {
namespace bootchunkseq_weighted {

// Implements weighted sequences, assuming items to be pointers
// to objects whose first field is a weight field.



/***********************************************************************/
// Statically compute log base K of N

/*
template <int K, int N>
struct LogInBase 
{
   enum { value = (N < K) ? 0 : 1 + LogInBase<K, N/K>::value };
};
*/ 

/***********************************************************************/
// for debugging

#ifdef BOOTCHUNKSEQ_TEST
#define BOOTCHUNKSEQ_TEST_ONLY(code) code
static int nbAlloc = 0;
static int nbDealloc = 0;
#else
#define BOOTCHUNKSEQ_TEST_ONLY(code)
#endif 

/***********************************************************************/

template <class Object>
class weighted {
public:
  using weight_type = uint64_t;

  weight_type weight;  // needs to be laid out as first field
  Object value;

  weighted() : value(), weight(0) { }

  weighted(const weighted& other) 
    : weight(other.weight), value(other.value) { }

  // default destructor: ~weighted() { }
};

// auxiliary class used to read the weight without specifying the Object type
class weighted_mask {
public:
  using weight_type = uint64_t;
  weight_type weight; 
};


/***********************************************************************/

// Assume "Chunk" to implement fixed-capacity circular buffers.
// Assume "TopChunkSize >= 2" and "RecChunkSize >= 2".
// Assume TopItem to have a trivial destructor.

template <class Item, 
          template <class ChunkItem, int ChunkSize> class Chunk,
          int ChunkSize>
class bootchunkseq {
public:

  using size_type = size_t;
  
  using weight_type = uint64_t;

  // Forward declaration.
  union item_type;

  // Type of chunks and chunk pointers
  using chunk_type = weighted< Chunk<item_type, ChunkSize> >; 
  using chunk_ptr = chunk_type*; 

  // Item type is the union of top- and rec- items.
  union item_type { 
    Item top_item; 
    chunk_ptr rec_item; 
    weighted_mask* item;
    item_type() {}
    ~item_type() {}
    };

  // Computing the maximum depth of the structure
  static constexpr size_t max_nb_items = 1l << 40; // 1000 billions
  static constexpr size_t max_depth = 
   // 2 + LogInBase<(RecChunkSize+1)/2, max_nb_items/(TopChunkSize/2)>::value;
    25l;

  // Representation of the structure as an array of layers:
  // with "depth" deep layers, then one shallow layers.
  // using top-chunks at depth zero, rec-chunks otherwise.
  // There are no middle pointers, since there are the cells of the "layers" array.

  struct deep_layer_type {  // 5 words
    weight_type weight; 
    chunk_ptr front_outer, front_inner, back_inner, back_outer; };

  union layer_type { // 5 words
    chunk_ptr shallow; 
    deep_layer_type deep; }; 

  size_t curdepth; 
  layer_type layers[max_depth+1]; // (max_depth+1)*5 words

  using self_type = bootchunkseq<Item, Chunk, ChunkSize>;


  /*---------------------------------------------------------------------*/

  // constants to be used for pop_front/front template arguments
  static constexpr bool doPopTrue = true;
  static constexpr bool doPopFalse = false;

  static inline int capacity(int depth) {
    return ChunkSize;
  }

  static inline weight_type item_weight(item_type x) {
    return x.item->weight;
  }

  /*---------------------------------------------------------------------*/

  static inline chunk_ptr chunk_alloc() {
    BOOTCHUNKSEQ_TEST_ONLY(nbAlloc++;)
    return new chunk_type();
  }

  // deallocate chunks only when they are empty; else use chunk_deep_free
  static inline void chunk_free(chunk_ptr c) {
    BOOTCHUNKSEQ_TEST_ONLY(nbDealloc++;)
    assert(c->value.size() == 0);
    delete c;
  }

  // free chunks and all the chunks it contains recursively
  static inline void chunk_deep_free(int depth, chunk_ptr c) {
    if (depth == 0) {
      c->value.for_each([depth] (size_t, item_type& v) {
        delete v.top_item;
      });
    } else {
      c->value.for_each([depth] (size_t, item_type& v) {
        chunk_deep_free(depth-1, v.rec_item);
      });
    }
    c->value.clear();
    chunk_free(c);
  }

  static inline bool chunk_empty(chunk_ptr c) {
    return c->value.empty();
  }

  static inline bool chunk_full(chunk_ptr c) {
    return c->value.full();
  }

  static inline size_t chunk_size(chunk_ptr c) {
    return c->value.size();
  }

  static inline weight_type chunk_weight(chunk_ptr c) {
    return c->weight;
  }

  // for debugging only: computes the sum of the weight of all the items recursively stored
  static inline weight_type chunk_deep_weight(int depth, chunk_ptr c) {
    if (depth == 0) {
      return c->weight;
    } else {
      weight_type w = 0;
      c->value.for_each([&w, depth] (size_t, item_type& v) {
        w += chunk_deep_weight(depth-1, v.rec_item);
      });
      assert(w == c->weight); 
      return w;
    }
  }

  // push an item x into a weighted chunk c, and add to wtotal the weight of x
  static inline void chunk_push_front(chunk_ptr c, item_type& x, weight_type& wtotal) {
    c->value.push_front(x);
    weight_type wx = item_weight(x);
    c->weight += wx;
    wtotal += wx;
  }

  // push an item x into a weighted chunk c
  static inline void chunk_push_front(chunk_ptr c, item_type& x) {
    weight_type dummy;
    chunk_push_front(c, x, dummy);
  }

  // symmetric to chunk_push_front
  static inline void chunk_push_back(chunk_ptr c, item_type x, weight_type& wtotal) {
    c->value.push_back(x);
    weight_type wx = item_weight(x);
    c->weight += wx;
    wtotal += wx;
  }

  // symmetric to chunk_push_front
  static inline void chunk_push_back(chunk_ptr c, item_type x) {
    weight_type dummy;
    chunk_push_back(c, x, dummy);
  }

  // returns the front() if doPop=false, returns pop_front() if doPop=true
  template <bool doPop>  
  static inline item_type chunk_front(chunk_ptr c) {
    item_type x; 
    if (doPop) {
      x = c->value.pop_front();
      c->weight -= item_weight(x);
    } else {
      x = c->value.front();
    }
    return x;
  }

  // symmetric to chunk_front
  template < bool doPop>  
  static inline item_type chunk_back(chunk_ptr c) {
    item_type x; 
    if (doPop) {
      x = c->value.pop_back();
      c->weight -= item_weight(x);
    } else {
      x = c->value.back();
    }
    return x;
  }

  // transfer all the items from cfront to the back of cback, 
  // updating the weight of cback.
  static inline void chunk_front_to_back(chunk_ptr cfront, chunk_ptr cback) {
    int nb = chunk_size(cfront);
    cfront->value.transfer_from_front_to_back(cback->value, nb);
    cback->weight += cfront->weight;
  }
  
  // symmetric to chunk_front_to_back
  static inline void chunk_back_to_front(chunk_ptr cback, chunk_ptr cfront) {
    int nb = chunk_size(cback);
    cback->value.transfer_from_back_to_front(cfront->value, nb);
    cfront->weight += cback->weight;
  }

  // allocate and returns a deep copy of a chunk --TODO: test
  static inline chunk_ptr chunk_copy(int depth, chunk_ptr c) {
    chunk_ptr cpy = new chunk_type(*c);
    if (depth > 0) {
      // deep copy the items, using chunk_copy
      cpy->value.for_each([depth] (size_t, item_type& v) {
        chunk_ptr* cell = &(v.rec_item);
        *cell = bootchunkseq::chunk_copy(depth-1, v.rec_item);
      });
    }
    return cpy;
  }

  // given a weight, split out from chunk "c" the item "dst" that covers this
  // weight position, and move all the previous items to the "cfront" chunk.
  static void chunk_split(weight_type w, chunk_ptr c, item_type& dst, chunk_ptr cfront) {
    assert(! chunk_empty(c));
    weight_type wtotal = 0;
    item_type cur = chunk_front<doPopTrue>(c);
    wtotal += item_weight(cur);
    while (wtotal <= w) {
      assert(! chunk_empty(c));
      chunk_push_back(cfront, cur);
      cur = chunk_front<doPopTrue>(c);
      wtotal += item_weight(cur);
    }
    dst = cur;
  }

  // print the content of chunk, recursively,
  // assuming Item to have a print() method.
  static void chunk_print(int depth, chunk_ptr c) { 
    printf("(");
    if (depth == 0) {
      c->value.for_each([&] (size_t, item_type& v) {
        v.top_item->print();
        printf(" ");
      });
    } else {
      for (int i = 0; i < depth-1; i++)
        printf("*");
      weight_type w = c->weight;
      printf("<%d>", w);
      c->value.for_each([depth] (size_t, item_type& v) {
        bootchunkseq::chunk_print(depth-1, v.rec_item);
      });
    }
    printf(") ");
  }

  // prints an item, assuming Item to have a print method
  static void item_print(int depth, item_type& x) { 
    if (depth == 0) {
      x.top_item->print();
      printf(" ");
    } else {
      chunk_print(depth-1, x.rec_item);
    }
  }
  
  template <class Body>
  static void chunk_for_each(int depth, chunk_ptr c, const Body& f) {
    if (depth == 0) {
      c->value.for_each([&] (size_t, item_type& v) {
        f(v.top_item);
      });
    } else {
      c->value.for_each([&] (size_t, item_type& v) {
        bootchunkseq::chunk_for_each(depth-1, v.rec_item, f);
      });
    }
  }

  /*---------------------------------------------------------------------*/

  // returns whether a given layer is shallow
  inline bool is_shallow(int depth) const {
    return (depth == curdepth);
  }

  // recursively check all the invariant of the structure
  void rec_check_invariants(int depth) {
    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] rec_check_invariants ===\n", depth);
    rec_print(depth);
    #endif

    assert(depth <= curdepth);
    layer_type& layer = layers[depth]; 
    if (is_shallow(depth)) { // shallow
      // checks nothing //LATER: check weight is sum of items
    } else { // deep
      deep_layer_type& d = layer.deep;
      weight_type wfo = chunk_weight(d.front_outer);
      weight_type wfi = chunk_weight(d.front_inner);
      weight_type wmid = rec_weight(depth+1);
      weight_type wbi = chunk_weight(d.back_inner);
      weight_type wbo = chunk_weight(d.back_outer);
      weight_type w = wfo + wfi + wmid + wbi + wbo;
      assert (wfo == chunk_deep_weight(depth, d.front_outer));
      assert (wfi == chunk_deep_weight(depth, d.front_inner));
      assert (wbi == chunk_deep_weight(depth, d.back_inner));
      assert (wbo == chunk_deep_weight(depth, d.back_outer));
      assert (d.weight == w); // weight should be up-to-date
      size_t capa = capacity(depth);
      size_t sfo = chunk_size(d.front_outer);
      size_t sfi = chunk_size(d.front_inner);
      size_t sbi = chunk_size(d.back_inner);
      size_t sbo = chunk_size(d.back_outer);
      assert (sfo == 0 || sfi == capa); // pack front inner first
      assert (sbo == 0 || sbi == capa); // pack back inner first
      assert (sfi + sbi + wmid > 1); // else should be shallow
      rec_check_invariants(depth+1);
    }
    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] result ok rec_check_invariants ===\n", depth);
    #endif
  }

  // print the structure recursively
  void rec_print(int depth) { 
    layer_type& layer = layers[depth]; 
    if (is_shallow(depth)) { // shallow
      chunk_ptr c = layer.shallow;
      weight_type w = chunk_weight(c);
      printf("{%d}", (int) w);
      chunk_print(depth, c);
      printf("\n");
    } else { // deep
      deep_layer_type& d = layer.deep;
      printf("{%d}", (int) d.weight);
      chunk_print(depth, d.front_outer);
      chunk_print(depth, d.front_inner);
      printf("|| ");
      chunk_print(depth, d.back_inner);
      chunk_print(depth, d.back_outer);
      printf("\n");
      rec_print(depth+1);
    }
  }
  
  template <class Body>
  void rec_for_each(int depth, const Body& f) {
    layer_type& layer = layers[depth];
    if (is_shallow(depth)) { // shallow
      chunk_ptr c = layer.shallow;
      chunk_for_each(depth, c, f);
    } else { // deep
      deep_layer_type& d = layer.deep;
      chunk_for_each(depth, d.front_outer, f);
      chunk_for_each(depth, d.front_inner, f);
      rec_for_each(depth+1, f);
      chunk_for_each(depth, d.back_inner, f);
      chunk_for_each(depth, d.back_outer, f);
    }
  }

  /*---------------------------------------------------------------------*/

  // determines if the structure is empty at a given depth
  bool rec_empty(int depth) const {
    const layer_type& layer = layers[depth];
    if (is_shallow(depth)) {
      return chunk_empty(layer.shallow);
    } else {
      return (layer.deep.weight == 0);
    }
  }

  // returns the weight of the structure at a given depth
  weight_type rec_weight(int depth) { 
    layer_type& layer = layers[depth];
    if (is_shallow(depth)) {
      return chunk_weight(layer.shallow);
    } else {
      return layer.deep.weight;
    }
  }

  void rec_push_front(int depth, item_type x) {
    layer_type& layer = layers[depth];
    if (is_shallow(depth)) { // shallow
      chunk_ptr c = layer.shallow;
      if (! chunk_full(c)) { 
        chunk_push_front(c, x);
      } else { // convert from shallow to deep
        deep_layer_type& d = layer.deep;
        d.weight = c->weight;
        d.front_outer = chunk_alloc();
        d.front_inner = chunk_alloc();
        d.back_inner = c;
        d.back_outer = chunk_alloc();
        curdepth++;
        layers[curdepth].shallow = chunk_alloc();
        chunk_push_front(d.front_inner, x, d.weight);
      }
    } else { // deep
      deep_layer_type& d = layer.deep;
      if (! chunk_full(d.front_inner)) {
        chunk_push_front(d.front_inner, x, d.weight);
      } else if (! chunk_full(d.front_outer)) {
        chunk_push_front(d.front_outer, x, d.weight);
      } else { // both front buffers are full
        chunk_ptr c = d.front_inner;
        d.front_inner = d.front_outer;
        d.front_outer = chunk_alloc();
        rec_push_front(depth+1, c);
        chunk_push_front(d.front_outer, x, d.weight);
      }
    }
    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants(depth);
    #endif
  }

  inline void rec_push_front(int depth, chunk_ptr x) {
    item_type y;
    y.rec_item = x;
    rec_push_front(depth, y);
  }

  // symmetric to rec_push_front
  // (obtained by swapping "front" and "back" in code of rec_push_front)
  void rec_push_back(int depth, item_type x) {
    layer_type& layer = layers[depth];
    if (is_shallow(depth)) { // shallow
      chunk_ptr c = layer.shallow;
      if (! chunk_full(c)) {
        chunk_push_back(c, x);
      } else { // convert from shallow to deep
        deep_layer_type& d = layer.deep;
        d.weight = c->weight;
        d.back_outer = chunk_alloc();
        d.back_inner = chunk_alloc();
        d.front_inner = c;
        d.front_outer = chunk_alloc();
        curdepth++;
        layers[curdepth].shallow = chunk_alloc();
        chunk_push_back(d.back_inner, x, d.weight);
      }
    } else { // deep
      deep_layer_type& d = layer.deep;
      if (! chunk_full(d.back_inner)) {
        chunk_push_back(d.back_inner, x, d.weight);
      } else if (! chunk_full(d.back_outer)) {
        chunk_push_back(d.back_outer, x, d.weight);
      } 
      else { // both back buffers are full
        chunk_ptr c = d.back_inner;
        d.back_inner = d.back_outer;
        d.back_outer = chunk_alloc();
        rec_push_back(depth+1, c);
        chunk_push_back(d.back_outer, x, d.weight);
      }
    }
  }

  inline void rec_push_back(int depth, chunk_ptr x) {
    item_type y;
    y.rec_item = x;
    rec_push_back(depth, y);
  }

  // The check functions compacts a deep layer to shallow 
  // if it stores no more than 1 item.
  // It assumes the current layer to be deep.
  inline void rec_check(int depth) {
    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] rec_check ===\n", depth);
    rec_print(depth);
    #endif

    assert(! is_shallow(depth));
    deep_layer_type& d = layers[depth].deep; 
    size_t sfi = chunk_size(d.front_inner);
    if (sfi > 1)
      return;
    size_t sbi = chunk_size(d.back_inner);
    if (sbi > 1)
      return;
    bool middle_empty = rec_empty(depth+1);
    // step 1
    if (sfi == 0 && sbi == 0 && !middle_empty) {
      chunk_free(d.front_inner);
      d.front_inner = rec_front<doPopTrue>(depth+1).rec_item;
      sfi = chunk_size(d.front_inner);
      middle_empty = rec_empty(depth+1);
    }
    // step 2
    if (sfi + sbi <= 1 && middle_empty) {
      chunk_free(d.back_outer);
      chunk_free(d.front_outer);
      chunk_ptr c;
      if (sbi == 1) {
        c = d.back_inner;
        chunk_free(d.front_inner);
      } else {
        c = d.front_inner;
        chunk_free(d.back_inner);
      }
      assert(curdepth == depth+1);
      chunk_free(layers[curdepth].shallow);
      curdepth--;
      layers[curdepth].shallow = c;
    }
      
    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] result rec_check ===\n", depth);
    rec_print(depth);
    #endif
  }

  // Function rec_front implements both front and pop_front,
  // its behavior being determined by doPop
  template <bool doPop>  
  item_type rec_front(int depth) {
    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants(depth);
    #endif

    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] pop_front ===\n", depth);
    rec_print(depth);
    #endif

    item_type x;
    layer_type& layer = layers[depth];
    if (is_shallow(depth)) { // shallow
      chunk_ptr c = layer.shallow;
      x = chunk_front<doPop>(c);
    } else { // deep
      deep_layer_type& d = layer.deep;
      bool need_check = false;
      
      bool inner_empty = chunk_empty(d.front_inner);
      bool inner_full = chunk_full(d.front_inner);
      if (!inner_empty && !inner_full) {
        x = chunk_front<doPop>(d.front_inner);
        need_check = true;
      } else if (!inner_empty) {
        if (! chunk_empty(d.front_outer)) {
          x = chunk_front<doPop>(d.front_outer);
        } else {
          x = chunk_front<doPop>(d.front_inner);
          need_check = true;
        }
      }
      /*slower:
      if (! chunk_empty(d.front_outer)) {
        x = chunk_front<doPop>(d.front_outer);
      } else if (! chunk_empty(d.front_inner)) {
        x = chunk_front<doPop>(d.front_inner);
        need_check = true;
      } */ 
      else if (! rec_empty(depth+1)) {
        chunk_free(d.front_inner);
        d.front_inner = rec_front<doPopTrue>(depth+1).rec_item;
        x = chunk_front<doPop>(d.front_inner);
        need_check = true;
      } else if (! chunk_empty(d.back_outer)) {
        chunk_ptr c = d.front_inner;
        d.front_inner = d.back_inner;
        d.back_inner = d.back_outer;
        d.back_outer = c;
        x = chunk_front<doPop>(d.front_inner);
      } else { // everything in back_inner
        x = chunk_front<doPop>(d.back_inner);
        need_check = true;
      }
      if (doPop)
        d.weight -= item_weight(x);
      if (need_check)
         rec_check(depth); // must be done at the end of the function
    }
    
    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] result of pop_front ===\n", depth);
    rec_print(depth);
    #endif

    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants(depth);
    #endif

    return x;
  }

  // symmetric to rec_front.
  // (obtained by swapping "front" and "back" in code of rec_front)
  template <bool doPop>  
  item_type rec_back(int depth) {
    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants(depth);
    #endif

    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] pop_back ===\n", depth);
    rec_print(depth);
    #endif

    layer_type& layer = layers[depth];
    item_type x;
    if (is_shallow(depth)) {
      chunk_ptr c = layer.shallow;
      x = chunk_back<doPop>(c);
    } else { // deep
      deep_layer_type& d = layer.deep; 
      bool need_check = false;

      bool inner_empty = chunk_empty(d.back_inner);
      bool inner_full = chunk_full(d.back_inner);
      if (!inner_empty && !inner_full) {
        x = chunk_back<doPop>(d.back_inner);
        need_check = true;
      } else if (!inner_empty) {
        if (! chunk_empty(d.back_outer)) {
          x = chunk_back<doPop>(d.back_outer);
        } else {
          x = chunk_back<doPop>(d.back_inner);
          need_check = true;
        }
      }
      /* slower:
      if (! chunk_empty(d.back_outer)) {
        x = chunk_back<doPop>(d.back_outer);
      } else if (! chunk_empty(d.back_inner)) {
        x = chunk_back<doPop>(d.back_inner);
        need_check = true;
      } */
      else if (! rec_empty(depth+1)) {
        chunk_free(d.back_inner);
        d.back_inner = rec_back<doPopTrue>(depth+1).rec_item;
        x = chunk_back<doPop>(d.back_inner);
        need_check = true;
      } else if (! chunk_empty(d.front_outer)) {
        chunk_ptr c = d.back_inner;
        d.back_inner = d.front_inner;
        d.front_inner = d.front_outer;
        d.front_outer = c;
        x = chunk_back<doPop>(d.back_inner);
      } else { // everything in front_inner
        x = chunk_back<doPop>(d.front_inner);
        need_check = true;
      }
      if (doPop)
        d.weight -= item_weight(x);
      if (need_check)
        rec_check(depth); // must be done at the end of the function
    }
    
    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] result of pop_back ===\n", depth);
    rec_print(depth);
    #endif

    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants(depth);
    #endif

    return x;
  }

  // Rec_push_buffer_back takes a chunk "c" at depth "depth", and concatenate 
  // it to the back of the middle sequence (which is at depth "depth+1").
  // It assumes the current layer to be deep.
  void rec_push_buffer_back(int depth, chunk_ptr c) {
    assert(! is_shallow(depth));
    size_t csize = chunk_size(c);
    if (csize == 0) {
      chunk_free(c);
    } else {
      if (! rec_empty(depth+1)) {
        chunk_ptr b = rec_back<doPopFalse>(depth+1).rec_item;
        size_t bsize = chunk_size(b);
        if (bsize + csize <= capacity(depth)) {
          rec_back<doPopTrue>(depth+1);
          chunk_back_to_front(b, c);
          chunk_free(b);
        }
      }
      rec_push_back(depth+1, c);
    }
  }

  // symmetric to rec_push_buffer_back
  void rec_push_buffer_front(int depth, chunk_ptr c) {
    assert(! is_shallow(depth));
    size_t csize = chunk_size(c);
    if (csize == 0) {
      chunk_free(c);
    } else {
      if (! rec_empty(depth+1)) {
        chunk_ptr b = rec_front<doPopFalse>(depth+1).rec_item;
        size_t bsize = chunk_size(b);
        if (bsize + csize <= capacity(depth)) {
          rec_front<doPopTrue>(depth+1);
          chunk_front_to_back(b, c);
          chunk_free(b);
        }
      }
      rec_push_front(depth+1, c);
    }
  }

  // Rec_move_spine moves the spine starting at depth from a structure to another;
  // but does not modify data from the source structure.
  static void rec_move_spine(int depth, self_type& source, self_type& target) {
    int curdepth = source.curdepth;
    target.curdepth = curdepth;
    for (int i = depth; i < curdepth; i++) 
      target.layers[i].deep = source.layers[i].deep; // copy layer by value
    target.layers[curdepth].shallow = source.layers[curdepth].shallow;
  }

  // Concatenate data from other to the back of the current structure
  // It's leaving "other" in an unspecified state,
  // but not leaking any memory (since chunks are migrated).
  void rec_concat(int depth, self_type& other) {
      
    #ifdef BOOTCHUNKSEQ_TEST
    printf("=== [%d] Concat ===\n", depth);
    rec_print(depth);
    printf("===      with ===\n", depth);
    other.rec_print(depth);
    #endif

    size_t& curdepth1 = curdepth;
    size_t& curdepth2 = other.curdepth;
    assert(depth <= curdepth1 && depth <= curdepth2);
    layer_type& layer1 = layers[depth];
    layer_type& layer2 = other.layers[depth];
    if (depth == curdepth2) { // if 2 is shallow, transfer items
      chunk_ptr c = layer2.shallow;
      int nb = chunk_size(c);
      for (int i = 0; i < nb; i++) {
        item_type x = chunk_front<doPopTrue>(c);
        rec_push_back(depth, x);
      }
      chunk_free(c);
    } else if (depth == curdepth1) { // if 1 is shallow, copy spine, transfer items
      chunk_ptr c = layer1.shallow;
      // copy the spine
      rec_move_spine(depth, other, *this);
      // transfer the items (symmetric to above)
      int nb = chunk_size(c);
      for (int i = 0; i < nb; i++) {
        item_type x = chunk_back<doPopTrue>(c);
        rec_push_front(depth, x);
      }
      chunk_free(c);
    } else { // both 1 and 2 are deep
      deep_layer_type& d1 = layer1.deep; 
      deep_layer_type& d2 = layer2.deep;
      // push the buffers in the middle sequences
      rec_push_buffer_back(depth, d1.back_inner);
      rec_push_buffer_back(depth, d1.back_outer);
      other.rec_push_buffer_front(depth, d2.front_inner);
      other.rec_push_buffer_front(depth, d2.front_outer);
      // fuse front and back, if needed
      if (   ! rec_empty(depth+1) 
          && ! other.rec_empty(depth+1) ) {
        chunk_ptr c1 = rec_back<doPopFalse>(depth+1).rec_item;
        chunk_ptr c2 = other.rec_front<doPopFalse>(depth+1).rec_item;
        int nb1 = chunk_size(c1);
        int nb2 = chunk_size(c2);
        if (nb1 + nb2 <= capacity(depth)) { // need fusion
          rec_back<doPopTrue>(depth+1);
          other.rec_front<doPopTrue>(depth+1);
          chunk_front_to_back(c2, c1);
          chunk_free(c2);
          rec_push_back(depth+1, c1); 
          // note: push might be factorized with earlier operations
        }
      }
 
      // migrate back chunks of the other and update the weight
      d1.back_inner = d2.back_inner;
      d1.back_outer = d2.back_outer;
      d1.weight += d2.weight;

      // recursively concatenate
      rec_concat(depth+1, other);

      // and call check
      rec_check(depth);
    }
    #ifdef BOOTCHUNKSEQ_TEST
    printf("=== [%d] result of concat ===\n", depth);
    rec_print(depth);
    #endif

  }

  // Fix_deep_weight is an helper function that sets d.weight
  // to be the expected value.
  // It assumes the current layer to be deep.
  void fix_deep_weight(int depth) {
    assert(! is_shallow(depth));
    deep_layer_type& d = layers[depth].deep;
    weight_type wfo = chunk_weight(d.front_outer);
    weight_type wfi = chunk_weight(d.front_inner);
    weight_type wmid = rec_weight(depth+1);
    weight_type wbi = chunk_weight(d.back_inner);
    weight_type wbo = chunk_weight(d.back_outer);
    d.weight = wfo + wfi + wmid + wbi + wbo;
  }

  // Rec_split splits the current structure by extracting the item "x"
  // covering target weight "w", and carving out the items after "x"
  // into the structure "other".
  // Other is assumed to be completely uninitialized; in particular, it
  // should not store any pointer to active chunks.
  void rec_split(int depth, weight_type w, item_type& x, self_type& other) {
    #ifdef BOOTCHUNKSEQ_TEST
    printf("=== [%d] Splitting at %d ===\n", depth, w);
    rec_print(depth);
    #endif

    layer_type& layer1 = layers[depth];
    layer_type& layer2 = other.layers[depth];
    if (is_shallow(depth)) { // shallow
      other.curdepth = depth;
      layer2.shallow = layer1.shallow;
      layer1.shallow = chunk_alloc();
      chunk_split(w, layer2.shallow, x, layer1.shallow); 
    } else { // deep
      self_type& current = *this;

      // helper function to handle  control flow, avoiding the use of goto.
      auto fix = [depth, &current, &other, &x]() {
        current.fix_deep_weight(depth);
        other.fix_deep_weight(depth);
        current.rec_check(depth);
        other.rec_check(depth);

        #ifdef BOOTCHUNKSEQ_TEST
        printf("=== [%d] result of split===\n", depth);
        current.rec_print(depth);
        printf("===      middle ===\n", depth);
        item_print(depth, x);
        printf("===      and ===\n", depth);
        other.rec_print(depth);
        #endif
      };

      deep_layer_type& d1 = layer1.deep; 
      deep_layer_type& d2 = layer2.deep; 
      /* for debugging:
        printf("[%d]--> Splitting deep at %d, weights: %d %d |%d| %d %d\n", depth, w,
          chunk_weight(d1.front_outer),
          chunk_weight(d1.front_inner),
          rec_weight(depth+1),
          chunk_weight(d1.back_inner),
          chunk_weight(d1.back_outer));
      */
      d2.front_outer = chunk_alloc();
      d2.front_inner = chunk_alloc();
      d2.back_inner = chunk_alloc();
      d2.back_outer = chunk_alloc();
      weight_type wtotal = 0;
      weight_type wleft = w - wtotal;
      wtotal = chunk_weight(d1.front_outer);
      if (w < wtotal) { // split in front-outer
        std::swap(d2.front_outer, d1.front_outer);
        std::swap(d2.front_inner, d1.front_inner);
        rec_move_spine(depth+1, *this, other);
        curdepth = depth+1;
        layers[curdepth].shallow = chunk_alloc();
        std::swap(d2.back_inner, d1.back_inner);
        std::swap(d2.back_outer, d1.back_outer);
        chunk_split(wleft, d2.front_outer, x, d1.front_inner);
        return fix();
      } 
      wleft = w - wtotal;
      wtotal += chunk_weight(d1.front_inner);
      if (w < wtotal) { // split in front-inner
        std::swap(d2.front_inner, d1.front_inner);
        rec_move_spine(depth+1, *this, other);
        curdepth = depth+1;
        layers[curdepth].shallow = chunk_alloc();
        std::swap(d2.back_inner, d1.back_inner);
        std::swap(d2.back_outer, d1.back_outer);
        std::swap(d1.front_inner, d1.front_outer);
        chunk_split(wleft, d2.front_inner, x, d1.back_inner);
        return fix();
      }
      wleft = w - wtotal;
      wtotal += rec_weight(depth+1);
      if (w < wtotal) { // split in middle
        std::swap(d2.back_inner, d1.back_inner);
        std::swap(d2.back_outer, d1.back_outer);
        chunk_free(d2.front_inner);
        item_type y;
        rec_split(depth+1, wleft, y, other);
        d2.front_inner = y.rec_item;
        wleft -= rec_weight(depth+1);
        // for debugging: printf("[%d]--> Resplitting middle chunk at %d\n", depth, wleft);
        chunk_split(wleft, d2.front_inner, x, d1.back_inner);
        return fix();
      }
      wleft = w - wtotal;
      wtotal += chunk_weight(d1.back_inner);
      if (w < wtotal) { // split in back-inner
        std::swap(d2.front_inner, d1.back_inner);
        std::swap(d2.back_inner, d1.back_outer);
        other.curdepth = depth+1;
        other.layers[other.curdepth].shallow = chunk_alloc();
        chunk_split(wleft, d2.front_inner, x, d1.back_inner);
        return fix();
      }
      wleft = w - wtotal;
      wtotal += chunk_weight(d1.back_outer);
      assert(w < wtotal); // split in back-outer
      {
        std::swap(d2.front_inner, d1.back_outer);
        other.curdepth = depth+1;
        other.layers[other.curdepth].shallow = chunk_alloc();
        chunk_split(wleft, d2.front_inner, x, d1.back_outer);
        return fix();
      }
    }
  }


  /*---------------------------------------------------------------------*/

  // name for the constant indicating "layer 0"
  static constexpr int depth0 = 0;

public:

  using value_type = Item;

  bootchunkseq() {
    debug_alloc();
    init();
    debug_alloc();
  }

  ~bootchunkseq() {
    debug_alloc();
    uninit();
    debug_alloc();
  }

  // copy constructor performs a deep copy
  bootchunkseq(const self_type& other) {
    curdepth = other.curdepth;
    layers = other.layers; // copy the spine array by value
    // copy deep layers
    for (size_t depth = 0; depth < curdepth; depth++) {
      deep_layer_type& d = layers[depth].deep; 
      d.front_outer = chunk_copy(depth, d.front_outer);
      d.front_inner = chunk_copy(depth, d.front_inner);
      d.back_inner = chunk_copy(depth, d.back_inner);
      d.back_outer = chunk_copy(depth, d.back_outer);
    }
    // copy shallow layer
    {
      layer_type& layer = layers[curdepth];
      layer.shallow = chunk_alloc(curdepth, layer.shallow);
    }
  }

  // allocate a shallow structure
  void init() {
    curdepth = depth0;
    layers[curdepth].shallow = chunk_alloc();
  }

  // deallocate a structure
  void uninit() {
    // deallocate deep layers
    for (size_t depth = 0; depth < curdepth; depth++) {
      deep_layer_type& d = layers[depth].deep; 
      chunk_deep_free(depth, d.front_outer);
      chunk_deep_free(depth, d.front_inner);
      chunk_deep_free(depth, d.back_inner);
      chunk_deep_free(depth, d.back_outer);
    }
    // deallocate shallow layer
    chunk_deep_free(curdepth, layers[curdepth].shallow);    
  }

  /*---------------------------------------------------------------------*/

  inline bool empty() const {  
    return rec_empty(depth0);
  }

  inline weight_type weight() {  // const
    return rec_weight(depth0);
  }

  inline void push_front(const value_type& x) { 
    item_type y;
    y.top_item = x;
    rec_push_front(depth0, y);
  }
 
  inline void push_back(const value_type& x) {
    item_type y;
    y.top_item = x;
    rec_push_back(depth0, y);
  }

  // Note that front() returns by value and not by reference;
  // --this is required due to the factorization with pop_front().
  inline value_type front() {
    item_type x = rec_front<doPopFalse>(depth0);
    return x.top_item;
  }

  inline value_type back() {
    item_type x = rec_back<doPopFalse>(depth0);
    return x.top_item;
  }

  inline value_type pop_front() {
    item_type x = rec_front<doPopTrue>(depth0);
    return x.top_item;
  }

  inline value_type pop_back() {
    item_type x = rec_back<doPopTrue>(depth0);
    return x.top_item;
  }

  // Function "concat" concatenates the items of "other" 
  // to the right of the current structure, in place; 
  // It leaves "other" empty.
  void concat(self_type& other) {
    rec_concat(depth0, other);
    other.init(); // reallocating other as empty structure
  }
  
  static self_type* concat(self_type* r, self_type* s) {
    r->concat(*s);
    delete s;
    return r;
  }

  // Function "split" takes a split weight; stores in "dst" the value 
  // covering this weight, and stores in "other" the items beyond this index.
  // As first step, it will first perform a deep deallocation of "other".
  void split(weight_type w, value_type& dst, self_type& other) {
    other.uninit();
    item_type y;
    rec_split(depth0, w, y, other);
    dst = y.top_item;
  }


  /*---------------------------------------------------------------------*/
  // Functions for compiling benchmarks:

  // Returns the weight interpreted as a size (for items of weight 1)
  size_t size() {
    return weight();
  }

  // Split-approximate splits at half of the weight. //TODO: needed?
  void split_approximate(self_type& dst) {
    weight_type mid_weight = weight() / 2;
    split(mid_weight, dst);
  }

  // Alias to "concat", useful for benchmarks
  void transfer_to_back(self_type& other) {
    concat(other);
  }

  // Alternative prototype for function "split", that stores the
  // item covering the targeted weight into the "other" sequence.
  void split(weight_type w, self_type& other) {
    value_type dst;
    split(w, dst, other);
    other.push_front(dst);
  }

  template <class Body>
  void for_each(const Body& f) {
    size_type i = 0;
    auto _f = [&] (Item& v) {
      f(i++, v);
    };
    rec_for_each(depth0, _f);
  }

  /*---------------------------------------------------------------------*/
  // For debugging

  static void debug_alloc() {
    #ifdef BOOTCHUNKSEQ_TEST
    printf("--> alloc: %d, free: %d\n", nbAlloc, nbDealloc);
    #endif
  }

  void check() {
    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants(depth0);
    #endif
  }

  void print() {
    #ifdef BOOTCHUNKSEQ_TEST
    printf("==========================\n");
    rec_print(depth0);
    #endif
  }

  /*---------------------------------------------------------------------*/
  // Dummy definitions for compiling benchmarks:

  using iterator = int; // dummy

  iterator begin() const {
    assert(false);
  }
  iterator end() const {
    assert(false);
  }

  void swap(self_type& other) {
    assert(false);
  }

};


/***********************************************************************/

}
}
}

#endif /*! _PASL_DATA_BOOTCHUNKSEQ_WEIGHTED_H_ */


