/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Algebraic structures
 * \file algebra.hpp
 *
 */

#ifndef _PASL_DATA_ALGEBRA_H_
#define _PASL_DATA_ALGEBRA_H_

namespace pasl {
namespace data {
namespace algebra {
  
/***********************************************************************/
  
/*---------------------------------------------------------------------*/
//! [noop]
/*!
 * \class noop
 * \ingroup algebras
 * \brief Trivial nullary algebra
 *
 */
class noop {
public:
  
  typedef struct { } value_type;
  
  static constexpr bool is_group = true;
  
  static void reduce(value_type* left, const value_type* right) {
  }
  
  static void identity(value_type* p) {
  }
  
  static void inverse(value_type* p) {
  }
  
};
//! [noop]

/*---------------------------------------------------------------------*/
//! [sum_int]
/*!
 * \class sum_int
 * \ingroup algebras
 * \brief Familiar algebraic group for the set of integers
 *
 * Group for the set of integers along with integer addition.
 *
 */
template <typename int_t>
class sum_int {
public:
  
  typedef int_t value_type;
  
  static constexpr bool is_group = true;
  
  static void reduce(value_type* left, const value_type* right) {
    *left += *right;
  }
  
  static void identity(value_type* p) {
    new (p) int_t(0);
  }
  
  static void inverse(value_type* p) {
    *p = -*p;
  }
  
};  
//! [sum_int]

/*---------------------------------------------------------------------*/
//! [combiner]
/*!
 * \class combiner
 * \ingroup algebras
 * \brief Combiner of two algebras
 *
 * Combines two algebras to make a new algebra that pairs together 
 * values of the two given algebras. The resuling algebra combines
 * together the operations of the given algebras to operate pointwise 
 * on the values of the pairs.
 *
 * The resulting algebra is a group only if both of the given algebras
 * are groups.
 *
 * \tparam Algebra1 an algebra
 * \tparam Algebra2 an algebra
 *
 */
template <class Algebra1, class Algebra2>
class combiner {
public:
  
  typedef Algebra1 algebra1;
  typedef Algebra2 algebra2;
  typedef typename Algebra1::value_type value1_type;
  typedef typename Algebra2::value_type value2_type;
  
  static constexpr bool is_group = algebra1::is_group && algebra2::is_group;
  
  class value_type {
  public:
    value1_type value1;
    value2_type value2;
  };
  
  static void reduce(value_type* left, const value_type* right) {
    algebra1::reduce(&(left->value1), &(right->value1));
    algebra2::reduce(&(left->value2), &(right->value2));
  }
  
  static void identity(value_type* p) {
    algebra1::identity(&(p->value1));
    algebra2::identity(&(p->value2));
  }
  
  static void inverse(value_type* p) {
    algebra1::inverse(&(p->value1));
    algebra2::inverse(&(p->value2));
  }
  
};
//! [combiner]
  
/*---------------------------------------------------------------------*/
/* Increment and decrement operations */

template <class Algebra>
inline void incr_front(typename Algebra::value_type* dst,
                             const typename Algebra::value_type* d) {
  typename Algebra::value_type tmp(*dst);
  new (dst) typename Algebra::value_type(*d);
  Algebra::reduce(dst, &tmp);
}

template <class Algebra>
inline void incr_back(typename Algebra::value_type* dst,
                            const typename Algebra::value_type* d) {
  Algebra::reduce(dst, d);
}

template <class Algebra>
inline void decr_back(typename Algebra::value_type* dst,
                             const typename Algebra::value_type* d) {
  assert(Algebra::is_group);
  typename Algebra::value_type tmp(*d);
  Algebra::inverse(&tmp);
  incr_back<Algebra>(dst, &tmp);
}

template <class Algebra>
inline void decr_front(typename Algebra::value_type* dst,
                              const typename Algebra::value_type* d) {
  assert(Algebra::is_group);
  typename Algebra::value_type tmp(*d);
  Algebra::inverse(&tmp);
  incr_front<Algebra>(dst, &tmp);
}
  
/***********************************************************************/

}
}
}

#endif /*! _PASL_DATA_ALGEBRA_H_ */