/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Predicates for guiding finger-tree search
 * \file predicate.hpp
 *
 */

#ifndef _PASL_DATA_PREDICATE_H_
#define _PASL_DATA_PREDICATE_H_

namespace pasl {
namespace data {
namespace predicate {

/***********************************************************************/

/*---------------------------------------------------------------------*/

template <class size_type>
class less_or_eq {
public:
  bool operator()(const size_type& x, const size_type& y) {
    return x <= y;
  }
};
  
/*---------------------------------------------------------------------*/
/*!
 * \class compare_by_size
 * \ingroup fftree
 * \brief Wrapper predicate which applies a predicate based on size field
 * of the cached measure.
 */
template <class Comparison, class FFTree_config>
class compare_by_size {
public:
  
  typedef Comparison comparison_type;
  typedef typename FFTree_config::size_type size_type;
  typedef typename FFTree_config::internal_measured_type measured_type;
  
private:
  
  size_type sz;
  
public:
  
  compare_by_size(size_type sz) : sz(sz) { }
  
  bool operator()(const measured_type& m) const {
    return Comparison()(sz, FFTree_config::csize(m));
  }
  
  size_type get_size() const {
    return sz;
  }
  
};

/*---------------------------------------------------------------------*/

template <class FFTree_config>
using less_or_eq_by_size =
  compare_by_size<less_or_eq<typename FFTree_config::size_type>, FFTree_config>;
  
/*---------------------------------------------------------------------*/

//! [always_predicate]
template <bool b>
class always {
public:
  
  template <class measured_type>
  bool operator()(const measured_type& m) const {
    return b;
  }
  
};
//! [always_predicate]

/***********************************************************************/

} // end namespace
} // end namespace
} // end namespace

#endif /*! _PASL_DATA_PREDICATE_H_ */