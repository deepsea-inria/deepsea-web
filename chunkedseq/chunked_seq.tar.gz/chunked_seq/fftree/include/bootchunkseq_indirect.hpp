
#include "fixedcapacity.hpp"

#ifndef _PASL_DATA_BOOTCHUNKSEQ_INDIRECT_H_
#define _PASL_DATA_BOOTCHUNKSEQ_INDIRECT_H_

namespace pasl {
namespace data {
namespace bootchunkseq_indirect {


/***********************************************************************/
// Statically compute log base K of N

/*
template <int K, int N>
struct LogInBase 
{
   enum { value = (N < K) ? 0 : 1 + LogInBase<K, N/K>::value };
};
*/ 

/***********************************************************************/
// for debugging

#ifdef BOOTCHUNKSEQ_TEST
#define BOOTCHUNKSEQ_TEST_ONLY(code) code
static int nbAlloc = 0;
static int nbDealloc = 0;

#else
#define BOOTCHUNKSEQ_TEST_ONLY(code)
#endif 

/***********************************************************************/

template <class Object>
class weighted {
public:
  using weight_type = uint64_t;

  weight_type weight;  // needs to be laid out as first field
  Object value;

  weighted() : value(), weight(0) { }

  weighted(const weighted& other) 
    : weight(other.weight), value(other.value) { }
/*
  weighted(Object value, weight_type weight) 
    : weight(weight), value(value)  { }
*/
  // default destructor: ~weighted() { }
};

// auxiliary class used to read the weight without specifying the Object type
class weighted_mask {
public:
  using weight_type = uint64_t;
  weight_type weight; 
};


/***********************************************************************/

// Assume "Chunk" to implement fixed-capacity circular buffers.
// Assume "TopChunkSize >= 2" and "RecChunkSize >= 2".
// Assume TopItem to have a trivial destructor.

template <class TopItem, 
          template <class Item, int ChunkSize> class Chunk, 
          int TopChunkSize, 
          int RecChunkSize>
          // LATER: bool ForceFirstLayerDeep = true>
          // LATER: bool WeightedSequence = true
          // LATER: bool DoCacheSize = true
class bootchunkseq {
public:

  using size_type = size_t;
  
  using weight_type = uint64_t;

  // Forward declaration.
  union chunk_ptr;

  // Items and chunks at top level, called top-chunks.
  // Remark: when a top chunk is used as a side buffer, 
  // its weight is not updated, as it is equal to the size.
  using top_item_type = TopItem;
  using top_chunk_type = weighted< Chunk<top_item_type, TopChunkSize> >; 
  using top_chunk_ptr = top_chunk_type*; 

  // Items and chunks in depth, called rec-chunks.
  using rec_item_type = chunk_ptr;
  using rec_chunk_type = weighted< Chunk<rec_item_type, RecChunkSize> >;
  using rec_chunk_ptr = rec_chunk_type*; 

  // Chunk type is the union of top- and rec- chunks; 
  // We also add a case to cover both, when we only care for the weight
  union chunk_ptr { 
    top_chunk_ptr top_chunk; 
    rec_chunk_ptr rec_chunk; 
    weighted_mask* chunk; };

  // Item type is the union of top- and rec- items.
  union item_type { 
    top_item_type top_item; 
    rec_item_type rec_item; 
    item_type() {}
    ~item_type() {}
    };
  // using item_type = item_type_repr;

  // Computing the maximum depth of the structure
  static constexpr size_t max_nb_items = 1l << 40; // 1000 billions
  static constexpr size_t max_depth = 
   // 2 + LogInBase<(RecChunkSize+1)/2, max_nb_items/(TopChunkSize/2)>::value;
    25l;

  // Representation of the structure as an array of layers:
  // with "depth" deep layers, then one shallow layers.
  // using top-chunks at depth zero, rec-chunks otherwise.
  // There are no middle pointers, since there are the cells of the "layers" array.

  struct deep_layer_type {  // 5 words
    weight_type weight; 
    chunk_ptr front_outer, front_inner, back_inner, back_outer; };

  union layer_type { // 5 words
    chunk_ptr shallow; 
    deep_layer_type deep; }; 

  size_t uninitialized_depth = -1l; //indicates non-initialized structure
  size_t curdepth; // may be equal to "uninitialized_depth"
  layer_type layers[max_depth+1]; // (max_depth+1)*5 words

  using self_type = bootchunkseq<TopItem, Chunk, TopChunkSize, RecChunkSize>;


  /*---------------------------------------------------------------------*/

  template <bool atTop>  
  inline bool is_shallow(int depth) {
    return !atTop && (depth == curdepth);
  }

  template <bool atTop>  
  inline int capacity(int depth) {
    if (atTop)
      return TopChunkSize;
    else 
      return RecChunkSize;
  }

  /*---------------------------------------------------------------------*/

  static constexpr bool atTopTrue = true;
  static constexpr bool atTopFalse = false;

  template <bool atTop> 
  static inline chunk_ptr chunk_alloc() {
    BOOTCHUNKSEQ_TEST_ONLY(nbAlloc++;)
    chunk_ptr c;
    if (atTop) {
      c.top_chunk = new top_chunk_type();
    } else {
      c.rec_chunk = new rec_chunk_type();
    }
    return c;
  }

  template <bool atTop>  
  static inline void chunk_free(chunk_ptr c) {
    BOOTCHUNKSEQ_TEST_ONLY(nbDealloc++;)
    if (atTop) 
      delete c.top_chunk;
    else 
      delete c.rec_chunk;
  }

  static inline void chunk_deep_free(int depth, chunk_ptr c) {
    if (depth > 0) {
      c.rec_chunk->value.for_each([depth] (size_t, chunk_ptr v) {
        chunk_deep_free(depth-1, v);
      });
    }
    if (depth == 0)
      chunk_free<atTopTrue>(c);
    else
      chunk_free<atTopFalse>(c);
  }

  template <bool atTop>  
  static inline bool chunk_empty(chunk_ptr c) {
    if (atTop)
      return c.top_chunk->value.empty();
    else
      return c.rec_chunk->value.empty();
  }

  template <bool atTop>  
  static inline bool chunk_full(chunk_ptr c) {
    if (atTop)
      return c.top_chunk->value.full();
    else
      return c.rec_chunk->value.full();
  }

  template <bool atTop>  
  static inline size_t chunk_size(chunk_ptr c) {
    if (atTop)
      return c.top_chunk->value.size();
    else
      return c.rec_chunk->value.size();
  }

  template <bool atTop>  
  static inline weight_type chunk_weight(chunk_ptr c) {
    if (atTop)
      return c.top_chunk->value.size();
    else
      return c.rec_chunk->weight;
  }

  // for debugging 
  static inline weight_type chunk_deep_weight(int depth, chunk_ptr c) {
    if (depth == 0) {
      return c.top_chunk->value.size();
    } else {
      weight_type w = 0;
      c.rec_chunk->value.for_each([&w, depth] (size_t, chunk_ptr v) {
        w += chunk_deep_weight(depth-1, v);
      });
      assert(w == c.rec_chunk->weight); 
      return w;
    }
  }

  // set the weight field of a chunk if it was not maintained
  template <bool atTop>  
  static inline void top_chunk_set_weight(chunk_ptr c) {
    if (atTop)
      c.top_chunk->weight = c.top_chunk->value.size();
  }

  template <bool atTop>  
  static inline void chunk_push_front(chunk_ptr c, item_type x, weight_type& wtotal) {
    if (atTop) {
      c.top_chunk->value.push_front(x.top_item);
      // remark: no update to c.weight
    } else {
      c.rec_chunk->value.push_front(x.rec_item);
      weight_type wx = x.rec_item.chunk->weight;
      c.rec_chunk->weight += wx;
      wtotal += wx;
    }
  }

  template <bool atTop>  
  static inline void chunk_push_front(chunk_ptr c, item_type x) {
    weight_type dummy;
    chunk_push_front<atTop>(c, x, dummy);
  }

  // symmetric to chunk_push_front
  template <bool atTop>  
  static inline void chunk_push_back(chunk_ptr c, item_type x, weight_type& wtotal) {
    if (atTop) {
      c.top_chunk->value.push_back(x.top_item);
      // remark: no update to c.weight
    } else {
      c.rec_chunk->value.push_back(x.rec_item);
      weight_type wx = x.rec_item.chunk->weight;
      c.rec_chunk->weight += wx;
      wtotal += wx;
    }
  }

  // symmetric to chunk_push_front
  template <bool atTop>  
  static inline void chunk_push_back(chunk_ptr c, item_type x) {
    weight_type dummy;
    chunk_push_back<atTop>(c, x, dummy);
  }

  template <bool atTop, bool doPop>  
  static inline item_type chunk_front(chunk_ptr c) {
    item_type x; 
    if (atTop) {
      if (doPop) {
        x.top_item = c.top_chunk->value.pop_front();
        // remark: no update to c.weight nor wtotal
      } else {
        x.top_item = c.top_chunk->value.front();
      }
    } else {
      if (doPop) {
        x.rec_item = c.rec_chunk->value.pop_front();
        weight_type wx = x.rec_item.chunk->weight;
        c.rec_chunk->weight -= wx;
      } else {
        x.rec_item = c.rec_chunk->value.front();
      }
    }
    return x;
  }

  // symmetric to chunk_front
  template <bool atTop, bool doPop>  
  static inline item_type chunk_back(chunk_ptr c) {
    item_type x; 
    if (atTop) {
      if (doPop) {
        x.top_item = c.top_chunk->value.pop_back();
        // remark: no update to c.weight
      } else {
        x.top_item = c.top_chunk->value.back();
      }
    } else {
      if (doPop) {
        x.rec_item = c.rec_chunk->value.pop_back();
        weight_type wx = x.rec_item.chunk->weight;
        c.rec_chunk->weight -= wx;
      } else {
        x.rec_item = c.rec_chunk->value.back();
      }
    }
    return x;
  }

  // transfer all the items from cfront to the back of cback, 
  // updating the weight of cbackt.
  template <bool atTop>  
  static inline void chunk_front_to_back(chunk_ptr cfront, chunk_ptr cback) {
    int nb = chunk_size<atTop>(cfront);
    if (atTop) {
      cfront.top_chunk->value.transfer_from_front_to_back(cback.top_chunk->value, nb);
    } else {
      cfront.rec_chunk->value.transfer_from_front_to_back(cback.rec_chunk->value, nb);
      cback.rec_chunk->weight += cfront.rec_chunk->weight;
    }
  }
  
  // symmetric to chunk_front_to_back
  template <bool atTop>  
  static inline void chunk_back_to_front(chunk_ptr cback, chunk_ptr cfront) {
    int nb = chunk_size<atTop>(cback);
    if (atTop) {
      cback.top_chunk->value.transfer_from_back_to_front(cfront.top_chunk->value, nb);
    } else {
      cback.rec_chunk->value.transfer_from_back_to_front(cfront.rec_chunk->value, nb);
      cfront.rec_chunk->weight += cback.rec_chunk->weight;
    }
  }

  template <bool atTop>  
  static inline chunk_ptr chunk_copy(int depth, chunk_ptr c) {
    chunk_ptr cpy;
    if (atTop) {
      cpy.top_chunk = new top_chunk_type(*c.top_chunk);
    } else {
      assert(depth > 0);
      cpy.rec_chunk = new rec_chunk_type(*c.rec_chunk);
      // deep copy the items, using chunk_copy
      cpy.rec_chunk->value.for_each([depth] (size_t, chunk_ptr& v) {
        chunk_ptr* cell = &v;
        *cell = bootchunkseq::chunk_copy(depth-1, v);
      });
    }
    return cpy;
  }

  // given a weight, split out from chunk "c" the item "dst" that covers this
  // weight position, and move all the previous items to the "cfront" chunk.
  template <bool atTop>  
  static void chunk_split(weight_type w, chunk_ptr c, item_type& dst, chunk_ptr cfront) {
    if (atTop) {
      assert(0 <= w && w < c.top_chunk->value.size());
      c.top_chunk->value.transfer_from_front_to_back(cfront.top_chunk->value, w);
      dst.top_item = c.top_chunk->value.pop_front();
    } else {
      weight_type wtotal = 0;
      assert(! chunk_empty<atTop>(c));
      item_type cur = chunk_front<atTop,doPopTrue>(c);
      if (atTop) // note: needed only if top level is not optimized
        wtotal++;
      else 
        wtotal += cur.rec_item.chunk->weight;
      while (wtotal <= w) {
        assert(! chunk_empty<atTop>(c));
        chunk_push_back<atTop>(cfront, cur);
        cur = chunk_front<atTop,doPopTrue>(c);
        if (atTop) // note: needed only if top level is not optimized
          wtotal++;
        else 
          wtotal += cur.rec_item.chunk->weight;
      }
      dst = cur;
    }
  }

  static void chunk_print(int depth, chunk_ptr c) { // assumes integer as item types
    printf("(");
    if (depth == 0) {
      c.top_chunk->value.for_each([&] (size_t, top_item_type v) {
#ifdef BOOTCHUNKSEQ_TESTING
        printf("%d ", v);
#else
        assert(false);
#endif
      });
    } else {
      for (int i = 0; i < depth-1; i++)
        printf("*");
      weight_type w = c.rec_chunk->weight;
      printf("<%d>", w);
      c.rec_chunk->value.for_each([depth] (size_t, rec_item_type v) {
        bootchunkseq::chunk_print(depth-1, v);
      });
    }
    printf(") ");
  }

  static void item_print(int depth, item_type& x) { // assumes integer as item types
    if (depth == 0) {
#ifdef BOOTCHUNKSEQ_TESTING
        printf("%d ", (int) x.top_item);
#else
        assert(false);
#endif
    } else {
      chunk_print(depth-1, x.rec_item);
    }
  }


  /*---------------------------------------------------------------------*/

  static constexpr bool doPopTrue = true;
  static constexpr bool doPopFalse = false;

  /*---------------------------------------------------------------------*/

  template <bool atTop>  
  void rec_check_invariants(int depth) {
    assert(depth <= curdepth);
    layer_type& layer = layers[depth]; // TODO: why layer_type& does not compile ??
    if (! is_shallow<atTop>(depth)) { // deep
      deep_layer_type& d = layer.deep;
      weight_type wfo = chunk_weight<atTop>(d.front_outer);
      weight_type wfi = chunk_weight<atTop>(d.front_inner);
      weight_type wmid = rec_weight<atTopFalse>(depth+1);
      weight_type wbi = chunk_weight<atTop>(d.back_inner);
      weight_type wbo = chunk_weight<atTop>(d.back_outer);
      weight_type w = wfo + wfi + wmid + wbi + wbo;
      assert (wfo == chunk_deep_weight(depth, d.front_outer));
      assert (wfi == chunk_deep_weight(depth, d.front_inner));
      assert (wbi == chunk_deep_weight(depth, d.back_inner));
      assert (wbo == chunk_deep_weight(depth, d.back_outer));
      assert (depth == 0 || d.weight == w); // weight should be up-to-date
      size_t capacity = (atTop) ? TopChunkSize : RecChunkSize;
      size_t sfo = chunk_size<atTop>(d.front_outer);
      size_t sfi = chunk_size<atTop>(d.front_inner);
      size_t sbi = chunk_size<atTop>(d.back_inner);
      size_t sbo = chunk_size<atTop>(d.back_outer);
      assert (sfo == 0 || sfi == capacity); // pack front inner first
      assert (sbo == 0 || sbi == capacity); // pack back inner first
      assert (depth == 0 || sfi + sbi + wmid > 1); // else should be shallow
      rec_check_invariants<atTopFalse>(depth+1);
    }
    printf("invariants ok\n");
  }

  void print_structure(int depth) { // assumes integer as item types
    layer_type& layer = layers[depth]; // TODO: why layer_type& does not compile ??
    if (depth == curdepth) { 
      if (depth > 0) {
        weight_type w = chunk_weight<atTopFalse>(layer.shallow);
        printf("{%d}", (int) w);
      }
      chunk_print(depth, layer.shallow);
      printf("\n");
    } else {// deep
      deep_layer_type& d = layer.deep;
      printf("{%d}", (int) d.weight);
      chunk_print(depth, d.front_outer);
      chunk_print(depth, d.front_inner);
      printf("|| ");
      chunk_print(depth, d.back_inner);
      chunk_print(depth, d.back_outer);
      printf("\n");
      print_structure(depth+1);
    }
  }

  /*---------------------------------------------------------------------*/

  template <bool atTop>  
  bool rec_empty(int depth) {
    layer_type& layer = layers[depth];
    if (is_shallow<atTop>(depth)) {
      return chunk_empty<atTop>(layer.shallow);
    } else {
      deep_layer_type& d = layer.deep;
      if (atTop) {  
        return chunk_empty<atTop>(d.front_inner) 
            && chunk_empty<atTop>(d.back_inner);
        // remark: not needed to test the others, due to the invariants
      } else {
        return d.weight == 0;
      }
    }
  }

  template <bool atTop>  
  weight_type rec_weight(int depth) { 
    layer_type& layer = layers[depth];
    if (is_shallow<atTop>(depth)) {
      return chunk_weight<atTop>(layer.shallow);
    } else {
      deep_layer_type& d = layer.deep;
      if (atTop) {
        weight_type wfo = weight_type(chunk_size<atTop>(d.front_outer));
        weight_type wfi = weight_type(chunk_size<atTop>(d.front_inner));
        weight_type wbi = weight_type(chunk_size<atTop>(d.back_inner));
        weight_type wbo = weight_type(chunk_size<atTop>(d.back_outer));
        return wfo + wfi + wbi + wbo + rec_weight<atTopFalse>(depth+1);
      } else {
        return d.weight;
      }
    }
  }

  template <bool atTop>  
  void rec_push_front(int depth, item_type x) {
    layer_type& layer = layers[depth];
    if (is_shallow<atTop>(depth)) {
      chunk_ptr c = layer.shallow;
      if (! chunk_full<atTop>(c)) {
        chunk_push_front<atTop>(c, x);
      } else {
        deep_layer_type& d = layer.deep;
        d.weight = c.chunk->weight;
        d.front_outer = chunk_alloc<atTop>();
        d.front_inner = chunk_alloc<atTop>();
        d.back_inner = c;
        d.back_outer = chunk_alloc<atTop>();
        curdepth++;
        layers[curdepth].shallow = chunk_alloc<atTopFalse>();
        chunk_push_front<atTop>(d.front_inner, x, d.weight);
      }
    } else { // deep
      deep_layer_type& d = layer.deep;
      if (! chunk_full<atTop>(d.front_inner)) {
        chunk_push_front<atTop>(d.front_inner, x, d.weight);
      } else if (! chunk_full<atTop>(d.front_outer)) {
        chunk_push_front<atTop>(d.front_outer, x, d.weight);
      } else { // both front buffers are full
        chunk_ptr c = d.front_inner;
        d.front_inner = d.front_outer;
        d.front_outer = chunk_alloc<atTop>();
        top_chunk_set_weight<atTop>(c);
        rec_push_front<atTopFalse>(depth+1, c);
        chunk_push_front<atTop>(d.front_outer, x, d.weight);
      }
    }
    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants<atTop>(depth);
    #endif
  }

  template <bool atTop>  
  inline void rec_push_front(int depth, chunk_ptr x) {
    item_type y;
    y.rec_item = x;
    rec_push_front<atTop>(depth, y);
  }

  // symmetric to rec_push_front
  // (obtained by swapping "front" and "back" in code of rec_push_front)
  template <bool atTop>  
  void rec_push_back(int depth, item_type x) {
    layer_type& layer = layers[depth];
    if (is_shallow<atTop>(depth)) {
      chunk_ptr c = layer.shallow;
      if (! chunk_full<atTop>(c)) {
        chunk_push_back<atTop>(c, x);
      } else {
        deep_layer_type& d = layer.deep;
        d.weight = c.chunk->weight;
        d.back_outer = chunk_alloc<atTop>();
        d.back_inner = chunk_alloc<atTop>();
        d.front_inner = c;
        d.front_outer = chunk_alloc<atTop>();
        curdepth++;
        layers[curdepth].shallow = chunk_alloc<atTopFalse>();
        chunk_push_back<atTop>(d.back_inner, x, d.weight);
      }
    } else { // deep
      deep_layer_type& d = layer.deep;

      if (! chunk_full<atTop>(d.back_inner)) {
        chunk_push_back<atTop>(d.back_inner, x, d.weight);
      } else if (! chunk_full<atTop>(d.back_outer)) {
        chunk_push_back<atTop>(d.back_outer, x, d.weight);
      } 
      /* slower:
      bool outer_empty = chunk_empty<atTop>(d.back_outer);
      bool outer_full = chunk_full<atTop>(d.back_outer);
      if (! outer_empty && ! outer_full) {
        chunk_push_back<atTop>(d.back_outer, x, d.weight);
      } else if (outer_empty) {
        if (chunk_full<atTop>(d.back_inner))
          chunk_push_back<atTop>(d.back_outer, x, d.weight);
        else
          chunk_push_back<atTop>(d.back_inner, x, d.weight);
      } */
      else { // both back buffers are full
        chunk_ptr c = d.back_inner;
        d.back_inner = d.back_outer;
        d.back_outer = chunk_alloc<atTop>();
        top_chunk_set_weight<atTop>(c);
        rec_push_back<atTopFalse>(depth+1, c);
        chunk_push_back<atTop>(d.back_outer, x, d.weight);
      }
    }
  }

  template <bool atTop>  
  inline void rec_push_back(int depth, chunk_ptr x) {
    item_type y;
    y.rec_item = x;
    rec_push_back<atTop>(depth, y);
  }

  // compact a deep layer to shallow if only 0 or 1 item and not at top level .
  // assumes current layer to be deep
  template <bool atTop>  
  inline void rec_check(int depth) {
    if (atTop) // || depth == 0
      return;

    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] rec_check ===\n", depth);
    print_structure(depth);
    #endif

    assert(! is_shallow<atTop>(depth));
    deep_layer_type& d = layers[depth].deep; 
    size_t sfi = chunk_size<atTop>(d.front_inner);
    if (sfi > 1)
      return;
    size_t sbi = chunk_size<atTop>(d.back_inner);
    if (sbi > 1)
      return;
    bool middle_empty = rec_empty<atTopFalse>(depth+1);
    // step 1
    if (sfi == 0 && sbi == 0 && !middle_empty) {
      chunk_free<atTop>(d.front_inner);
      d.front_inner = rec_front<atTopFalse,doPopTrue>(depth+1).rec_item;
      sfi = chunk_size<atTop>(d.front_inner);
      middle_empty = rec_empty<atTopFalse>(depth+1);
    }
    // step 2
    if (sfi + sbi <= 1 && middle_empty) {
      chunk_free<atTop>(d.back_outer);
      chunk_free<atTop>(d.front_outer);
      chunk_ptr c;
      if (sbi == 1) {
        c = d.back_inner;
        chunk_free<atTop>(d.front_inner);
      } else {
        c = d.front_inner;
        chunk_free<atTop>(d.back_inner);
      }
      assert(curdepth == depth+1);
      chunk_free<atTopFalse>(layers[curdepth].shallow);
      curdepth--;
      layers[curdepth].shallow = c;
    }
      
    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] result rec_check ===\n", depth);
    print_structure(depth);
    #endif

  }

  template <bool atTop, bool doPop>  
  item_type rec_front(int depth) {
    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants<atTop>(depth);
    #endif

    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] pop_front ===\n", depth);
    print_structure(depth);
    #endif
    item_type x;
    layer_type& layer = layers[depth];
    if (is_shallow<atTop>(depth)) {
      chunk_ptr c = layer.shallow;
      x = chunk_front<atTop,doPop>(c);
    } else { // deep
      deep_layer_type& d = layer.deep;
      bool need_check = false;
      
      bool inner_empty = chunk_empty<atTop>(d.front_inner);
      bool inner_full = chunk_full<atTop>(d.front_inner);
      if (!inner_empty && !inner_full) {
        x = chunk_front<atTop,doPop>(d.front_inner);
        need_check = true;
      } else if (!inner_empty) {
        if (! chunk_empty<atTop>(d.front_outer)) {
          x = chunk_front<atTop,doPop>(d.front_outer);
        } else {
          x = chunk_front<atTop,doPop>(d.front_inner);
          need_check = true;
        }
      }
      /*slower:
      if (! chunk_empty<atTop>(d.front_outer)) {
        x = chunk_front<atTop,doPop>(d.front_outer);
      } else if (! chunk_empty<atTop>(d.front_inner)) {
        x = chunk_front<atTop,doPop>(d.front_inner);
        need_check = true;
      } */ 
      else if (! rec_empty<atTopFalse>(depth+1)) {
        chunk_free<atTop>(d.front_inner);
        d.front_inner = rec_front<atTopFalse,doPopTrue>(depth+1).rec_item;
        x = chunk_front<atTop,doPop>(d.front_inner);
        need_check = true;
      } else if (! chunk_empty<atTop>(d.back_outer)) {
        chunk_ptr c = d.front_inner;
        d.front_inner = d.back_inner;
        d.back_inner = d.back_outer;
        d.back_outer = c;
        x = chunk_front<atTop,doPop>(d.front_inner);
      } else { // everything in back_inner
        x = chunk_front<atTop,doPop>(d.back_inner);
        need_check = true;
      }
      if (doPop && !atTop)
        d.weight -= x.rec_item.chunk->weight;
      if (need_check)
         rec_check<atTop>(depth);
    }
    
    #ifdef BOOTCHUNKSEQ_TEST_ALL
    printf("=== [%d] result of pop_front ===\n", depth);
    print_structure(depth);
    #endif

    #ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants<atTop>(depth);
    #endif

    return x;
  }

  // obtained by swapping "front" and "back" in code of rec_front
  template <bool atTop, bool doPop>  
  item_type rec_back(int depth) {
    layer_type& layer = layers[depth];
    item_type x;
    if (is_shallow<atTop>(depth)) {
      chunk_ptr c = layer.shallow;
      x = chunk_back<atTop,doPop>(c);
    } else { // deep
      deep_layer_type& d = layer.deep; 
      bool need_check = false;

      bool inner_empty = chunk_empty<atTop>(d.back_inner);
      bool inner_full = chunk_full<atTop>(d.back_inner);
      if (!inner_empty && !inner_full) {
        x = chunk_back<atTop,doPop>(d.back_inner);
        need_check = true;
      } else if (!inner_empty) {
        if (! chunk_empty<atTop>(d.back_outer)) {
          x = chunk_back<atTop,doPop>(d.back_outer);
        } else {
          x = chunk_back<atTop,doPop>(d.back_inner);
          need_check = true;
        }
      }
      /* slower:
      if (! chunk_empty<atTop>(d.back_outer)) {
        x = chunk_back<atTop,doPop>(d.back_outer);
      } else if (! chunk_empty<atTop>(d.back_inner)) {
        x = chunk_back<atTop,doPop>(d.back_inner);
        need_check = true;
      }*/
       else if (! rec_empty<atTopFalse>(depth+1)) {
        chunk_free<atTop>(d.back_inner);
        d.back_inner = rec_back<atTopFalse,doPopTrue>(depth+1).rec_item;
        x = chunk_back<atTop,doPop>(d.back_inner);
        need_check = true;
      } else if (! chunk_empty<atTop>(d.front_outer)) {
        chunk_ptr c = d.back_inner;
        d.back_inner = d.front_inner;
        d.front_inner = d.front_outer;
        d.front_outer = c;
        x = chunk_back<atTop,doPop>(d.back_inner);
      } else { // everything in front_inner
        x = chunk_back<atTop,doPop>(d.front_inner);
        need_check = true;
      }
      if (doPop && !atTop)
        d.weight -= x.rec_item.chunk->weight;
      if (need_check)
        rec_check<atTop>(depth);
    }
    return x;
  }

  // take a chunk "c" at depth "depth", and concatenate it into
  // the back of the middle sequence (which is at depth "depth+1").
  template <bool atTop>  
  void rec_push_buffer_back(int depth, chunk_ptr c) {
    assert(depth < curdepth);
    size_t csize = chunk_size<atTop>(c);
    if (csize == 0) {
      chunk_free<atTop>(c);
    } else {
      if (! rec_empty<atTopFalse>(depth+1)) {
        chunk_ptr b = rec_back<atTopFalse,doPopFalse>(depth+1).rec_item;
        size_t bsize = chunk_size<atTop>(b);
        if (bsize + csize <= capacity<atTop>(depth)) {
          rec_back<atTopFalse,doPopTrue>(depth+1);
          chunk_back_to_front<atTop>(b, c);
          chunk_free<atTop>(b);
        }
      }
      top_chunk_set_weight<atTop>(c);
      rec_push_back<atTopFalse>(depth+1, c);
    }
  }

  // symmetric to rec_push_buffer_back
  template <bool atTop>  
  void rec_push_buffer_front(int depth, chunk_ptr c) {
    assert(depth < curdepth);
    size_t csize = chunk_size<atTop>(c);
    if (csize == 0) {
      chunk_free<atTop>(c);
    } else {
      if (! rec_empty<atTopFalse>(depth+1)) {
        chunk_ptr b = rec_front<atTopFalse,doPopFalse>(depth+1).rec_item;
        size_t bsize = chunk_size<atTop>(b);
        if (bsize + csize <= capacity<atTop>(depth)) {
          rec_front<atTopFalse,doPopTrue>(depth+1);
          chunk_front_to_back<atTop>(b, c);
          chunk_free<atTop>(b);
        }
      }
      top_chunk_set_weight<atTop>(c);
      rec_push_front<atTopFalse>(depth+1, c);
    }
  }

  // moves the spine starting at depth from a structure to another;
  // but does not modify data from the source structure.
  template <bool atTop>
  static void rec_move_spine(int depth, self_type& source, self_type& target) {
    int curdepth = source.curdepth;
    target.curdepth = curdepth;
    for (int i = depth; i < curdepth; i++) 
      target.layers[i].deep = source.layers[i].deep; // copy layer by value
    target.layers[curdepth].shallow = source.layers[curdepth].shallow;
  }

  // concatenate data from other; leaving other in an unspecified state,
  // but not leaking memory (since chunks are migrated).
  template <bool atTop>
  void rec_concat(int depth, self_type& other) {
      
    #ifdef BOOTCHUNKSEQ_TEST
    printf("=== [%d] Concat ===\n", depth);
    print_structure(depth);
    printf("===      with ===\n", depth);
    other.print_structure(depth);
    #endif

    size_t& curdepth1 = curdepth;
    size_t& curdepth2 = other.curdepth;
    assert(depth <= curdepth1 && depth <= curdepth2);
    layer_type& layer1 = layers[depth];
    layer_type& layer2 = other.layers[depth];
    if (depth == curdepth2) { // if 2 is shallow, transfer items
      chunk_ptr c = layer2.shallow;
      int nb = chunk_size<atTop>(c);
      for (int i = 0; i < nb; i++) {
        item_type x = chunk_front<atTop,doPopTrue>(c);
        rec_push_back<atTop>(depth, x);
      }
      chunk_free<atTop>(c);
    } else if (depth == curdepth1) { // if 1 is shallow, copy spine, transfer items
      chunk_ptr c = layer1.shallow;
      // copy the spine
      rec_move_spine<atTop>(depth, other, *this);
      // transfer the items (symmetric to above)
      int nb = chunk_size<atTop>(c);
      for (int i = 0; i < nb; i++) {
        item_type x = chunk_back<atTop,doPopTrue>(c);
        rec_push_front<atTop>(depth, x);
      }
      chunk_free<atTop>(c);
    } else { // both 1 and 2 are deep
      deep_layer_type& d1 = layer1.deep; 
      deep_layer_type& d2 = layer2.deep;

      // push the buffers in the middle sequences
      rec_push_buffer_back<atTop>(depth, d1.back_inner);
      rec_push_buffer_back<atTop>(depth, d1.back_outer);
      other.rec_push_buffer_front<atTop>(depth, d2.front_inner);
      other.rec_push_buffer_front<atTop>(depth, d2.front_outer);
      // fuse front and back, if needed
      if (   ! rec_empty<atTopFalse>(depth+1) 
          && ! other.rec_empty<atTopFalse>(depth+1) ) {
        chunk_ptr c1 = rec_back<atTopFalse,doPopFalse>(depth+1).rec_item;
        chunk_ptr c2 = other.rec_front<atTopFalse,doPopFalse>(depth+1).rec_item;
        int nb1 = chunk_size<atTop>(c1);
        int nb2 = chunk_size<atTop>(c2);
        if (nb1 + nb2 <= capacity<atTop>(depth)) {
          rec_back<atTopFalse,doPopTrue>(depth+1);
          other.rec_front<atTopFalse,doPopTrue>(depth+1);
          chunk_front_to_back<atTop>(c2, c1);
          chunk_free<atTop>(c2);
          top_chunk_set_weight<atTop>(c1);
          rec_push_back<atTopFalse>(depth+1, c1); 
          // note: push might be factorized with earlier operations
        }
      }
 
      // migrate back chunks of the other and update the weight
      d1.back_inner = d2.back_inner;
      d1.back_outer = d2.back_outer;
      if (! atTop)
        d1.weight += d2.weight;

      // recursively concatenate
      rec_concat<atTopFalse>(depth+1, other);

      // and call check
      rec_check<atTop>(depth);
    }
    #ifdef BOOTCHUNKSEQ_TEST
    printf("=== [%d] result of concat ===\n", depth);
    print_structure(depth);
    #endif

  }

  template <bool atTop>  
  weight_type fix_deep_weight(int depth) { 
    deep_layer_type& d = layers[depth].deep;
    weight_type wfo = chunk_weight<atTop>(d.front_outer);
    weight_type wfi = chunk_weight<atTop>(d.front_inner);
    weight_type wmid = rec_weight<atTopFalse>(depth+1);
    weight_type wbi = chunk_weight<atTop>(d.back_inner);
    weight_type wbo = chunk_weight<atTop>(d.back_outer);
    d.weight = wfo + wfi + wmid + wbi + wbo;
  }

  template <bool atTop>  
  void rec_split(int depth, weight_type w, item_type& x, self_type& other) {
    #ifdef BOOTCHUNKSEQ_TEST
    printf("=== [%d] Splitting at %d ===\n", depth, w);
    print_structure(depth);
    #endif

    layer_type& layer1 = layers[depth];
    layer_type& layer2 = other.layers[depth];
    if (is_shallow<atTop>(depth)) {
      // printf("[%d]--> Splitting shallow at %d\n", depth, w);
      other.curdepth = depth;
      layer2.shallow = layer1.shallow;
      layer1.shallow = chunk_alloc<atTop>();
      chunk_split<atTop>(w, layer2.shallow, x, layer1.shallow); 
    } else { // deep
      self_type& current = *this;
      auto fix = [depth, &current, &other, &x]() {
        current.fix_deep_weight<atTop>(depth);
        other.fix_deep_weight<atTop>(depth);
        current.rec_check<atTop>(depth);
        other.rec_check<atTop>(depth);
        #ifdef BOOTCHUNKSEQ_TEST
        printf("=== [%d] result of split===\n", depth);
        current.print_structure(depth);
        printf("===      middle ===\n", depth);
        item_print(depth, x);
        printf("===      and ===\n", depth);
        other.print_structure(depth);
        #endif

      };
      deep_layer_type& d1 = layer1.deep; 
      deep_layer_type& d2 = layer2.deep; 
      /*
      printf("[%d]--> Splitting deep at %d, weights: %d %d |%d| %d %d\n", depth, w,
        chunk_weight<atTop>(d1.front_outer),
        chunk_weight<atTop>(d1.front_inner),
        rec_weight<atTopFalse>(depth+1),
        chunk_weight<atTop>(d1.back_inner),
        chunk_weight<atTop>(d1.back_outer));
      */
      d2.front_outer = chunk_alloc<atTop>();
      d2.front_inner = chunk_alloc<atTop>();
      d2.back_inner = chunk_alloc<atTop>();
      d2.back_outer = chunk_alloc<atTop>();
      weight_type wtotal = 0;
      weight_type wleft = w - wtotal;
      wtotal = chunk_weight<atTop>(d1.front_outer);
      if (w < wtotal) { // split in front-outer
        std::swap(d2.front_outer, d1.front_outer);
        std::swap(d2.front_inner, d1.front_inner);
        rec_move_spine<atTop>(depth+1, *this, other);
        curdepth = depth+1;
        layers[curdepth].shallow = chunk_alloc<atTopFalse>();
        std::swap(d2.back_inner, d1.back_inner);
        std::swap(d2.back_outer, d1.back_outer);
        chunk_split<atTop>(wleft, d2.front_outer, x, d1.front_inner);
        return fix();
      } 
      wleft = w - wtotal;
      wtotal += chunk_weight<atTop>(d1.front_inner);
      if (w < wtotal) { // split in front-inner
        std::swap(d2.front_inner, d1.front_inner);
        rec_move_spine<atTop>(depth+1, *this, other);
        curdepth = depth+1;
        layers[curdepth].shallow = chunk_alloc<atTopFalse>();
        std::swap(d2.back_inner, d1.back_inner);
        std::swap(d2.back_outer, d1.back_outer);
        std::swap(d1.front_inner, d1.front_outer);
        chunk_split<atTop>(wleft, d2.front_inner, x, d1.back_inner);
        return fix();
      }
      wleft = w - wtotal;
      wtotal += rec_weight<atTopFalse>(depth+1);
      if (w < wtotal) { // split in middle
        std::swap(d2.back_inner, d1.back_inner);
        std::swap(d2.back_outer, d1.back_outer);
        chunk_free<atTop>(d2.front_inner);
        item_type y;
        rec_split<atTopFalse>(depth+1, wleft, y, other);
        d2.front_inner = y.rec_item;
        wleft -= rec_weight<atTopFalse>(depth+1);
        // printf("[%d]--> Resplitting middle chunk at %d\n", depth, wleft);
        chunk_split<atTop>(wleft, d2.front_inner, x, d1.back_inner);
        return fix();
      }
      wleft = w - wtotal;
      wtotal += chunk_weight<atTop>(d1.back_inner);
      if (w < wtotal) { // split in back-inner
        std::swap(d2.front_inner, d1.back_inner);
        std::swap(d2.back_inner, d1.back_outer);
        other.curdepth = depth+1;
        other.layers[other.curdepth].shallow = chunk_alloc<atTopFalse>();
        chunk_split<atTop>(wleft, d2.front_inner, x, d1.back_inner);
        return fix();
      }
      wleft = w - wtotal;
      wtotal += chunk_weight<atTop>(d1.back_outer);
      assert(w < wtotal); // split in back-outer
      {
        std::swap(d2.front_inner, d1.back_outer);
        other.curdepth = depth+1;
        other.layers[other.curdepth].shallow = chunk_alloc<atTopFalse>();
        chunk_split<atTop>(wleft, d2.front_inner, x, d1.back_outer);
        return fix();
      }
    }
  }


  /*---------------------------------------------------------------------*/

  static constexpr int depth0 = 0;

public:

  using value_type = TopItem;
  struct do_not_initialize_type { };
  static constexpr do_not_initialize_type do_not_initialize = { } ;

  bootchunkseq() {
    debug_alloc();
    init();
    debug_alloc();
  }

  bootchunkseq(do_not_initialize_type dummy) {
    curdepth = uninitialized_depth;
  }

  ~bootchunkseq() {
    debug_alloc();
    uninit();
    debug_alloc();
  }

  bootchunkseq(const self_type& other) {
    curdepth = other.curdepth;
    layers = other.layers;
    // top level
    {
      layer_type& layer = layers[0];
      deep_layer_type& d = layer.deep; 
      d.front_outer = chunk_copy<atTopTrue>(depth0, d.front_outer);
      d.front_inner = chunk_copy<atTopTrue>(depth0, d.front_inner);
      d.back_inner  = chunk_copy<atTopTrue>(depth0, d.back_inner);
      d.back_outer  = chunk_copy<atTopTrue>(depth0, d.back_outer);
    }
    // other deep levels
    for (size_t depth = 1; depth < curdepth; depth++) {
      layer_type& layer = layers[depth];
      deep_layer_type& d = layer.deep; 
      d.front_outer = chunk_copy<atTopFalse>(depth, d.front_outer);
      d.front_inner = chunk_copy<atTopFalse>(depth, d.front_inner);
      d.back_inner  = chunk_copy<atTopFalse>(depth, d.back_inner);
      d.back_outer  = chunk_copy<atTopFalse>(depth, d.back_outer);
    }
    // shallow level
    {
      layer_type& layer = layers[curdepth];
      layer.shallow = chunk_alloc<atTopFalse>(curdepth, layer.shallow);
    }
  }

  void init() {
    curdepth = 1;
    deep_layer_type& d = layers[0].deep;
    d.weight = 0;
    d.front_outer = chunk_alloc<atTopTrue>();
    d.front_inner = chunk_alloc<atTopTrue>();
    d.back_inner  = chunk_alloc<atTopTrue>();
    d.back_outer  = chunk_alloc<atTopTrue>();
    layers[1].shallow = chunk_alloc<atTopFalse>();
  }

  void uninit() {
    // top level
    {
      deep_layer_type& d = layers[depth0].deep; 
      chunk_deep_free(depth0, d.front_outer);
      chunk_deep_free(depth0, d.front_inner);
      chunk_deep_free(depth0, d.back_inner);
      chunk_deep_free(depth0, d.back_outer);
    }
    // other deep levels
    for (size_t depth = 1; depth < curdepth; depth++) {
      deep_layer_type& d = layers[depth].deep; 
      chunk_deep_free(depth, d.front_outer);
      chunk_deep_free(depth, d.front_inner);
      chunk_deep_free(depth, d.back_inner);
      chunk_deep_free(depth, d.back_outer);
    }
    // shallow level
    chunk_deep_free(curdepth, layers[curdepth].shallow);    
  }

  inline bool empty() const {  
    return rec_empty<atTopTrue>(depth0);
  }

  inline size_t size() {  // const
    return rec_weight<atTopTrue>(depth0);
  }

  inline void push_front(const value_type& x) { 
    item_type y;
    y.top_item = x;
    rec_push_front<atTopTrue>(depth0, y);
    // TODO: need manual deallocation of y, or not? y.~item_type();
  }

  inline value_type pop_front() {
    item_type x = rec_front<atTopTrue, doPopTrue>(depth0);
    return x.top_item;
  }
 
  // temporary
  inline void push_back(const value_type& x) {
    item_type y;
    y.top_item = x;
    rec_push_back<atTopTrue>(depth0, y);
    // TODO: need manual deallocation of y, or not? y.~item_type();
  }

  // temporary
  inline value_type pop_back() {
    item_type x = rec_back<atTopTrue, doPopTrue>(depth0);
    return x.top_item;
  }

  // concatenate the items of "other" to the right of the present sequence, 
  // in place; 
  // LATER: "other" is left in a state where curdepth=uninitialized_depth.
  void concat(self_type& other) {
    rec_concat<atTopTrue>(depth0, other);
    other.curdepth = uninitialized_depth;
    other.init(); // REESTABLISH INVARIANT
  }

  // alias for benchmarks
  void transfer_to_back(self_type& other) {
    concat(other);
  }

  // takes a split index; stores in "dst" the value at this index,
  // and stores in "other" the items beyond this index.
  void split(size_t index, value_type& dst, self_type& other) {
    other.uninit(); // DEALLOC STRUCTURE
    item_type y;
    rec_split<atTopTrue>(depth0, index, y, other);
    dst = y.top_item;
  }

  // takes a split index; stores items starting at this index
  // into the sequence "other". 
  // LATER: Assumes other.curdepth=uninitialized_depth
  void split(size_t index, self_type& other) {
    value_type dst;
    split(index, dst, other);
    other.push_front(dst);
  }

  // for benchmarks
  void split_approximate(self_type& dst) {
    size_t i = size() / 2;
    split(i, dst);
  }

  static void debug_alloc() {
#ifdef BOOTCHUNKSEQ_TEST
    printf("--> alloc: %d, free: %d\n", nbAlloc, nbDealloc);
#endif
  }

  void check() {
#ifdef BOOTCHUNKSEQ_TEST
    rec_check_invariants<atTopTrue>(depth0);
#endif
  }

  void print() {
    printf("==========================\n");
    print_structure(depth0);
  }

  void swap(self_type& other) {
    assert(false);
  }

  //-----------------------------------------

  using iterator = int; // dummy

  iterator begin() const {
    assert(false);
  }
  iterator end() const {
    assert(false);
  }

};


/***********************************************************************/

}
}
}

#endif /*! _PASL_DATA_BOOTCHUNKSEQ_INDIRECT_H_ */
