/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Fast finger tree
 * \file fftree.hpp
 * \ingroup fftree
 *
 */

#include "fixedcapacity.hpp"
#include "ftree.hpp"
#include "chunk.hpp"
#include "iterator.hpp"
#include "bootchunkseq_weighted.hpp"

#ifndef _PASL_DATA_FFTREE_H_
#define _PASL_DATA_FFTREE_H_

namespace pasl {
namespace data {
namespace fftree_base {

/***********************************************************************/

/*!
 * \class fftree
 * \ingroup fftree
 * \brief Resizable sequence container with logarithmic-time split
 * and concat
 *
 * \tparam FTree Type of \ref ftree
 *
 */
template <class FFTree_config>
class fftree {
  
  /*---------------------------------------------------------------------*/
  /* Type aliases */

private:
  
  typedef typename FFTree_config::inner_chunk_type inner_chunk_type;
  typedef typename FFTree_config::inner_chunk_type::algebra_type internal_algebra_type;
  typedef typename FFTree_config::internal_measured_type internal_measured_type;
  typedef typename FFTree_config::internal_measure_type internal_measure_type;
  
  typedef typename FFTree_config::outer_chunk_type outer_chunk_type;
  typedef typename FFTree_config::outer_chunk_type::algebra_type client_algebra_type;
  typedef typename FFTree_config::client_measured_type client_measured_type;
  typedef typename FFTree_config::client_measure_type client_measure_type;
  
  typedef outer_chunk_type chunk_type;
  
  typedef typename FFTree_config::ftree_type ftree_type;
  typedef typename FFTree_config::leaf_node_type leaf_node_type;
  
public:
  
  /*---------------------------------------------------------------------*/
  /** @name Container-specific types
   */
  ///@{
  
  //! type which sets the [configuration parameters of this fast finger tree](@ref fftree_config)
  typedef FFTree_config fftree_config_type;
  //! type of this container
  typedef fftree<fftree_config_type> self_type;
  //! alias for `fftree_config_type::size_type`
  typedef typename fftree_config_type::size_type size_type;
  //! alias for `allocator_type::difference_type`
  typedef typename fftree_config_type::inner_chunk_type::allocator_type::difference_type difference_type;
 
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Item-specific  types
   */
  ///@{

  //! type of the allocator object used to define the storage allocation model
  typedef typename fftree_config_type::inner_chunk_type::allocator_type allocator_type;
  //! type of the items stored in the container
  typedef typename fftree_config_type::value_type value_type;
  //! alias for `value_type&`
  typedef value_type& reference;
  //! alias for `const value_type&`
  typedef const value_type& const_reference;
  //! alias for `value_type*`
  typedef value_type* pointer;
  //! alias for `const value_type*`
  typedef const value_type* const_pointer;
  //! type of a [segment](@ref segments) of values in a chunk
  typedef typename fftree_config_type::inner_chunk_type::segment_type segment_type;
  //! type of the STL-style iterator
  typedef typename fftree_config_type::iterator_type iterator;
  //! type of the result of a weighted split operation
  typedef struct {
    self_type* fr;                   //!< front
    value_type middle;               //!< middle
    self_type* bk;                   //!< back
  } split_type;
  
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Cached-measurement-specific  types
   */
  ///@{
  
  //! type of the measure value of zero or more items in the container
  typedef client_measured_type measured_type;
  //! type of the measure operators whose purpose is to compute the measure values for items in the container
  typedef client_measure_type measure_type;
  //! type of the algebra whose purpose is to combine measure values
  typedef client_algebra_type algebra_type;
  
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Constant values
   */
  ///@{
  
  static constexpr bool has_cached_size = fftree_config_type::has_cached_size;
  
  ///@}
  
private:
  
  static constexpr int chunk_capacity = fftree_config_type::chunk_capacity;
  static constexpr int compaction_group_sz = fftree_config_type::compaction_group_sz;
  
  typedef ftree_type* ftree_p;
  typedef leaf_node_type* leaf_p;
  typedef self_type* self_pointer;
  static constexpr int tinybuffer_sz = compaction_group_sz*2 + 8;
  template <class Item>
  using tinybuffer_allocator_type =
    fixedcapacity::inline_allocator<Item, tinybuffer_sz>;
  template <class Item>
  using tinybuffer_type =
    fixedcapacity::ringbuffer_idx<tinybuffer_allocator_type<Item> >;
  
  /*---------------------------------------------------------------------*/
  /* Side buffer
   *
   * A sidebuffer is a buffer that consists of one outer and one inner
   * chunk.
   *
   * An of object of type sidebuffer is oriented to either the front or
   * back depending on whether the object is positioned on the front or
   * back of the fftree. If front oriented, then the outer chunk
   * contains the items closest to the front, whereas if back oriented,
   * the outer contains the items closest to the back.
   *
   * Invariant: the inner chunk is either full or empty.
   */
  class sidebuffer {
  public:
    
    outer_chunk_type outer;
    outer_chunk_type inner;
    
    /* exchanges the contents of the inner and outer chunk of this
     * sidebuffer */
    void rotate() {
      outer.swap(inner);
    }
    
    /* exchanges the contents of the given sidebuffer with the contents
     * of this sidebuffer, assuming that this sidebuffer is empty,
     * the given sidebuffer is nonempty, and the two chunks are oriented
     * differently (e.g., front oriented / back oriented or vice versa).
     */
    void migrate(sidebuffer& other) {
      assert(outer.empty());
      assert(inner.empty());
      if (other.inner.empty())
        other.rotate();
      outer.swap(other.inner);
      assert(! outer.empty());
    }
    
    /* exchanges the contents of the given chunk pair with those of this
     * dual chunk. */
    void swap(sidebuffer& other) {
      outer.swap(other.outer);
      inner.swap(other.inner);
    }
    
  };
  
  /*---------------------------------------------------------------------*/
  /* Basic members */
  
  sidebuffer fr;
  ftree_p ft;
  sidebuffer bk;
  measure_type meas;
  //! \todo (for bootstrap) introduce mode in which cached value is updated incrementally by update operations
  mutable measured_type cached;
  
  /*---------------------------------------------------------------------*/
  /* Auxilliary functions */
  
  static void ftree_push_back(ftree_p ft, leaf_node_type* leaf) {
    leaf->init();
    ft->push_back(leaf);
  }
  
  static void ftree_push_front(ftree_p ft, leaf_node_type* leaf) {
    leaf->init();
    ft->push_front(leaf);
  }
  
  /* creates a fresh ftree leaf node and exhcanges the contents
   * of its associated chunk with those of the given chunk
   * `src`. returns the fresh leaf, leaving `src` empty.
   */
  static leaf_p create_leaf_node(outer_chunk_type& src) {
    leaf_p fresh = new leaf_node_type();
    assert(fresh != NULL);
    src.swap(fresh->item);
    return fresh;
  }
  
  /* pushes to the back of the ftree the contents of the given
   * chunk `src`, leaving `src` empty upon return.
   */
  void ftree_push_back(outer_chunk_type& src) {
    assert(! src.empty());
    ftree_push_back(ft, create_leaf_node(src));
  }
  
  /* same as above but acts on the front of the ftree.
   */
  void ftree_push_front(outer_chunk_type& src) {
    assert(! src.empty());
    ftree_push_front(ft, create_leaf_node(src));
  }
  
  /* similar to ftree_push_back but tries to coalesce with a leaf
   * in the ftree
   */
  void ftree_push_back_try_coalesce(outer_chunk_type& src) {
    if (ft->empty()) {
      ftree_push_back(src);
      return;
    }
    leaf_p leaf = ft->back();
    if (leaf->item.size() + src.size() > chunk_capacity) {
      ftree_push_back(src);
      return;
    }
    ft->pop_back();
    inner_chunk_type tmp;
    tmp.swap(src);
    tmp.transfer_from_front_to_back(meas, leaf->item, tmp.size());
    ftree_push_back(ft, leaf);
  }
  
  /* same as above but acts on the front of the ftree */
  void ftree_push_front_try_coalesce(outer_chunk_type& src) {
    if (ft->empty()) {
      ftree_push_front(src);
      return;
    }
    leaf_p leaf = ft->front();
    if (leaf->item.size() + src.size() > chunk_capacity) {
      ftree_push_front(src);
      return;
    }
    ft->pop_front();
    inner_chunk_type tmp;
    tmp.swap(src);
    tmp.transfer_from_back_to_front(meas, leaf->item, tmp.size());
    ftree_push_front(ft, leaf);
  }
  
  /* moves into the finger tree any inner side chunks than violate the
   * chunk invariant, which requires that inner side chunks are only
   * either full or empty
   */
  void restore_chunk_invariants() {
    if (! (bk.inner.full() || bk.inner.empty()))
      ftree_push_back_try_coalesce(bk.inner);
    if (! (fr.inner.full() || fr.inner.empty()))
      ftree_push_front_try_coalesce(fr.inner);
  }
  
  /* exchanges the contents of the chunk associated with the
   * given leaf node `dst` with those of the given chunk `buf`
   * and destroys `dst`.
   */
  void destroy_leaf_node(leaf_p dst, outer_chunk_type& buf) {
    buf.swap(dst->item);
    delete dst;
  }
  
  /* pops from the back of the finger tree a leaf node, exchanges
   * the contents of the chunk associated with the leaf node
   * with those of the given chunk, and destroys the leaf node.
   */
  void ftree_pop_back(outer_chunk_type& dst) {
    assert(! ft->empty());
    leaf_p leaf = ft->back();
    ft->pop_back();
    destroy_leaf_node(leaf, dst);
  }
  
  /* same as above but acts on the front of the ftree */
  void ftree_pop_front(outer_chunk_type& dst) {
    assert(! ft->empty());
    leaf_p leaf = ft->front();
    ft->pop_front();
    destroy_leaf_node(leaf, dst);
  }
  
  /* tries to move nonempty chunks from the front to any
   * empty chunk slots in the back
   */
  inline void shift_chunks_from_front_to_back() {
    assert(! empty());
    if (! bk.outer.empty())
      return;
    bk.rotate();
    if (! bk.outer.empty())
      return;
    if (! ft->empty())
      ftree_pop_back(bk.outer);
    if (! bk.outer.empty())
      return;
    bk.migrate(fr);
    assert(! bk.outer.empty());
  }
  
  /* similar to above */
  inline void shift_chunks_from_back_to_front() {
    assert(! empty());
    if (! fr.outer.empty())
      return;
    fr.rotate();
    if (! fr.outer.empty())
      return;
    if (! ft->empty())
      ftree_pop_front(fr.outer);
    if (! fr.outer.empty())
      return;
    fr.migrate(bk);
    assert(! fr.outer.empty());
  }
  
  /* moves back chunks toward the front so that the
   * outer back chunk is left in an empty state */
  void shift_back_chunks_toward_ftree() {
    if (! bk.inner.empty())
      ftree_push_back(bk.inner);
    bk.rotate();
  }
  
  /* moves front chunks toward the back so that the
   * outer front chunk is left in an empty state */
  void shift_front_chunks_toward_ftree() {
    if (! fr.inner.empty())
      ftree_push_front(fr.inner);
    fr.rotate();
  }
  
  /* transfers from the front of src to the back of dst as many items
   * as can fit into dst, leaving the remaining items in src */
  static void compact_front_to_back(const measure_type& meas,
                                    leaf_node_type* src,
                                    leaf_node_type* dst) {
    size_type f = chunk_capacity - dst->item.size();
    size_type n = src->item.size();
    size_type m = std::min(f, n);
    src->item.transfer_from_front_to_back(meas, dst->item, m);
  }
  
  /* transfers from the front of src to the back of dst as many items
   * as can fit into dst, leaving the remaining items in src */
  static void compact_back_to_front(const measure_type& meas,
                                    leaf_node_type* src,
                                    leaf_node_type* dst) {
    size_type f = chunk_capacity - dst->item.size();
    size_type n = src->item.size();
    size_type m = std::min(f, n);
    src->item.transfer_from_back_to_front(meas, dst->item, m);
  }
  
  /* transfers from the front of the combined contents of the chunks of
   * src to the back of dst as many items as can fit into dst, leaving
   * the remaining items in the chunks of src.
   */
  static void compact_front_to_back(const measure_type& meas,
                                    tinybuffer_type<leaf_node_type*>& src,
                                    leaf_node_type* dst) {
    while (! dst->item.full() && ! src.empty()) {
      leaf_node_type* leaf = src.front();
      if (leaf->item.empty()) {
        src.pop_front();
        delete leaf;
      } else {
        compact_front_to_back(meas, leaf, dst);
      }
    }
  }
  
  /* transfers from the back of the combined contents of the chunks of
   * src to the front of dst as many items as can fit into dst, leaving
   * the remaining items in the chunks of src.
   */
  static void compact_back_to_front(const measure_type& meas,
                                    tinybuffer_type<leaf_node_type*>& src,
                                    leaf_node_type* dst) {
    while (! dst->item.full() && ! src.empty()) {
      leaf_node_type* leaf = src.back();
      if (leaf->item.empty()) {
        src.pop_back();
        delete leaf;
      } else {
        compact_back_to_front(meas, leaf, dst);
      }
    }
  }
  
  /* compacts the contents of the chunks of src into full chunks, pushing
   * each full chunk on the back of dst. if all of the items of the chunks
   * are pushed into the tree, the return value is NULL. otherwise, the
   * return value is a pointer to a partial chunk that contains the
   * remaining items. on return, src is empty.
   */
  leaf_node_type* push_full_chunks_back(const measure_type& meas,
                                        tinybuffer_type<leaf_node_type*>& src,
                                        ftree_p dst) {
    leaf_node_type* leaf = NULL;
    while (! src.empty()) {
      leaf = src.front();
      src.pop_front();
      if (leaf->item.empty()) {
        delete leaf;
        leaf = NULL;
        continue;
      }
      compact_front_to_back(meas, src, leaf);
      if (! src.empty()) {
        assert(leaf->item.full());
        ftree_push_back(dst, leaf);
//        dst->push_back(leaf);
      }
    }
    return leaf;
  }
  
  /* compacts the contents of the chunks of src into full chunks, pushing
   * each full chunk on the front of dst. if all of the items of the chunks
   * are pushed into the tree, the return value is NULL. otherwise, the
   * return value is a pointer to a partial chunk that contains the
   * remaining items. on return, src is empty.
   */
  leaf_node_type* push_full_chunks_front(const measure_type& meas,
                                         tinybuffer_type<leaf_node_type*>& src,
                                         ftree_p dst) {
    leaf_node_type* leaf = NULL;
    while (! src.empty()) {
      leaf = src.back();
      src.pop_back();
      if (leaf->item.empty()) {
        delete leaf;
        leaf = NULL;
        continue;
      }
      compact_back_to_front(meas, src, leaf);
      if (! src.empty()) {
        assert(leaf->item.full());
        ftree_push_front(dst, leaf);
//        dst->push_front(leaf);
      }
    }
    return leaf;
  }
  
  /* moves the contents of the four given chunks (bk.outer,bk.inner,
   * fr.inner,fr.outer) to fresh leaf nodes and put pointers to these
   * leaf nodes in the given buffer dst.
   */
  static void take_middle_chunks(sidebuffer& bk, sidebuffer& fr,
                                 tinybuffer_type<leaf_node_type*>& dst) {
    dst.push_back(create_leaf_node(bk.inner));
    dst.push_back(create_leaf_node(bk.outer));
    dst.push_back(create_leaf_node(fr.outer));
    dst.push_back(create_leaf_node(fr.inner));
  }
  
  /* pops from the back of src the first min(nb,n) chunks pointers,
   * where n equals the number of chunks in src, and pushes the pointers
   * on the buffer dst, leaving chunks in their order in the ftree.
   */
  static void take_chunks_back(ftree_p src, int nb,
                               tinybuffer_type<leaf_node_type*>& dst) {
    for (int i = 0; i < nb; i++) {
      if (src->empty())
        break;
      dst.push_front(src->back());
      src->pop_back();
    }
  }
  
  /* pops from the front of src the first min(nb,n) chunks pointers,
   * where n equals the number of chunks in src, and pushes the pointers
   * on the buffer dst, leaving chunks in their order in the ftree.
   */
  static void take_chunks_front(ftree_p src, int nb,
                                tinybuffer_type<leaf_node_type*>& dst) {
    for (int i = 0; i < nb; i++) {
      if (src->empty())
        break;
      dst.push_back(src->front());
      src->pop_front();
    }
  }
  
  /* prepares for the concatenation of this fftree and the given fftree by
   * transferring all the items contained by the outer buffers on the back
   * of this fftree and the front of the other fftree to the front of this
   * fftree.
   *
   * this operation compacts chunks in a fashion that is safe only in the
   * bag semantics of the fftree, that is, the mode of the fftree in which
   * items can be safely reordered in the container. the compaction ensures
   * that only full chunks ever enter the underlying ftree.
   */
  void evacuate_middle_chunks_for_append_using_bag_semantics(fftree& other) {
    tinybuffer_type<leaf_node_type*> outer_chunks;
    take_middle_chunks(bk, other.fr, outer_chunks);
    outer_chunks.push_back(create_leaf_node(fr.inner));
    outer_chunks.push_back(create_leaf_node(fr.outer));
    leaf_node_type* leaf = push_full_chunks_front(meas, outer_chunks, ft);
    if (leaf != NULL) {
      leaf->item.swap(fr.outer);
      delete leaf;
    }
  }
  
  /* prepares for the concatenation of this fftree and the given fftree by
   * transferring all the items contained by the outer buffers on the back
   * of this fftree and the front of the other fftree to the front of this
   * fftree.
   *
   * this operation ensures that, for any neighborhood of
   * compaction_group_sz many consecutive chunks in the underlying ftree, 
   * the combined size of the chunks fills no fewer than
   * compaction_group_sz-1 chunks.
   */
  void evacuate_middle_chunks_for_append(fftree& other) {
    tinybuffer_type<leaf_node_type*> mid_chunks;
    take_middle_chunks(bk, other.fr, mid_chunks);
    ftree_p ft1 = ft;
    ftree_p ft2 = other.ft;
    tinybuffer_type<leaf_node_type*> bk_chunks;
    tinybuffer_type<leaf_node_type*> fr_chunks;
    take_chunks_back(ft1, std::max(1, compaction_group_sz - 1), bk_chunks);
    take_chunks_front(ft2, std::max(1, compaction_group_sz - 1), fr_chunks);
    for (int i = 0; i < mid_chunks.size(); i++)
      bk_chunks.push_back(mid_chunks[i]);
    mid_chunks.clear();
    leaf_node_type* left;
    leaf_node_type* right;
    left = push_full_chunks_back(meas, bk_chunks, ft1);
    if (left != NULL)
      fr_chunks.push_front(left);
    right = push_full_chunks_front(meas, fr_chunks, ft2);
    if (right != NULL)
      ftree_push_front(ft2, right);
//      ft2->push_front(right);
  }
  
  /* pushes into the back of the fftree the contents generated by
   * `nb` successive applications of `body()`
   */
  template <class Body_gen>
  void _pushn_back(const Body_gen& body_gen, size_type nb) {
    outer_chunk_type buf;
    while (nb > 0) {
      size_type m = std::min((size_type)chunk_capacity, nb);
      nb -= m;
      auto body = body_gen(nb);
      buf.pushn_back(meas, body, m);
      shift_back_chunks_toward_ftree();
      buf.swap(bk.outer);
    }
  }
  
  /* pushes into the front of the fftree the contents generated by
   * `nb` successive applications of `body()`
   */
  template <class Body_gen>
  void _pushn_front(const Body_gen& body_gen, size_type nb) {
    outer_chunk_type buf;
    size_type n = 0;
    while (n < nb) {
      size_type m = std::min((size_type)chunk_capacity, nb - n);
      auto body = body_gen(n);
      buf.pushn_front(meas, body, m);
      shift_front_chunks_toward_ftree();
      buf.swap(fr.outer);
      n += m;
    }
  }
  
  /* combines the cached measure of the given chunk with that of the
   * given measured value
   */
  static void incr_back(client_measured_type& dst,
                        const outer_chunk_type& buf) {
    algebra::incr_back<client_algebra_type>(&dst, buf.cget_cached());
  }
  
  iterator new_iterator(iterator_side_type side) const {
    return iterator(size(),
                    &(fr.outer), &(fr.inner), ft,
                    &(bk.inner), &(bk.outer),
                    get_measure(),
                    side);
  }
  
  /*---------------------------------------------------------------------*/
  /* Split operation */
  
  /* splits chunk `src` by predicate `p` and measure `m`, leaving the
   * first items for which the predicate returns `false` in `dst1` and
   * the remaining items in `dst2`.
   */
  template <typename Pred>
  void split_chunk(const Pred& p,
                   inner_chunk_type& src,
                   internal_measured_type& prefix,
                   outer_chunk_type& dst1, outer_chunk_type& dst2) {
    inner_chunk_type tmp;
    src.transfer_from_back_to_front(meas, tmp, p, prefix);
    src.swap(dst1);
    tmp.swap(dst2);
  }
  
  template <typename Pred>
  void ___split(fftree& dst, internal_measured_type& prefix, const Pred& p) {
    assert(dst.empty());
    if (size() == 0)
      return;
    enum {
      front_outer, front_inner, back_inner, back_outer, middle, not_found
    } pos;
    inner_chunk_type tmp1;
    inner_chunk_type tmp2;
    internal_measured_type cur;
    internal_algebra_type::identity(&cur);
    internal_algebra_type::reduce(&cur, &prefix);
    // find and split the target chunk
    do {
      tmp1.swap(fr.outer);
      internal_algebra_type::reduce(&cur, tmp1.get_cached());
      if (tmp1.size() > 0 && p(cur)) {  // found in front outer
        split_chunk(p, tmp1, prefix, fr.outer, dst.fr.outer);
        pos = front_outer;
        break;
      }
      prefix = cur;
      tmp1.swap(fr.outer);
      tmp1.swap(fr.inner);
      internal_algebra_type::reduce(&cur, tmp1.get_cached());
      if (tmp1.size() > 0 && p(cur)) {  // found in front inner
        split_chunk(p, tmp1, prefix, fr.inner, dst.fr.inner);
        pos = front_inner;
        break;
      }
      prefix = cur;
      tmp1.swap(fr.inner);
      assert(tmp1.size() == 0);
 //     const internal_measured_type* fft_cached = ft->cget_cached();
      internal_measured_type fft_cached;
      fftree_config_type::get_cached_of_ftree(ft, fft_cached);
      internal_algebra_type::reduce(&cur, &fft_cached);
      if (fftree_config_type::csize(fft_cached) > 0 && p(cur)) {  // found in finger tree
        /*
        internal_measured_type tmpm = prefix;
        auto split = ftree_type::template split<Pred>(p, tmpm, ft);
        internal_algebra_type::reduce(&prefix, split.fr->cget_cached());
         */
        auto split = fftree_config_type::ftree_split(p, prefix, ft);
        ft = split.fr;
        delete dst.ft;
        dst.ft = split.bk;
        tmp1.swap(split.middle->item);
        delete split.middle;
        tmp1.transfer_from_back_to_front(meas, tmp2, p, prefix);
        pos = middle;
        break;
      }
      prefix = cur;
      tmp1.swap(bk.inner);
      internal_algebra_type::reduce(&cur, tmp1.get_cached());
      if (tmp1.size() > 0 && p(cur)) {  // found in back inner
        split_chunk(p, tmp1, prefix, bk.inner, dst.bk.inner);
        pos = back_inner;
        break;
      }
      prefix = cur;
      tmp1.swap(bk.inner);
      tmp1.swap(bk.outer);
      internal_algebra_type::reduce(&cur, tmp1.get_cached());
      if (tmp1.size() > 0 && p(cur)) {  // found in back outer
        split_chunk(p, tmp1, prefix, bk.outer, dst.bk.outer);
        pos = back_outer;
        break;
      }
      tmp1.swap(bk.outer);
      // not found
      pos = not_found;
      break;
    } while (false);
    // move chunks occuring after the location of the split
    switch (pos) {
      case front_outer:
        fr.inner.swap(dst.fr.inner);
      case front_inner:
        std::swap(ft, dst.ft);
      case middle:
        bk.inner.swap(dst.bk.inner);
      case back_inner:
        bk.outer.swap(dst.bk.outer);
      case back_outer:
        ;
      case not_found:
        ;
    }
    if (pos == middle) {
      tmp1.swap(bk.outer);
      tmp2.swap(dst.fr.outer);
    }
    restore_chunk_invariants();
    dst.restore_chunk_invariants();
  }
  
  template <typename Pred>
  void __split(fftree& dst, internal_measured_type& pre, const Pred& p) {
    if (dst.empty()) {
      ___split(dst, pre, p);
    } else {
      fftree tmp(meas);
      ___split(tmp, pre, p);
      dst.transfer_to_back(tmp);
    }
  }
  
  template <typename Pred>
  void _split(fftree& dst, const Pred& p) {
    internal_measured_type pre;
    internal_algebra_type::identity(&pre);
    __split(dst, pre, p);
  }
  
  /*---------------------------------------------------------------------*/
  /* Constructors */
  
  void check_chunk_invariant() {
    assert(bk.inner.empty() || bk.inner.full());
    assert(fr.inner.empty() || fr.inner.full());
  }
  
  void init() {
    assert(inner_chunk_type::capacity == outer_chunk_type::capacity);
    ft = new ftree_type();
  }
  
public:
  
  /*---------------------------------------------------------------------*/
  /** @name Constructors and destructors
   */
  ///@{
  
  /*!
   * \brief Empty container constructor
   *
   * Constructs an empty container, with no items.
   *
   * #### Complexity ####
   * Constant
   *
   */
  fftree() {
    init();
  }
  
  /*!
   * \brief Fill constructor
   *
   * Constructs an empty container, with `nb` items.
   * Each item is a copy of `val`.
   *
   * \param nb Number of items to put in the container
   * \param val Value to replicate
   *
   * #### Complexity ####
   * Linear in `nb`.
   *
   */
  fftree(size_type nb, const value_type& val) {
    init();
    pushn_back(val, nb);
  }
  
  /*!
   * \brief Empty container constructor
   *
   * Constructs an empty container, with no items.
   *
   * \param meas Measure object
   *
   * #### Complexity ####
   * Constant
   *
   */
  fftree(const measure_type& meas) : meas(meas) {
    init();
  }
  
  /*!
   * \brief Fill constructor
   *
   * Constructs an empty container, with `nb` items.
   * Each item is a copy of `val`.
   *
   * \param meas Measure object
   *
   * #### Complexity ####
   * Linear in `nb`.
   *
   */
  fftree(const measure_type& meas, size_type nb, const value_type& val)
  : meas(meas) {
    init();
    pushn_back(val, nb);
  }
  
  /*!
   * \brief Destroys the container object
   *
   * This calls Allocator::destroy on each of the
   * contained items, and deallocates all the storage
   * capacity allocated by the fftree using its allocator.
   *
   * #### Complexity ####
   * Linear in fftree size
   *
   */
  ~fftree() {
    clear();
    assert(ft->empty());
    delete ft;
  }
  
  /*!
   * \brief Copy constructor
   *
   * Constructs a container with a copy of each of the
   * elements in `other`, in the same order.
   *
   * \param other Container from which to copy.
   *
   * #### Complexity ####
   * Linear in the resulting container size.
   *
   */
  fftree(const fftree& other)
  : fr(other.fr), ft(new ftree_type(*other.ft)), bk(other.bk), meas(other.meas) {
    using copy_item_type =  typename fftree_config_type::copy_item_type;
    if (fftree_config_type::copy_item_type::should_deep_copy) {
      for_each([&] (size_type, value_type& v) {
        copy_item_type::copy(v);
      });
    }
  }
  
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Capacity
   */
  ///@{
  /*!
   * \brief Test whether the container is empty
   *
   * Returns whether the container is empty (
   * i.e. whether its size is 0).
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  inline bool empty() const {
    bool is_empty =
        fr.outer.empty() && fr.inner.empty()
    &&  ft->empty()
    &&  bk.inner.empty() && bk.outer.empty();
    assert(is_empty ? size() == 0 : true);
    assert(size() == 0 ? is_empty : true);
    return is_empty;
  }
  
  /*!
   * \brief Returns size
   *
   * Returns the number of items in the container.
   *
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  inline size_type size() const {
    size_type sz = 0;
    sz += fr.outer.size() + fr.inner.size();
    internal_measured_type tmp;
    fftree_config_type::get_cached_of_ftree(ft, tmp);
    sz += fftree_config_type::csize(tmp);
    sz += bk.inner.size() + bk.outer.size();
    return sz;
  }
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Cached measurement
   */
  ///@{
  /*!
   * \brief Copies cached measurement
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  void cget_cached(measured_type& dst) const {
    client_algebra_type::identity(&dst);
    incr_back(dst, fr.outer);
    incr_back(dst, fr.inner);
//    auto ft_cached = ft->cget_cached();
    internal_measured_type tmp;
    fftree_config_type::get_cached_of_ftree(ft, tmp);
    auto client_measured = &fftree_config_type::cclient_measured(tmp);
    client_algebra_type::reduce(&dst, client_measured);
    incr_back(dst, bk.inner);
    incr_back(dst, bk.outer);
  }
  
  const measured_type* cget_cached() const {
    cget_cached(cached);
    return &cached;
  }
  
  /*!
   * \brief Returns measurement operator
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  const measure_type& get_measure() const {
    return meas;
  }
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Modifiers
   */
  ///@{
  /*!
   * \brief Adds item at the end
   *
   * Adds a new item to the back of the container,
   * after its current last item. The content of `x` is
   * copied (or moved) to the new item.
   *
   * \param x Value to be copied (or moved) to the new item.
   *
   * #### Complexity ####
   * Amortized constant (worst case logarithmic).
   *
   */
  void push_back(const value_type& x) {
    if (bk.outer.full()) {
      bk.rotate();
      if (bk.outer.full())
        ftree_push_back(bk.outer);
      else
        assert(bk.outer.empty());
    }
    assert(! bk.outer.full());
    bk.outer.push_back(meas, x);
  }
  
  /*!
   * \brief Adds item at the beginning
   *
   * Adds a new item to the front of the container,
   * before its current first item. The content of `x` is
   * copied (or moved) to the new item.
   *
   * \param x Value to be copied (or moved) to the new item.
   *
   * #### Complexity ####
   * Amortized constant (worst case logarithmic).
   *
   */
  void push_front(const value_type& x) {
    if (fr.outer.full()) {
      fr.rotate();
      if (fr.outer.full())
        ftree_push_front(fr.outer);
      else
        assert(fr.outer.empty());
    }
    assert(! fr.outer.full());
    fr.outer.push_front(meas, x);
  }
  
  /*!
   * \brief Deletes last item
   *
   * Removes the last item in the deque container, effectively
   * reducing the container size by one.
   *
   * Calling this method destroys the removed item.
   *
   * Calling this method on an `empty` container causes undefined
   * behavior.
   *
   * #### Complexity ####
   * Amortized constant (worst case logarithmic).
   *
   * \return A copy of the last item in the fftree container.
   *
   */
  value_type pop_back() {
    value_type x = back();
    bk.outer.pop_back(meas);
    return x;
  }
  
  /*!
   * \brief Deletes first item
   *
   * Removes the first item in the deque container, effectively
   * reducing the container size by one.
   *
   * Calling this method destroys the removed item.
   *
   * Calling this method on an `empty` container causes undefined
   * behavior.
   *
   * #### Complexity ####
   * Amortized constant (worst case logarithmic).
   *
   * \return A copy of the first item in the fftree
   * container.
   *
   */
  value_type pop_front() {
    value_type x = front();
    fr.outer.pop_front(meas);
    return x;
  }
  
  /*!
   * \brief Adds items at the end
   *
   * Adds new items from a given array to the back of the container,
   * after its current last item. The content of `items` is
   * copied (or moved) to the new positions in the container.
   *
   * \param items Values to be copied (or moved) to the container.
   * \param nb Number of items to be inserted.
   *
   * #### Complexity ####
   * Linear in number of inserted items.
   *
   */
  void pushn_back(const value_type* source, size_type nb) {
    shift_back_chunks_toward_ftree();
    size_type m = std::min(nb, chunk_capacity - bk.inner.size());
    bk.inner.pushn_back(meas, source, m);
    source += m;
    nb -= m;
    while (nb > 0) {
      m = std::min(nb, (size_type)chunk_capacity);
      bk.outer.pushn_back(meas, source, m);
      source += m;
      nb -= m;
      shift_back_chunks_toward_ftree();
    }
  }
  
  /*!
   * \brief Adds items at the beginning
   *
   * Adds new items to the front of the container,
   * before its current first item. The content of `items` is
   * copied (or moved) to the new positions in the container.
   *
   * \param items Values to be copied (or moved) to the container.
   * \param nb Number of items to be inserted.
   *
   * #### Complexity ####
   * Linear in number of inserted items.
   *
   */
  void pushn_front(const value_type* source, size_type nb) {
    shift_front_chunks_toward_ftree();
    source += nb;
    size_type m = std::min(nb, chunk_capacity - fr.inner.size());
    source -= m;
    nb -= m;
    fr.inner.pushn_front(meas, source, m);
    while (nb > 0) {
      m = std::min(nb, (size_type)chunk_capacity);
      source -= m;
      nb -= m;
      fr.outer.pushn_front(meas, source, m);
      shift_front_chunks_toward_ftree();
    }
  }
  
  /*!
   * \brief Adds items at the end
   *
   * Adds new items from a given array to the back of the container,
   * after its current last item. The content is generated by applications
   * of the client-supplied function `body`. The applications initialize
   * the cells in the container in place.
   *
   * For a container `a`, new content is generated by applying
   *   body(0, a[0]); body(1, a[1]); ... body(n-1, a[n-1]);
   * where `n` is the size of the container.
   *
   * \tparam Type of the loop body class. This class must implement the
   * interface defined by \ref foreach_loop_body.
   * \param body function to generate the contents
   * \param nb Number of items to be inserted.
   *
   * #### Complexity ####
   * Linear in number of inserted items.
   *
   */
  template <class Body>
  void pushn_back(const Body& body, size_type nb) {
    auto body2 = [&] (size_type i) {
      return fixedcapacity::apply_foreach_body<allocator_type, Body>(body, i);
    };
    _pushn_back(body2, nb);
  }
  
  /*!
   * \brief Adds items at the beginning
   *
   * Adds new items to the front of the container,
   * before its current first item. The content is generated by applications
   * of the client-supplied function `body`. The applications initialize
   * the cells in the container in place.
   *
   * For a container `a`, new content is generated by applying
   *   body(0, a[0]); body(1, a[1]); ... body(n-1, a[n-1]);
   * where `n` is the size of the container.
   *
   * \tparam Type of the loop body class. This class must implement the
   * interface defined by \ref foreach_loop_body.
   * \param body function to generate the contents
   * \param nb Number of items to be inserted.
   *
   * #### Complexity ####
   * Linear in number of inserted items.
   *
   */
  template <class Body>
  void pushn_front(const Body& body, size_type nb) {
    auto body2 = [&] (size_type i) {
      return fixedcapacity::apply_foreach_body<allocator_type, Body>(body, i);
    };
    _pushn_front(body2, nb);
  }
  
  /*!
   * \brief Adds items at the end
   *
   * Adds to the back of the container `nb` copies of `val`.
   *
   * \param val Value to fill the last `nb` positions
   * \param nb Number of items to be inserted.
   *
   * #### Complexity ####
   * Linear in number of inserted items.
   *
   */
  void pushn_back(const value_type val, size_type nb) {
    auto body2 = [&] (size_type i) {
      return fixedcapacity::const_foreach_body<allocator_type>(val);
    };
    _pushn_back(body2, nb);
  }
  
  /*!
   * \brief Adds items at the beginning
   *
   * Adds to the front of the container `nb` copies of `val`.
   *
   * \param val Value to fill the first `nb` positions
   * \param nb Number of items to be inserted.
   *
   * #### Complexity ####
   * Linear in number of inserted items.
   *
   */
  void pushn_front(const value_type val, size_type nb) {
    auto body2 = [&] (size_type i) {
      return fixedcapacity::const_foreach_body<allocator_type>(val);
    };
    _pushn_front(body2, nb);
  }
  
  /*!
   * \brief Deletes last items
   *
   * Removes the last items in the deque container, effectively
   * reducing the container size by one.
   *
   * Copies the removed items to the array `destination`.
   *
   * Calling this method destroys the removed items.
   *
   * The behavior is undefined if `nb > size()`.
   *
   * #### Complexity ####
   * Linear in number of items to be removed.
   *
   * \param destination Array to which the removed values
   * are to be copied (or moved).
   * \param nb Number of items to remove.
   *
   */
  void popn_back(value_type* destination, size_type nb) {
    assert(! has_cached_size || nb <= size());
    destination += nb;
    while (nb > 0) {
      shift_chunks_from_front_to_back();
      size_type m = std::min(nb, bk.outer.size());
      destination -= m;
      nb -= m;
      bk.outer.popn_back(meas, destination, m);
    }
  }
  
  /*!
   * \brief Deletes first items
   *
   * Removes the first items in the deque container, effectively
   * reducing the container size by `nb`.
   *
   * Copies the removed items to the array `destination`.
   *
   * Calling this method destroys the removed items.
   *
   * The behavior is undefined if `nb > size()`.
   *
   * #### Complexity ####
   * Linear in number of items to be removed.
   *
   * \param destination Array to which the removed values
   * are to be copied (or moved).
   * \param nb Number of items to remove.
   *
   */
  void popn_front(value_type* destination, size_type nb) {
    assert(! has_cached_size || nb <= size());
    while (nb > 0) {
      shift_chunks_from_back_to_front();
      size_type m = std::min(nb, fr.outer.size());
      fr.outer.popn_front(meas, destination, m);
      destination += m;
      nb -= m;
    }
  }
  
  /*!
   * \brief Deletes last items
   *
   * Removes the last items in the deque container, effectively
   * reducing the container size by one.
   *
   * Calling this method destroys the removed items.
   *
   * The behavior is undefined if `nb > size()`.
   *
   * #### Complexity ####
   * Linear in number of items to be removed.
   *
   * \param destination Array to which the removed values
   * are to be copied (or moved).
   * \param nb Number of items to remove.
   *
   */
  void popn_back(size_type nb) {
    assert(! has_cached_size || nb <= size());
    while (nb > 0) {
      shift_chunks_from_front_to_back();
      size_type m = std::min(nb, bk.outer.size());
      bk.outer.popn_back(meas, m);
      nb -= m;
    }
  }
  
  /*!
   * \brief Deletes first items
   *
   * Removes the first items in the deque container, effectively
   * reducing the container size by `nb`.
   *
   * Calling this method destroys the removed items.
   *
   * The behavior is undefined if `nb > size()`.
   *
   * #### Complexity ####
   * Linear in number of items to be removed.
   *
   * \param nb Number of items to remove.
   *
   */
  void popn_front(size_type nb) {
    assert(! has_cached_size || nb <= size());
    while (nb > 0) {
      shift_chunks_from_back_to_front();
      size_type m = std::min(nb, fr.outer.size());
      fr.outer.popn_front(meas, m);
      nb -= m;
    }
  }
  
  /*!
   * \brief Splits the container
   *
   * Let _C<SUB>i</SUB>_ denote the sum of the cached measurements
   * from the items in the range of positions [0, _i_].
   *
   * The fftree container is erased after the first item `i` whose
   * measurement _C<SUB>i</SUB>_ satisfies the predicate `p(`
   * _C<SUB>i</SUB>_ `)`.
   *
   * The subfftree that is erased from this container is
   * appended to the back of the given container `dst`.
   *
   * \tparam Pred Type of predicate.
   * \param dst fftree container to receive erased items.
   * \param p A predicate to determine the position of the split.
   *
   * #### Complexity ####
   * Logarithmic in the number of items.
   *
   */
  template <typename Pred>
  void transfer_from_back_to_front_by_client(fftree& dst, const Pred& p) {
    auto q = [&] (const internal_measured_type& m) {
      return p(fftree_config_type::cclient_measured(m));
    };
    _split(dst, q);
  }
  
  /*!
   * \brief Splits the container based on the given index
   *
   * The fftree container `s` is erased after the first `n-1` items,
   * where `n = position.size()`.
   *
   * The subfftree corresponding to the erased items is
   * appended to back of the given fftree container `dst`.
   *
   * \param dst A fftree container to receive the erased
   * subfftree.
   * \param n Number of items to keep.
   *
   * Keeps the first `max(n, size())` items in the container.
   *
   * #### Complexity ####
   * Logarithmic in the number of items.
   *
   */
  void transfer_from_back_to_front_by_position(fftree& dst, iterator position) {
    assert(has_cached_size);
    size_type sz_p = position.size();
    if (size() == 0 || position == end())
      return;
    _split(dst, predicate::less_or_eq_by_size<fftree_config_type>(sz_p));
  }
  
  void split_by_index(fftree& dst, size_type i) {
    assert(has_cached_size);
    size_type sz_p = i + 1;
    if (size() == 0)
      return;
    _split(dst, predicate::less_or_eq_by_size<fftree_config_type>(sz_p));
  }
  
  void split_approximate(fftree& dst) {
    size_type mid = size() / 2;
    //transfer_from_back_to_front_by_position(dst, begin() + mid);
    split_by_index(dst, mid);
  }
  
  /*!
   * \brief Appends a fftree
   *
   * Appends the contents of `other` on the back of the
   * container.
   *
   * Erases the contents of `other`.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   */
  void transfer_to_back(fftree& other) {
    if (compaction_group_sz < 0)
      evacuate_middle_chunks_for_append_using_bag_semantics(other);
    else
      evacuate_middle_chunks_for_append(other);
    ftree_p ft1 = ft;
    ftree_p ft2 = other.ft;
    ft = ftree_type::concat(ft1, ft2);
    other.ft = new ftree_type();
    other.bk.inner.swap(bk.inner);
    other.bk.outer.swap(bk.outer);
    assert(other.empty());
  }
  
  /*!
   * \brief Clears items
   *
   * Removes all items from the fftree (which are
   * destroyed), leaving the container with a size of 0.
   *
   * #### Complexity ####
   * Linear time (destructions).
   *
   */
  void clear() {
    if (has_cached_size)
      popn_back(size());
    else
      while (! empty())
        pop_back();
  }
  
  /*!
   * \brief Swaps content
   *
   * Exchanges the content of the container by the
   * content of `x`, which is another fftree object
   * containing items of the same type. Sizes may differ.
   *
   * After the call to this member function, the items
   * in this container are those which were in `x` before
   * the call, and the elements of `x` are those which were
   * in this.
   *
   * #### Complexity ####
   * Constant time.
   *
   * \param x Another fftree container of the same type
   * (i.e., instantiated with the same template parameters)
   * whose content is swapped with that of this container.
   *
   */
  void swap(fftree& other) {
    fr.swap(other.fr);
    bk.swap(other.bk);
    std::swap(ft, other.ft);
  }
  
  /*!
   * \brief Erases items
   *
   * Removes from the container either a single item
   * (`position`) or a  range of items (`[first,last)`).
   *
   * This effectively reduces the container size by the
   * number of elements removed, which are destroyed.
   *
   * #### Complexity ####
   * Linear in the number of items erased (destructions)
   * and logarithmic in the number of items in the size
   * of the sequence.
   *
   * \param first Iterator specifying a range within the fftree
   * to be removed: `[first,last)`.
   *
   * \param last Iterator specifying a range within the fftree
   * to be removed: `[first,last)`.
   *
   * \todo other instances of erase
   *
   */
  void erase(iterator first, iterator last) {
    assert(has_cached_size);
    fftree dst;
    size_type nb = last.size() - first.size();
    transfer_from_back_to_front_by_position(dst, first);
    for (size_type i = 0; i < nb; i++)
      dst.pop_front();
    transfer_to_back(dst);
  }
  
  /*!
   * \brief Inserts items
   *
   * The container is extended by inserting new items before
   * the item at the specified position.
   *
   * This effectively increates the container size by the amount
   * of items inserted.
   *
   * Insertions at the front or back are slightly more efficient
   * than on other positions.
   *
   * The parameters determine how many elements are inserted and
   * to which values they are initialized.
   *
   * \param position Position in the container where the new
   * items are inserted
   *
   * \param val Value to be copied (or moved) to the inserted
   * items
   *
   * \return An iterator that points to the first of the newly
   * inserted items.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   * \todo other instances of insert
   *
   */
  iterator insert(iterator position, const value_type& val) {
    assert(has_cached_size);
    fftree dst;
    size_type ix = position.size() - 1;
    transfer_from_back_to_front_by_position(dst, position);
    push_back(val);
    transfer_to_back(dst);
    return begin() + ix;
  }
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Item access
   */
  ///@{
  /*!
   * \brief Accesses last item
   *
   * Returns a reference to the last item in the container.
   *
   * Calling this method on an `empty` container causes undefined
   * behavior.
   *
   * #### Complexity ####
   * Amortized constant time (worst case logarithmic time).
   *
   *
   * \return A reference to the last item in the fftree
   * container.
   *
   */
  inline reference back() {
    assert(! empty());
    shift_chunks_from_front_to_back();
    return bk.outer.back();
  }
  
  /*!
   * \brief Accesses first item
   *
   * Returns a reference to the first item in the container.
   *
   * Calling this method on an `empty` container causes undefined
   * behavior.
   *
   * #### Complexity ####
   * Amortized constant time (worst case logarithmic time).
   *
   * \return A reference to the first item in the fftree
   * container.
   *
   */
  inline reference front() {
    assert(! empty());
    shift_chunks_from_back_to_front();
    return fr.outer.front();
  }
  
  /*!
   * \brief Accesses last item
   *
   * Returns a reference to the last item in the container.
   *
   * Calling this method on an `empty` container causes undefined
   * behavior.
   *
   * When called repeatedly, this `const` version of `back` may
   * deliver poorer performance than its non-`const` counterpart
   * because the non-`const` counterpart can move a leaf vector
   * into position whereas the `const` version cannot.
   *
   * #### Complexity ####
   * Amortized constant time (worst case logarithmic time).
   *
   *
   * \return A reference to the last item in the fftree
   * container.
   *
   */
  inline reference back() const {
    //! \todo implement version without depencency on cached size
    assert(has_cached_size);
    assert(size() > 0);
    return (*this)[size() - 1];
  }
  
  /*!
   * \brief Accesses first item
   *
   * Returns a reference to the first item in the container.
   *
   * Calling this method on an `empty` container causes undefined
   * behavior.
   *
   * When called repeatedly, this `const` version of `front` may
   * deliver poorer performance than its non-`const` counterpart
   * because the non-`const` counterpart can move a leaf vector
   * into position whereas the `const` version cannot.
   *
   * #### Complexity ####
   * Amortized constant time (worst case logarithmic time).
   *
   *
   * \return A reference to the first item in the fftree
   * container.
   *
   */
  inline reference front() const {
    //! \todo implement version without depencency on cached size
    assert(has_cached_size);
    assert(size() > 0);
    return (*this)[0];
  }
  
  /*!
   * \brief Accesses last items
   *
   * Copies items from the back of the container to the array.
   *
   * Behavior is undefined if `size() < nb`.
   *
   * #### Complexity ####
   * Linear in the number of items to be copied.
   *
   */
  void backn(value_type* destination, size_type nb) const {
    assert(has_cached_size);
    assert(size() >= nb);
    size_type nb_before_target = size() - nb;
    for_each_segment(begin() + nb_before_target, end(), [&] (size_type i, segment_type seg) {
      size_type nb_items_to_copy = size_type(seg.end - seg.middle);
      fixedcapacity::pmemcpy<allocator_type>(destination, seg.middle, nb_items_to_copy);
      destination += nb_items_to_copy;
    });
  }
  
  /*!
   * \brief Accesses first items
   *
   * Copies items from the front of the container to the array.
   *
   * Behavior is undefined if `size() < nb`.
   *
   * #### Complexity ####
   * Linear in the number of items to be copied.
   *
   */
  void frontn(value_type* destination, size_type nb) const {
    assert(has_cached_size);
    assert(size() >= nb);
    for_each_segment(begin(), begin() + nb, [&] (size_type i, segment_type seg) {
      size_type nb_items_to_copy = size_type(seg.end - seg.middle);
      fixedcapacity::pmemcpy<allocator_type>(destination, seg.middle, nb_items_to_copy);
      destination += nb_items_to_copy;
    });
  }
  
  /*!
   * \brief Access item
   *
   * Returns a copy of the element at position `n` in
   * the vector container.
   *
   * \return The item at the specified position in the fftree.
   *
   * \param Position of an item in the container.
   * Notice that the first item has a position of 0 (not 1).
   * Member type size_type is an unsigned integral type.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   *
   */
  value_type operator[](size_type n) const {
    assert(has_cached_size);
    assert(n >= 0);
    assert(n < size());
    auto it = begin();
    it.search_by_index(n);
    assert(it.size()-1 == n);
    return *it;
  }
  
  /*!
   * \brief Access item
   *
   * Returns a reference to the element at position `n` in
   * the vector container.
   *
   * \return The item at the specified position in the fftree.
   *
   * \param Position of an item in the container.
   * Notice that the first item has a position of 0 (not 1).
   * Member type size_type is an unsigned integral type.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   *
   */
  reference operator[](size_type n) {
    assert(has_cached_size);
    assert(n >= 0);
    assert(n < size());
    auto it = begin();
    it.search_by_index(n);
    if (!(it.size()-1 == n))
      std::cout << size() << " " << it.size() << " " << n << std::endl;
    assert(it.size()-1 == n);
    return *it;
  }
  
  /*!
   * \brief Visit every item
   *
   * Applies a given function to each item of the container.
   *
   * \todo In-place updates to individual items are currently not
   * allowed because in general updates can change the cached value of
   * the leaf node associated with the item. Any change made to
   * the cached value of the leaf must be propagated to the
   * parent, to the parent of the parent, and so on. In the
   * future, we may want to support such cascading updates, but
   * for now they remain to be implemented.
   *
   * \tparam Type of the loop-body class. This class must implement
   * the read-only loop-body interface defined by \ref foreach_loop_body.
   * \param body A function that takes as its first parameter
   * the current index `i` of type `size_type` and as its second
   * a reference `r` of type `const_reference` to the corresponding
   * item. The reference `r` points to the item at index `i`
   * in the container. The function has return type `void`.
   *
   * #### Complexity ####
   * Linear time.
   *
   */
  template <class Body>
  void for_each(const Body& body) {
    auto _body = [&] (size_type offset, value_type* lo, value_type* hi) {
      size_type i = offset;
      for (auto p = lo; p < hi; p++) {
        body(i, *p);
        i++;
      }
    };
    for_each_segment(_body);
  }
  
  template <class Body>
  void for_each_segment(const Body& body) {
    assert(has_cached_size);
    size_type offset = 0;
    fr.outer.for_each_segment(offset, body);
    offset += fr.outer.size();
    fr.inner.for_each_segment(offset, body);
    offset += fr.inner.size();
    ft->for_each([&] (size_type, leaf_node_type* leaf) {
      inner_chunk_type& chunk = leaf->item;
      chunk.for_each_segment(offset, body);
      offset += chunk.size();
    });
    bk.inner.for_each_segment(offset, body);
    offset += bk.inner.size();
    bk.outer.for_each_segment(offset, body);
  }
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Container traversal via iterators
   */
  ///@{
  /*!
   * \brief Visit every item in a given range
   *
   * Applies a given function to each item in the range of positions
   * (beg, end].
   *
   * \todo In-place updates to individual items are currently not
   * allowed because in general updates can change the cached value of
   * the leaf node associated with the item. Any change made to
   * the cached value of the leaf must be propagated to the
   * parent, to the parent of the parent, and so on. In the
   * future, we may want to support such cascading updates, but
   * for now they remain to be implemented.
   *
   * \tparam Type of the loop-body class. This class must implement
   * the read-only loop-body interface defined by \ref foreach_loop_body.
   * \param beg The first item to visit.
   * \param end The item after the last item to visit.
   * \param body A function that takes as its first parameter
   * the current index `i` of type `size_type` and as its second
   * a reference `r` of type `const_reference` to the corresponding
   * item. The reference `r` points to the item at index `i`
   * in the container. The function has return type `void`.
   *
   * #### Complexity ####
   * Linear time.
   *
   */
  template <class Body>
  static void for_each(iterator beg, iterator end, const Body& body) {
    for_each_segment(beg, end, [&] (size_type ix, segment_type seg) {
      for (value_type* lo = seg.middle; lo < seg.end; lo++)
        body(ix++, *lo);
    });
  }
  
  template <class Body>
  static void for_each_segment(iterator beg, iterator end, const Body& body) {
    assert(has_cached_size);
    size_type sz_end = end.size();
    while (beg < end) {
      size_type sz_beg = beg.size();
      size_type nb_to_be_processed_in_total = sz_end - sz_beg;
      auto seg = beg.get_segment();
      seg.end = std::min(seg.end, seg.middle + nb_to_be_processed_in_total);
      body(sz_beg - 1, seg);
      beg += seg.end - seg.middle;
    }
  }
  ///@}

  
  /*---------------------------------------------------------------------*/
  /** @name Iterators
   */
  ///@{
  
  /*!
   * \brief Returns iterator to beginning
   *
   * Returns an iterator pointing to the first element in the
   * fftree.
   *
   * Notice that, unlike member fftree::front, which returns
   * a reference to the first element, this function returns a
   * random access iterator pointing to it.
   *
   * If the container is empty, the returned iterator value
   * shall not be dereferenced.
   *
   * \return An iterator to the beginning of the fftree container.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   */
  iterator begin() const {
    return new_iterator(BEGIN);
  }
  
  /*!
   * \brief Returns iterator to end
   *
   * Returns an iterator referring to the past-the-end element
   * in the fftree container.
   *
   * The past-the-end element is the theoretical element that
   * would follow the last element in the vector. It does not
   * point to any element, and thus shall not be dereferenced.
   *
   * Because the ranges used by functions of the standard
   * library do not include the element pointed by their closing
   * iterator, this function is often used in combination with
   * fftree::begin to specify a range including all the elements
   * in the container.
   *
   * If the container is empty, this function returns the same as
   * fftree::begin.
   *
   * \return An iterator to the element past the end of the fftree.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   */
  iterator end() const {
    return new_iterator(END);
  }
  ///@}

  /*---------------------------------------------------------------------*/
  /** @name Split and concat
   */
  ///@{
  
  template <typename Pred>
  static split_type split(const Pred& p, client_measured_type& prefix, self_type* f) {
    auto q = [&] (const internal_measured_type& m) {
      return p(fftree_config_type::cclient_measured(m));
    };
    internal_measured_type _prefix;
    internal_algebra_type::identity(&_prefix);
    fftree_config_type::client_measured(_prefix) = prefix;
    split_type res;
    self_type* dst = new self_type();
    f->__split(*dst, _prefix, q);
    res.fr = f;
    if (dst->empty()) {
      res.middle = NULL;
    } else {
      res.middle = dst->front();
      dst->pop_front();
    }
    res.bk = dst;
    prefix = fftree_config_type::cclient_measured(_prefix);
    return res;
  }
  
  static self_type* concat(self_type* fr, self_type* bk) {
    fr->transfer_to_back(*bk);
    return fr;
  }
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Relational operators
   */
  ///@{
  bool operator==(const fftree& rhs) const {
    const fftree& lhs = *this;
    if (lhs.size() != rhs.size())
      return false;
    auto itl = lhs.begin();
    auto itr = rhs.begin();
    for (; itl != lhs.end(); itl++, itr++) {
      assert(itr != rhs.end());
      if (*itl != *itr)
        return false;
    }
    assert(itr == rhs.end());
    return true;
  }
  
  bool operator!=(const fftree& rhs) const {
    return ! (*this == rhs);
  }
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Debugging
   */
  ///@{
  
  template <class Node_container>
  void dump_debug(Node_container& nodes) {
    typedef typename Node_container::edge_set edge_set_type;
    edge_set_type edges;
    edges.push_back(&(fr.outer));
    edges.push_back(&(fr.inner));
    edges.push_back(ft->cget_cached());
    edges.push_back(&(bk.inner));
    edges.push_back( &(bk.outer));
    nodes(&(fr.outer), *fr.outer.get_cached(), fr.outer);
    nodes(&(fr.inner), *fr.inner.get_cached(), fr.inner);
    nodes(&(bk.inner), *bk.inner.get_cached(), bk.inner);
    nodes(&(bk.outer), *bk.outer.get_cached(), bk.outer);
    client_measured_type tmp;
    cget_cached(tmp);
    internal_measured_type tmp2;
    fftree_config_type::size(tmp2) = size();
    fftree_config_type::client_measured(tmp2) = tmp;
    nodes(NULL, tmp2, debug::fft, edges);
    ft->dump_debug(nodes);
  }
  ///@}
  
};

/*---------------------------------------------------------------------*/

template <class Item>
class dflt_copy {
public:
  static constexpr bool should_deep_copy = false;
  static void copy(Item& x) {}
};
  
//! [deque_with_size_plus]
template <class Client_cache, class Vector, int Compaction_group_sz,
          class Copy_item = dflt_copy<typename Vector::value_type> >
class deque_with_size_plus {
public:
  
  static constexpr int chunk_capacity = Vector::capacity;
  static constexpr int compaction_group_sz = Compaction_group_sz;
  static constexpr bool has_cached_size = true;
  
  typedef without_chain chunk_chain_type;
  typedef deque_with_size_plus<Client_cache, Vector, compaction_group_sz, Copy_item> self_type;
  typedef Vector vector_type; 
  typedef Client_cache outer_cache_type;
  typedef typename outer_cache_type::value_type value_type;
  typedef value_type& reference;
  typedef value_type* pointer;
  typedef typename outer_cache_type::size_type size_type;
  typedef cache::combiner<cache::size<Vector, size_type>, outer_cache_type> inner_cache_type;
  typedef chunk<vector_type, inner_cache_type, self_type> inner_chunk_type;
  typedef typename inner_cache_type::algebra_type internal_algebra_type;
  typedef typename inner_cache_type::measured_type internal_measured_type;
  typedef typename inner_cache_type::measure_type internal_measure_type;
  typedef chunk<vector_type, outer_cache_type, self_type> outer_chunk_type;
  typedef typename outer_cache_type::measured_type client_measured_type;
  typedef typename outer_cache_type::measure_type client_measure_type;
  typedef typename inner_chunk_type::allocator_type::difference_type difference_type;
  typedef ftree<inner_chunk_type> ftree_type;
  typedef typename ftree_type::leaf_node leaf_node_type;
  
  static void get_cached_of_ftree(const ftree_type* ft, internal_measured_type& dst) {
    dst = * (ft->cget_cached());
  }
  
  template <class Pred>
  static typename ftree_type::split_type ftree_split(const Pred& p, internal_measured_type& prefix, ftree_type* ft) {
    internal_measured_type tmpm = prefix;
    auto split = ftree_type::template split<Pred>(p, tmpm, ft);
    internal_algebra_type::reduce(&prefix, split.fr->cget_cached());
    return split;
  }
  
  class middle_search_type {
  private:
    
    ftree_type* ft;
    
  public:
    
    void set_middle(ftree_type* _ft) {
      ft = _ft;
    }
    
    const internal_measured_type* cget_cached() const {
      return ft->cget_cached();
    }
    
    void cget_prefix_of_leaf(const leaf_node_type* leaf_or_null, internal_measured_type& prefix) const {
      assert(leaf_or_null != NULL);
      prefix = *(leaf_or_null->cget_prefix());
    }
    
    template <class Pred>
    const leaf_node_type* search_by(const Pred& p, const leaf_node_type* leaf_or_null, internal_measured_type& prefix) const {
      const leaf_node_type* leaf;
      //! \todo fix so that finger search and bootstrapping are correct in combination
#ifndef DISABLE_FTREE_FINGER_SEARCH
      bool no_finger_search = (leaf_or_null == NULL);
#else
      bool no_finger_search = true;
#endif
      if (no_finger_search) {
        internal_measured_type tmp = prefix;
        leaf = ftree_type::search_by(p, ft, tmp);
      } else { // finger search
        internal_measured_type tmp = prefix;
        leaf = ftree_type::search_by(p, ft, tmp, leaf_or_null);
      }
      cget_prefix_of_leaf(leaf, prefix);
      return leaf;
    }
    
  };
  
  typedef random_access_iterator<self_type> iterator_type;
  typedef Copy_item copy_item_type;
  
private:
  
  static void convert_measure_and_swap(size_type sz,
                                       client_measured_type& m1,
                                       internal_measured_type& m2) {
    size(m2) = sz;
    Client_cache::swap(client_measured(m2), m1);
  }
  
  static void convert_measure_and_swap(const vector_type& vec,
                                       client_measured_type& m1,
                                       internal_measured_type& m2) {
    size_type sz = size_type(vec.size());
    convert_measure_and_swap(sz, m1, m2);
  }
  
public:
  
  static void convert_measure(size_type sz,
                              const client_measured_type& src,
                              internal_measured_type& dst) {
    client_measured_type tmp(src);
    convert_measure_and_swap(sz, tmp, dst);
  }
  
  static void swap_measured(client_measured_type& m1, client_measured_type& m2) {
    Client_cache::swap(client_measured(m1), client_measured(m2));
  }
  
  static void swap_measured(internal_measured_type& m1, internal_measured_type& m2) {
    std::swap(size(m1), size(m2));
    Client_cache::swap(client_measured(m1), client_measured(m2));
  }
  
  static void swap_measured(const vector_type& vec,
                            client_measured_type& m1,
                            internal_measured_type& m2) {
    convert_measure_and_swap(vec, m1, m2);
  }
  
  static void swap_measured(const vector_type& vec,
                            internal_measured_type& m1,
                            internal_measured_type& m2) {
    swap_measured(m1, m2);
  }
  
  static void swap(vector_type& vec1,
                   vector_type& vec2,
                   client_measured_type& m1,
                   internal_measured_type& m2) {
    convert_measure_and_swap(vec1, m1, m2);
    vec1.swap(vec2);
  }
  
  static void swap(vector_type& vec1,
                   vector_type& vec2,
                   internal_measured_type& m1,
                   client_measured_type& m2) {
    swap(vec2, vec1, m2, m1);
  }
  
  static void swap(vector_type& vec1,
                   vector_type& vec2,
                   client_measured_type& m1,
                   client_measured_type& m2) {
    vec1.swap(vec2);
    Client_cache::swap(m1, m2);
  }
  
  static void swap(vector_type& vec1,
                   vector_type& vec2,
                   internal_measured_type& m1,
                   internal_measured_type& m2) {
    swap_measured(vec1, m1, m2);
    vec1.swap(vec2);
  }
  
  static size_type& size(internal_measured_type& inner) {
    return inner.value1;
  }
  
  static size_type csize(const internal_measured_type& inner) {
    return inner.value1;
  }
  
  static client_measured_type& client_measured(internal_measured_type& inner) {
    return inner.value2;
  }
  
  static const client_measured_type& cclient_measured(const internal_measured_type& inner) {
    return inner.value2;
  }
  
};
//! [deque_with_size_plus]

/*---------------------------------------------------------------------*/
//! [deque_with_just_size]
template <class Vector, class Size>
using deque_with_just_size =
  deque_with_size_plus<cache::zero_byte<Vector, Size>, Vector, 4>;
//! [deque_with_just_size]
  
//! [bag]
template <class Vector, class Size>
using bag =
  deque_with_size_plus<cache::zero_byte<Vector, Size>, Vector, -1>;
//! [bag]
  
/*---------------------------------------------------------------------*/

//! [bootstrap_config]
template <class Client_cache, class Vector, int Compaction_group_sz,
          class Copy_item = dflt_copy<typename Vector::value_type> >
class bootstrap_config {
public:
  
  static constexpr int chunk_capacity = Vector::capacity;
  static constexpr int compaction_group_sz = Compaction_group_sz;
  static constexpr bool has_cached_size = true;
  
  typedef without_chain chunk_chain_type;
  
  typedef Vector vector_type;
  typedef bootstrap_config<Client_cache, Vector, Compaction_group_sz, Copy_item> self_type;
  typedef Client_cache outer_cache_type;
  
  typedef typename outer_cache_type::value_type value_type;
  typedef value_type& reference;
  typedef value_type* pointer;
  typedef typename outer_cache_type::size_type size_type;
  typedef fftree_base::chunk<vector_type, outer_cache_type, self_type> outer_chunk_type;
  typedef typename outer_cache_type::measured_type client_measured_type;
  typedef typename outer_cache_type::measure_type client_measure_type;
  
  typedef fftree_base::cache::combiner<fftree_base::cache::size<vector_type, size_type>, outer_cache_type> inner_cache_type;
  typedef typename inner_cache_type::algebra_type internal_algebra_type;
  typedef fftree_base::chunk<vector_type, inner_cache_type, self_type> inner_chunk_type;
  typedef typename inner_cache_type::measured_type internal_measured_type;
  typedef typename inner_cache_type::measure_type internal_measure_type;
  
  typedef ftree<inner_chunk_type> inner_ftree_type;
  typedef typename inner_ftree_type::leaf_node inner_leaf_node_type;
  
  typedef typename inner_chunk_type::allocator_type::difference_type difference_type;
  
  typedef Copy_item copy_item_type;
  
  class inner_inner_cache_type {
  public:
    
    typedef typename bootstrap_config::size_type size_type;
    typedef typename inner_cache_type::algebra_type algebra_type;
    typedef typename algebra_type::value_type measured_type;
    typedef inner_leaf_node_type* value_type;
    
    class measure_type {
    public:
      
      void operator()(const value_type& v, measured_type& dst) const {
        dst = *(v->cget_cached());
      }
      
      void operator()(const value_type* lo, const value_type* hi,
                      measured_type& dst) const {
        algebra_type::identity(&dst);
        for (auto p = lo; p < hi; p++) {
          measured_type tmp;
          algebra_type::identity(&tmp);
          operator()(*p, tmp);
          algebra_type::reduce(&dst, &tmp);
        }
      }
      
    };
    
    static void swap(measured_type& m1, measured_type& m2) {
      std::swap(m1, m2);
    }
    
  };
  
  static constexpr int inner_inner_capacity = 32;
  using inner_inner_heap_alloc = fixedcapacity::heap_allocator<inner_leaf_node_type*, inner_inner_capacity>;
  using inner_inner_vector_type = fixedcapacity::ringbuffer_ptr<inner_inner_heap_alloc>;

  class leaf_copy {
  public:
    static constexpr bool should_deep_copy = true;
    static void copy(inner_leaf_node_type*& x) {
      x = new inner_leaf_node_type(*x);
    }
  };
  typedef fftree_base::deque_with_size_plus<inner_inner_cache_type, inner_inner_vector_type, Compaction_group_sz, leaf_copy> ftree_config_type;
  typedef fftree_base::fftree<ftree_config_type> ftree_type;
  typedef inner_leaf_node_type leaf_node_type;
  
  static void get_cached_of_ftree(const ftree_type* ft, internal_measured_type& dst) {
    dst = * (ft->cget_cached());
  }
  
  template <class Pred>
  static typename ftree_type::split_type ftree_split(const Pred& p, internal_measured_type& prefix, ftree_type* ft) {
    internal_measured_type tmpm = prefix;
    auto split = ftree_type::template split<Pred>(p, tmpm, ft);
    internal_algebra_type::reduce(&prefix, split.fr->cget_cached());
    return split;
  }
  
  class middle_search_type {
  private:
    
    ftree_type* ft;
    mutable typename ftree_type::iterator it;
    
  public:
    
    void set_middle(ftree_type* _ft) {
      ft = _ft;
      it = ft->begin();
    }
    
    void cget_prefix_of_leaf(const leaf_node_type* leaf_or_null, internal_measured_type& prefix) const {
      const leaf_node_type* leaf = *it;
      prefix = *(leaf->cget_prefix());
    }
    
    const internal_measured_type* cget_cached() const {
      return ft->cget_cached();
    }
    
    template <class Pred>
    const leaf_node_type* search_by(const Pred& p, const leaf_node_type* leaf_or_null, internal_measured_type& prefix) const {
      it.search_by(p, prefix);
      const leaf_node_type* leaf = *it;
      leaf->set_prefix(&prefix);
      return leaf;
    }
    
  };
  
  typedef random_access_iterator<self_type> iterator_type;
  
private:
  
  static void convert_measure_and_swap(size_type sz, client_measured_type& m1, internal_measured_type& m2) {
    size(m2) = sz;
    outer_cache_type::swap(client_measured(m2), m1);
  }
  
  static void convert_measure_and_swap(const vector_type& vec, client_measured_type& m1, internal_measured_type& m2) {
    size_type sz = size_type(vec.size());
    convert_measure_and_swap(sz, m1, m2);
  }
  
public:
  
  static void convert_measure(size_type sz,
                              const client_measured_type& src,
                              internal_measured_type& dst) {
    client_measured_type tmp(src);
    convert_measure_and_swap(sz, tmp, dst);
  }
  
  static void swap_measured(client_measured_type& m1, client_measured_type& m2) {
    outer_cache_type::swap(client_measured(m1), client_measured(m2));
  }
  
  static void swap_measured(internal_measured_type& m1, internal_measured_type& m2) {
    std::swap(size(m1), size(m2));
    outer_cache_type::swap(client_measured(m1), client_measured(m2));
  }
  
  static void swap_measured(const vector_type& vec,
                            client_measured_type& m1,
                            internal_measured_type& m2) {
    convert_measure_and_swap(vec, m1, m2);
  }
  
  static void swap_measured(const vector_type& vec,
                            internal_measured_type& m1,
                            internal_measured_type& m2) {
    swap_measured(m1, m2);
  }
  
  static void swap(vector_type& vec1,
                   vector_type& vec2,
                   client_measured_type& m1,
                   internal_measured_type& m2) {
    convert_measure_and_swap(vec1, m1, m2);
    vec1.swap(vec2);
  }
  
  static void swap(vector_type& vec1,
                   vector_type& vec2,
                   internal_measured_type& m1,
                   client_measured_type& m2) {
    swap(vec2, vec1, m2, m1);
  }
  
  static void swap(vector_type& vec1,
                   vector_type& vec2,
                   client_measured_type& m1,
                   client_measured_type& m2) {
    vec1.swap(vec2);
    outer_cache_type::swap(m1, m2);
  }
  
  static void swap(vector_type& vec1,
                   vector_type& vec2,
                   internal_measured_type& m1,
                   internal_measured_type& m2) {
    swap_measured(vec1, m1, m2);
    vec1.swap(vec2);
  }
  
  static size_type& size(internal_measured_type& inner) {
    return inner.value1;
  }
  
  static size_type csize(const internal_measured_type& inner) {
    return inner.value1;
  }
  
  static client_measured_type& client_measured(internal_measured_type& inner) {
    return inner.value2;
  }
  
  static const client_measured_type& cclient_measured(const internal_measured_type& inner) {
    return inner.value2;
  }
  
};
//! [bootstrap_config]
  
template <class Vector, class Size>
using bootstrap_deque_with_just_size = bootstrap_config<cache::zero_byte<Vector, Size>, Vector, 4>;

template <class Vector, class Size>
using bootstrap_bag = bootstrap_config<cache::zero_byte<Vector, Size>, Vector, -1>;
  
  
  template <class Client_cache, class Vector, int Compaction_group_sz,
  class Copy_item = dflt_copy<typename Vector::value_type> >
  class bootseq_config {
  public:
    
    static constexpr int chunk_capacity = Vector::capacity;
    static constexpr int compaction_group_sz = Compaction_group_sz;
    static constexpr bool has_cached_size = true;
    
    typedef without_chain chunk_chain_type;
    typedef bootseq_config<Client_cache, Vector, compaction_group_sz, Copy_item> self_type;
    typedef Vector vector_type;
    typedef Client_cache outer_cache_type;
    typedef typename outer_cache_type::value_type value_type;
    typedef value_type& reference;
    typedef value_type* pointer;
    typedef typename outer_cache_type::size_type size_type;
    typedef cache::combiner<cache::size<Vector, size_type>, outer_cache_type> inner_cache_type;
    typedef chunk<vector_type, inner_cache_type, self_type> inner_chunk_type;
    typedef typename inner_cache_type::algebra_type internal_algebra_type;
    typedef typename inner_cache_type::measured_type internal_measured_type;
    typedef typename inner_cache_type::measure_type internal_measure_type;
    typedef chunk<vector_type, outer_cache_type, self_type> outer_chunk_type;
    typedef typename outer_cache_type::measured_type client_measured_type;
    typedef typename outer_cache_type::measure_type client_measure_type;
    typedef typename inner_chunk_type::allocator_type::difference_type difference_type;
    
    class dummy_ftree_type {
    public:
      
      class leaf_node {
      public:
        uint64_t weight;
        inner_chunk_type item;
        void init() {
          weight = (uint64_t) item.size();
        }
      };

      
    };
    
    typedef typename dummy_ftree_type::leaf_node leaf_node_type;
    
    template<class Item, int capacity>
    using bootseq_chunk = pasl::data::fixedcapacity::ringbuffer_ptrx< pasl::data::fixedcapacity::heap_allocator<Item, capacity+1 > >;
    
    typedef pasl::data::bootchunkseq_weighted::bootchunkseq<leaf_node_type*, bootseq_chunk, 32> ftree_type;
    
    typedef struct {
      ftree_type* fr;
      leaf_node_type* middle;
      ftree_type* bk;
    } split_type;
    
    static void get_cached_of_ftree( ftree_type* ft, internal_measured_type& dst) {
      size(dst) = ft->weight();
    }
    
    template <class Pred>
    static split_type ftree_split(const Pred& p, internal_measured_type& prefix, ftree_type* ft) {
      size_type nb = csize(prefix);
      size_type target = p.get_size();
      size_type adjusted_target = target - nb;
      ftree_type* dst = new ftree_type();
      leaf_node_type* middle;
      ft->split(adjusted_target-1, middle, *dst);
      split_type split;
      split.fr = ft;
      split.middle = middle;
      split.bk = dst;
      size(prefix) += ft->weight();
      return split;
    }
    
    class middle_search_type {
    private:
      
      ftree_type* ft;
      
    public:
      
      void set_middle(ftree_type* _ft) {
        ft = _ft;
      }
      
      const internal_measured_type* cget_cached() const {
        assert(false);
        return NULL;
      }
      
      void cget_prefix_of_leaf(const leaf_node_type* leaf_or_null, internal_measured_type& prefix) const {
        assert(false);
      }
      
      template <class Pred>
      const leaf_node_type* search_by(const Pred& p, const leaf_node_type* leaf_or_null, internal_measured_type& prefix) const {
        assert(false);
        return NULL;
      }
      
    };
    
    typedef bidirectional_iterator<self_type> iterator_type;
    typedef Copy_item copy_item_type;
    
  private:
    
    static void convert_measure_and_swap(size_type sz,
                                         client_measured_type& m1,
                                         internal_measured_type& m2) {
      size(m2) = sz;
      Client_cache::swap(client_measured(m2), m1);
    }
    
    static void convert_measure_and_swap(const vector_type& vec,
                                         client_measured_type& m1,
                                         internal_measured_type& m2) {
      size_type sz = size_type(vec.size());
      convert_measure_and_swap(sz, m1, m2);
    }
    
  public:
    
    static void convert_measure(size_type sz,
                                const client_measured_type& src,
                                internal_measured_type& dst) {
      client_measured_type tmp(src);
      convert_measure_and_swap(sz, tmp, dst);
    }
    
    static void swap_measured(client_measured_type& m1, client_measured_type& m2) {
      Client_cache::swap(client_measured(m1), client_measured(m2));
    }
    
    static void swap_measured(internal_measured_type& m1, internal_measured_type& m2) {
      std::swap(size(m1), size(m2));
      Client_cache::swap(client_measured(m1), client_measured(m2));
    }
    
    static void swap_measured(const vector_type& vec,
                              client_measured_type& m1,
                              internal_measured_type& m2) {
      convert_measure_and_swap(vec, m1, m2);
    }
    
    static void swap_measured(const vector_type& vec,
                              internal_measured_type& m1,
                              internal_measured_type& m2) {
      swap_measured(m1, m2);
    }
    
    static void swap(vector_type& vec1,
                     vector_type& vec2,
                     client_measured_type& m1,
                     internal_measured_type& m2) {
      convert_measure_and_swap(vec1, m1, m2);
      vec1.swap(vec2);
    }
    
    static void swap(vector_type& vec1,
                     vector_type& vec2,
                     internal_measured_type& m1,
                     client_measured_type& m2) {
      swap(vec2, vec1, m2, m1);
    }
    
    static void swap(vector_type& vec1,
                     vector_type& vec2,
                     client_measured_type& m1,
                     client_measured_type& m2) {
      vec1.swap(vec2);
      Client_cache::swap(m1, m2);
    }
    
    static void swap(vector_type& vec1,
                     vector_type& vec2,
                     internal_measured_type& m1,
                     internal_measured_type& m2) {
      swap_measured(vec1, m1, m2);
      vec1.swap(vec2);
    }
    
    static size_type& size(internal_measured_type& inner) {
      return inner.value1;
    }
    
    static size_type csize(const internal_measured_type& inner) {
      return inner.value1;
    }
    
    static client_measured_type& client_measured(internal_measured_type& inner) {
      return inner.value2;
    }
    
    static const client_measured_type& cclient_measured(const internal_measured_type& inner) {
      return inner.value2;
    }
    
  };
  
  template <class Vector, class Size>
  using bootsequence = bootseq_config<cache::zero_byte<Vector, Size>, Vector, 4>;

/*---------------------------------------------------------------------*/
/* Printing */
  
template <class FFTree_config>
std::ostream& operator<<(std::ostream& out, const fftree<FFTree_config>& xs) {
  out << "[";
  size_t i = 0;
  for (auto it = xs.begin(); it != xs.end(); it++, i++) {
    if (i == 0)
      std::cout << "" << std::endl;
    if (it == xs.end() - 1)
      out << *it;
    else
      out << *it << ", ";
    
  }
  return out << "]";
}
  
/***********************************************************************/

}
}
}

#endif /*! _PASL_DATA_FFTREE_H_ */
