/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Finger tree
 * \file ftree.hpp
 * \ingroup ftree
 *
 */

#include <assert.h>
#include <stddef.h>
#include <utility>

#include "fixedcapacity.hpp"
#include "algebra.hpp"
#include "debug.hpp"
#include "predicate.hpp"

#ifndef _PASL_DATA_FTREE_H_
#define _PASL_DATA_FTREE_H_

namespace pasl {
namespace data {

/***********************************************************************/

/*!
 * \class ftree
 * \ingroup ftree
 * \brief Ephemeral 2-3 Finger tree
 *
 * See \ref ftree
 *
 * \tparam Leaf_item Type of the contents of a leaf node. The interface
 * requirements are documented by \ref custom_leaf.
 */
template <class Leaf_item>
class ftree {
/*---------------------------------------------------------------------*/
/* Forward declarations */
private:
  
  class digit;
  class node;
  class branch_node;
  
  template <class Inner, class Outer>
  class parent_pointer {
  private:
    
    union {
      Inner n;
      Outer d;
      size_t bits;
    } p;
    
  public:
    
    parent_pointer() {
      p.n = NULL;
    }
    
    parent_pointer(Inner n) {
      p.n = n;
      p.bits |= 1l;
    }
    
    parent_pointer(Outer d) {
      p.d = d;
    }
    
    bool is_inner() const {
      return (p.bits & 1l) == 1l;
    }
    
    Inner get_inner() const {
      assert(is_inner());
      parent_pointer c(*this);
      c.p.bits &= ~1l;
      return c.p.n;
    }
    
    Outer get_outer() const {
      assert(! is_inner());
      return p.d;
    }
    
  };
  
/*---------------------------------------------------------------------*/
/* Exported types */
public:
  
  /** @name Exported structures
   */
  ///@{
  class leaf_node;
  /*! \struct split
   *  \brief Result of a finger-tree split
   */
  struct split {
    ftree* fr;                   //!< front
    leaf_node* middle;           //!< middle
    ftree* bk;                   //!< back
  };
  ///@}
  
  /** @name Exported types
   */
  ///@{
  /*!
   * a signed integral type, identical to:
   * `iterator_traits<iterator>::difference_type`
   */
  typedef ptrdiff_t difference_type;
  /*!
   * an unsigned integral type that can represent any non-negative value 
   * of `difference_type`
   */
  typedef size_t size_type;
  //! Type of leaf nodes
  typedef leaf_node leaf_node_type;
  //! Type of the items that adorn the leaf nodes
  typedef Leaf_item leaf_item_type;
  //! Type of the chain of links between leaf nodes
  typedef typename leaf_item_type::chain_type chain_type;
  //! Type of the algebra used to combine cached measurements
  typedef typename leaf_item_type::algebra_type algebra_type;
  //! Type of the cached measurements
  typedef typename algebra_type::value_type measured_type;
  //! Type alias for this class
  typedef ftree<Leaf_item> self_type;
  //! Type alias for struct `split`
  typedef split split_type;
  ///@}
  
/*---------------------------------------------------------------------*/
/* Type aliases for internal use */
private:

  typedef digit* digit_p;
  typedef node* node_p;
  typedef self_type* ftree_p;
  typedef leaf_node* leaf_node_p;
  typedef branch_node* branch_node_p;
  
/*---------------------------------------------------------------------*/
/* 2-3 tree node */

  class node {
  private:
    
    // note: uninitialized_tag is only needed for debug mode
    typedef enum {
      leaf_node_tag,
      branch_node_tag,
      uninitialized_tag
    } tag_t;
    
    tag_t tag;
    
  protected:
    
    typedef parent_pointer<const node*, const digit*> parent_pointer_type;
    parent_pointer_type parent;
    mutable measured_type prefix;
    
    node()
    : tag(uninitialized_tag) { }

    node(tag_t _tag)
    : tag(_tag) { }

    node(const node& other)
    : tag(other.tag), parent(other.parent), prefix(other.prefix) { }
    
    virtual ~node() { }
    
    bool is_leaf() const {
      return tag == leaf_node_tag;
    }
    
    bool is_branch() const {
      return tag == branch_node_tag;
    }
    
    void set_tag(tag_t _tag) {
      assert(tag == uninitialized_tag);
      tag = _tag;
    }
    
    void make_leaf() {
      set_tag(leaf_node_tag);
    }
    
    void make_branch() {
      set_tag(branch_node_tag);
    }
    
    void set_parent_pointer(const node* n) {
      parent = parent_pointer_type(n);
    }
    
    void set_parent_pointer(const digit* d) {
      parent = parent_pointer_type(d);
    }
    
    void clear_parent_pointer() {
      parent = parent_pointer_type();
    }
    
    virtual measured_type* get_cached() = 0;
    
    virtual const measured_type* cget_cached() const = 0;
    
    measured_type* get_prefix() {
      return &prefix;
    }
    
    const measured_type* cget_prefix() const {
      return &prefix;
    }
    
    void set_prefix(const measured_type* m) const {
      prefix = *m;
    }
    
    void evaluate_cached_upto_and_including(measured_type& dst) const {
      algebra_type::identity(&dst);
      algebra_type::reduce(&dst, cget_prefix());
      algebra_type::reduce(&dst, cget_cached());
    }
    
    template <class Pred>
    static parent_pointer_type up(const leaf_node_type* l, const Pred& p);
    
    template <class Pred>
    static const leaf_node_type* down(const node* cur,
                                      const Pred& p,
                                      measured_type& prefix);
    
    virtual void clear() = 0;
    
    friend class ftree;
  };
  
/*---------------------------------------------------------------------*/
/* Leaf */
  
public:
  
  class leaf_node : public node {
  private:
    
    typedef leaf_node* leaf_node_p;
    
    static leaf_node_p force(node_p t) {
      assert(t != NULL);
      assert(t->is_leaf());
      return (leaf_node_p)t;
    }
    
    static const leaf_node_type* cforce(const node* t) {
      assert(t != NULL);
      assert(t->is_leaf());
      return (const leaf_node_type*)t;
    }
    
  public:
    
    mutable leaf_item_type item;
    chain_type chain;
    
    leaf_node() : node() {
      node::make_leaf();
    }
    
    leaf_node(const leaf_item_type& leaf)
    : node(), item(leaf) {
      node::make_leaf();
    }
    
    leaf_node(const leaf_node& other)
    : node(other), item(other.item) { }
    
    measured_type* get_prefix() {
      return node::get_prefix();
    }
    
    const measured_type* cget_prefix() const {
      return node::cget_prefix();
    }
    
    measured_type* get_cached() {
      return item.get_cached();
    }
    
    const measured_type* cget_cached() const {
      return item.cget_cached();
    }
    
    void set_prefix(const measured_type* m) const {
      node::set_prefix(m);
    }
    
   void clear() {
      item.clear();
    }
    
    template <class Node_container>
    void dump_debug(Node_container& nodes) {
      nodes(this, *get_cached(), item);
    }
    
    template <class Body>
    void for_each(const Body& body) {
      body(this);
    }
    
    void init() { }  // later remove
    
    friend class ftree;
  };

/*---------------------------------------------------------------------*/
/* Branch */
  
private:
  
  class branch_node : public node {
  private:
    
    typedef branch_node* branch_node_p;
    
    static const int max_nb_branches = 3;
    
    int nb;    // number of branches (== 2 or 3)
    node_p branches[max_nb_branches];
    measured_type cached;
    
    static branch_node_p force(node_p t) {
      assert(t->is_branch());
      return (branch_node_p)t;
    }
    
    static const branch_node* cforce(const node* t) {
      assert(t->is_branch());
      return (const branch_node*)t;
    }
    
    void set_branch(int id, node_p t) {
      t->set_parent_pointer(this);
      branches[id] = t;
    }
    
    void refresh_cache() {
      measured_type* p = get_cached();
      algebra_type::identity(p);
      for (int i = 0; i < nb; i++)
        algebra_type::reduce(p, branches[i]->get_cached());
    }
    
  public:
    
    branch_node(node_p t0, node_p t1)
    : node(), nb(2) {
      node::make_branch();
      set_branch(0, t0);
      set_branch(1, t1);
      refresh_cache();
    }
    
    branch_node(node_p t0, node_p t1, node_p t2)
    : node(), nb(3) {
      node::make_branch();
      set_branch(0, t0);
      set_branch(1, t1);
      set_branch(2, t2);
      refresh_cache();
    }
    
    branch_node(leaf_node_type*& prev, const branch_node& other)
    : node(other), nb(other.nb) {
      for (int i = 0; i < other.nb_branches(); i++)
        set_branch(i, make_deep_copy_tree(prev, other.branches[i]));
      refresh_cache();
    }
    
    int nb_branches() const {
      return nb;
    }
    
    node_p get_branch(int i) const {
      return branches[i];
    }
    
    measured_type* get_cached() {
      return &cached;
    }
    
    const measured_type* cget_cached() const {
      return &cached;
    }
    
    void clear() {
      for (int i = 0; i < nb; i++)
        delete branches[i];
    }
    
    template <class Node_container>
    void dump_debug(Node_container& nodes) {
      typedef typename Node_container::edge_set edge_set_type;
      edge_set_type edges;

      for (int i = 0; i < nb_branches(); i++)
        edges.push_back(branches[i]);
      for (int i = 0; i < nb_branches(); i++) {
        if (branches[i]->is_leaf())
          leaf_node::force(branches[i])->dump_debug(nodes);
        else
          branch_node::force(branches[i])->dump_debug(nodes);
      }
      nodes(this, *get_cached(), debug::ft_two_three, edges);
    }
    
    template <class Body>
    void for_each(const Body& body) {
      for (int i = 0; i < nb; i++)
        node_for_each(body, branches[i]);
    }
    
    friend class ftree;
  };
  
  static node* make_deep_copy_tree(leaf_node_type*& prev, node* n) {
    node* new_node;
    if (n->is_leaf()) {
      leaf_node_type* new_leaf = new leaf_node(*leaf_node::force(n));
      if (chain_type::enabled) {
        if (prev != NULL)
          chain_type::link(prev->chain, new_leaf->chain, prev, new_leaf);
        prev = new_leaf;
      }
      new_node = new_leaf;
    } else {
      new_node = new branch_node(prev, *branch_node::force(n));
    }
    return new_node;
  }
  
  template <class Body>
  static void node_for_each(const Body& body, node* n) {
    if (n->is_leaf()) {
      leaf_node_p l = leaf_node::force(n);
      l->for_each(body);
    } else {
      branch_node_p b = branch_node::force(n);
      b->for_each(body);
    }
  }
  
/*---------------------------------------------------------------------*/
/* Digit */
  
  class digit {
  private:
    
    typedef node* node_p;
    typedef branch_node* branch_node_p;
    typedef leaf_node* leaf_node_p;
    typedef digit* digit_p;
    static const int max_nb_digits = 4;
    using buffer_allocator_type =
      fixedcapacity::inline_allocator<node_p, max_nb_digits>;
    using buffer_type = fixedcapacity::ringbuffer_idx<buffer_allocator_type>;
    
    ftree_p parent;
    buffer_type d;
    
    void reroot_tree(node_p x) {
      if (x != NULL)
        x->set_parent_pointer(this);
    }
    
  public:
    
    digit() : parent(NULL) { }
    
    size_type size() const {
      return d.size();
    }
    
    bool empty() const {
      return d.empty();
    }
    
    node_p back() const {
      return d.back();
    }
    
    node_p front() const {
      return d.front();
    }
    
    void push_back(node_p x) {
      reroot_tree(x);
      d.push_back(x);
    }
    
    void push_front(node_p x) {
      reroot_tree(x);
      d.push_front(x);
    }
    
    void pop_back() {
      d.pop_back();
    }
    
    void pop_front() {
      d.pop_front();
    }
    
    void pop_front(int nb) {
      for (int i = 0; i < nb; i++)
        pop_front();
    }
    
    void pop_back(int nb) {
      for (int i = 0; i < nb; i++)
        pop_back();
    }
    
    node_p operator[](size_type ix) const {
      assert(ix >= 0 && ix < d.size());
      return d[ix];
    }
    
    void clear() {
      size_type sz = size();
      for (size_type i = 0; i < sz; i++) {
        d[i]->clear();
        delete d[i];
      }
      d.clear();
    }
    
    bool is_one() const {
      return size() == 1;
    }
    
    bool is_four() const {
      return size() == 4;
    }
    
    /* Registers the trees of this digit by setting the
     * parent pointers of the roots of the trees.
     */
    void reroot_trees() {
      for (int i = 0; i < size(); i++)
        reroot_tree((*this)[i]);
    }
    
    void make_deep_copy(leaf_node_type*& prev, digit& dst) const {
      for (size_type i = 0; i < size(); i++)
        dst.push_back(make_deep_copy_tree(prev, d[i]));
    }
    
    void set_parent_pointer(ftree_p parent) {
      this->parent = parent;
    }
    
    /*
     * Assigns new contents to the digit container,
     * replacing current items with those of the
     * branches of the given tree
     */
    void assign(branch_node_p x) {
      clear();
      for (int i = 0; i < x->nb_branches(); i++)
        push_back(x->get_branch(i));
    }
    
    branch_node_p front_three() const {
      assert(is_four());
      return new branch_node(d[0], d[1], d[2]);
    }
    
    branch_node_p back_three() const {
      assert(is_four());
      return new branch_node(d[1], d[2], d[3]);
    }
    
    /*
     * Returns the index of the first tree t in d
     * for which p(t.cached+i) holds
     */
    template <typename Pred>
    size_type find(const Pred& p, const measured_type& i) const {
      size_type ix;
      measured_type j;
      algebra_type::identity(&j);
      algebra_type::reduce(&j, &i);
      for (ix = 0; ix < size(); ix++) {
        algebra_type::reduce(&j, d[ix]->get_cached());
        if (p(j))
          break;
      }
      return ix;
    }
    
    static digit concat3(digit d1, digit d2, digit d3) {
      static constexpr int max_concat_nb_digits = max_nb_digits*3;
      using concat_buffer_allocator_type =
        fixedcapacity::inline_allocator<node_p, max_concat_nb_digits>;
      fixedcapacity::ringbuffer_idx<concat_buffer_allocator_type> tmp;
      digit digits[3] = {d1, d2, d3};
      for (int k = 0; k < 3; k++) {
        digit d = digits[k];
        for (size_type i = 0; i < d.size(); i++)
          tmp.push_back(d[i]);
      }
      digit res;
      size_type sz = tmp.size();
      for (size_type i = 0; i < sz; ) {
        size_type m = sz - i;
        if (m == 2) {
          res.push_back(new branch_node(tmp[i], tmp[i+1]));
        } else if (m == 3) {
          res.push_back(new branch_node(tmp[i], tmp[i+1], tmp[i+2]));
        } else if (m == 4) {
          res.push_back(new branch_node(tmp[i], tmp[i+1]));
          res.push_back(new branch_node(tmp[i+2], tmp[i+3]));
        } else {
          res.push_back(new branch_node(tmp[i], tmp[i+1], tmp[i+2]));
          m = 3;
        }
        i += m;
      }
      return res;
    }
    
    void reduce_with(measured_type* dst) const {
      for (size_type i = 0; i < size(); i++)
        algebra::incr_back<algebra_type>(dst, d[i]->get_cached());
    }
    
    void evaluate_prefix(measured_type& dst) const;
    
    void evaluate_cached_upto_and_including(measured_type& dst) const {
      evaluate_prefix(dst);
      reduce_with(&dst);
    }
    
    template <class Pred>
    static ftree_p up(const Pred& p, const digit* d) {
      measured_type c;
      d->evaluate_prefix(c);
      bool r;
      for (size_type i = 0; i < d->size(); i++) {
        algebra::incr_back<algebra_type>(&c, (*d)[i]->get_cached());
        if (i > 0 && r != p(c))
          return NULL;
        r = p(c);
      }
      assert(d->parent != NULL);
      return d->parent;
    }
    
    template <class Pred>
    static const node* down(const Pred& p, const digit* d, measured_type& prefix) {
      measured_type v(prefix);
      node_p n;
      for (size_type i = 0; i < d->size(); i++) {
        n = (*d)[i];
        algebra_type::reduce(&v, n->get_cached());
        if (p(v))
          return n;
        algebra_type::identity(&prefix);
        algebra_type::reduce(&prefix, &v);
      }
      return n;
    }
    
    template <class Body>
    void for_each(const Body& body) {
      for (int i = 0; i < size(); i++)
        node_for_each(body, d[i]);
    }
    
    template <class Node_container>
    void dump_debug(Node_container& nodes) {
      typedef typename Node_container::edge_set edge_set_type;
      edge_set_type edges;
      measured_type tmp;
      algebra_type::identity(&tmp);
      reduce_with(&tmp);
      for (int i = 0; i < size(); i++)
        edges.push_back(d[i]);
      for (int i = 0; i < size(); i++) {
        if (d[i]->is_leaf())
          leaf_node::force(d[i])->dump_debug(nodes);
        else
          branch_node::force(d[i])->dump_debug(nodes);
      }
      nodes(this, tmp, debug::ft_buff, edges);
    }
    
  };
  
/*---------------------------------------------------------------------*/
/* Finger tree */
  
private:
  
  typedef parent_pointer<ftree_p, const void*> parent_pointer_type;
  
  measured_type cached;
  mutable measured_type prefix;
  digit fr;
  ftree_p middle;
  parent_pointer_type parent;
  digit bk;
  
  bool single() const {
    return fr.is_one() && bk.empty();
  }
  
  bool deep() const {
    return ! (empty() || single());
  }
  
  void refresh_cache() {
    algebra_type::identity(&cached);
    fr.reduce_with(&cached);
    if (deep())
      algebra_type::reduce(&cached, middle->get_cached());
    bk.reduce_with(&cached);
  }
  
  void set_parent_pointer(ftree_p _parent) {
    if (_parent == NULL)
      parent = parent_pointer_type((void*)_parent);
    else
      parent = parent_pointer_type(_parent);
  }
  
  void set_parent_pointers() {
    fr.set_parent_pointer(this);
    bk.set_parent_pointer(this);
    if (deep())
      middle->set_parent_pointer(this);
  }
  
  void initialize() {
    refresh_cache();
    set_parent_pointers();
  }
  
  // Registers the digits of this ftree
  void reroot_digits() {
    fr.reroot_trees();
    bk.reroot_trees();
  }
  
  ftree_p take_middle() {
    ftree_p m = middle;
    middle = NULL;
    return m;
  }
  
  /* copies contents from other to this
   * the correctness of the inter-leaf linking relies on the deep
   * copy visiting leaf nodes in left-to-right order.
   */
  void make_deep_copy(leaf_node_type*& prev, ftree_p _parent, const ftree& other) {
    set_parent_pointer(_parent);
    other.fr.make_deep_copy(prev, fr);
    middle = NULL;
    if (other.deep())
      middle = new ftree(prev, this, *other.middle);
    other.bk.make_deep_copy(prev, bk);
    initialize();
    prefix = other.prefix;
  }
  
  ftree(leaf_node_type*& prev, ftree_p _parent, const ftree& other) {
    make_deep_copy(prev, _parent, other);
  }
  
  ftree(digit fr, ftree_p middle, digit bk, ftree_p parent = NULL)
  : fr(fr), middle(middle), bk(bk) {
    set_parent_pointer(parent);
    initialize();
  }
  
  ftree(digit d, ftree_p parent = NULL) {
    set_parent_pointer(parent);
    size_type sz = d.size();
    if (sz == 0) {
      ;
    } else if (sz == 1) {
      fr.push_front(d[0]);
    } else if (sz == 2) {
      fr.push_front(d[0]);
      bk.push_back(d[1]);
    } else if (sz == 3) {
      fr.push_front(d[1]);
      fr.push_front(d[0]);
      bk.push_back(d[2]);
    } else {
      assert(sz == 4);
      fr.push_front(d[2]);
      fr.push_front(d[1]);
      fr.push_front(d[0]);
      bk.push_back(d[3]);
    }
    if (sz > 1)
      middle = new ftree(this);
    else
      middle = NULL;
    initialize();
  }
  
  node_p _back() const {
    assert(! empty());
    if (single())
      return fr.front();
    return bk.back();
  }
  
  node_p _front() const {
    assert(! empty());
    return fr.front();
  }
  
  void _push_back(node_p x) {
    if (empty()) {
      fr.push_front(x);
    } else if (single()) {
      middle = new ftree(this);
      bk.push_back(x);
    } else {
      if (bk.is_four()) {
        branch_node_p y = bk.front_three();
        bk.pop_front(3);
        bk.push_back(x);
        middle->_push_back(y);
      } else {
        bk.push_back(x);
      }
    }
    algebra::incr_back<algebra_type>(&cached, x->get_cached());
  }
  
  void _push_front(node_p x) {
    if (empty()) {
      fr.push_front(x);
      algebra::incr_back<algebra_type>(&cached, x->get_cached());
      return;
    } else if (single()) {
      middle = new ftree(this);
      bk.push_back(fr.front());
      fr.pop_front();
      fr.push_front(x);
    } else {
      if (fr.is_four()) {
        branch_node_p y = fr.back_three();
        fr.pop_back(3);
        fr.push_front(x);
        middle->_push_front(y);
      } else {
        fr.push_front(x);
      }
    }
    algebra::incr_front<algebra_type>(&cached, x->get_cached());
  }
  
  void _pop_back() {
    assert(! empty());
    if (algebra_type::is_group)
      algebra::decr_back<algebra_type>(&cached, _back()->get_cached());
    if (single()) {
      fr.pop_front();
      assert(empty());
    } else { // deep
      bk.pop_back();
      if (bk.empty()) {
        if (middle->empty()) {
          if (fr.is_one()) {
            delete middle;
          } else {
            node_p x = fr.back();
            fr.pop_back();
            bk.push_back(x);
          }
        } else {
          branch_node_p x = branch_node::force(middle->_back());
          middle->_pop_back();
          bk.assign(x);
          delete x;
        }
      }
    }
    if (! algebra_type::is_group)
      refresh_cache();
  }
  
  void _pop_front() {
    assert(! empty());
    if (algebra_type::is_group)
      algebra::decr_front<algebra_type>(&cached, _front()->get_cached());
    if (single()) {
      fr.pop_front();
      assert(empty());
    } else { // deep
      fr.pop_front();
      if (fr.empty()) {
        if (middle->empty()) {
          fr.push_front(bk.front());
          bk.pop_front();
          if (bk.empty())
            delete middle;
        } else {
          branch_node_p x = branch_node::force(middle->_front());
          middle->_pop_front();
          fr.assign(x);
          delete x;
        }
      }
    }
    if (! algebra_type::is_group)
      refresh_cache();
  }
  
  void _push_back(digit d) {
    for (size_type i = 0; i < d.size(); i++)
      _push_back(d[i]);
  }
  
  void _push_front(digit d) {
    for (int i = (int)d.size() - 1; i >= 0; i--)
      _push_front(d[i]);
  }
  
  static ftree_p app3(ftree_p fr, digit m, ftree_p bk) {
    ftree_p r;
    if (fr->empty()) {
      r = bk;
      r->_push_front(m);
      delete fr;
    } else if (bk->empty()) {
      r = fr;
      r->_push_back(m);
      delete bk;
    } else if (fr->single()) {
      r = bk;
      node_p x = fr->_back();
      r->_push_front(m);
      r->_push_front(x);
      delete fr;
    } else if (bk->single()) {
      r = fr;
      node_p x = bk->_back();
      r->_push_back(m);
      r->_push_back(x);
      delete bk;
    } else {
      digit m2 = digit::concat3(fr->bk, m, bk->fr);
      ftree_p n = app3(fr->take_middle(), m2, bk->take_middle());
      r = new ftree(fr->fr, n, bk->bk);
      delete fr;
      delete bk;
    }
    r->reroot_digits();
    return r;
  }
  
  bool is_front(const digit* d) const {
    return d == &fr;
  }
  
  bool is_back(const digit* d) const {
    return d == &bk;
  }
  
  typedef struct {
    ftree_p fr;       //!< front
    node_p middle;    //!< middle
    ftree_p bk;       //!< back
  } split_rec_type;
  
  template <typename Pred>
  static split_rec_type split_rec(const Pred& p, const measured_type& i, ftree_p f) {
    assert(! f->empty());
    split_rec_type v;
    if (f->single()) {
      v.fr = new ftree();
      v.middle = f->_back();
      v.bk = new ftree();
      delete f;
    } else { // deep
      measured_type vfr;
      algebra_type::identity(&vfr);
      algebra_type::reduce(&vfr, &i);
      f->fr.reduce_with(&vfr);
      size_type sz;
      size_type ix;
      if (p(vfr)) {
        ix = f->fr.find(p, i);
        sz = f->fr.size();
        v.fr = new ftree(f->fr);
        v.middle = f->fr[ix];
        v.bk = f;
      } else {
        measured_type vm;
        algebra_type::identity(&vm);
        algebra_type::reduce(&vm, &vfr);
        algebra_type::reduce(&vm, f->middle->get_cached());
        if (p(vm)) {
          split_rec_type ms = split_rec(p, vfr, f->take_middle());
          digit xs;
          xs.assign(branch_node::force(ms.middle));
          delete ms.middle;
          measured_type tmp;
          algebra_type::identity(&tmp);
          algebra_type::reduce(&tmp, &vfr);
          algebra_type::reduce(&tmp, ms.fr->get_cached());
          ix = xs.find(p, tmp);
          sz = xs.size();
          v.fr = new ftree(f->fr, ms.fr, xs);
          v.middle = xs[ix];
          v.bk = new ftree(xs, ms.bk, f->bk);
          delete f;
        } else {
          ix = f->bk.find(p, vm);
          sz = f->bk.size();
          v.fr = f;
          v.middle = f->bk[ix];
          v.bk = new ftree(f->bk);
        }
      }
      for (size_type i = 0; i < sz - ix; i++)
        v.fr->_pop_back();
      for (size_type i = 0; i < ix + 1; i++)
        v.bk->_pop_front();
    }
    v.fr->reroot_digits();
    v.bk->reroot_digits();
    v.fr->parent = parent_pointer_type();
    v.middle->clear_parent_pointer();
    v.bk->parent = parent_pointer_type();
    return v;
  }
  
  void evaluate_cached_upto_and_including(measured_type& dst) const {
    algebra_type::identity(&dst);
    algebra_type::reduce(&dst, &prefix);
    algebra_type::reduce(&dst, cget_cached());
  }
  
  template <class Pred>
  static const ftree* up(const ftree* ft, const Pred& p) {
    measured_type c;
    ft->evaluate_cached_upto_and_including(c);
    bool b = p(c);
    while (ft->parent.is_inner()) {
      if (p(c) != b)
        return ft;
      ft = ft->parent.get_inner();
      ft->evaluate_cached_upto_and_including(c);
    }
    return ft;
  }
  
  template <class Pred>
  static const digit* down(const ftree* ft, const Pred& p, measured_type& prefix) {
    assert(! ft->empty());
    // to leave a trail of cached values
    ft->prefix = prefix;
    if (ft->single())
      return &(ft->fr);
    assert(ft->deep());
    measured_type v(prefix);
    ft->fr.reduce_with(&v);
    if (p(v))
      return &(ft->fr);
    prefix = v;
    algebra_type::reduce(&v, ft->middle->get_cached());
    if (p(v))
      return down(ft->middle, p, prefix);
    prefix = v;
    ft->bk.reduce_with(&v);
    if (p(v))
      return &(ft->bk);
    assert(ft->bk.size() > 0);
    return &(ft->bk);
  }
  
public:
  
  /** @name Constructors
   */
  ///@{
  ftree(ftree_p parent = NULL)
  : middle(NULL) {
    set_parent_pointer(parent);
    initialize();
  }
  
  ftree(const ftree& other) {
    leaf_node_type* prev = NULL;
    make_deep_copy(prev, NULL, other);
  }
  
  ~ftree() {
    if (middle != NULL && deep())
      delete middle;
  }
  ///@}
  
  /** @name Cached measurements
   */
  ///@{
  
  /*!
   * \brief Returns a pointer to the cached measurement cell
   * of the finger tree
   *
   * The cached measurement cell stores the combined measurement
   * over all the items of the finger tree.
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  measured_type* get_cached() {
    return &cached;
  }
  
  /*!
   * \brief Returns a pointer to the cached measurement cell
   * of the finger tree
   *
   * The cached measurement cell stores the combined measurement
   * over all the items of the finger tree.
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  const measured_type* cget_cached() const {
    return &cached;
  }
  ///@}
  
  /** @name Capacity
   */
  ///@{
  /*!
   * \brief Test whether the finger tree is empty
   *
   * Returns whether the container is empty (
   * i.e. whether its size expressed in number of leaves is 0).
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  bool empty() const {
    return fr.empty();
  }
  ///@}
  
  /** @name Leaf access
   */
  ///@{
  /*!
   * \brief Accesses last leaf
   *
   * Returns a reference to the last leaf in the finger tree.
   *
   * Calling this method on an `empty` finger tree causes undefined
   * behavior.
   *
   * #### Complexity ####
   * Amortized constant time (worst case logarithmic time).
   *
   *
   * \return A pointer to the last leaf in the finger
   * tree.
   *
   */
  leaf_node_type* back() const {
    return leaf_node::force(_back());
  }
  
  /*!
   * \brief Accesses first leaf
   *
   * Returns a reference to the first leaf in the finger tree.
   *
   * Calling this method on an `empty` finger tree causes undefined
   * behavior.
   *
   * #### Complexity ####
   * Amortized constant time (worst case logarithmic time).
   *
   *
   * \return A pointer to the first leaf in the finger
   * tree.
   *
   */
  leaf_node_type* front() const {
    return leaf_node::force(_front());
  }
  
  template <class Body>
  void _for_each(const Body& body) {
    if (empty())
      return;
    if (single()) {
      fr.for_each(body);
      return;
    }
    fr.for_each(body);
    middle->_for_each(body);
    bk.for_each(body);
  }
  
  template <class Body>
  void for_each(const Body& body) {
    size_type i = 0;
    auto _body = [&] (leaf_node_type* leaf) {
      body(i, leaf);
      i++;
    };
    _for_each(_body);
  }
  ///@}
  
  /** @name Modifiers
   */
  ///@{
  /*!
   * \brief Adds leaf at the end
   *
   * Adds a new leaf to the back of the container,
   * after its current last leaf.
   *
   * \param comb Combiner object to be used for making
   * cached measurements.
   * \param x Leaf to be copied to the new item.
   *
   * #### Complexity ####
   * Amortized constant (worst case logarithmic).
   *
   */
  void push_back(leaf_node_type* x) {
    if (chain_type::enabled && ! empty()) {
      leaf_node_type* y = back();
      leaf_item_type::chain_type::link(y->chain, x->chain, y, x);
    }
    _push_back(x);
  }
  
  /*!
   * \brief Adds leaf at the beginning
   *
   * Adds a new leaf to the front of the container,
   * before its current first leaf.
   *
   * \param comb Combiner object to be used for making
   * cached measurements.
   * \param x Leaf to be copied to the new item.
   *
   * #### Complexity ####
   * Amortized constant (worst case logarithmic).
   *
   */
  void push_front(leaf_node_type* x) {
    if (chain_type::enabled && ! empty()) {
      leaf_node_type* y = front();
      leaf_item_type::chain_type::link(x->chain, y->chain, x, y);
    }
    _push_front(x);
  }
  
  /*!
   * \brief Deletes last leaf
   *
   * Removes the last leaf in the finger tree.
   *
   * Calling this method on an `empty` finger tree causes
   * undefined behavior.
   *
   * \param comb Combiner object to be used for making
   * cached measurements.
   *
   * #### Complexity ####
   * Amortized constant (worst case logarithmic).
   *
   */
  void pop_back() {
    assert(_back()->is_leaf());
    leaf_node_type* x = back();
    _pop_back();
    if (chain_type::enabled && ! empty()) {
      leaf_node_type* y = back();
      leaf_item_type::chain_type::unlink(y->chain, x->chain, y, x);
    }
  }
  
  /*!
   * \brief Deletes first leaf
   *
   * Removes the first leaf in the finger tree.
   *
   * Calling this method on an `empty` finger tree causes
   * undefined behavior.
   *
   * \param comb Combiner object to be used for making
   * cached measurements.
   *
   * #### Complexity ####
   * Amortized constant (worst case logarithmic).
   *
   */
  void pop_front() {
    assert(_front()->is_leaf());
    leaf_node_type* x = front();
    _pop_front();
    if (chain_type::enabled && ! empty()) {
      leaf_node_type* y = front();
      leaf_item_type::chain_type::unlink(x->chain, y->chain, x, y);
    }
  }
  
  /*!
   * \brief Clears tree
   *
   * Removes all nodes from the finger tree (which are
   * destroyed), leaving the finger tree with a size of 0.
   *
   * #### Complexity ####
   * Linear time (destructions).
   *
   */
  void clear() {
    //! \todo make sure that the leaves themselves are deallocated
    while (! empty())
      pop_back();
  }
  ///@}
  
  /** @name Item search
   */
  ///@{
  /*!
   * \brief Item search
   *
   * Returns a leaf-pointer `target` such that `target` points to the
   * first leaf node at position _i_ in the sequence order whose
   * measurement _C<SUB>i</SUB>_ satisfies the given predicate, where
   * _C<SUB>i</SUB>_ = the sum of the cached measurements from the
   * leaf nodes between positions 0 and _i_. For example, consider
   * the table below. The `target` in this case is the node
   * representing index 1.
   *
   * index                    | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9
   * -----                    | - | - | - | - | - | - | - | - | - | -
   * `p(` _C<SUB>i</SUB> `)`  | f | t | t | f | t | t | t | f | f | f
   *
   * \pre container is nonempty
   *
   * \tparam Pred Type of a predicate class that implements the
   * predicate interface as described by \ref predicates
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   */
  template <class Pred>
  static const leaf_node* search_by(const Pred& p, self_type* start, measured_type& prefix) {
    const digit* d = down(start, p, prefix);
    const node* n = digit::down(p, d, prefix);
    return leaf_node::down(n, p, prefix);
  }
  
  /*!
   * \brief Item search by finger
   *
   * Returns a leaf-node pointer `target` such that either 
   *
   *  1. `target` is the nearest leaf-node neighbor of `start` with
   *  respect to the sequence ordering of the leaves -and- the cached
   *  measurement of `target` satisfies the predicate -and- there is
   *  either no predecessor of `target` (i.e., target is first in
   *  sequence order) or the predecessor of `target` does not satisfy
   *  the predicate. For example, consider the table below, and
   *  suppose that `start` occurs at index 6. Then `target` would be
   *  at position 4.
   *  2. otherwise, `target` is the last node in sequence order
   *
   * index                    | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9
   * -----                    | - | - | - | - | - | - | - | - | - | -
   * `p(` _C<SUB>i</SUB> `)`  | f | t | t | f | t | t | t | f | f | f
   *
   * \param p Predicate used to guide the search
   * \param start Leaf node from which to start the search
   *
   * \tparam Pred Type of a predicate class that implements the
   * predicate interface as described by \ref predicates
   *
   * \pre container enclosing `start` is nonempty.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   */
  template <class Pred>
  static const leaf_node* search_by(const Pred& p, const leaf_node* start) {
    measured_type tmp;
    return search_by(p, NULL, tmp, start);
  }
  
  template <class Pred>
  static const leaf_node* search_by(const Pred& p, self_type* root, measured_type& root_prefix, const leaf_node* start) {
    typedef typename node::parent_pointer_type parent_pointer_t;
    measured_type prefix;
    algebra_type::identity(&prefix);
    parent_pointer_t parent = leaf_node::up(start, p);
    if (parent.is_inner()) {
      // found in the given leaf node
      const node* n = parent.get_inner();
      prefix = *(n->cget_prefix());
      return leaf_node::down(n, p, prefix);
    }
    // not found in the given leaf node
    // so, search from the corresponding digit
    const digit* d = parent.get_outer();
    const ftree* ft = digit::up(p, d);
    if (ft != NULL) {
      // not found in the corresponding digit
      // so, search from the corresponding ftree
      ft = ft->up(ft, p);
      prefix = ft->prefix;
      d = down(ft, p, prefix);
    }
    d->evaluate_prefix(prefix);
    const node* n = digit::down(p, d, prefix);
    const leaf_node* leaf = leaf_node::down(n, p, prefix);
#ifndef NDEBUG
    if (root != NULL) {
      const leaf_node* leaf2 = search_by(p, root, root_prefix);
      assert(leaf == leaf2);
    }
#endif
    return leaf;
  }
  
  /*!
   * \brief Get cursor on first item
   *
   * Returns the cursor pointing to the first item
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  const leaf_node* cursor_front(measured_type& prefix) {
    auto p = [] (const measured_type& m) {
      return true;
    };
    return search_by(p, this, prefix);
  }
  
  /*!
   * \brief Get cursor on last item
   *
   * Returns the cursor pointing to the last item
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  const leaf_node* cursor_back(measured_type& prefix) {
    auto p = [] (const measured_type& m) {
      return false;
    };
    return search_by(p, this, prefix);
  }
  ///@}
  
  /** @name Split and concat
   */
  ///@{
  /*!
   * \brief Split
   *
   * Creates and returns a split based on a given predicate. The split
   * consists of a pointer to one leaf node that represents the focus,
   * or middle, of the split, and two pointers to the two pieces of
   * the original ftree, front and back respectively, that straddle
   * the leaf node in the middle.
   *
   * The split preserves the sequence order of the leaves of the
   * container in the sense that the result of the concatenation of
   * front, middle, and back preserves the sequence order of the
   * leaves of the original container.
   *
   * The middle of the split is selected to be the first leaf node at
   * position _i_, with respect to the sequence order of the leaves,
   * for which the cached measurement _C<SUB>i</SUB>_ satisfies the
   * given predicate, where _C<SUB>i</SUB>_ = the sum of the cached
   * measurements from the leaf nodes between positions 0 and _i_.
   *
   * The parameter `prefix` is updated in place by the split
   * operation. After the operation, the contents are equal to the
   * identity value _I_ if _i_ = 0 and _C<SUB>i-1</SUB>_ otherwise.
   *
   * The given finger tree, namely `f`, is invalidated by this
   * operation.
   *
   * \param p Predicate used to guide the search
   * \param prefix Measurement representing the sum of the
   * measurements of items occuring in positions that occur
   * logically earlier in a larger logical sequence
   * \param f Pointer to the ftree to split
   *
   * \tparam Pred Type of a predicate class that implements the
   * predicate interface as described by \ref predicates
   *
   * \pre container is nonempty.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   */
  template <typename Pred>
  static split_type split(const Pred& p, measured_type& prefix, ftree* f) {
    split_rec_type s1 = split_rec(p, prefix, f);
    leaf_node_p l = leaf_node::force(s1.middle);
    split_type s2 = {s1.fr, l, s1.bk};
    if (chain_type::enabled) {
      if (! s1.fr->empty()) {
        leaf_node_type* fr = s1.fr->back();
        chain_type::unlink(fr->chain, l->chain, fr, l);
      }
      if (! s2.bk->empty()) {
        leaf_node_type* bk = s2.bk->front();
        chain_type::unlink(l->chain, bk->chain, l, bk);
      }
    }
    return s2;
  }

  /*!
   * \brief Concatenate two ftrees
   *
   * Returns the finger tree representing the concatenation of
   * the two given finger trees.
   *
   * The two given finger trees, namely `fr` and `bk`, are
   * invalidated by this operation.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   */
  static self_type* concat(self_type* fr, self_type* bk) {
    digit d;
    if (chain_type::enabled && ! fr->empty() && ! bk->empty()) {
      leaf_node_type* l1 = fr->back();
      leaf_node_type* l2 = bk->front();
      chain_type::link(l1->chain, l2->chain, l1, l2);
    }
    return app3(fr, d, bk);
  }
  ///@}
  
  /** @name Debugging
   */
  ///@{
  template <class Node_container>
  void dump_debug_tree(Node_container& nodes,
                       typename Node_container::edge_set& edges, digit& d) {
    for (int i = 0; i < d.size(); i++) {
      edges.push_back(d[i]);
      if (d[i]->is_leaf())
        leaf_node::force(d[i])->dump_debug(nodes);
      else
        branch_node::force(d[i])->dump_debug(nodes);
    }
  }
  
  template <class Node_container>
  void dump_debug(Node_container& nodes, bool show_digits = true) {
    typedef typename Node_container::edge_set edge_set_type;
    edge_set_type edges;
    void* ptr = get_cached();
    if (empty()) {
      nodes(ptr, *get_cached(), debug::ft_spine, edges);
      return;
    }
    if (show_digits && fr.size() > 0)
      edges.push_back(&fr);
    if (show_digits && fr.size() > 0)
      fr.dump_debug(nodes);
    if (! show_digits)
      dump_debug_tree(nodes, edges, fr);
    if (deep()) {
      edges.push_back(middle);
      middle->dump_debug(nodes);
    }
    if (show_digits && bk.size() > 0)
      bk.dump_debug(nodes);
    if (show_digits && bk.size() > 0)
      edges.push_back(&bk);
    if (! show_digits)
      dump_debug_tree(nodes, edges, bk);
    measured_type cached;
    nodes(ptr, *get_cached(), debug::ft_spine, edges);
  }
  ///@}

};
  
/*---------------------------------------------------------------------*/
/* Out-of-line declarations */
  
template <class Leaf_item>
template <class Pred>
typename ftree<Leaf_item>::node::parent_pointer_type
  ftree<Leaf_item>::node::up(const leaf_node_type* l, const Pred& p) {
  measured_type c;
  l->evaluate_cached_upto_and_including(c);
  bool b = p(c);
  const node* m = l;
  while (m->parent.is_inner()) {
    if (p(c) != b)
      return parent_pointer_type(m);
    m = m->parent.get_inner();
    m->evaluate_cached_upto_and_including(c);
  }
  return m->parent;
}  
  
template <class Leaf_item>
template <class Pred>
const typename ftree<Leaf_item>::leaf_node_type*
  ftree<Leaf_item>::node::down(const node* t,
                               const Pred& p,
                               measured_type& prefix) {
  // to leave a trail of cached measurements along the spine
  algebra_type::identity(&(t->prefix));
  algebra_type::reduce(&(t->prefix), &prefix);
  if (t->is_leaf())
    return ftree<Leaf_item>::leaf_node::cforce(t);
  const branch_node* b = branch_node::cforce(t);
  int nb = b->nb_branches();
  for (int i = 0; i < nb; i++) {
    node_p s = b->get_branch(i);
    measured_type v;
    algebra_type::identity(&v);
    algebra_type::reduce(&v, &prefix);
    algebra_type::reduce(&v, s->get_cached());
    if (p(v))
      return down(s, p, prefix);
    algebra_type::identity(&prefix);
    algebra_type::reduce(&prefix, &v);
  }
  return down(b->get_branch(nb-1), p, prefix);
}
  
template <class Leaf_item>
void ftree<Leaf_item>::digit::evaluate_prefix(measured_type& dst) const {
  algebra_type::identity(&dst);
  algebra_type::reduce(&dst, &(parent->prefix));
  if (parent->is_back(this)) {
    parent->fr.reduce_with(&dst);
    if (parent->deep())
      algebra_type::reduce(&dst, parent->middle->get_cached());
  }
}
  
/***********************************************************************/

}
}

#endif /*! _PASL_DATA_FTREE_H_ */
