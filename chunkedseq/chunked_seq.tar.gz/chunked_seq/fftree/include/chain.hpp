/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Chain builders
 * \file chain.hpp
 *
 */

#include <assert.h>

#ifndef _PASL_DATA_CHAIN_H_
#define _PASL_DATA_CHAIN_H_

namespace pasl {
namespace data {
  
/***********************************************************************/

/*---------------------------------------------------------------------*/

class with_chain {
public:
  
  typedef with_chain self_type;
  
private:
  
  void* next;
  void* prev;
  
public:
  
  static constexpr bool enabled = true;
  
  with_chain()
  : next(NULL), prev(NULL) { }
  
  template <class Pointer>
  Pointer get_next() const {
    return (Pointer)next;
  }
  
  template <class Pointer>
  Pointer get_prev() const {
    return (Pointer)prev;
  }
  
  template <class Pointer>
  static void link(self_type& l1, self_type& l2, Pointer p1, Pointer p2) {
    l1.next = (void*)p2;
    l2.prev = (void*)p1;
  }
  
  template <class Pointer>
  static void unlink(self_type& l1, self_type& l2, Pointer p1, Pointer p2) {
    assert(l1.get_next<void*>() == (void*)p2);
    assert((void*)p1 == l2.get_prev<void*>());
    l1.next = NULL;
    l2.prev = NULL;
  }
  
};
  
/*---------------------------------------------------------------------*/

class without_chain {
public:
  
  typedef without_chain self_type;
  
  static constexpr bool enabled = false;
  
  template <class Pointer>
  Pointer get_next() const {
    return NULL;
  }
  
  template <class Pointer>
  Pointer get_prev() const {
    return NULL;
  }
  
  template <class Pointer>
  static void link(self_type& l1, self_type& l2, Pointer p1, Pointer p2) {
  }
  
  template <class Pointer>
  static void unlink(self_type& l1, self_type& l2, Pointer p1, Pointer p2) {
  }
  
};

/***********************************************************************/

}
}

#endif /*! _PASL_DATA_CHAIN_H_ */