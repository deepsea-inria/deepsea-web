/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Representation of the chunk of the fast finger tree
 * \file chunk.hpp
 *
 */

#include <type_traits>
#include <stdio.h>
#include <string.h>

#include "fftreecache.hpp"
#include "predicate.hpp"
#include "chain.hpp"

#ifndef _PASL_DATA_CHUNK_H_
#define _PASL_DATA_CHUNK_H_

namespace pasl {
namespace data {
namespace fftree_base {

/***********************************************************************/
  
/*---------------------------------------------------------------------*/
//! [chunk_search]
template <class Chunk, class Cache, class FFTree_config>
class chunk_search {
public:
  
  using fftree_config_type = FFTree_config;
  using chunk_type = Chunk;
  using cache_type = Cache;
  using measured_type = typename cache_type::measured_type;
  using measure_type = typename cache_type::measure_type;
  using algebra_type = typename cache_type::algebra_type;
  using size_type = typename FFTree_config::size_type;
  
  template <class Pred>
  static size_type search_by(const Pred& p,
                        const measure_type& meas,
                        const chunk_type& chunk,
                        measured_type& prefix,
                        measured_type& cached) {
    size_type i;
    for (i = 0; i < chunk.size(); i++) {
      measured_type tmp;
      meas(chunk[i], tmp);
      algebra_type::reduce(&cached, &tmp);
      if (p(cached))
        break;
      algebra_type::reduce(&prefix, &tmp);
    }
    return i;
  }
  

  static size_type search_by(const predicate::less_or_eq_by_size<FFTree_config>& p,
                        const measure_type& meas,
                        const chunk_type& chunk,
                        measured_type& prefix,
                        measured_type& cached) {
    size_type tgt = p.get_size();
    size_type sz_prefix = fftree_config_type::csize(prefix);
    size_type avail = chunk.size() + sz_prefix;
    size_type i = (tgt > avail) ? avail : tgt - 1;
    fftree_config_type::size(prefix) = i;
    fftree_config_type::size(cached) = (tgt > avail) ? avail : tgt;
    return i - sz_prefix;
  }
  
};
//! [chunk_search]

/*---------------------------------------------------------------------*/
//! [chunk_example]
/*!
 * \class chunk
 * \ingroup fftree
 * \brief Fixed-capacity deque that can be put in a leaf node of a \ref fftree.
 *
 * \tparam Vector Type of buffer to be used to maintain items.
 * \tparam Cache Type of the policy to be used to maintain cached values.
 * \tparam FFTree_config Type of the fast finger tree configuration class.
 */
template <class Vector, class Cache, class FFTree_config>
class chunk {
public:

  typedef chunk<Vector, Cache, FFTree_config> self_type;  
  typedef Cache cache_type;
  typedef Vector vector_type;
  typedef FFTree_config fftree_config_type;
  typedef typename vector_type::value_type value_type;
  typedef value_type& reference;
  typedef const value_type& const_reference;
  typedef value_type* pointer;
  typedef const value_type* const_pointer;
  typedef typename vector_type::allocator_type allocator_type;
  typedef typename vector_type::segment_type segment_type;
  typedef typename cache_type::size_type size_type;
  typedef typename cache_type::measured_type measured_type;
  typedef typename cache_type::algebra_type algebra_type;
  typedef typename cache_type::measure_type measure_type;
  typedef typename fftree_config_type::chunk_chain_type chain_type;
  typedef chunk_search<self_type, cache_type, fftree_config_type> chunk_search_type;
  
private:
  
  vector_type vec;
  measured_type cached;
  
  inline void incr_front(const measure_type& meas, const value_type& v) {
    measured_type m;
    meas(v, m);
    algebra::incr_front<algebra_type>(&cached, &m);
  }
  
  inline void incr_back(const measure_type& meas, const value_type& v) {
    measured_type m;
    meas(v, m);
    algebra::incr_back<algebra_type>(&cached, &m);
  }
  
  inline void decr_front(const measure_type& meas, const value_type& v) {
    measured_type m;
    meas(v, m);
    algebra::decr_front<algebra_type>(&cached, &m);
  }
  
  inline void decr_back(const measure_type& meas, const value_type& v) {
    measured_type m;
    meas(v, m);
    algebra::decr_back<algebra_type>(&cached, &m);
  }
  
  void sum_range(const measure_type& meas, size_type lo, size_type hi,
                 measured_type& dst) {
    algebra_type::identity(&dst);
    vec.for_each_segment(0, int(lo), int(hi), [&] (int, const value_type* lo, const value_type* hi) {
      measured_type tmp;
      meas(lo, hi, tmp);
      algebra::incr_back<algebra_type>(&dst, &tmp);
    });
  }
  
  void reset_cache(const measure_type& meas) {
    sum_range(meas, 0, size(), cached);
  }
  
  void incrn_back(const measure_type& meas, size_type lo) {
    measured_type tmp;
    sum_range(meas, lo, vec.size(), tmp);
    algebra::incr_back<algebra_type>(&cached, &tmp);
  }
  
  void incrn_front(const measure_type& meas, size_type hi) {
    measured_type tmp;
    sum_range(meas, 0, hi, tmp);
    algebra::incr_front<algebra_type>(&cached, &tmp);
  }
  
  void decrn_back(const measure_type& meas, size_type lo) {
    measured_type tmp;
    sum_range(meas, lo, vec.size(), tmp);
    algebra::decr_back<algebra_type>(&cached, &tmp);
  }
  
  void decrn_front(const measure_type& meas, size_type hi) {
    measured_type tmp;
    sum_range(meas, 0, hi, tmp);
    algebra::decr_front<algebra_type>(&cached, &tmp);
  }
  
  template <class Other_chunk>
  void _swap(Other_chunk& other) {
    vector_type& other_vec = other.get_vec();
    fftree_config_type::swap(vec, other_vec, cached, *other.get_cached());
  }
  
public:
  
  static constexpr int capacity = vector_type::capacity;
  
  chunk() {
    algebra_type::identity(&cached);
  }
  
  bool full() const {
    return vec.full();
  }
  
  bool empty() const {
    return vec.empty();
  }
  
  size_type size() const {
    return vec.size();
  }
  
  value_type& front() const {
    return vec.front();
  }
  
  value_type& back() const {
    return vec.back();
  }
  
  void push_front(const measure_type& meas, const value_type& x) {
    vec.push_front(x);
    incr_front(meas, x);
  }
  
  void push_back(const measure_type& meas, const value_type& x) {
    vec.push_back(x);
    incr_back(meas, x);
  }
  
  void pop_front(const measure_type& meas) {
    if (algebra_type::is_group)
      decr_front(meas, front());
    vec.pop_front();
    if (! algebra_type::is_group)
      reset_cache(meas);
  }
  
  void pop_back(const measure_type& meas) {
    if (algebra_type::is_group)
      decr_back(meas, back());
    vec.pop_back();
    if (! algebra_type::is_group)
      reset_cache(meas);
  }
  
  void backn(value_type* xs, size_type nb) {
    vec.backn(xs, (int)nb);
  }
  
  void frontn(value_type* xs, size_type nb) {
    vec.frontn(xs, (int)nb);
  }
  
  void pushn_back(const measure_type& meas, const value_type* xs, size_type nb) {
    size_type nb_before = size();
    vec.pushn_back(xs, (int)nb);
    incrn_back(meas, int(nb_before));
  }
  
  void pushn_front(const measure_type& meas, const value_type* xs, size_type nb) {
    vec.pushn_front(xs, (int)nb);
    incrn_front(meas, nb);
  }
  
  template <class Body>
  void pushn_back(const measure_type& meas, const Body& body, size_type nb) {
    size_type nb_before = size();
    vec.pushn_back(body, (int)nb);
    incrn_back(meas, int(nb_before));
  }
  
  void popn_front(const measure_type& meas, size_type nb) {
    if (algebra_type::is_group)
      decrn_front(meas, nb);
    vec.popn_front(int(nb));
    if (! algebra_type::is_group)
      reset_cache(meas);
  }
  
  void popn_back(const measure_type& meas, size_type nb) {
    if (algebra_type::is_group) {
      size_type nb_before = size() - nb;
      decrn_back(meas, nb_before);
    }
    vec.popn_back((int)nb);
    if (! algebra_type::is_group)
      reset_cache(meas);
  }

  void popn_front(const measure_type& meas, value_type* xs, size_type nb) {
    if (algebra_type::is_group)
      decrn_front(meas, nb);
    vec.popn_front(xs, (int)nb);
    if (! algebra_type::is_group)
      reset_cache(meas);
  }
  
  void popn_back(const measure_type& meas, value_type* xs, size_type nb) {
    if (algebra_type::is_group) {
      size_type nb_before = size() - nb;
      decrn_back(meas, nb_before);
    }
    vec.popn_back(xs, (int)nb);
    if (! algebra_type::is_group)
      reset_cache(meas);
  }
  
  void swap(typename fftree_config_type::inner_chunk_type& other) {
    _swap(other);
  }
  
  void swap(typename fftree_config_type::outer_chunk_type& other) {
    _swap(other);
  }
  
  void transfer_from_back_to_front(const measure_type& meas, chunk& target, size_type nb) {
    measured_type delta;
    assert(size() >= nb);
    sum_range(meas, size() - nb, size(), delta);
    if (algebra_type::is_group)
      algebra::decr_back<algebra_type>(&cached, &delta);
    vec.transfer_from_back_to_front(target.vec, (int)nb);
    if (! algebra_type::is_group)
      reset_cache(meas);
    algebra::incr_front<algebra_type>(&(target.cached), &delta);
  }
  
  template <typename Pred>
  void transfer_from_back_to_front(const measure_type& meas, chunk& target, const Pred& p, measured_type& prefix) {
    measured_type cached = prefix;
    size_type k = chunk_search_type::search_by(p, meas, *this, prefix, cached);
    transfer_from_back_to_front(meas, target, size() - k);
  }
  
  void transfer_from_front_to_back(const measure_type& meas, chunk& target, size_type nb) {
    measured_type delta;
    sum_range(meas, size_type(0), nb, delta);
    if (algebra_type::is_group)
      algebra::decr_front<algebra_type>(&cached, &delta);
    vec.transfer_from_front_to_back(target.vec, (int)nb);
    if (! algebra_type::is_group)
      reset_cache(meas);
    algebra::incr_back<algebra_type>(&(target.cached), &delta);
  }
  
  vector_type& get_vec() {
    return vec;
  }
  
  void clear() {
    vec.popn_back((int)size());
    algebra_type::identity(&cached);
  }
  
  value_type& operator[](size_type ix) const {
    return vec[ix];
  }
  
  segment_type segment_by_index(size_type ix) const {
    return vec.segment_by_index((int)ix);
  }
  
  size_type index_of_pointer(const value_type* p) const {
    return (size_type)vec.index_of_pointer(p);
  }
  
  measured_type* get_cached() {
    return &cached;
  }
  
  const measured_type* cget_cached() const {
    return &cached;
  }
  
  static void swap_measured(measured_type& m1, measured_type& m2) {
    fftree_config_type::swap_measured(m1, m2);
  }
  
  template <class Body>
  void for_each(const Body& body) {
    for_each(size_type(0), body);
  }
  
  template <class Body>
  void for_each(size_type offset, const Body& body) {
    vec.for_each(offset, body);
  }
  
  template <class Body>
  void for_each_segment(size_type offset, const Body& body) {
    for_each_segment(offset, size_type(0), size(), body);
  }
  
  template <class Body>
  void for_each_segment(size_type offset, size_type lo, size_type hi, const Body& body) {
    vec.for_each_segment(offset, int(lo), int(hi), body);
  }
  
};
//! [chunk_example]
  
/***********************************************************************/

} // end namespace
} // end namespace
} // end namespace

#endif /*! _PASL_DATA_CHUNK_H_ */
