/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Fast finger tree iterators
 * \file iterator.hpp
 *
 */

#include <iterator>

#ifndef _PASL_ITERATOR_H_
#define _PASL_ITERATOR_H_

namespace pasl {
namespace data {

/***********************************************************************/
  
typedef enum { BEGIN, END } iterator_side_type;

/*---------------------------------------------------------------------*/

template <class FFTree_config>
class chunk_cursor {
private:
  
  typedef FFTree_config fftree_config_type;
  typedef typename fftree_config_type::leaf_node_type leaf_node_type;
  typedef typename fftree_config_type::outer_chunk_type outer_chunk_type;
  
  union {
    const leaf_node_type* inner;
    const outer_chunk_type* outer;
    size_t bits;
  } cur;
  
public:
  
  chunk_cursor() {
    cur.outer = NULL;
  }
  
  chunk_cursor(const leaf_node_type* inner) {
    cur.inner = inner;
    cur.bits |= 1l;
  }
  
  chunk_cursor(const outer_chunk_type* outer) {
    cur.outer = outer;
  }
  
  bool is_inner() const {
    return (cur.bits & 1l) == 1l;
  }
  
  const leaf_node_type* get_inner() const {
    assert(is_inner());
    chunk_cursor c(*this);
    c.cur.bits &= ~1l;
    return c.cur.inner;
  }
  
  const outer_chunk_type* get_outer() const {
    assert(! is_inner());
    return cur.outer;
  }
  
};
  
/*---------------------------------------------------------------------*/
//! [bidirectional_iterator]
/*!
 *  \class bidirectional_iterator
 *  \ingroup fftree
 *  \brief Iterator
 *
 * Implements a RandomAccessIterator.
 *
 * In addition, this iterator provides fftree-specific function,
 * such as logarithmic-time binary search.
 *
 */
template <class FFTree_config>
class bidirectional_iterator {
public:
  
  typedef FFTree_config fftree_config_type;
  typedef typename fftree_config_type::leaf_node_type leaf_node_type;
  typedef typename fftree_config_type::outer_chunk_type outer_chunk_type;
  typedef typename fftree_config_type::ftree_type ftree_type;
  typedef typename fftree_config_type::size_type size_type;
  typedef typename fftree_config_type::internal_measure_type internal_measure_type;
  typedef typename fftree_config_type::internal_measured_type internal_measured_type;
  typedef typename fftree_config_type::inner_cache_type::algebra_type internal_algebra_type;
  typedef typename fftree_config_type::value_type value_type;
  typedef typename fftree_config_type::difference_type difference_type;
  typedef typename fftree_config_type::pointer pointer;
  typedef typename fftree_config_type::reference reference;
  typedef typename fftree_config_type::inner_chunk_type::segment_type segment_type;
  typedef bidirectional_iterator<fftree_config_type> self_type;
  typedef std::bidirectional_iterator_tag iterator_category;
  
private:
  
  typedef chunk_cursor<fftree_config_type> chunk_cursor_type;
  
  struct {
    const outer_chunk_type* fr_outer;
    const outer_chunk_type* fr_inner;
    ftree_type* ft;
    const outer_chunk_type* bk_inner;
    const outer_chunk_type* bk_outer;
  } fft;
  chunk_cursor_type cur;
  segment_type seg;
  
  size_type cur_size() {
    return (cur.is_inner())
    ? cur.get_inner()->item.size()
    : cur.get_outer()->size();
  }
  
  void initialize_segment(size_type i) {
    if (i == cur_size()) {
      // position is one past the end of the sequence
      seg.begin = NULL;
      seg.middle = NULL;
      seg.end = NULL;
    } else {
      seg = (cur.is_inner())
      ? cur.get_inner()->item.segment_by_index(i)
      : cur.get_outer()->segment_by_index(i);
    }
  }
  
  self_type& increment() {
    seg.middle++;
    if (seg.middle == seg.end) {
      // reached end of current chunk
      do {
        if (cur.is_inner()) {
          // current chunk is in the underlying finger tree
          const leaf_node_type* leaf = cur.get_inner();
          const leaf_node_type* next = leaf->chain.template get_next<const leaf_node_type*>();
          if (next != NULL) {
            // next chunk is in the underlying finger tree
            cur = chunk_cursor_type(next);
            break;
          }
          // next chunk is one of the two outer chunks on the back of the fftree
          cur = chunk_cursor_type(fft.bk_inner);
          if (! fft.bk_inner->empty())
            break;
          // continue searching from back inner chunk
        }
        const outer_chunk_type* chunk = cur.get_outer();
        if (chunk == fft.fr_outer) {
          if (! fft.fr_inner->empty()) {
            // next chunk is front inner chunk
            cur = chunk_cursor_type(fft.fr_inner);
            break;
          } else {
            // continue searching from front inner chunk
            chunk = fft.fr_inner;
          }
        }
        if (chunk == fft.fr_inner) {
          if (! fft.ft->empty()) {
            // next chunk is front chunk of underlying finger tree
            cur = chunk_cursor_type(fft.ft->front());
            break;
          } else {
            cur = chunk_cursor_type(fft.bk_inner);
            if (! fft.bk_inner->empty())
              // next chunk is back inner chunk
              break;
            // continue searching from back inner chunk
            chunk = fft.bk_inner;
          }
        }
        if (chunk == fft.bk_inner) {
          if (! fft.bk_outer->empty()) {
            // next chunk is back inner chunk
            cur = chunk_cursor_type(fft.bk_outer);
            break;
          }
        }
        // current chunk is back outer chunk
        cur = chunk_cursor_type(fft.bk_outer);
        initialize_segment(cur_size());
        return *this;
      } while (false);
      initialize_segment(0);
    }
    return *this;
  }
  
  self_type& decrement() {
    if (seg.middle == seg.begin) {
      // reached beginning of current chunk
      do {
        if (cur.is_inner()) {
          // current chunk is in the underlying finger tree
          const leaf_node_type* leaf = cur.get_inner();
          const leaf_node_type* prev = leaf->chain.template get_prev<const leaf_node_type*>();
          if (prev != NULL) {
            // previous chunk is in the underlying finger tree
            cur = chunk_cursor_type(prev);
            break;
          }
          // previous chunk is one of the two outer chunks on the front of the fftree
          cur = chunk_cursor_type(fft.fr_inner);
          if (! fft.fr_inner->empty())
            // current chunk is front inner chunk
            break;
        }
        const outer_chunk_type* chunk = cur.get_outer();
        if (seg.middle == NULL) {
          if (! fft.bk_outer->empty()) {
            // current chunk is back outer chunk
            cur = chunk_cursor_type(fft.bk_outer);
            break;
          } else {
            // continue searching from back outer chunk
            chunk = fft.bk_outer;
          }
        }
        if (chunk == fft.bk_outer) {
          if (! fft.bk_inner->empty()) {
            // previous chunk is back inner chunk
            cur = chunk_cursor_type(fft.bk_inner);
            break;
          } else {
            // continue searching from back inner chunk
            chunk = fft.bk_inner;
          }
        }
        if (chunk == fft.bk_inner) {
          if (! fft.ft->empty()) {
            // previous chunk is back chunk of underlying finger tree
            cur = chunk_cursor_type(fft.ft->back());
            break;
          } else {
            if (! fft.fr_inner->empty()) {
              // previous chunk is front inner chunk
              cur = chunk_cursor_type(fft.fr_inner);
              break;
            }
            // continue searching from front inner chunk
            chunk = fft.fr_inner;
          }
        }
        if (chunk == fft.fr_inner) {
          if (! fft.fr_outer->empty()) {
            // previous chunk is front outer chunk
            cur = chunk_cursor_type(fft.fr_outer);
            break;
          } else {
            // continue searching from front outer chunk
            chunk = fft.fr_outer;
          }
        }
        assert(! fft.fr_outer->empty());
        // previous chunk is front outer chunk
        cur = chunk_cursor_type(fft.fr_outer);
      } while (false);
      size_type last = cur_size() - 1;
      initialize_segment(last);
      return *this;
    }
    seg.middle--;
    return *this;
  }
  
public:
  
  bidirectional_iterator(size_type fft_sz,
                         const outer_chunk_type* fr_outer,
                         const outer_chunk_type* fr_inner,
                         ftree_type* ft,
                         const outer_chunk_type* bk_inner,
                         const outer_chunk_type* bk_outer,
                         const internal_measure_type& meas,
                         iterator_side_type side) {
    fft.fr_outer = fr_outer;
    fft.fr_inner = fr_inner;
    fft.ft = ft;
    fft.bk_inner = bk_inner;
    fft.bk_outer = bk_outer;
    if (side == BEGIN) {
      if (! fft.fr_outer->empty())
        cur = chunk_cursor_type(fft.fr_outer);
      else if (! fft.fr_inner->empty())
        cur = chunk_cursor_type(fft.fr_inner);
      else if (! fft.ft->empty())
        cur = chunk_cursor_type(fft.ft->front());
      else if (! fft.bk_inner->empty())
        cur = chunk_cursor_type(fft.bk_inner);
      else
        cur = chunk_cursor_type(fft.bk_outer);
      initialize_segment(0);
    } else {
      assert(side == END);
      cur = chunk_cursor_type(fft.bk_outer);
      initialize_segment(cur_size());
    }
  }
  
  bidirectional_iterator() {
    fft.ft = NULL;
  }
  
  /*---------------------------------------------------------------------*/
  /** @name ForwardIterator
   */
  ///@{
  
  bool operator==(const self_type& other) const {
    return   seg.middle == other.seg.middle
    && seg.end == other.seg.end;
  }
  
  bool operator!=(const self_type& other) const {
    return ! (*this == other);
  }
  
  reference operator*() const {
    return *seg.middle;
  }
  
  self_type& operator++() {
    return increment();
  }
  
  self_type operator++(int) {
    return increment();
    
  }
  
  self_type& operator--() {
    return decrement();
  }
  
  self_type operator--(int) {
    return decrement();
  }
  
  ///@}
  
  /*!
   * \brief Returns current segment
   *
   * Returns a segment descriptor, which is a triple of
   * pointers (begin, middle, end) that describe a
   * range of contiguous memory in a chunk. The beginning
   * points to the first address in the range, middle
   * points to the address that is pointed to by the
   * iterator. The end points to one cell past the
   * last cell in the range.
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  segment_type get_segment() const {
    return seg;
  }
  
  self_type operator>>(const self_type& other) const {
    assert(false);
    return *this;
  }
  
  self_type operator>>(const size_type other) const {
    assert(false);
    return *this;
  }
  
  ///@}
  
};
//! [bidirectional_iterator]
  
/*---------------------------------------------------------------------*/
//! [random_access_iterator]
/*!
 *  \class random_access_iterator
 *  \ingroup fftree
 *  \brief Iterator
 *
 * Implements a RandomAccessIterator.
 *
 * In addition, this iterator provides fftree-specific function,
 * such as logarithmic-time binary search.
 *
 */
template <class FFTree_config>
class random_access_iterator {
public:
  
  typedef FFTree_config fftree_config_type;
  typedef typename fftree_config_type::leaf_node_type leaf_node_type;
  typedef typename fftree_config_type::outer_chunk_type outer_chunk_type;
  typedef typename fftree_config_type::ftree_type ftree_type;
  typedef typename fftree_config_type::size_type size_type;
  typedef typename fftree_config_type::client_measured_type client_measured_type;
  typedef typename fftree_config_type::internal_measure_type internal_measure_type;
  typedef typename fftree_config_type::internal_measured_type internal_measured_type;
  typedef typename fftree_config_type::inner_chunk_type inner_chunk_type;
  typedef typename fftree_config_type::inner_cache_type inner_cache_type;
  typedef typename fftree_config_type::outer_cache_type outer_cache_type;
  typedef typename inner_cache_type::algebra_type internal_algebra_type;
  typedef typename outer_cache_type::algebra_type client_algebra_type;
  typedef typename fftree_config_type::value_type value_type;
  typedef typename fftree_config_type::difference_type difference_type;
  typedef typename fftree_config_type::pointer pointer;
  typedef typename fftree_config_type::reference reference;
  typedef typename fftree_config_type::inner_chunk_type::segment_type segment_type;
  typedef random_access_iterator<FFTree_config> self_type;
  typedef std::random_access_iterator_tag iterator_category;
  typedef typename fftree_config_type::middle_search_type middle_search_type;
  
private:
  
  typedef fftree_base::chunk_search<inner_chunk_type, inner_cache_type, fftree_config_type> inner_search_type;
  typedef fftree_base::chunk_search<outer_chunk_type, inner_cache_type, fftree_config_type> outer_search_type;
  typedef chunk_cursor<fftree_config_type> chunk_cursor_type;
  
  struct {
    const outer_chunk_type* fr_outer;
    const outer_chunk_type* fr_inner;
    middle_search_type mid;
    const outer_chunk_type* bk_inner;
    const outer_chunk_type* bk_outer;
  } fft;
  chunk_cursor_type cur;
  segment_type seg;
  internal_measure_type meas;
  
  bool is_cur_chunk_empty() const {
    return (cur.is_inner())
    ? cur.get_inner()->item.empty()
    : cur.get_outer()->empty();
  }
  
  void get_internal_measured_of_chunk(const outer_chunk_type* chunk, internal_measured_type& dst) const {
    fftree_config_type::convert_measure(chunk->size(), *chunk->cget_cached(), dst);
  }
  
  /* computes the prefix (w.r.t the whole chunked sequence) of the measured value of the 
   * first item of the given chunk
   */
  void get_prefix_of_chunk(const outer_chunk_type* chunk, internal_measured_type& prefix) const {
    internal_measured_type tmp;
    do {
      if (chunk == fft.fr_outer)
        break;
      get_internal_measured_of_chunk(fft.fr_outer, tmp);
      internal_algebra_type::reduce(&prefix, &tmp);
      if (chunk == fft.fr_inner)
        break;
      get_internal_measured_of_chunk(fft.fr_inner, tmp);
      internal_algebra_type::reduce(&prefix, &tmp);
      internal_algebra_type::reduce(&prefix, fft.mid.cget_cached());
      if (chunk == fft.bk_inner)
        break;
      get_internal_measured_of_chunk(fft.bk_inner, tmp);
      internal_algebra_type::reduce(&prefix, &tmp);
      if (chunk == fft.bk_outer)
        break;
      assert(false);
    } while (false);
  }
  
  /* returns the number of items in the chunk pointed to by chunk
   * that occur in positions preceding the position of the cell
   * pointed to by middle of seg
   */
  template <class Chunk>
  size_type nb_items_before_item(segment_type seg, Chunk* chunk) const {
    return (seg.middle == seg.end)
    ? chunk->size()
    : chunk->index_of_pointer(seg.middle);
  }
  
  /* returns the number of items in the fftree that occur in
   * chunks preceding the side chunk pointed to by chunk
   */
  size_type nb_items_before_chunk(const outer_chunk_type* chunk) const {
    internal_measured_type prefix;
    internal_algebra_type::identity(&prefix);
    get_prefix_of_chunk(chunk, prefix);
    return fftree_config_type::csize(prefix);
  }
  
  /* returns the number of items in the fftree that occur in
   * chunks preceding the side chunk pointed to by leaf
   */
  size_type nb_items_before_leaf(const leaf_node_type* leaf) const {
    internal_measured_type tmp;
    internal_algebra_type::identity(&tmp);
    fft.mid.cget_prefix_of_leaf(leaf, tmp);
    return fftree_config_type::csize(tmp);
  }
  
  /* computes the prefix of the measured value of the item pointed to 
   * by pos.middle and stores the result to the cell pointed to by prefix
   */
  template <class Chunk>
  void get_prefix_of_position(segment_type pos, const Chunk* chunk, internal_measured_type& prefix) const {
    for (size_type i = 0; i < nb_items_before_item(pos, chunk); i++) {
      internal_measured_type tmp;
      meas((*chunk)[i], tmp);
      internal_algebra_type::reduce(&prefix, &tmp);
    }
  }
  
  /* computes the prefix of the measured value of the item pointed to
   * by this iterator and stores the result to the cell pointed to by prefix
   */
  void get_prefix(internal_measured_type& prefix) const {
    if (cur.is_inner()) {
      const leaf_node_type* inner = cur.get_inner();
      internal_algebra_type::reduce(&prefix, inner->cget_prefix());
      get_prefix_of_position(seg, &(inner->item), prefix);
    } else {
      const outer_chunk_type* outer = cur.get_outer();
      get_prefix_of_chunk(outer, prefix);
      get_prefix_of_position(seg, outer, prefix);
    }
  }
  
  /* adds to the contents of the cell pointed to by target the cached-measured
   * value of the chunk pointed to by the given chunk pointer
   */
  void incr_by_chunk_measured(const outer_chunk_type* chunk, internal_measured_type& target) {
    internal_measured_type tmp;
    const client_measured_type* chunk_cached = chunk->cget_cached();
    fftree_config_type::convert_measure(chunk->size(), *chunk_cached, tmp);
    internal_algebra_type::reduce(&target, &tmp);
  }
  
  /* performs a search for an item contained in the current chunk and
   * stores the prefix of the measured value of this item in the cell
   * pointed to by the reference named prefix
   */
  template <class Pred>
  void current_chunk_search_by(const Pred& p, internal_measured_type& prefix) {
    assert(! is_cur_chunk_empty());
    internal_measured_type prefix_of_current_pos = prefix;
    internal_measured_type cached_of_curent_pos = prefix;
    if (cur.is_inner())
      inner_search_type::search_by(p, meas, cur.get_inner()->item, prefix_of_current_pos, cached_of_curent_pos);
    else
      outer_search_type::search_by(p, meas, *cur.get_outer(), prefix_of_current_pos, cached_of_curent_pos);
    size_type d = fftree_config_type::size(cached_of_curent_pos) - fftree_config_type::size(prefix);
    size_type i = (d > 0) ? d - 1 : d;
    seg = (cur.is_inner())
      ? cur.get_inner()->item.segment_by_index(i)
      : cur.get_outer()->segment_by_index(i);
    if (fftree_config_type::size(cached_of_curent_pos) == fftree_config_type::size(prefix_of_current_pos)) {
      // not found; i.e., target position is one past end
      assert(cur.get_outer() == fft.bk_outer);
      seg.middle = seg.end;
    } else {
      assert(d > 0);
    }
    prefix = prefix_of_current_pos;
  }
  
  /* performs a search for an item contained in the sequence associated with
   * this iterator and stores the prefix of the measured value of this item 
   * in the cell pointed to by the reference named prefix
   */
  template <class Pred>
  void search_by(const Pred& p, internal_measured_type& prefix) {
    do {
      internal_measured_type m = prefix;
      incr_by_chunk_measured(fft.fr_outer, m);
      if (fft.fr_outer->size() > 0 && p(m)) {
        // found it in the outer chunk of front
        cur = chunk_cursor_type(fft.fr_outer);
        break;
      }
      prefix = m;
      incr_by_chunk_measured(fft.fr_inner, m);
      if (fft.fr_inner->size() > 0 && p(m)) {
        // found it in the inner chunk of front
        cur = chunk_cursor_type(fft.fr_inner);
        break;
      }
      prefix = m;
      const internal_measured_type* fft_cached = fft.mid.cget_cached();
      internal_algebra_type::reduce(&m, fft_cached);
      if (fftree_config_type::csize(*fft_cached) > 0 && p(m)) {
        // found it in the finger tree
        const leaf_node_type* leaf_or_null = (cur.is_inner()) ? cur.get_inner() : NULL;
        const leaf_node_type* leaf = fft.mid.search_by(p, leaf_or_null, prefix);
        cur = chunk_cursor_type(leaf);
        break;
      }
      prefix = m;
      incr_by_chunk_measured(fft.bk_inner, m);
      if (fft.bk_inner->size() > 0 && p(m)) {
        // found it in the inner chunk of back
        cur = chunk_cursor_type(fft.bk_inner);
        break;
      }
      prefix = m;
      incr_by_chunk_measured(fft.bk_outer, m);
      if (fft.bk_outer->size() > 0 && p(m)) {
        // found it in the outer chunk of back
        cur = chunk_cursor_type(fft.bk_outer);
        break;
      }
      // not found
      cur = chunk_cursor_type(fft.bk_outer);
      if (is_cur_chunk_empty()) {
        seg.begin = NULL;
        seg.middle = NULL;
        seg.end = NULL;
        return;
      }
    } while (false);
    current_chunk_search_by(p, prefix);
  }
  
  void search_by_one_based_index(size_type n) {
    assert(n >= 1);
    internal_measured_type prefix;
    internal_algebra_type::identity(&prefix);
    search_by(predicate::less_or_eq_by_size<fftree_config_type>(n), prefix);
    assert(fftree_config_type::csize(prefix) + 1 == n);
    if (size() != n)
      std::cout << size() << std::endl;
    assert(size() == n);
  }
  
  self_type& increment_by(size_type n) {
    size_type orig_sz = size();
    pointer m = seg.middle + n;
    if (m >= seg.end)
      search_by_one_based_index(size() + n);
    else
      seg.middle = m;
    assert(size() == orig_sz + n);
    return *this;
  }
  
  self_type& decrement_by(size_type n) {
    size_type orig_sz = size();
    pointer m = seg.middle - n;
    if (m < seg.begin)
      search_by_one_based_index(size() - n);
    else
      seg.middle = m;
    assert(size() == orig_sz - n);
    return *this;
  }
  
  self_type new_iterator_at(size_type sz) const {
    self_type tmp(*this);
    tmp.search_by_one_based_index(sz);
    assert(sz == tmp.size());
    return tmp;
  }
  
public:
  
  random_access_iterator(size_type fft_sz,
                         const outer_chunk_type* fr_outer,
                         const outer_chunk_type* fr_inner,
                         ftree_type* ft,
                         const outer_chunk_type* bk_inner,
                         const outer_chunk_type* bk_outer,
                         const internal_measure_type& meas,
                         iterator_side_type side)
  : meas(meas) {
    fft.fr_outer = fr_outer;
    fft.fr_inner = fr_inner;
    fft.mid.set_middle(ft);
    fft.bk_inner = bk_inner;
    fft.bk_outer = bk_outer;
    cur = chunk_cursor_type(fft.bk_outer);
    size_type nb = (side == BEGIN) ? 1 : fft_sz + 1;
    search_by_one_based_index(nb);
  }
  
  random_access_iterator() {
    fft.mid.set_middle(NULL);
  }
  
  /*---------------------------------------------------------------------*/
  /** @name ForwardIterator
   */
  ///@{
  
  bool operator==(const self_type& other) const {
    return   seg.middle == other.seg.middle
    && seg.end == other.seg.end;
  }
  
  bool operator!=(const self_type& other) const {
    return ! (*this == other);
  }
  
  reference operator*() const {
    return *seg.middle;
  }
  
  self_type& operator++() {
    return increment_by(1);
  }
  
  self_type operator++(int) {
    return increment_by(1);
  }
  
  self_type& operator--() {
    return decrement_by(1);
  }
  
  self_type operator--(int) {
    return decrement_by(1);
  }
  
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name RandomAccessIterator
   */
  ///@{
  
  self_type& operator+=(const size_type n) {
    return increment_by(n);
  }
  
  self_type operator+(const self_type& other) const {
    return new_iterator_at(size() + other.size());
  }
  
  self_type operator+(const size_type n) const {
    return new_iterator_at(size() + n);
  }
  
  self_type& operator-=(const size_type n) {
    return decrement_by(n);
  }
  
  difference_type operator-(const self_type& other) const {
    return size() - other.size();
  }
  
  self_type operator-(const size_type n) const {
    size_type sz = size();
    assert(sz > n);
    return new_iterator_at(sz - n);
  }
  
  reference operator[](const size_type n) const {
    return *(*this + n);
  }
  
  bool operator<(const self_type& other) const {
    return size() < other.size();
  }
  
  bool operator>(const self_type& other) const {
    return size() > other.size();
  }
  
  bool operator<=(const self_type& other) const {
    return size() <= other.size();
  }
  
  bool operator>=(const self_type& other) const {
    return size() >= other.size();
  }
  
  ///@}
  
  /*---------------------------------------------------------------------*/
  /** @name Tree search
   */
  ///@{
  
  /*!
   * \brief Returns the number of items preceding and including the item
   * pointed to by the iterator
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  size_type size() const {
    size_type nb_items_before_current_chunk;
    size_type nb_items_before_current_item;
    if (cur.is_inner()) {
      const leaf_node_type* leaf = cur.get_inner();
      const inner_chunk_type* chunk = &(leaf->item);
      nb_items_before_current_chunk = nb_items_before_leaf(leaf);
      nb_items_before_current_item = nb_items_before_item(seg, chunk) + 1;
    } else {
      const outer_chunk_type* chunk = cur.get_outer();
      nb_items_before_current_chunk = nb_items_before_chunk(chunk);
      nb_items_before_current_item = nb_items_before_item(seg, chunk) + 1;
    }
    return nb_items_before_current_chunk + nb_items_before_current_item;
  }
  
  void get_prefix(client_measured_type& prefix) const {
    internal_measured_type tmp;
    internal_algebra_type::identity(&tmp);
    fftree_config_type::client_measured(tmp) = prefix;
    get_prefix(tmp);
    prefix = fftree_config_type::cclient_measured(tmp);
  }
  
  template <class Pred>
  void search_by(const Pred& p) {
    client_measured_type prefix;
    client_algebra_type::identity(&prefix);
    search_by(p, prefix);
  }
  
  template <class Pred>
  void search_by(const Pred& p, client_measured_type& prefix) {
    auto q = [&] (const internal_measured_type& m) {
      return p(fftree_config_type::cclient_measured(m));
    };
    internal_measured_type internal_prefix;
    internal_algebra_type::identity(&internal_prefix);
    fftree_config_type::client_measured(internal_prefix) = prefix;
    search_by(q, internal_prefix);
    prefix = fftree_config_type::cclient_measured(internal_prefix);
  }
  
  /*!
   * \brief Moves cursor to given index
   *
   * Moves the cursor to position `i` in the container.
   *
   * #### Complexity ####
   * Logarithmic time.
   *
   */
  void search_by_index(size_type i) {
    search_by_one_based_index(i + 1);
  }
  
  /*!
   * \brief Returns current segment
   *
   * Returns a segment descriptor, which is a triple of
   * pointers (begin, middle, end) that describe a
   * range of contiguous memory in a chunk. The beginning
   * points to the first address in the range, middle
   * points to the address that is pointed to by the
   * iterator. The end points to one cell past the
   * last cell in the range.
   *
   * #### Complexity ####
   * Constant time.
   *
   */
  segment_type get_segment() const {
    return seg;
  }
  
  ///@}
  
};
//! [random_access_iterator]
  
/***********************************************************************/
  
}
}

#endif /*! _PASL_ITERATOR_H_ */
