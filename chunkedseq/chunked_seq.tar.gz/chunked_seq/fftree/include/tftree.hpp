/*!
 * \author Umut A. Acar
 * \author Arthur Chargueraud
 * \author Mike Rainey
 * \date 2013-2018
 * \copyright 2013 Umut A. Acar, Arthur Chargueraud, Mike Rainey
 *
 * \brief Trivial ftree
 * \file tftree.hpp
 * \example tftree.hpp
 * \ingroup ftree
 *
 */

#include "chain.hpp"
#include "ftree.hpp"

#ifndef _PASL_DATA_TFTREE_H_
#define _PASL_DATA_TFTREE_H_

namespace pasl {
namespace data {

/***********************************************************************/
  
/*---------------------------------------------------------------------*/
/* Singleton finger-tree leaf */
  
//! [tleaf]
template <typename Item>
class tleaf {
public:
  
  typedef size_t measured_type;
  typedef algebra::sum_int<measured_type> algebra_type;
  typedef with_chain chain_type;
  
  measured_type cached;
  Item value;
  
  tleaf()
  : cached(1) { }
  
  tleaf(const Item& value)
  : cached(1), value(value) { }
  
  measured_type* get_cached() {
    return &cached;
  }
  
  const measured_type* cget_cached() const {
    return &cached;
  }
  
  static void swap_measured(measured_type& m1, measured_type& m2) {
    std::swap(m1, m2);
  }
  
  void clear() { }
  
};
//! [tleaf]
  
/*---------------------------------------------------------------------*/
/* Finger tree with STL-style interface */

//! [tftree]
template <typename Item>
class tftree {
private:
  
  typedef tleaf<Item> leaf_type;
  typedef typename leaf_type::algebra_type algebra_type;
  typedef ftree<leaf_type> ftree_type;
  typedef typename ftree_type::leaf_node leaf_node_type;
  
  ftree_type* ft;
  
public:
  
  typedef tftree<Item> self_type;
  typedef size_t size_type;
  typedef Item value_type;
  typedef value_type& reference;
  typedef typename leaf_type::algebra_type::value_type measured_type;
  
  tftree() {
    ft = new ftree_type();
  }
  
  tftree(const tftree& other) {
    ft = new ftree_type(*other.ft);
  }
  
  tftree(size_type n, const value_type& val) {
    ft = new ftree_type();
    pushn_back(val, n);
  }
  
  ~tftree() {
    clear();
    delete ft;
  }
  
  value_type& back() {
    return ft->back()->item.value;
  }
  
  value_type& front() {
    return ft->front()->item.value;
  }
  
  value_type pop_back() {
    value_type v = back();
    leaf_node_type* nd = ft->back();
    ft->pop_back();
    delete nd;
    return v;
  }
  
  value_type pop_front() {
    value_type v = front();
    leaf_node_type* nd = ft->front();
    ft->pop_front();
    delete nd;
    return v;
  }
  
  void push_back(const value_type& v) {
    leaf_type leaf(v);
    leaf_node_type* node = new leaf_node_type(leaf);
    ft->push_back(node);
  }
  
  void push_front(const value_type& v) {
    leaf_type leaf(v);
    leaf_node_type* node = new leaf_node_type(leaf);
    ft->push_front(node);
  }
  
  void pushn_back(const value_type& v, size_type nb) {
    for (size_type i = 0; i < nb; i++)
      push_back(v);
  }
  
  void pushn_front(const value_type& v, size_type nb) {
    for (size_type i = 0; i < nb; i++)
      push_front(v);
  }

  void clear() {
    while (! empty())
      pop_back();
  }
  
  size_type size() const {
    return *(ft->cget_cached());
  }

  bool empty() const {
    return size() == 0;
  }
    
  class iterator {
  private:
    
    typedef const typename ftree_type::leaf_node* cursor_type;
    
    cursor_type cur;
    size_type sz;
    
  public:
    
    iterator(const tftree* tft, size_type sz)
    : sz(sz) {
      if (! tft->ft->empty()) {
        measured_type prefix;
        algebra_type::identity(&prefix);
        cur = tft->ft->cursor_front(prefix);
      }
    }
    
    iterator(const iterator& other)
    : cur(other.cur), sz(other.sz) { }
    
    value_type& operator*() {
      size_type _sz = sz;
      auto p = [_sz] (const measured_type& v) {
        return v >= _sz;
      };
      measured_type tmp;
      algebra_type::identity(&tmp);
      cur = ftree_type::search_by(p, cur);
      assert(*(cur->cget_prefix()) + 1 == sz);
      return cur->item.value;
    }
    
    iterator operator+(const size_type v) const {
      iterator other(*this);
      other.sz += v;
      return other;
    }
    
    iterator operator-(const size_type v) const {
      iterator other(*this);
      other.sz -= v;
      return other;
    }
    
    iterator operator++(int) {
      sz++;
      return *this;
    }
    
    iterator operator+=(size_type x) {
      sz += x;
      return *this;
    }
    
    bool operator==(const iterator& other) const {
      return sz == other.sz;
    }
    
    bool operator!=(const iterator& other) const {
      return ! (*this == other);
    }
    
    size_type size() const {
      return sz;
    }
    
  };
  
  iterator begin() const {
    return iterator(this, 1);
  }
  
  iterator end() const {
    return iterator(this, size() + 1);
  }
  
  reference operator[](size_type n) const {
    iterator it = begin();
    it += n;
    return *it;
  }
  
  iterator insert(iterator position, const value_type& val) {
    tftree dst;
    size_type ix = position.size() - 1;
    transfer_from_back_to_front_by_position(dst, position);
    dst.push_front(val);
    transfer_to_back(dst);
    return begin() + ix;
  }
 
  template <class Pred>
  void split(tftree& dst, const Pred& p) {
    if (size() == 0)
      return;
    measured_type id;
    algebra_type::identity(&id);
    auto s = ftree_type::split(p, id, ft);
    ft = s.fr;
    delete dst.ft;
    dst.ft = s.bk;
    dst.ft->push_front(s.middle);
  }
  
  void transfer_from_back_to_front_by_position(tftree& dst, iterator it) {
    size_type ix = it.size() - 1;
    assert(ix <= size() + 1);
    if (size() == 0)
      return;
    split(dst, [&] (const measured_type& v) { return ix < v; });
  }

  void split_approximate(tftree& dst) {
    size_type mid = size() / 2;
    transfer_from_back_to_front_by_position(dst, begin() + mid);
  }
  
  void transfer_to_back(tftree& other) {
    ft = ftree_type::concat(ft, other.ft);
    other.ft = new ftree_type();
  }
  
  void swap(tftree& other) {
    std::swap(ft, other.ft);
  }
  
  bool operator==(const tftree& rhs) {
    const tftree& lhs = *this;
    if (lhs.size() != rhs.size())
      return false;
    auto itl = lhs.begin();
    auto itr = rhs.begin();
    for (; itl != lhs.end(); itl++, itr++)
      if (*itl != *itr)
        return false;
    assert(itr == rhs.end());
    return true;
  }
  
  template <class Body>
  void for_each(const Body& b) {
    auto _b = [&] (size_type i, leaf_node_type* leaf) {
      b(i, leaf->item);
    };
    ft->for_each(_b);
  }
  
};
//! [tftree]

/***********************************************************************/

}
}

#endif /*! _PASL_DATA_TFTREE_H_ */
