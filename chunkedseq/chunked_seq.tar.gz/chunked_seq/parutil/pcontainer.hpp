/* COPYRIGHT (c) 2011 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file pcontainer.hpp
 * \brief Resizable container data structures for parallel execution
 *
 */

#ifndef _PASL_PCONTAINER_H_
#define _PASL_PCONTAINER_H_

#include <utility>

#include "native.hpp"
#include "fftree.hpp"

namespace pasl {
namespace data {
namespace pcontainer {

/***********************************************************************/
  
using namespace pasl::sched;

#ifdef PASL_PCONTAINER_CHUNK_CAPACITY
static const int chunk_capacity = PASL_PCONTAINER_CHUNK_CAPACITY;
#else  
static const int chunk_capacity = 4096;
#endif

template <class Item>
using stack_chunk_allocator = pasl::data::fixedcapacity::heap_allocator<Item, chunk_capacity>;

template <class Item>
using ringbuffer_chunk_allocator = pasl::data::fixedcapacity::heap_allocator<Item, chunk_capacity+1>;

template <class Item>
using fixedcapacity_stack = pasl::data::fixedcapacity::stack<stack_chunk_allocator<Item>>;

template <class Item>
using fixedcapacity_deque = pasl::data::fixedcapacity::ringbuffer_ptr<ringbuffer_chunk_allocator<Item>>;

template <class Vector>
using fftree_seq_config = pasl::data::fftree_base::deque_with_just_size<Vector, size_t>;

template <class Vector>
using fftree_seq = pasl::data::fftree_base::fftree<fftree_seq_config<Vector>>;

template <class Vector>
using fftree_bag_config = pasl::data::fftree_base::bag<Vector, size_t>;

template <class Vector>
using fftree_bag = pasl::data::fftree_base::fftree<fftree_bag_config<Vector>>;

template <class Item>
using deque = fftree_seq<fixedcapacity_deque<Item>>;

template <class Item>
using stack = fftree_seq<fixedcapacity_stack<Item>>;

template <class Item>
using bag = fftree_bag<fixedcapacity_stack<Item>>;
  
  
template <class Vector>
using bootstrap_fftree_seq_config = pasl::data::fftree_base::bootstrap_deque_with_just_size<Vector, size_t>;

template <class Vector>
using bootstrap_fftree_seq = pasl::data::fftree_base::fftree<bootstrap_fftree_seq_config<Vector>>;

template <class Vector>
using bootstrap_fftree_bag_config = pasl::data::fftree_base::bootstrap_bag<Vector, size_t>;

template <class Vector>
using bootstrap_fftree_bag = pasl::data::fftree_base::fftree<bootstrap_fftree_bag_config<Vector>>;

template <class Item>
using bootstrap_deque = bootstrap_fftree_seq<fixedcapacity_deque<Item>>;

template <class Item>
using bootstrap_stack = bootstrap_fftree_seq<fixedcapacity_stack<Item>>;

template <class Item>
using bootstrap_bag = bootstrap_fftree_bag<fixedcapacity_stack<Item>>;
  
  
template <class Vector>
using bootseq_fftree_seq_config = pasl::data::fftree_base::bootsequence<Vector, size_t>;

template <class Vector>
using bootseq_fftree_seq = pasl::data::fftree_base::fftree<bootseq_fftree_seq_config<Vector>>;

template <class Item>
using bootseq_deque = bootseq_fftree_seq<fixedcapacity_deque<Item>>;

template <class Item>
using bootseq_stack = bootseq_fftree_seq<fixedcapacity_stack<Item>>;
  

template <class Container, class Body>
void for_each_segment(const Container& cont, const Body& body) {
  using size_type = typename Container::size_type;
  using iterator_type = typename Container::iterator;
  using segment_type = typename Container::segment_type;
  using input_type = std::pair<iterator_type, iterator_type>;
  auto cutoff = [] (const input_type& in) {
    size_type sz_beg = in.first.size();
    size_type sz_end = in.second.size();
    return sz_end - sz_beg <= size_type(native::loop_cutoff);
  };
  auto split = [&] (input_type& src, input_type& dst) {
    size_type sz_beg = src.first.size();
    size_type sz_end = src.second.size();
    iterator_type mid = cont.begin() + ((sz_beg + sz_end) / 2);
    dst.first = mid;
    dst.second = src.second;
    src.second = mid;
  };
  struct { } dummy;
  using dummy_type = typeof(dummy);
  auto join = [] (dummy_type, dummy_type) { };
  auto _body = [&] (input_type& in, dummy_type& out) {
    iterator_type beg = in.first;
    iterator_type end = in.second;
    cont.for_each_segment(beg, end, body);
  };
  input_type in(cont.begin(), cont.end());
  native::reduce(in, dummy, cutoff, split, join, _body);
}

template <class Container, class Body>
void for_each(const Container& cont, const Body& body) {
  using size_type = typename Container::size_type;
  using value_type = typename Container::value_type;
  using segment_type = typename Container::segment_type;
  auto _body = [&] (size_type i, segment_type seg) {
    for (value_type* lo = seg.middle; lo < seg.end; lo++)
      body(i++, *lo);
  };
  for_each_segment(cont, _body);
}
  
template <class Item, class Body>
void for_each(const stl::deque_seq<Item>& cont, const Body& body) {
  assert(false);
}

template <class Number, class Container, class Body>
void tabulate(Number lo, Number hi, Container& dst, const Body& body) {
  auto join = [] (Container& c1, Container& c2) {
    c1.transfer_to_back(c2);
  };
  native::tabulate(lo, hi, dst, join, body);
}

template <class Container_src, class Pointer>
void transfer_contents_to_array(Container_src& src, Pointer dst) {
  using size_type = typename Container_src::size_type;
  using pointer_type = Pointer;
  class input_type {
  public:
    Container_src* first;
    Pointer second;
    input_type() {
      this->first = new Container_src();
      this->second = NULL;
    }
    input_type(Container_src* first, Pointer second)
    : first(first), second(second) { }
    ~input_type() {
      if (first != NULL)
        delete first;
    }
  };
  using value_type = typename Container_src::value_type;
  struct { } dummy;
  using dummy_type = typeof(dummy);
  auto cutoff = [] (input_type& f) {
    return f.first->size() <= size_type(native::loop_cutoff);
  };
  auto split = [] (input_type& src, input_type& dst) {
    size_type m = src.first->size() / 2;
    src.first->transfer_from_back_to_front_by_position(*dst.first, src.first->begin() + m);
    dst.second = src.second + m;
  };
  auto join = [] (dummy_type, dummy_type) { };
  auto body = [&] (input_type& in, dummy_type& out) {
    in.first->popn_back(in.second, in.first->size());
  };
  input_type in(&src, dst);
  native::reduce(in, dummy, cutoff, split, join, body);
  in.first = NULL;
}

template <class Container, class Array>
void transfer_contents_to_array_seq(Container& src, Array& dst) {
  dst.alloc(src.size());
  transfer_contents_to_array(src, dst.data());
}
  
/***********************************************************************/
  
} // end namespace
} // end namespace
} // end namespace

#endif //! _PASL_PCONTAINER_H_
