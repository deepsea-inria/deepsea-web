/* COPYRIGHT (c) 2014 Umut Acar, Arthur Chargueraud, and Michael
 * Rainey
 * All rights reserved.
 *
 * \file perworker.hpp
 * \brief Per-worker local storage
 *
 */

#ifndef _PASL_DATA_PERWORKER_H_
#define _PASL_DATA_PERWORKER_H_

#include <assert.h>

#include "worker.hpp"

/***********************************************************************/

namespace pasl {
namespace data {
namespace perworker {
  
/*---------------------------------------------------------------------*/

static constexpr int default_padding_szb = 64 * 2;
static constexpr int default_max_nb_workers = 128;
  
/*---------------------------------------------------------------------*/
/*! \class base
 *  \brief Array indexed by worker id
 *  \tparam Item type of the items to be stored in the container
 *  \tparam padding_szb number of bytes of empty space to add to the 
 *  end of each item in the container
 *  \tparam max_nb_workers one plus the highest worker id to be 
 *  addressed by the container
 *  \ingroup data
 *  \ingroup perworker
 *
 * This container is a polymorphic fixed-capacity container that
 * provides one storage cell for each of PASL worker thread. The
 * purpose is to provide a container that enables workers to make
 * many writes to their own private position of the array and for 
 * one worker to make a few reads from the cells of all the workers.
 * This kind of container is useful for statistics: for example, it
 * can be used to obtain a count of a type of event that occurs
 * frequently during the parallel run of a program.
 *
 * Assuming that the given padding is at least twice the size of
 * a cache line, each cell in the container is guaranteed not
 * to share a cache line with any other cell (or any other piece
 * of memory in the program for that matter). This property is
 * crucial to avoid false sharing on frequent writes to the
 * cells of the container.
 *
 * Access to this container is not synchronized. Thread safety must
 * be enforced by clients of the container.
 *
 */
template <class Item,
          int padding_szb = default_padding_szb,
          int max_nb_workers = default_max_nb_workers>
class base {
public:
  
  using value_type = Item;
  using index_type = worker_id_t;
  
private:
  
  typedef struct {
    value_type item;
    int padding[padding_szb/4];
  } contents_type;
  
  int padding[padding_szb/4];
  __attribute__ ((aligned (64))) contents_type contents[max_nb_workers];
  
  void check_index(index_type id) const {
    assert(id >= 0);
    assert(id <= max_nb_workers);
    util::worker::the_group.check_worker_id(worker_id_t(id));
  }
  
public:
  
  value_type& operator[](const index_type id) {
    check_index(id);
    return contents[id].item;
  }
  
  value_type& operator[](const int id) {
    return operator[](index_type(id));
  }
  
  value_type& mine() {
    return operator[](util::worker::get_my_id());
  }

  template <class Body>
  void for_each(const Body& body) {
    auto _body = [&] (index_type id) {
      body(id, (*this)[id]);
    };
    util::worker::the_group.for_each_worker(_body);
  }
  
  template <class Combiner>
  value_type combine(value_type identity, const Combiner& comb) {
    value_type res = identity;
    for_each([&] (index_type id, value_type v) {
      res = comb(res, v);
    });
    return res;
  }
  
  void init(const value_type& v) {
    for_each([&] (index_type id, value_type& dst) {
      dst = v;
    });
  }
  
};
  
/*---------------------------------------------------------------------*/
/*! \class with_undefined
 *  \brief Per-worker array that can index the undefined worker id
 *  \tparam Base type that must be an instantiation of 
 *  pasl::data:perworker::base.
 *  \ingroup data
 *  \ingroup perworker
 *
 * This container has the same behavior as the base perworker array,
 * with the one exception that the container can be indexed by the
 * undefined worker id, namely `worker::undef`.
 *
 */
template <class Base>
class with_undefined {
public:
  
  using value_type = typename Base::value_type;
  using index_type = worker_id_t;
  
private:
  
  value_type ext;
  Base base;
  
public:
  
  value_type& operator[](const worker_id_t id_or_undef) {
    return (id_or_undef == util::worker::undef) ? ext : base[id_or_undef];
  }
  
  value_type& operator[](const int id) {
    return operator[](index_type(id));
  }
  
  value_type& mine() {
    return operator[](int(util::worker::get_my_id()));
  }
  
  template <class Body>
  void for_each(const Body& body) {
    body(util::worker::undef, ext);
    base.for_each(body);
  }
  
  template <class Combiner>
  value_type combine(value_type identity, const Combiner& comb) {
    value_type res = comb(identity, ext);
    return base.combine(res, comb);
  }
  
  void init(const value_type& v) {
    ext = v;
    base.init(v);
  }
  
};
  
template <class Item,
          int padding_szb = default_padding_szb,
          int max_nb_workers = default_max_nb_workers>
using extra = with_undefined<base<Item, padding_szb, max_nb_workers>>;
    
} // end namespace
} // end namespace
} // end namespace

/***********************************************************************/

#endif /*! _PASL_DATA_PERWORKER_H_ */